import { Button } from '@/app/components/Button';
import { ArrowRight, Download, Heart, Star, User, Mail } from 'lucide-react';

export function DesignSystemPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-black text-white py-16 border-b border-white/10">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-5xl font-bold mb-4">Design System</h1>
          <p className="text-lg text-white/70 max-w-[700px]">
            A comprehensive showcase of design tokens, components, and patterns built with Atomic Design methodology.
          </p>
        </div>
      </header>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 md:px-8 py-16">
        
        {/* ========================================
            ATOMS - Foundation Elements
            ======================================== */}
        <section className="mb-20">
          <div className="mb-12">
            <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Level 01</span>
            <h2 className="text-4xl font-bold text-black mb-3">Atoms</h2>
            <p className="text-base text-black/60 max-w-[700px]">
              The foundational building blocks - smallest design elements that can't be broken down further.
            </p>
          </div>

          {/* Colors */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Colors</h3>
            
            {/* Primary Colors */}
            <div className="mb-8">
              <h4 className="text-lg font-bold text-black mb-4">Primary Palette (92% usage)</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] bg-black shadow-md"></div>
                  <p className="text-sm font-mono">#000000</p>
                  <p className="text-xs text-black/60">Pure Black</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] bg-white border border-black/10 shadow-md"></div>
                  <p className="text-sm font-mono">#ffffff</p>
                  <p className="text-xs text-black/60">Pure White</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] shadow-md" style={{ backgroundColor: '#f5f2f1' }}></div>
                  <p className="text-sm font-mono">#f5f2f1</p>
                  <p className="text-xs text-black/60">Warm Off-White</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] shadow-md" style={{ backgroundColor: '#eae5e3' }}></div>
                  <p className="text-sm font-mono">#eae5e3</p>
                  <p className="text-xs text-black/60">Warm Border</p>
                </div>
              </div>
            </div>

            {/* Brand Red */}
            <div className="mb-8">
              <h4 className="text-lg font-bold text-black mb-4">Brand Red (5% usage - CTAs only)</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] shadow-md" style={{ backgroundColor: '#c62d31' }}></div>
                  <p className="text-sm font-mono">#c62d31</p>
                  <p className="text-xs text-black/60">Red 500</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] shadow-md" style={{ backgroundColor: '#b01f24' }}></div>
                  <p className="text-sm font-mono">#b01f24</p>
                  <p className="text-xs text-black/60">Red 600 (Brand)</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 rounded-[5px] shadow-md" style={{ backgroundColor: '#8f181d' }}></div>
                  <p className="text-sm font-mono">#8f181d</p>
                  <p className="text-xs text-black/60">Red 700 (Hover)</p>
                </div>
              </div>
            </div>

            {/* Gradients */}
            <div className="mb-8">
              <h4 className="text-lg font-bold text-black mb-4">Gradients</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div 
                    className="h-24 rounded-[5px] shadow-lg relative overflow-hidden"
                    style={{
                      backgroundImage: 'linear-gradient(90deg, #0a0a0a, #6a6a6a)',
                    }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-white font-bold text-sm">Primary Dark-to-Grey</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div 
                    className="h-24 rounded-[5px] shadow-lg relative overflow-hidden"
                    style={{
                      backgroundImage: 'linear-gradient(90deg, #b01f24, #c62d31)',
                    }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-white font-bold text-sm">Brand Red Gradient</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Typography */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Typography</h3>
            <div className="space-y-6">
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-3xl (48.8px) - Hero H1</p>
                <h1 style={{ fontSize: 'var(--text-3xl)' }} className="font-bold">
                  Hero Heading - Reserved for Hero Moments
                </h1>
              </div>
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-2xl (39px) - Section H2</p>
                <h2 style={{ fontSize: 'var(--text-2xl)' }} className="font-bold">
                  Section Heading - Standard for Main Sections
                </h2>
              </div>
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-xl (31.25px) - Subsection H3</p>
                <h3 style={{ fontSize: 'var(--text-xl)' }} className="font-bold">
                  Subsection Heading - Objectives & Steps
                </h3>
              </div>
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-lg (25px) - Card Titles</p>
                <h4 style={{ fontSize: 'var(--text-lg)' }} className="font-bold">
                  Card Title (2-3 cards)
                </h4>
              </div>
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-base (20px) - Large Body</p>
                <p style={{ fontSize: 'var(--text-base)' }}>
                  Large body text, card titles when 4+ cards present
                </p>
              </div>
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs text-black/40 mb-2">--text-sm (16px) - Body Text</p>
                <p style={{ fontSize: 'var(--text-sm)' }}>
                  Standard body text, descriptions, paragraphs
                </p>
              </div>
            </div>
          </div>

          {/* Border Radius */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Border Radius System</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '2.5px' }}></div>
                <p className="text-sm font-mono">2.5px</p>
                <p className="text-xs text-black/60">Images, Photos</p>
              </div>
              <div className="space-y-3">
                <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '5px' }}></div>
                <p className="text-sm font-mono">5px</p>
                <p className="text-xs text-black/60">Buttons, Small Cards</p>
              </div>
              <div className="space-y-3">
                <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '10px' }}></div>
                <p className="text-sm font-mono">10px</p>
                <p className="text-xs text-black/60">Big Cards, Containers</p>
              </div>
            </div>
          </div>

          {/* Shadows */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Shadow System</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' }}></div>
                <p className="text-sm font-mono">shadow-sm</p>
                <p className="text-xs text-black/60">Subtle elevation</p>
              </div>
              <div className="space-y-3">
                <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}></div>
                <p className="text-sm font-mono">shadow-md</p>
                <p className="text-xs text-black/60">Standard cards</p>
              </div>
              <div className="space-y-3">
                <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}></div>
                <p className="text-sm font-mono">shadow-lg</p>
                <p className="text-xs text-black/60">Prominent elements</p>
              </div>
            </div>
          </div>

          {/* Icons */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Icon Library (Lucide React)</h3>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-6">
              {[
                { Icon: ArrowRight, name: 'ArrowRight' },
                { Icon: Download, name: 'Download' },
                { Icon: Heart, name: 'Heart' },
                { Icon: Star, name: 'Star' },
                { Icon: User, name: 'User' },
                { Icon: Mail, name: 'Mail' },
              ].map(({ Icon, name }) => (
                <div key={name} className="flex flex-col items-center gap-2 p-4 bg-black/5 rounded-[5px]">
                  <Icon className="w-6 h-6 text-black" />
                  <span className="text-xs text-black/60">{name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ========================================
            MOLECULES - Simple Components
            ======================================== */}
        <section className="mb-20">
          <div className="mb-12">
            <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Level 02</span>
            <h2 className="text-4xl font-bold text-black mb-3">Molecules</h2>
            <p className="text-base text-black/60 max-w-[700px]">
              Simple UI components combining atoms - reusable building blocks with specific functionality.
            </p>
          </div>

          {/* Buttons */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Buttons</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Brand Variant */}
              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                <div className="space-y-4">
                  <div className="flex items-baseline justify-between mb-2">
                    <h4 className="font-bold text-lg text-black">Brand Variant</h4>
                    <span className="text-xs text-black/40 font-mono">variant="brand"</span>
                  </div>
                  <Button 
                    variant="brand" 
                    size="lg"
                    icon={<ArrowRight className="w-4 h-4" />}
                    iconPosition="right"
                  >
                    Primary CTA
                  </Button>
                  <p className="text-sm text-black/60">
                    ✅ Highest conversion priority • Red gradient • Animated shift
                  </p>
                </div>
              </div>

              {/* Primary Variant */}
              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                <div className="space-y-4">
                  <div className="flex items-baseline justify-between mb-2">
                    <h4 className="font-bold text-lg text-black">Primary Variant</h4>
                    <span className="text-xs text-black/40 font-mono">variant="primary"</span>
                  </div>
                  <Button 
                    variant="primary" 
                    size="lg"
                    icon={<ArrowRight className="w-4 h-4" />}
                    iconPosition="right"
                  >
                    Secondary Action
                  </Button>
                  <p className="text-sm text-black/60">
                    ✅ Dark-to-grey gradient • Strong contrast
                  </p>
                </div>
              </div>

              {/* Secondary Variant */}
              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                <div className="space-y-4">
                  <div className="flex items-baseline justify-between mb-2">
                    <h4 className="font-bold text-lg text-black">Secondary Variant</h4>
                    <span className="text-xs text-black/40 font-mono">variant="secondary"</span>
                  </div>
                  <Button variant="secondary" size="lg">
                    Alternative Action
                  </Button>
                  <p className="text-sm text-black/60">
                    ✅ Alternative actions • Lower visual weight
                  </p>
                </div>
              </div>

              {/* Ghost Variant */}
              <div className="bg-black rounded-[10px] p-8">
                <div className="space-y-4">
                  <div className="flex items-baseline justify-between mb-2">
                    <h4 className="font-bold text-lg text-white">Ghost Variant</h4>
                    <span className="text-xs text-white/40 font-mono">variant="ghost"</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="lg"
                    icon={<ArrowRight className="w-4 h-4" />}
                    iconPosition="right"
                  >
                    Tertiary Action
                  </Button>
                  <p className="text-sm text-white/60">
                    ✅ Only on dark backgrounds
                  </p>
                </div>
              </div>
            </div>

            {/* Button Sizes */}
            <div className="mt-12 bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="font-bold text-lg text-black mb-6">Button Sizes</h4>
              <div className="flex flex-wrap gap-4 items-end">
                <div className="space-y-2">
                  <Button variant="primary" size="sm">Small</Button>
                  <p className="text-xs text-black/60 text-center">40px</p>
                </div>
                <div className="space-y-2">
                  <Button variant="primary" size="md">Medium</Button>
                  <p className="text-xs text-black/60 text-center">48px</p>
                </div>
                <div className="space-y-2">
                  <Button variant="primary" size="lg">Large</Button>
                  <p className="text-xs text-black/60 text-center">56px</p>
                </div>
                <div className="space-y-2">
                  <Button variant="primary" size="xl">Extra Large</Button>
                  <p className="text-xs text-black/60 text-center">64px</p>
                </div>
              </div>
            </div>

            {/* Button States */}
            <div className="mt-8 bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="font-bold text-lg text-black mb-6">Button States</h4>
              <div className="flex flex-wrap gap-4">
                <Button variant="brand" size="lg">Default</Button>
                <Button variant="brand" size="lg" loading>Loading</Button>
                <Button variant="brand" size="lg" disabled>Disabled</Button>
                <Button 
                  variant="brand" 
                  size="lg"
                  icon={<ArrowRight className="w-4 h-4" />}
                  iconPosition="right"
                >
                  With Icon
                </Button>
              </div>
            </div>
          </div>

          {/* Cards */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Cards</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-[10px] p-6 shadow-md border border-black/5">
                <h4 className="text-lg font-bold mb-2">White Card</h4>
                <p className="text-sm text-black/60">
                  Standard card with shadow and border.
                </p>
              </div>
              <div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
                <h4 className="text-lg font-bold mb-2">Warm Card</h4>
                <p className="text-sm text-black/60">
                  Warm background for highlighted sections.
                </p>
              </div>
              <div className="bg-black rounded-[10px] p-6">
                <h4 className="text-lg font-bold mb-2 text-white">Dark Card</h4>
                <p className="text-sm text-white/60">
                  Dark background for contrast sections.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================
            ORGANISMS - Complex Components
            ======================================== */}
        <section className="mb-20">
          <div className="mb-12">
            <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Level 03</span>
            <h2 className="text-4xl font-bold text-black mb-3">Organisms</h2>
            <p className="text-base text-black/60 max-w-[700px]">
              Complex UI components combining molecules and atoms - forming distinct interface sections.
            </p>
          </div>

          {/* Feature Grid */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Feature Grid Pattern</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
                  01
                </div>
                <h4 className="text-xl font-bold mb-3">Feature Title One</h4>
                <p className="text-sm text-black/60">Detailed description of the feature explaining the value proposition and key benefits.</p>
              </div>
              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
                  02
                </div>
                <h4 className="text-xl font-bold mb-3">Feature Title Two</h4>
                <p className="text-sm text-black/60">Detailed description of the feature explaining the value proposition and key benefits.</p>
              </div>
            </div>
          </div>

          {/* CTA Section Pattern */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">CTA Section Pattern</h3>
            <div className="bg-black rounded-[10px] p-12 text-center">
              <h3 className="text-3xl font-bold text-white mb-4">
                Ready to Get Started?
              </h3>
              <p className="text-base text-white/70 mb-8 max-w-[600px] mx-auto">
                Supporting description text that provides context and encourages users to take action.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Button 
                  variant="brand" 
                  size="lg"
                  icon={<ArrowRight className="w-4 h-4" />}
                  iconPosition="right"
                >
                  Primary Action
                </Button>
                <Button variant="ghost" size="lg">
                  Secondary Action
                </Button>
              </div>
            </div>
          </div>

          {/* Stats Grid Pattern */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-black mb-6">Stats Grid Pattern</h3>
            <div className="bg-[#f5f2f1] rounded-[10px] p-12">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {[
                  { value: '2.4K+', label: 'Active Users', description: 'Monthly active' },
                  { value: '98%', label: 'Satisfaction', description: 'Customer rate' },
                  { value: '150+', label: 'Components', description: 'Reusable elements' },
                  { value: '24/7', label: 'Support', description: 'Available hours' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <div className="text-4xl font-bold text-black mb-2">{stat.value}</div>
                    <div className="text-sm font-bold text-black mb-1">{stat.label}</div>
                    <div className="text-xs text-black/60">{stat.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ========================================
            USAGE GUIDELINES
            ======================================== */}
        <section className="mb-20">
          <div className="mb-12">
            <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Guidelines</span>
            <h2 className="text-4xl font-bold text-black mb-3">Design Principles</h2>
            <p className="text-base text-black/60 max-w-[700px]">
              Core rules and principles that govern all design decisions. See full documentation for detailed guidance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Color Usage */}
            <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="text-xl font-bold mb-4">Color Hierarchy</h4>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-2">
                  <span className="font-bold text-black">92%</span>
                  <span className="text-black/70">Black/White/Warm - Foundation</span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#b01f24]">5%</span>
                  <span className="text-black/70">Ken Bold Red - Major CTAs only</span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#806ce0]">3%</span>
                  <span className="text-black/70">Accents - Shadows & highlights only</span>
                </li>
              </ul>
            </div>

            {/* Typography Usage */}
            <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="text-xl font-bold mb-4">Typography Scale</h4>
              <ul className="space-y-3 text-sm text-black/70">
                <li>→ Major Third ratio (1.25x)</li>
                <li>→ --text-3xl reserved for hero moments</li>
                <li>→ --text-2xl standard for sections</li>
                <li>→ Generous whitespace between sections</li>
              </ul>
            </div>

            {/* Spacing Usage */}
            <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="text-xl font-bold mb-4">Spacing & Layout</h4>
              <ul className="space-y-3 text-sm text-black/70">
                <li>→ Max content width: 1000px</li>
                <li>→ Centered alignment for all content</li>
                <li>→ Section padding: py-16 to py-20</li>
                <li>→ Grid gap: gap-6 or gap-8</li>
              </ul>
            </div>

            {/* Border Radius Usage */}
            <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
              <h4 className="text-xl font-bold mb-4">Border Radius System</h4>
              <ul className="space-y-3 text-sm text-black/70">
                <li>→ 2.5px: Images and photos</li>
                <li>→ 5px: Buttons and small cards</li>
                <li>→ 10px: Big cards and containers</li>
                <li>→ Never mix radius sizes in same component</li>
              </ul>
            </div>
          </div>

          {/* Documentation Links */}
          <div className="mt-12 bg-black rounded-[10px] p-8 text-center">
            <h4 className="text-xl font-bold text-white mb-4">Complete Documentation</h4>
            <p className="text-sm text-white/70 mb-6 max-w-[600px] mx-auto">
              For comprehensive guides, detailed specifications, and decision-making frameworks, see the complete documentation files.
            </p>
            <div className="flex flex-wrap gap-3 justify-center text-xs">
              <span className="px-4 py-2 bg-white/10 rounded-[5px] text-white/90">DESIGN_TOKENS.md</span>
              <span className="px-4 py-2 bg-white/10 rounded-[5px] text-white/90">COMPONENT_LIBRARY.md</span>
              <span className="px-4 py-2 bg-white/10 rounded-[5px] text-white/90">PATTERN_LIBRARY.md</span>
              <span className="px-4 py-2 bg-white/10 rounded-[5px] text-white/90">DESIGN_PRINCIPLES.md</span>
            </div>
          </div>
        </section>

        {/* Footer Note */}
        <div className="text-center py-12 border-t border-black/10">
          <p className="text-sm text-black/60">
            Design System v1.0 • Built with Atomic Design • January 2026
          </p>
        </div>
      </div>
    </div>
  );
}
