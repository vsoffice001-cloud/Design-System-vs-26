/**
 * Stripe-Style Design System
 * 
 * Category-based design system with left sidebar navigation
 */

import React, { useState } from 'react';
import { DesignSystemSidebar, CategoryGroup } from './DesignSystemSidebar';
import { ColorsCategory } from './categories/ColorsCategory';
import { TypographyCategory } from './categories/TypographyCategory';
import { ButtonsCategory } from './categories/ButtonsCategory';
import { Palette, Type, Square } from 'lucide-react';

export function StripeDesignSystem() {
  const [activeCategory, setActiveCategory] = useState('colors');

  // Category structure
  const categoryGroups: CategoryGroup[] = [
    {
      id: 'foundation',
      label: 'Foundation',
      items: [
        { 
          id: 'colors', 
          label: 'Colors',
          icon: <Palette className="size-4" />
        },
        { 
          id: 'typography', 
          label: 'Typography',
          icon: <Type className="size-4" />
        },
      ],
    },
    {
      id: 'components',
      label: 'Components',
      items: [
        { 
          id: 'buttons', 
          label: 'Buttons',
          icon: <Square className="size-4" />
        },
      ],
    },
  ];

  // Render content based on active category
  const renderContent = () => {
    switch (activeCategory) {
      case 'colors':
        return <ColorsCategory />;
      case 'typography':
        return <TypographyCategory />;
      case 'buttons':
        return <ButtonsCategory />;
      default:
        return <ColorsCategory />;
    }
  };

  return (
    <div className="flex min-h-screen bg-white">
      {/* Sidebar */}
      <DesignSystemSidebar
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
        categoryGroups={categoryGroups}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-[1200px] mx-auto px-12 py-16">
          {/* Content transitions smoothly */}
          <div className="animate-in fade-in duration-300">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
}