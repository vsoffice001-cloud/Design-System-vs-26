import { useState } from 'react';
import { Button } from '@/app/components/Button';
import { 
  ChevronDown, 
  ArrowRight, 
  Search, 
  X, 
  Menu,
  Loader2,
  ChevronRight,
  Download,
  Copy,
  Check
} from 'lucide-react';
import {
  SpacingScaleVisualization,
  MarginPaddingGuide,
  ComponentSpacingExamples,
  ListFormSpacingDemo,
  ResponsiveSpacingDemo,
  VisualRhythmDemo
} from '@/app/components/SpacingHelpers';

/**
 * ULTIMATE DESIGN SYSTEM PAGE
 * ============================
 * Complete visual reference following WHY/WHAT/WHERE/WHEN/HOW framework
 * 
 * Categories:
 * 1. Colors ✅
 * 2. Typography ✅
 * 3. Spacing (Enhanced) ✨
 * 4. Layout Patterns (NEW) 🆕
 * 5. Buttons ✅
 * 6. Icons ✅
 * 7. Motion & Animations (NEW) 🆕
 * 8. Backgrounds ✅
 * 9. Components ✅
 */

export function UltimateDesignSystem() {
  const [activeTab, setActiveTab] = useState('colors');

  const tabs = [
    { id: 'colors', label: 'Colors' },
    { id: 'typography', label: 'Typography' },
    { id: 'spacing', label: 'Spacing' },
    { id: 'layout', label: 'Layout Patterns' }, // NEW
    { id: 'buttons', label: 'Buttons' },
    { id: 'icons', label: 'Icons' },
    { id: 'motion', label: 'Motion' }, // NEW
    { id: 'backgrounds', label: 'Backgrounds' },
    { id: 'components', label: 'Components' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-black/10 backdrop-blur-md">
        <div className="max-w-[1400px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-normal" style={{ fontSize: 'var(--text-xl)', color: 'var(--text-primary)' }}>
                Ultimate Design System
              </h1>
              <p style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
                YASH Case Study — Complete Reference with WHY/WHAT/WHERE/WHEN/HOW
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="secondary" size="sm" icon={<Download size={16} />}>
                Export Tokens
              </Button>
              <Button variant="primary" size="sm">
                Download Guide
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="sticky top-[73px] z-30 bg-white border-b border-black/8">
        <div className="max-w-[1400px] mx-auto px-6">
          <div className="flex gap-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap border-b-2 ${
                  activeTab === tab.id
                    ? 'border-[var(--brand-red)] text-[var(--brand-red)]'
                    : 'border-transparent text-black/60 hover:text-black/90'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-[1400px] mx-auto px-6 py-12">
        {activeTab === 'colors' && <ColorsSection />}
        {activeTab === 'typography' && <TypographySection />}
        {activeTab === 'spacing' && <SpacingSection />}
        {activeTab === 'layout' && <LayoutPatternsSection />}
        {activeTab === 'buttons' && <ButtonsSection />}
        {activeTab === 'icons' && <IconsSection />}
        {activeTab === 'motion' && <MotionSection />}
        {activeTab === 'backgrounds' && <BackgroundsSection />}
        {activeTab === 'components' && <ComponentsSection />}
      </main>
    </div>
  );
}

// ============================================================================
// COLORS SECTION
// ============================================================================

function ColorsSection() {
  return (
    <div className="space-y-12">
      {/* Brand Colors */}
      <DocSection
        title="Brand Colors - Ken Bold Red"
        why="Brand identity color - bold, confident, action-oriented. Limited to 5% of any page for maximum impact."
        what="Primary brand red (#b01f24) with hover and active states"
        when="Primary CTAs, critical alerts, key brand moments"
        whenNot="Section backgrounds, large content areas, body text, decorative elements"
        where="Hero CTAs, Sticky CTA, Primary buttons, Inline links (on hover)"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ColorCard
            name="Brand Red"
            token="--brand-red"
            value="#b01f24"
            usage="Primary CTAs, brand identity"
            wcag="4.54:1 on white"
          />
          <ColorCard
            name="Brand Red Hover"
            token="--brand-red-hover"
            value="#8f191e"
            usage="Button hover states"
            wcag="5.77:1 on white"
          />
          <ColorCard
            name="Brand Red Active"
            token="--brand-red-active"
            value="#6e1317"
            usage="Button active/pressed states"
            wcag="7.41:1 on white"
          />
        </div>
      </DocSection>

      {/* Text Colors */}
      <DocSection
        title="Semantic Text Colors (WCAG AAA)"
        why="Every text color passes WCAG AAA (7:1+) for maximum accessibility and readability"
        what="4-tier opacity system using black base"
        when="All text content - headings, body, labels, metadata"
        where="Throughout all sections - see specific usage in table below"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <TextColorCard
            name="Primary"
            token="--text-primary"
            value="rgba(0,0,0,0.90)"
            contrast="17.1:1"
            usage="Main headings, body text"
            where="Hero title, section headings, paragraphs"
          />
          <TextColorCard
            name="Secondary"
            token="--text-secondary"
            value="rgba(0,0,0,0.70)"
            contrast="11.4:1"
            usage="Supporting text"
            where="Descriptions, secondary content"
          />
          <TextColorCard
            name="Tertiary"
            token="--text-tertiary"
            value="rgba(0,0,0,0.60)"
            contrast="8.9:1"
            usage="Labels, metadata ⭐ MOST USED"
            where="Section labels, timestamps, categories"
          />
          <TextColorCard
            name="Subtle"
            token="--text-subtle"
            value="rgba(0,0,0,0.45)"
            contrast="5.9:1"
            usage="Decorative text"
            where="Watermarks, background text"
          />
        </div>
      </DocSection>

      {/* How to Use */}
      <DocSection title="Implementation Guide">
        <CodeExample
          code={`// In React/TSX:
<h1 style={{ color: 'var(--text-primary)' }}>
  Hero Heading
</h1>

<button style={{ background: 'var(--brand-red)' }}>
  Primary CTA
</button>

// In CSS:
.section-label {
  color: var(--text-tertiary);
}

.cta-button {
  background: var(--brand-red);
}
.cta-button:hover {
  background: var(--brand-red-hover);
}`}
        />
      </DocSection>

      {/* NEW: Complete Color Scales */}
      <DocSection
        title="Complete Color Scales"
        why="Full color palettes provide flexibility for various use cases while maintaining visual consistency"
        what="50-900 scales for Warm, Red, Purple, Coral, Amber, and Periwinkle"
        when="When you need lighter or darker variations for backgrounds, borders, hover states"
        where="Background highlights, section tints, border colors, subtle accents"
      >
        <ColorScaleSection />
      </DocSection>

      {/* NEW: Background Colors */}
      <DocSection
        title="Background Colors"
        why="Subtle background colors create visual hierarchy without overwhelming content"
        what="Ultra-light tints (2-3% opacity) for section differentiation"
        when="Section backgrounds, card backgrounds, subtle emphasis areas"
        whenNot="Never use saturated backgrounds that compete with text readability"
        where="Challenges (#f5f2f1), Methodology (#f9f7f6), Final CTA (#fefdfd)"
      >
        <BackgroundColorsDemo />
      </DocSection>

      {/* NEW: Border Colors */}
      <DocSection
        title="Border Colors & Dividers"
        why="Subtle borders create separation without harsh lines"
        what="Black opacity variants (8%, 10%, 15%, 20%) for different emphasis levels"
        when="Card outlines, section dividers, input borders, subtle separations"
        where="Card borders (8%), Section dividers (10%), Input focus (15%)"
      >
        <BorderColorsDemo />
      </DocSection>

      {/* NEW: Color Accessibility Matrix */}
      <DocSection
        title="Color Contrast Matrix (WCAG AAA)"
        why="Ensures all text/background combinations meet accessibility standards"
        what="Pre-calculated contrast ratios for all color combinations"
        when="Choosing text colors for any background"
        where="Reference table for designers and developers"
      >
        <ColorAccessibilityMatrix />
      </DocSection>
    </div>
  );
}

// ============================================================================
// TYPOGRAPHY SECTION  
// ============================================================================

function TypographySection() {
  const typeScale = [
    { token: '--text-xs', pixels: '12.8px', usage: 'Section labels, metadata ⭐', where: '"CASE STUDY" badge, category tags' },
    { token: '--text-sm', pixels: '16px', usage: 'Body text, descriptions ⭐ MOST USED', where: 'All paragraph content, challenge questions' },
    { token: '--text-base', pixels: '20px', usage: 'Large body, card titles', where: 'Card headings with 4+ cards' },
    { token: '--text-xl', pixels: '31.25px', usage: 'Subsection headings (h3)', where: 'Methodology steps, objective titles' },
    { token: '--text-2xl', pixels: '39px', usage: 'Section headings (h2) ⭐', where: 'Client Context, Challenges, Impact, etc.' },
    { token: '--text-3xl', pixels: '48.8px', usage: 'Hero headings (h1) ⭐ HERO ONLY', where: 'Hero Section title, Final CTA heading' },
  ];

  return (
    <div className="space-y-12">
      <DocSection
        title="Type Scale - Major Third (1.25 Ratio)"
        why="Mathematical progression creates harmonious visual hierarchy. Major Third (1.25x) ratio provides clear distinction between sizes while maintaining readability."
        what="Each size is 1.25× the previous size, starting from 16px base"
        when="Use for all typography - headings, body text, labels. Only deviate for spatial constraints."
        where="Throughout all 9 sections of the case study"
      >
        <div className="space-y-4">
          {typeScale.map((type) => (
            <TypeScaleDemo key={type.token} {...type} />
          ))}
        </div>
      </DocSection>

      {/* Letter Spacing */}
      <DocSection
        title="Letter Spacing (Tracking)"
        why="Fine-tuning for optical balance - large text needs tightening, small all-caps need opening"
        what="Context-specific tracking adjustments"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <TrackingDemo
            label="All-Caps Labels"
            tracking="1.8px"
            example="CASE STUDY"
            usage="Section labels, badges"
            style={{ letterSpacing: '1.8px', textTransform: 'uppercase' as const, fontSize: '12.8px' }}
          />
          <TrackingDemo
            label="Hero Headings"
            tracking="-0.5px"
            example="Large Title"
            usage="48px+ headings"
            style={{ letterSpacing: '-0.5px', fontSize: '48px' }}
          />
          <TrackingDemo
            label="Normal Text"
            tracking="0"
            example="Standard Text"
            usage="Body, descriptions"
            style={{ letterSpacing: '0', fontSize: '16px' }}
          />
        </div>
      </DocSection>

      {/* Line Height */}
      <DocSection
        title="Line Height System"
        why="Proper line height improves readability and creates comfortable rhythm"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <LineHeightDemo type="Headings" value="1.2-1.3" usage="Tight, impactful" />
          <LineHeightDemo type="Body Text" value="1.6-1.7" usage="Comfortable reading" />
          <LineHeightDemo type="Labels" value="1.4-1.5" usage="Compact but clear" />
        </div>
      </DocSection>

      {/* NEW: Font Weight System */}
      <DocSection
        title="Font Weight System"
        why="Two fonts (DM Sans + Noto Serif) with strategic weight usage create hierarchy without overwhelming variety"
        what="Normal (400) for body, Medium (500) for emphasis, Bold (700) for headings"
        when="DM Sans for UI/system, Noto Serif for editorial content"
        where="DM Sans: buttons, labels, metadata. Noto Serif: headings, body paragraphs"
      >
        <FontWeightDemo />
      </DocSection>

      {/* NEW: Font Family Comparison */}
      <DocSection
        title="Font Family Usage"
        why="Two-font system: DM Sans (geometric, clean) + Noto Serif (editorial, warm)"
        what="DM Sans for UI elements, Noto Serif for content"
        when="DM Sans: navigation, buttons, labels. Noto Serif: headings, paragraphs"
      >
        <FontFamilyComparison />
      </DocSection>

      {/* NEW: Real Text Examples */}
      <DocSection
        title="Typography in Context"
        why="See how each size performs with actual content"
        what="Real examples at each scale with proper line height and spacing"
      >
        <RealTextExamples />
      </DocSection>

      {/* NEW: Heading Hierarchy */}
      <DocSection
        title="Heading Hierarchy (H1-H3)"
        why="Clear visual distinction between heading levels maintains content structure"
        what="3-level system: H1 (Hero), H2 (Sections), H3 (Subsections)"
        when="H1 once per page, H2 for major sections, H3 for subsections"
      >
        <HeadingHierarchy />
      </DocSection>

      {/* NEW: Responsive Typography */}
      <DocSection
        title="Responsive Typography Scaling"
        why="Text adjusts for optimal readability across all screen sizes"
        what="16px mobile base → 16px+ desktop base. Hero scales more dramatically"
        when="Mobile-first approach with breakpoint adjustments"
      >
        <ResponsiveTypographyDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// SPACING SECTION (ENHANCED)
// ============================================================================

function SpacingSection() {
  return (
    <div className="space-y-12">
      {/* Typography Pairing */}
      <DocSection
        title="Typography Pairing System (7-Tier)"
        why="Consistent relationships between typography elements create visual hierarchy through proximity (Gestalt principle)"
        what="7-tier spacing system defining relationships between labels, headings, descriptions, and content"
        when="Apply these exact tokens for typography relationships throughout all sections"
      >
        <PairingTable />
      </DocSection>

      {/* Section Spacing */}
      <DocSection
        title="Section Spacing (Vertical Rhythm)"
        why="Consistent vertical rhythm creates professional flow and helps users navigate content"
        what="Progressive scaling from mobile to desktop across 3 levels: compact, standard, spacious"
      >
        <SectionSpacingTable />
      </DocSection>

      {/* Grid Gaps */}
      <DocSection
        title="Grid Gap System"
        why="Consistent gaps between cards/items create visual harmony"
        what="Responsive gap system that scales from mobile to desktop"
        where="Challenge cards, Resource cards, Impact metrics"
      >
        <GridGapTable />
      </DocSection>

      {/* Card Internal Padding */}
      <DocSection
        title="Card Internal Padding"
        why="Proper internal padding creates comfortable reading space and premium feel"
      >
        <CardPaddingTable />
      </DocSection>

      {/* Content Max Width */}
      <DocSection
        title="Content Max Width"
        why="1000px prevents overly long line lengths (45-75 characters optimal), maintains readability"
        when="ALL content sections"
        where="Client Context, Challenges, Objectives, Methodology, Impact, Endorsement"
      >
        <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-8">
          <div className="max-w-[1000px] mx-auto bg-[var(--brand-red)]/10 border-2 border-dashed border-[var(--brand-red)] rounded-[10px] p-8">
            <p className="text-center font-mono text-sm text-[var(--brand-red)] mb-2">
              max-width: 1000px
            </p>
            <p className="text-center text-xs text-black/60">
              All content sections maintain this maximum width for optimal readability
            </p>
          </div>
        </div>
        <CodeExample code={`.content-container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 0 1.5rem; /* Mobile */
}

@media (min-width: 640px) {
  padding: 0 2rem; /* Tablet */
}

@media (min-width: 768px) {
  padding: 0 3rem; /* Desktop */
}`} />
      </DocSection>

      {/* NEW: Full Spacing Scale */}
      <DocSection
        title="Complete Spacing Scale"
        why="Consistent spacing increments create visual harmony and predictable layouts"
        what="12-value scale from 4px to 128px following 4px base unit system"
        when="Use for margins, padding, gaps - choose from scale rather than arbitrary values"
        where="All spacing decisions throughout the design system"
      >
        <SpacingScaleVisualization />
      </DocSection>

      {/* NEW: Margin vs Padding Decision Tree */}
      <DocSection
        title="Margin vs Padding Decision Guide"
        why="Understanding when to use margin vs padding prevents layout issues"
        what="Decision tree and visual examples showing appropriate use cases"
        when="Every time you need to add space around or inside an element"
      >
        <MarginPaddingGuide />
      </DocSection>

      {/* NEW: Component Internal Spacing */}
      <DocSection
        title="Component Internal Spacing Patterns"
        why="Consistent internal spacing makes components feel polished and professional"
        what="Standard spacing patterns for buttons, cards, forms, and other components"
        where="All interactive components and content containers"
      >
        <ComponentSpacingExamples />
      </DocSection>

      {/* NEW: List & Form Spacing */}
      <DocSection
        title="List & Form Spacing"
        why="Proper spacing in lists and forms improves scannability and usability"
        what="Specific spacing values for list items, form fields, and form groups"
        when="Building navigation, content lists, or form interfaces"
      >
        <ListFormSpacingDemo />
      </DocSection>

      {/* NEW: Responsive Spacing */}
      <DocSection
        title="Responsive Spacing Strategy"
        why="Spacing should adapt to screen size to optimize use of space"
        what="Mobile-first spacing that scales up for tablet and desktop"
        when="All responsive layouts - adjust spacing at breakpoints"
      >
        <ResponsiveSpacingDemo />
      </DocSection>

      {/* NEW: Visual Rhythm */}
      <DocSection
        title="Visual Rhythm & Flow"
        why="Consistent vertical rhythm creates a professional, harmonious layout"
        what="Demonstration of how spacing creates visual flow through content"
        where="Long-form content, marketing pages, documentation"
      >
        <VisualRhythmDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// LAYOUT PATTERNS SECTION (NEW)
// ============================================================================

function LayoutPatternsSection() {
  return (
    <div className="space-y-12">
      {/* Grid Systems */}
      <DocSection
        title="Grid Systems"
        why="Consistent grid patterns create visual harmony and responsive layouts"
        what="3 primary grid patterns: 2-column, 3-column, and asymmetric split"
        when="Use based on content count and hierarchy needs"
      >
        <GridSystemDemo />
      </DocSection>

      {/* Z-Index Hierarchy */}
      <DocSection
        title="Z-Index Hierarchy"
        why="Prevents stacking conflicts, ensures proper layering of elements"
        what="5-tier system from backgrounds (0) to modals (100)"
        when="Apply to all overlapping elements - modals, navbars, sticky elements"
      >
        <ZIndexTable />
      </DocSection>

      {/* Responsive Breakpoints */}
      <DocSection
        title="Responsive Breakpoints"
        why="Tailwind standard breakpoints ensure consistent responsive behavior"
        what="3 primary breakpoints: sm (640px), md (768px), lg (1024px)"
      >
        <BreakpointsTable />
      </DocSection>

      {/* Centering Patterns */}
      <DocSection
        title="Centering Patterns"
        why="Different centering techniques for different use cases"
      >
        <CenteringDemo />
      </DocSection>

      {/* Sticky Positioning */}
      <DocSection
        title="Sticky Positioning"
        why="Keeps important navigation elements visible during scroll"
        when="Navbar, tab navigation, sidebar"
        where="Navbar (top: 0), Tab Nav (top: 73px), Client Context sidebar"
      >
        <StickyDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// BUTTONS SECTION
// ============================================================================

function ButtonsSection() {
  const sizes = ['sm', 'md', 'lg', 'xl'] as const;
  const variants = ['primary', 'brand', 'secondary', 'ghost'] as const;

  return (
    <div className="space-y-12">
      {/* Button Variants */}
      <DocSection
        title="Button Variants (4 Types)"
        why="Different visual weights for different action hierarchies"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <ButtonVariantCard
            variant="primary"
            title="Primary"
            why="Main conversion actions"
            what="Dark-to-grey gradient creates premium feel"
            when="Hero CTAs, Form submissions, Download buttons"
            where="Hero Section, Final CTA, Modals"
          />
          <ButtonVariantCard
            variant="brand"
            title="Brand"
            why="Ken Red brand identity - maximum impact"
            what="Red gradient with brand shadow glow"
            when="Sticky CTA, Critical brand actions, Limited use"
            where="Sticky CTA button, Special promotional CTAs"
          />
          <ButtonVariantCard
            variant="secondary"
            title="Secondary"
            why="Lower hierarchy actions"
            what="White background with subtle border"
            when="Secondary actions, 'Learn More', Alternative options"
            where="Final CTA secondary, Modal cancel buttons"
          />
          <ButtonVariantCard
            variant="ghost"
            title="Ghost"
            why="Minimal weight for dark backgrounds"
            what="Transparent with light border"
            when="Dark backgrounds, Subtle navigation, Tertiary actions"
            where="Hero on black, Resources section, Dark modals"
          />
        </div>
      </DocSection>

      {/* Button Sizes */}
      <DocSection
        title="Button Sizes (4 Options)"
        why="Different contexts require different button sizes"
      >
        <ButtonSizeTable />
      </DocSection>

      {/* Button States */}
      <DocSection
        title="Button States & Interactions"
        why="Provides tactile feedback and confirms user actions"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StateDemo state="Default" description="Normal resting state">
            <Button variant="primary" size="md">Default</Button>
          </StateDemo>
          <StateDemo state="Hover" description="Gradient shifts, shadow increases">
            <Button variant="primary" size="md">Hover Me</Button>
          </StateDemo>
          <StateDemo state="Loading" description="Spinner replaces content, 70% opacity">
            <Button variant="primary" size="md" loading>Loading</Button>
          </StateDemo>
          <StateDemo state="Disabled" description="50% opacity, cursor not-allowed">
            <Button variant="primary" size="md" disabled>Disabled</Button>
          </StateDemo>
        </div>
      </DocSection>

      {/* Ripple Effect */}
      <DocSection
        title="Ripple Effect (600ms)"
        why="Provides tactile feedback like Material Design - confirms click location"
        what="Circular expanding effect from click point, auto-removes after 600ms"
        when="All button clicks (enabled by default, can disable with ripple=false)"
      >
        <RippleDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// ICONS SECTION
// ============================================================================

function IconsSection() {
  const icons = [
    { name: 'ChevronDown', component: ChevronDown, size: 20, stroke: 1.5, usage: 'Scroll indicator, dropdowns' },
    { name: 'ChevronRight', component: ChevronRight, size: 16, stroke: 2.5, usage: 'List bullets, navigation ⭐' },
    { name: 'ArrowRight', component: ArrowRight, size: 16, stroke: 2, usage: 'CTA arrows, link indicators ⭐' },
    { name: 'Search', component: Search, size: 20, stroke: 2, usage: 'Search button' },
    { name: 'X', component: X, size: 20, stroke: 2, usage: 'Close buttons' },
    { name: 'Menu', component: Menu, size: 24, stroke: 2, usage: 'Mobile menu' },
    { name: 'Loader2', component: Loader2, size: 18, stroke: 2, usage: 'Loading spinner' },
  ];

  return (
    <div className="space-y-12">
      <DocSection
        title="Icon Library: Lucide React"
        why="Clean, consistent outlined icons with perfect React integration"
        what="Lightweight icon library (lucide-react) with customizable size and stroke"
        when="All icon needs throughout the case study"
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-6">
          {icons.map((icon) => {
            const IconComponent = icon.component;
            return (
              <div key={icon.name} className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 text-center">
                <div className="flex items-center justify-center mb-3 h-8">
                  <IconComponent size={icon.size} strokeWidth={icon.stroke} />
                </div>
                <p className="font-mono text-xs text-black/90 mb-1">{icon.name}</p>
                <p className="text-[10px] text-black/60 mb-2">{icon.size}×{icon.size}px</p>
                <p className="text-[10px] text-black/50">Stroke: {icon.stroke}px</p>
                <p className="text-[9px] text-black/40 mt-2">{icon.usage}</p>
              </div>
            );
          })}
        </div>
      </DocSection>

      <DocSection
        title="Icon Size Guidelines"
        why="Consistent sizing creates visual harmony"
      >
        <IconSizeTable />
      </DocSection>

      <DocSection
        title="Stroke Width Variations"
        why="Visual weight variations for different contexts"
      >
        <StrokeWidthDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// MOTION & ANIMATIONS SECTION (NEW)
// ============================================================================

function MotionSection() {
  return (
    <div className="space-y-12">
      {/* 4-Layer Duration System */}
      <DocSection
        title="4-Layer Animation Duration System"
        why="Consistent timing creates polished, professional feel across all interactions"
        what="4 distinct duration layers for different interaction types"
        when="Apply appropriate layer based on interaction complexity and user expectation"
      >
        <AnimationLayersTable />
      </DocSection>

      {/* Easing Functions */}
      <DocSection
        title="Easing Functions"
        why="Easing creates natural, organic motion (vs robotic linear movement)"
        what="3 primary easing functions for different animation types"
      >
        <EasingDemo />
      </DocSection>

      {/* Hover Effects */}
      <DocSection
        title="Hover Effects"
        why="Provides immediate visual feedback that element is interactive"
      >
        <HoverEffectsDemo />
      </DocSection>

      {/* Scroll Animations */}
      <DocSection
        title="Scroll Animations"
        why="Reveals content progressively, creates engaging experience"
        what="Fade-in with vertical translate on scroll into view"
        when="All section content, cards, major elements"
      >
        <ScrollAnimationDemo />
      </DocSection>

      {/* Counter Animation */}
      <DocSection
        title="Counter Animation (Impact Metrics)"
        why="Engaging way to present data, draws attention to results"
        what="Values count up from 0 using easeOutCubic easing"
        when="Impact metrics, statistics, numerical highlights"
        where="Impact Section (Section 6)"
      >
        <CounterDemo />
      </DocSection>

      {/* Ripple Effect */}
      <DocSection
        title="Ripple Effect (Material Design)"
        why="Confirms click location, provides tactile feedback"
        what="Circular expanding effect from click point"
        when="All button interactions (default enabled)"
      >
        <RippleCodeExample />
      </DocSection>
    </div>
  );
}

// ============================================================================
// BACKGROUNDS SECTION
// ============================================================================

function BackgroundsSection() {
  return (
    <div className="space-y-12">
      <DocSection
        title="14 Background Gradient Themes"
        why="Flexible, reusable gradient compositions using brand colors only - never random colors"
        what="Radial gradient systems with 3-14 blobs per theme, 60-160px blur, 0.25-0.95 opacity"
        when="Sections needing visual interest without solid colors"
      >
        <p className="text-sm text-black/60 mb-6">
          All themes use ONLY brand colors (Red, Warm, Coral, Amber, Purple, Periwinkle, Perano) at strategic opacities.
          Each theme follows a 4-stop gradient pattern: Strong center → Medium → Subtle → Transparent
        </p>
        <BackgroundThemesGrid />
      </DocSection>

      <DocSection
        title="Solid Section Backgrounds"
        why="Subtle warm tones create visual rhythm without gradients"
        where="Challenges (#f5f2f1), Methodology (#f9f7f6), Final CTA (#fefdfd)"
      >
        <SolidBackgroundsDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// COMPONENTS SECTION
// ============================================================================

function ComponentsSection() {
  return (
    <div className="space-y-12">
      <DocSection
        title="Border Radius System (3-Tier)"
        why="Strict system creates visual consistency across all components"
        what="3 distinct values: 2.5px, 5px, 10px"
        when="ALWAYS use these exact values - no random border-radius"
      >
        <BorderRadiusDemo />
      </DocSection>

      <DocSection
        title="Card Hover Effects"
        why="Subtle interactions provide feedback without overwhelming"
      >
        <CardHoverDemo />
      </DocSection>
    </div>
  );
}

// ============================================================================
// HELPER COMPONENTS
// ============================================================================

interface DocSectionProps {
  title: string;
  why?: string;
  what?: string;
  when?: string;
  whenNot?: string;
  where?: string;
  how?: string;
  children: React.ReactNode;
}

function DocSection({ title, why, what, when, whenNot, where, how, children }: DocSectionProps) {
  return (
    <section>
      <div className="mb-6">
        <h2 style={{ fontSize: 'var(--text-xl)', marginBottom: '0.5rem', color: 'var(--text-primary)' }}>
          {title}
        </h2>
        <div className="space-y-2">
          {why && (
            <InfoBlock label="WHY" content={why} color="purple" />
          )}
          {what && (
            <InfoBlock label="WHAT" content={what} color="blue" />
          )}
          {when && (
            <InfoBlock label="WHEN" content={when} color="green" />
          )}
          {whenNot && (
            <InfoBlock label="WHEN NOT" content={whenNot} color="red" />
          )}
          {where && (
            <InfoBlock label="WHERE" content={where} color="amber" />
          )}
          {how && (
            <InfoBlock label="HOW" content={how} color="gray" />
          )}
        </div>
      </div>
      {children}
    </section>
  );
}

function InfoBlock({ label, content, color }: { label: string; content: string; color: string }) {
  const colors = {
    purple: 'bg-purple-50 text-purple-900 border-purple-200',
    blue: 'bg-blue-50 text-blue-900 border-blue-200',
    green: 'bg-green-50 text-green-900 border-green-200',
    red: 'bg-red-50 text-red-900 border-red-200',
    amber: 'bg-amber-50 text-amber-900 border-amber-200',
    gray: 'bg-gray-50 text-gray-900 border-gray-200',
  };

  return (
    <div className={`px-4 py-3 rounded-[5px] border ${colors[color as keyof typeof colors]}`}>
      <span className="font-mono text-xs font-bold mr-2">{label}:</span>
      <span className="text-sm">{content}</span>
    </div>
  );
}

function ColorCard({ name, token, value, usage, wcag }: any) {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="border border-black/8 rounded-[10px] overflow-hidden">
      <div className="h-32 relative group cursor-pointer" style={{ background: value }} onClick={copyToClipboard}>
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all flex items-center justify-center">
          {copied ? (
            <Check size={24} className="text-white" />
          ) : (
            <Copy size={20} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          )}
        </div>
      </div>
      <div className="p-4 bg-white">
        <p className="font-semibold text-sm mb-1">{name}</p>
        <p className="font-mono text-xs text-black/60 mb-2">{value}</p>
        {wcag && <p className="text-xs text-green-600 mb-2">✓ {wcag}</p>}
        <p className="text-xs text-black/60 mb-3">{usage}</p>
        <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono text-black/80">
          var({token})
        </code>
      </div>
    </div>
  );
}

function TextColorCard({ name, token, value, contrast, usage, where }: any) {
  return (
    <div className="border border-black/8 rounded-[10px] p-6 bg-white">
      <div className="mb-4">
        <p className="text-4xl mb-2" style={{ color: value }}>Aa</p>
        <p className="font-semibold text-sm mb-1">{name}</p>
        <p className="text-xs text-green-600 mb-2">✓ WCAG AAA ({contrast})</p>
      </div>
      <p className="text-xs text-black/60 mb-2"><strong>USAGE:</strong> {usage}</p>
      <p className="text-xs text-black/50 mb-3"><strong>WHERE:</strong> {where}</p>
      <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono text-black/80">
        var({token})
      </code>
    </div>
  );
}

function CodeExample({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative mt-4 bg-black/5 rounded-[10px] p-4">
      <button
        onClick={copyCode}
        className="absolute top-3 right-3 p-2 rounded-[5px] bg-white/80 hover:bg-white transition-colors"
      >
        {copied ? <Check size={16} /> : <Copy size={16} />}
      </button>
      <pre className="text-xs font-mono text-black/80 overflow-x-auto pr-12">
        {code}
      </pre>
    </div>
  );
}

function TypeScaleDemo({ token, pixels, usage, where }: any) {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
      <div className="flex items-end justify-between mb-4">
        <p style={{ fontSize: `var(${token})`, lineHeight: 1.3 }}>
          The quick brown fox
        </p>
        <div className="text-right ml-4">
          <p className="font-mono text-xs text-black/60">{token}</p>
          <p className="font-mono text-xs text-black/40">{pixels}</p>
        </div>
      </div>
      <div className="pt-4 border-t border-black/8 space-y-1">
        <p className="text-xs text-black/60"><strong>USAGE:</strong> {usage}</p>
        <p className="text-xs text-black/50"><strong>WHERE:</strong> {where}</p>
      </div>
    </div>
  );
}

function TrackingDemo({ label, tracking, example, usage, style }: any) {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
      <p className="text-xs text-black/60 mb-3">{label}</p>
      <p style={style} className="mb-4">{example}</p>
      <p className="text-xs text-black/50 mb-2"><strong>Tracking:</strong> {tracking}</p>
      <p className="text-xs text-black/50"><strong>Usage:</strong> {usage}</p>
    </div>
  );
}

function LineHeightDemo({ type, value, usage }: any) {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
      <p className="font-mono text-sm mb-2">{type}</p>
      <p className="text-2xl font-bold mb-3">{value}</p>
      <p className="text-xs text-black/60">{usage}</p>
    </div>
  );
}

function PairingTable() {
  const pairs = [
    { token: '--pair-label-heading', mobile: '12px', desktop: '16px', usage: 'Label → Heading ⭐ TIGHTEST', example: '"CLIENT CONTEXT" → "Yash Highvoltage..."' },
    { token: '--pair-heading-description', mobile: '24px', desktop: '32px', usage: 'Heading → Description text', example: 'Section heading → Lead paragraph' },
    { token: '--pair-heading-content', mobile: '32px', desktop: '48px', usage: 'Heading → Content ⭐ MOST USED', example: 'Section heading → First card/paragraph' },
    { token: '--pair-heading-content-direct', mobile: '40px', desktop: '56px', usage: 'Heading → Content (no description)', example: 'Hero title → Info cards' },
    { token: '--pair-description-content', mobile: '40px', desktop: '56px', usage: 'Description → Major content', example: 'Lead paragraph → Content blocks' },
    { token: '--pair-description-subheading', mobile: '32px', desktop: '40px', usage: 'Description → Subheading', example: 'Overview → "Key Capabilities"' },
    { token: '--pair-subheading-content', mobile: '24px', desktop: '32px', usage: 'Subheading → Content', example: '"Key Capabilities" → List items' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Token</th>
            <th className="text-left p-3 text-sm font-bold">Mobile</th>
            <th className="text-left p-3 text-sm font-bold">Desktop</th>
            <th className="text-left p-3 text-sm font-bold">Usage</th>
            <th className="text-left p-3 text-sm font-bold">Example</th>
          </tr>
        </thead>
        <tbody>
          {pairs.map((pair) => (
            <tr key={pair.token} className="border-b border-black/8">
              <td className="p-3 font-mono text-xs">{pair.token}</td>
              <td className="p-3 text-sm">{pair.mobile}</td>
              <td className="p-3 text-sm">{pair.desktop}</td>
              <td className="p-3 text-sm">{pair.usage}</td>
              <td className="p-3 text-xs text-black/60">{pair.example}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SectionSpacingTable() {
  const spacing = [
    { level: 'Compact', mobile: '64px (4rem)', tablet: '80px (5rem)', desktop: '96px (6rem)', usage: 'Hero, Navbar', token: '--section-py-compact' },
    { level: 'Standard ⭐', mobile: '80px (5rem)', tablet: '96px (6rem)', desktop: '128px (8rem)', usage: 'Most sections', token: '--section-py-standard' },
    { level: 'Spacious', mobile: '96px (6rem)', tablet: '112px (7rem)', desktop: '144px (9rem)', usage: 'Feature sections', token: '--section-py-spacious' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Level</th>
            <th className="text-left p-3 text-sm font-bold">Mobile</th>
            <th className="text-left p-3 text-sm font-bold">Tablet</th>
            <th className="text-left p-3 text-sm font-bold">Desktop</th>
            <th className="text-left p-3 text-sm font-bold">Usage</th>
            <th className="text-left p-3 text-sm font-bold">Token</th>
          </tr>
        </thead>
        <tbody>
          {spacing.map((s) => (
            <tr key={s.level} className="border-b border-black/8">
              <td className="p-3 font-semibold text-sm">{s.level}</td>
              <td className="p-3 text-sm">{s.mobile}</td>
              <td className="p-3 text-sm">{s.tablet}</td>
              <td className="p-3 text-sm">{s.desktop}</td>
              <td className="p-3 text-sm">{s.usage}</td>
              <td className="p-3 font-mono text-xs">{s.token}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function GridGapTable() {
  const gaps = [
    { grid: '2-column', mobile: '24px (1.5rem)', desktop: '32px (2rem)', usage: 'Challenge cards, Impact metrics', token: 'gap: 1.5rem md:gap-2rem' },
    { grid: '3-column', mobile: '20px (1.25rem)', desktop: '24px (1.5rem)', usage: 'Resource cards', token: 'gap: 1.25rem lg:gap-1.5rem' },
    { grid: '4-item grid', mobile: '24px (1.5rem)', desktop: '32px (2rem)', usage: 'Objectives, equal items', token: 'gap: 1.5rem md:gap-2rem' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Grid Type</th>
            <th className="text-left p-3 text-sm font-bold">Mobile Gap</th>
            <th className="text-left p-3 text-sm font-bold">Desktop Gap</th>
            <th className="text-left p-3 text-sm font-bold">Where Used</th>
            <th className="text-left p-3 text-sm font-bold">Implementation</th>
          </tr>
        </thead>
        <tbody>
          {gaps.map((gap) => (
            <tr key={gap.grid} className="border-b border-black/8">
              <td className="p-3 font-semibold text-sm">{gap.grid}</td>
              <td className="p-3 text-sm">{gap.mobile}</td>
              <td className="p-3 text-sm">{gap.desktop}</td>
              <td className="p-3 text-sm">{gap.usage}</td>
              <td className="p-3 font-mono text-xs">{gap.token}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CardPaddingTable() {
  const padding = [
    { size: 'Large cards', mobile: '32px (2rem)', desktop: '40px (2.5rem)', usage: 'Challenge cards, Objective cards' },
    { size: 'Medium cards', mobile: '24px (1.5rem)', desktop: '32px (2rem)', usage: 'Resource cards, Impact metrics' },
    { size: 'Small cards', mobile: '20px (1.25rem)', desktop: '20px (1.25rem)', usage: 'Compact UI elements' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Card Size</th>
            <th className="text-left p-3 text-sm font-bold">Mobile Padding</th>
            <th className="text-left p-3 text-sm font-bold">Desktop Padding</th>
            <th className="text-left p-3 text-sm font-bold">Where Used</th>
          </tr>
        </thead>
        <tbody>
          {padding.map((p) => (
            <tr key={p.size} className="border-b border-black/8">
              <td className="p-3 font-semibold text-sm">{p.size}</td>
              <td className="p-3 text-sm">{p.mobile}</td>
              <td className="p-3 text-sm">{p.desktop}</td>
              <td className="p-3 text-sm">{p.usage}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Grid System Demo
function GridSystemDemo() {
  return (
    <div className="space-y-8">
      {/* 2-Column */}
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm mb-4">2-Column Grid (Challenges, Impact Metrics)</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="h-24 bg-[var(--brand-red)]/20 border-2 border-[var(--brand-red)] rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 1</span>
          </div>
          <div className="h-24 bg-[var(--brand-red)]/20 border-2 border-[var(--brand-red)] rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 2</span>
          </div>
          <div className="h-24 bg-[var(--brand-red)]/20 border-2 border-[var(--brand-red)] rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 3</span>
          </div>
          <div className="h-24 bg-[var(--brand-red)]/20 border-2 border-[var(--brand-red)] rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 4</span>
          </div>
        </div>
        <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono">
          grid-cols-1 md:grid-cols-2 gap-6
        </code>
      </div>

      {/* 3-Column */}
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm mb-4">3-Column Grid (Resources)</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <div className="h-24 bg-blue-500/20 border-2 border-blue-500 rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 1</span>
          </div>
          <div className="h-24 bg-blue-500/20 border-2 border-blue-500 rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 2</span>
          </div>
          <div className="h-24 bg-blue-500/20 border-2 border-blue-500 rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Item 3</span>
          </div>
        </div>
        <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono">
          grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4
        </code>
      </div>

      {/* Asymmetric 4/8 Split */}
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm mb-4">Asymmetric 4/8 Split (Client Context)</p>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-4">
          <div className="md:col-span-4 h-32 bg-purple-500/20 border-2 border-purple-500 rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Sidebar (33%)</span>
          </div>
          <div className="md:col-span-8 h-32 bg-purple-500/20 border-2 border-purple-500 rounded-[5px] flex items-center justify-center">
            <span className="font-mono text-sm">Main Content (67%)</span>
          </div>
        </div>
        <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono">
          grid-cols-1 md:grid-cols-12<br/>
          md:col-span-4 (sidebar)<br/>
          md:col-span-8 (content)
        </code>
      </div>
    </div>
  );
}

// Z-Index Table
function ZIndexTable() {
  const zIndex = [
    { layer: 'Modals', value: '100', elements: 'Contact modal, Search modal', reasoning: 'Highest - must overlay everything' },
    { layer: 'Progress Bar', value: '50', elements: 'Reading progress, Variant switcher', reasoning: 'Above navbar, always visible' },
    { layer: 'Navigation', value: '40', elements: 'Navbar, Sticky CTA', reasoning: 'Above content, below modals' },
    { layer: 'Content', value: '10', elements: 'Section content', reasoning: 'Above backgrounds' },
    { layer: 'Backgrounds', value: '0', elements: 'BackgroundHighlight themes', reasoning: 'Lowest - behind content' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Layer</th>
            <th className="text-left p-3 text-sm font-bold">Z-Index</th>
            <th className="text-left p-3 text-sm font-bold">Elements</th>
            <th className="text-left p-3 text-sm font-bold">Reasoning</th>
          </tr>
        </thead>
        <tbody>
          {zIndex.map((z) => (
            <tr key={z.layer} className="border-b border-black/8">
              <td className="p-3 font-semibold text-sm">{z.layer}</td>
              <td className="p-3 font-mono text-lg font-bold text-[var(--brand-red)]">{z.value}</td>
              <td className="p-3 text-sm">{z.elements}</td>
              <td className="p-3 text-xs text-black/60">{z.reasoning}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Breakpoints Table
function BreakpointsTable() {
  const breakpoints = [
    { name: 'sm', width: '640px', usage: 'Tablet portrait', example: 'sm:grid-cols-2' },
    { name: 'md', width: '768px', usage: 'Tablet landscape', example: 'md:grid-cols-3' },
    { name: 'lg', width: '1024px', usage: 'Desktop', example: 'lg:grid-cols-4' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Breakpoint</th>
            <th className="text-left p-3 text-sm font-bold">Min Width</th>
            <th className="text-left p-3 text-sm font-bold">Device</th>
            <th className="text-left p-3 text-sm font-bold">Example</th>
          </tr>
        </thead>
        <tbody>
          {breakpoints.map((bp) => (
            <tr key={bp.name} className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">{bp.name}:</td>
              <td className="p-3 text-sm">{bp.width}</td>
              <td className="p-3 text-sm">{bp.usage}</td>
              <td className="p-3 font-mono text-xs">{bp.example}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Centering Demo
function CenteringDemo() {
  return (
    <div className="space-y-6">
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm mb-4">Content Centering (Max-Width + Margin Auto)</p>
        <div className="h-32 bg-gradient-to-r from-black/5 to-black/10 rounded-[5px] flex items-center justify-center">
          <div className="max-w-[600px] w-full bg-green-500/20 border-2 border-green-500 rounded-[5px] p-4">
            <p className="font-mono text-xs text-center">max-width: 600px; margin: 0 auto;</p>
          </div>
        </div>
        <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono mt-4">
          .container {'{'}
          <br/>&nbsp;&nbsp;max-width: 1000px;
          <br/>&nbsp;&nbsp;margin: 0 auto;
          <br/>{'}'}
        </code>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm mb-4">Flex Centering (Hero, Modals)</p>
        <div className="h-32 bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-[5px] flex items-center justify-center">
          <div className="bg-purple-500/20 border-2 border-purple-500 rounded-[5px] p-4">
            <p className="font-mono text-xs">Centered Both Ways</p>
          </div>
        </div>
        <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono mt-4">
          display: flex;<br/>
          align-items: center;<br/>
          justify-content: center;
        </code>
      </div>
    </div>
  );
}

// Sticky Demo
function StickyDemo() {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
      <p className="font-mono text-sm mb-4">Sticky Positioning Hierarchy</p>
      <div className="space-y-3">
        <div className="bg-black text-white p-4 rounded-[5px]">
          <p className="font-mono text-xs">Navbar: sticky top-0 z-40</p>
        </div>
        <div className="bg-gray-800 text-white p-4 rounded-[5px] ml-4">
          <p className="font-mono text-xs">Tab Nav: sticky top-[73px] z-30</p>
        </div>
        <div className="bg-gray-200 p-4 rounded-[5px] ml-8">
          <p className="font-mono text-xs">Scrollable Content</p>
        </div>
      </div>
      <code className="block bg-black/5 rounded-[5px] p-3 text-xs font-mono mt-4">
        {`/* Navbar */
position: sticky;
top: 0;
z-index: 40;

/* Tabs below navbar */
position: sticky;
top: 73px; /* Height of navbar */
z-index: 30;`}
      </code>
    </div>
  );
}

// Button Variant Card
function ButtonVariantCard({ variant, title, why, what, when, where }: any) {
  const isDark = variant === 'ghost';
  
  return (
    <div className={`border border-black/8 rounded-[10px] p-6 ${isDark ? 'bg-black' : 'bg-white'}`}>
      <p className={`font-semibold text-lg mb-3 ${isDark ? 'text-white' : 'text-black'}`}>
        {title}
      </p>
      <div className="space-y-2 mb-4">
        <p className={`text-xs ${isDark ? 'text-white/70' : 'text-black/70'}`}>
          <strong className={isDark ? 'text-white/90' : 'text-black/90'}>WHY:</strong> {why}
        </p>
        <p className={`text-xs ${isDark ? 'text-white/70' : 'text-black/70'}`}>
          <strong className={isDark ? 'text-white/90' : 'text-black/90'}>WHAT:</strong> {what}
        </p>
        <p className={`text-xs ${isDark ? 'text-white/70' : 'text-black/70'}`}>
          <strong className={isDark ? 'text-white/90' : 'text-black/90'}>WHEN:</strong> {when}
        </p>
        <p className={`text-xs ${isDark ? 'text-white/60' : 'text-black/60'}`}>
          <strong className={isDark ? 'text-white/80' : 'text-black/80'}>WHERE:</strong> {where}
        </p>
      </div>
      <Button variant={variant} size="md">
        {title} Button
      </Button>
    </div>
  );
}

// Button Size Table
function ButtonSizeTable() {
  const sizes = [
    { size: 'sm', height: '40px', padding: '20px', font: '14px', minWidth: '80px', usage: 'Compact spaces, mobile' },
    { size: 'md', height: '48px', padding: '28px', font: '16px', minWidth: '112px', usage: 'Standard, most common ⭐' },
    { size: 'lg', height: '56px', padding: '36px', font: '16px', minWidth: '144px', usage: 'Hero, emphasis ⭐' },
    { size: 'xl', height: '64px', padding: '40px', font: '18px', minWidth: '-', usage: 'Extra emphasis (rare)' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Size</th>
            <th className="text-left p-3 text-sm font-bold">Height</th>
            <th className="text-left p-3 text-sm font-bold">Padding X</th>
            <th className="text-left p-3 text-sm font-bold">Font Size</th>
            <th className="text-left p-3 text-sm font-bold">Min Width</th>
            <th className="text-left p-3 text-sm font-bold">Usage</th>
          </tr>
        </thead>
        <tbody>
          {sizes.map((s) => (
            <tr key={s.size} className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">{s.size}</td>
              <td className="p-3 text-sm">{s.height}</td>
              <td className="p-3 text-sm">{s.padding}</td>
              <td className="p-3 text-sm">{s.font}</td>
              <td className="p-3 text-sm">{s.minWidth}</td>
              <td className="p-3 text-sm">{s.usage}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StateDemo({ state, description, children }: any) {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 text-center">
      <div className="mb-3">{children}</div>
      <p className="font-mono text-sm font-bold mb-1">{state}</p>
      <p className="text-xs text-black/60">{description}</p>
    </div>
  );
}

function RippleDemo() {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-8">
      <div className="text-center mb-6">
        <Button variant="primary" size="lg">
          Click Me to See Ripple
        </Button>
      </div>
      <CodeExample code={`// Ripple Effect Specs:
- Duration: 600ms
- Animation: Expand from 0 to 4× button size
- Opacity: 1 → 0 (fade out)
- Color: White 30% (dark buttons), Black 10% (light buttons)
- Auto-remove: setTimeout after 600ms

// Implementation in Button.tsx:
const createRipple = (event) => {
  const size = Math.max(button.width, button.height);
  const x = event.clientX - rect.left - size / 2;
  const y = event.clientY - rect.top - size / 2;
  
  // Create ripple element
  // Animate 600ms
  // Remove after animation
};`} />
    </div>
  );
}

// Icon Size Table
function IconSizeTable() {
  const sizes = [
    { size: '14-16px', usage: 'Inline text, list bullets', example: 'ChevronRight in capability lists' },
    { size: '18-20px', usage: 'Standard buttons, navbar actions', example: 'Search icon, ChevronDown' },
    { size: '24px+', usage: 'Mobile menu, modal close buttons', example: 'Menu hamburger, X close icon' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Size Range</th>
            <th className="text-left p-3 text-sm font-bold">Usage Context</th>
            <th className="text-left p-3 text-sm font-bold">Example</th>
          </tr>
        </thead>
        <tbody>
          {sizes.map((s) => (
            <tr key={s.size} className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">{s.size}</td>
              <td className="p-3 text-sm">{s.usage}</td>
              <td className="p-3 text-xs text-black/60">{s.example}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StrokeWidthDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 text-center">
        <ChevronDown size={32} strokeWidth={1.5} className="mx-auto mb-3" />
        <p className="font-mono text-sm mb-1">Thin (1.5px)</p>
        <p className="text-xs text-black/60">Delicate, scroll indicators</p>
      </div>
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 text-center">
        <Search size={32} strokeWidth={2} className="mx-auto mb-3" />
        <p className="font-mono text-sm mb-1">Standard (2px) ⭐</p>
        <p className="text-xs text-black/60">Default for most icons</p>
      </div>
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 text-center">
        <ChevronRight size={32} strokeWidth={2.5} className="mx-auto mb-3" />
        <p className="font-mono text-sm mb-1">Bold (2.5px)</p>
        <p className="text-xs text-black/60">Emphasis, list bullets</p>
      </div>
    </div>
  );
}

// Animation Layers Table
function AnimationLayersTable() {
  const layers = [
    { layer: 'Layer 1: Micro', duration: '100-200ms', easing: 'ease', usage: 'Link color changes, icon transforms, small state changes', example: 'InlineLink underline (200ms)' },
    { layer: 'Layer 2: Short', duration: '200-300ms', easing: 'ease', usage: 'Button backgrounds, shadow changes, border colors', example: 'Button gradient shift (300ms)' },
    { layer: 'Layer 3: Medium', duration: '300-600ms', easing: 'ease-out', usage: 'Card hovers, scroll reveals, component transitions', example: 'Fade-in on scroll (600ms)' },
    { layer: 'Layer 4: Ripple', duration: '600ms', easing: 'ease-out', usage: 'Click feedback, emphasis animations', example: 'Button ripple effect (600ms)' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Layer</th>
            <th className="text-left p-3 text-sm font-bold">Duration</th>
            <th className="text-left p-3 text-sm font-bold">Easing</th>
            <th className="text-left p-3 text-sm font-bold">Usage</th>
            <th className="text-left p-3 text-sm font-bold">Example</th>
          </tr>
        </thead>
        <tbody>
          {layers.map((layer) => (
            <tr key={layer.layer} className="border-b border-black/8">
              <td className="p-3 font-semibold text-sm">{layer.layer}</td>
              <td className="p-3 font-mono font-bold text-[var(--brand-red)]">{layer.duration}</td>
              <td className="p-3 font-mono text-sm">{layer.easing}</td>
              <td className="p-3 text-sm">{layer.usage}</td>
              <td className="p-3 text-xs text-black/60">{layer.example}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Easing Demo
function EasingDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm font-bold mb-3">ease (default)</p>
        <p className="text-xs text-black/60 mb-4">Slow start, fast middle, slow end. Most natural for transitions.</p>
        <div className="h-2 bg-black/10 rounded-full mb-2">
          <div className="h-full bg-[var(--brand-red)] rounded-full w-3/4 transition-all duration-1000 ease"></div>
        </div>
        <code className="block text-[10px] font-mono">transition: all 0.3s ease;</code>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm font-bold mb-3">ease-out</p>
        <p className="text-xs text-black/60 mb-4">Fast start, slow end. Best for entrances and reveals.</p>
        <div className="h-2 bg-black/10 rounded-full mb-2">
          <div className="h-full bg-blue-500 rounded-full w-3/4 transition-all duration-1000 ease-out"></div>
        </div>
        <code className="block text-[10px] font-mono">transition: all 0.6s ease-out;</code>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-sm font-bold mb-3">easeOutCubic</p>
        <p className="text-xs text-black/60 mb-4">Custom cubic: 1 - (1 - t)³. Used for counter animations.</p>
        <div className="h-2 bg-black/10 rounded-full mb-2">
          <div className="h-full bg-green-500 rounded-full w-3/4 transition-all duration-1000 cubic-bezier(0.33, 1, 0.68, 1)"></div>
        </div>
        <code className="block text-[10px] font-mono">easing: (t) =&gt; 1 - Math.pow(1 - t, 3)</code>
      </div>
    </div>
  );
}

// Hover Effects Demo
function HoverEffectsDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 hover:border-black/30 transition-all duration-300">
        <p className="font-mono text-sm font-bold mb-3">Border Darken</p>
        <p className="text-xs text-black/60">Border opacity: 8% → 30%</p>
        <p className="text-xs text-black/50 mt-2">Duration: 300ms</p>
      </div>

      <div className="bg-white border border-black/8 rounded-[10px] p-6 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
        <p className="font-mono text-sm font-bold mb-3">Card Lift</p>
        <p className="text-xs text-black/60">Transform: translateY(-4px)</p>
        <p className="text-xs text-black/50 mt-2">Shadow increases</p>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6 hover:bg-black/[0.04] transition-all duration-300">
        <p className="font-mono text-sm font-bold mb-3">BG Lighten</p>
        <p className="text-xs text-black/60">Background: 2% → 4% opacity</p>
        <p className="text-xs text-black/50 mt-2">Subtle color shift</p>
      </div>
    </div>
  );
}

// Scroll Animation Demo
function ScrollAnimationDemo() {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-8">
      <div className="space-y-4 mb-6">
        <div className="bg-white border border-black/8 rounded-[10px] p-4 opacity-100">
          <p className="font-mono text-sm">Card 1: Already visible</p>
        </div>
        <div className="bg-white border border-black/8 rounded-[10px] p-4 opacity-70">
          <p className="font-mono text-sm">Card 2: Fading in...</p>
        </div>
        <div className="bg-white border border-black/8 rounded-[10px] p-4 opacity-40">
          <p className="font-mono text-sm">Card 3: About to appear...</p>
        </div>
      </div>
      <CodeExample code={`// Scroll Animation Specs:
- Opacity: 0 → 1
- Transform: translateY(20px) → translateY(0)
- Duration: 600ms
- Easing: ease-out
- Trigger: IntersectionObserver (10% threshold)
- Stagger: 100ms delay between cards

// Implementation with useScrollAnimation hook:
const ref = useScrollAnimation();

<div ref={ref} className="opacity-0 translate-y-5">
  {/* Content fades in when scrolled into view */}
</div>`} />
    </div>
  );
}

// Counter Demo
function CounterDemo() {
  return (
    <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-8">
      <div className="text-center mb-6">
        <p className="text-5xl font-bold text-[var(--green-600)] mb-2">₹110 Cr</p>
        <p className="text-sm text-black/60">Counts from 0 → 110 over 2 seconds</p>
      </div>
      <CodeExample code={`// Counter Animation Specs:
- Duration: 2000ms
- Easing: easeOutCubic
- Start value: 0
- End value: Parsed from metric text
- Trigger: Scroll into view

// Easing Function:
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

// Implementation with useCounter hook:
const count = useCounter(110, {
  duration: 2000,
  easing: 'easeOutCubic'
});

return <span>₹{count} Cr</span>;`} />
    </div>
  );
}

// Ripple Code Example
function RippleCodeExample() {
  return (
    <CodeExample code={`// Ripple Effect Implementation:

// 1. Calculate ripple size and position
const rect = button.getBoundingClientRect();
const size = Math.max(rect.width, rect.height);
const x = event.clientX - rect.left - size / 2;
const y = event.clientY - rect.top - size / 2;

// 2. Create ripple element
const ripple = {
  x, y, size,
  key: Date.now()
};

// 3. Add to state (renders with CSS animation)
setRipples(prev => [...prev, ripple]);

// 4. Auto-remove after 600ms
setTimeout(() => {
  setRipples(prev => prev.filter(r => r.key !== ripple.key));
}, 600);

// 5. CSS Animation:
@keyframes ripple {
  0% {
    transform: scale(0);
    opacity: 1;
  }
  100% {
    transform: scale(4);
    opacity: 0;
  }
}

// 6. Ripple colors:
- Dark buttons (primary/brand): rgba(255, 255, 255, 0.3)
- Light buttons (secondary): rgba(0, 0, 0, 0.1)`} />
  );
}

// Background Themes Grid
function BackgroundThemesGrid() {
  const themes = [
    { id: 'multi-color-sophisticated', name: 'Multi-Color Sophisticated', usage: 'Client Context (default) ⭐' },
    { id: 'objectives-energy', name: 'Objectives Energy', usage: 'Strategic goals ⭐' },
    { id: 'growth-impact', name: 'Growth Impact', usage: 'Metrics, results ⭐' },
    { id: 'hero-dark', name: 'Hero Dark', usage: 'Bold dark hero ⭐' },
    { id: 'hero-light', name: 'Hero Light', usage: 'Elegant light hero' },
    { id: 'hero-pure-black', name: 'Hero Pure Black', usage: 'Ultra-minimal 🆕' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {themes.map((theme) => (
        <div key={theme.id} className="border border-black/8 rounded-[10px] overflow-hidden">
          <div className="h-40 bg-gray-100 flex items-center justify-center">
            <p className="font-mono text-xs text-black/40">Preview: {theme.name}</p>
          </div>
          <div className="p-4 bg-white">
            <p className="font-mono text-sm mb-1">{theme.name}</p>
            <p className="text-xs text-black/60 mb-3">{theme.usage}</p>
            <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
              &lt;BackgroundHighlight theme="{theme.id}" /&gt;
            </code>
          </div>
        </div>
      ))}
    </div>
  );
}

// Solid Backgrounds Demo
function SolidBackgroundsDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="border border-black/8 rounded-[10px] overflow-hidden">
        <div className="h-32" style={{ background: '#f5f2f1' }}></div>
        <div className="p-4 bg-white">
          <p className="font-mono text-sm mb-1">Warm 300</p>
          <p className="text-xs text-black/60 mb-2">Challenges section</p>
          <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
            background: var(--warm-300);
          </code>
        </div>
      </div>

      <div className="border border-black/8 rounded-[10px] overflow-hidden">
        <div className="h-32" style={{ background: '#f9f7f6' }}></div>
        <div className="p-4 bg-white">
          <p className="font-mono text-sm mb-1">Warm 200</p>
          <p className="text-xs text-black/60 mb-2">Methodology section</p>
          <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
            background: var(--warm-200);
          </code>
        </div>
      </div>

      <div className="border border-black/8 rounded-[10px] overflow-hidden">
        <div className="h-32" style={{ background: '#fefdfd' }}></div>
        <div className="p-4 bg-white">
          <p className="font-mono text-sm mb-1">Warm 50</p>
          <p className="text-xs text-black/60 mb-2">Final CTA section</p>
          <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
            background: var(--warm-50);
          </code>
        </div>
      </div>
    </div>
  );
}

// Border Radius Demo
function BorderRadiusDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <div className="w-full h-24 bg-[var(--brand-red)] mb-4" style={{ borderRadius: '2.5px' }}></div>
        <p className="font-mono text-sm mb-1">2.5px</p>
        <p className="text-xs text-black/60 mb-2">Images, logos, thumbnails</p>
        <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
          border-radius: 2.5px;
        </code>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <div className="w-full h-24 bg-[var(--brand-red)] mb-4" style={{ borderRadius: '5px' }}></div>
        <p className="font-mono text-sm mb-1">5px ⭐</p>
        <p className="text-xs text-black/60 mb-2">Buttons, inputs, small cards</p>
        <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
          border-radius: 5px;
        </code>
      </div>

      <div className="bg-black/[0.02] border border-black/8 rounded-[10px] p-6">
        <div className="w-full h-24 bg-[var(--brand-red)] mb-4" style={{ borderRadius: '10px' }}></div>
        <p className="font-mono text-sm mb-1">10px</p>
        <p className="text-xs text-black/60 mb-2">Big cards, modals, containers</p>
        <code className="block bg-black/5 rounded-[5px] px-2 py-1 text-[10px] font-mono">
          border-radius: 10px;
        </code>
      </div>
    </div>
  );
}

// Card Hover Demo
function CardHoverDemo() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="group bg-black/[0.02] hover:bg-black/[0.025] border border-black/8 hover:border-black/20 rounded-[10px] p-6 transition-all duration-300">
        <p className="font-mono text-sm mb-2">Subtle Color Shift</p>
        <p className="text-xs text-black/60">Background: 2% → 2.5%<br/>Border: 8% → 20%<br/>Duration: 300ms</p>
      </div>

      <div className="group bg-black/[0.02] border border-black/8 rounded-[10px] p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
        <p className="font-mono text-sm mb-2">Lift Effect</p>
        <p className="text-xs text-black/60">Transform: translateY(-4px)<br/>Shadow increases<br/>Duration: 300ms</p>
      </div>
    </div>
  );
}

// ============================================================================
// NEW COLOR HELPER COMPONENTS
// ============================================================================

// Color Scale Section - Complete Palettes
function ColorScaleSection() {
  const colorScales = {
    warm: [
      { shade: '50', hex: '#fdfcfc', usage: 'Lightest backgrounds' },
      { shade: '100', hex: '#fbf9f8', usage: 'Section backgrounds' },
      { shade: '200', hex: '#f9f7f6', usage: 'Card backgrounds' },
      { shade: '300', hex: '#f5f2f1', usage: 'Challenge backgrounds' },
      { shade: '400', hex: '#ede9e7', usage: 'Subtle emphasis' },
      { shade: '500', hex: '#d4ccc8', usage: 'Border colors' },
      { shade: '600', hex: '#b3a7a0', usage: 'Secondary borders' },
      { shade: '700', hex: '#8b7f77', usage: 'Disabled states' },
      { shade: '800', hex: '#5d544e', usage: 'Subtle text' },
      { shade: '900', hex: '#3d352f', usage: 'Dark accents' },
    ],
    red: [
      { shade: '50', hex: '#fef2f2', usage: 'Error backgrounds' },
      { shade: '100', hex: '#fee2e2', usage: 'Alert backgrounds' },
      { shade: '200', hex: '#fecaca', usage: 'Warning highlights' },
      { shade: '300', hex: '#fca5a5', usage: 'Light error states' },
      { shade: '400', hex: '#f87171', usage: 'Error indicators' },
      { shade: '500', hex: '#ef4444', usage: 'Standard error' },
      { shade: '600', hex: '#dc2626', usage: 'Critical alerts' },
      { shade: '700', hex: '#b91c1c', usage: 'Destructive actions' },
      { shade: '800', hex: '#991b1b', usage: 'Dark error states' },
      { shade: '900', hex: '#7f1d1d', usage: 'Deep error' },
    ],
    purple: [
      { shade: '50', hex: '#faf5ff', usage: 'Purple tint' },
      { shade: '100', hex: '#f3e8ff', usage: 'Light purple bg' },
      { shade: '200', hex: '#e9d5ff', usage: 'Soft purple' },
      { shade: '300', hex: '#d8b4fe', usage: 'Accent purple' },
      { shade: '400', hex: '#c084fc', usage: 'Medium purple' },
      { shade: '500', hex: '#a855f7', usage: 'Brand purple' },
      { shade: '600', hex: '#9333ea', usage: 'Strong purple' },
      { shade: '700', hex: '#7e22ce', usage: 'Deep purple' },
      { shade: '800', hex: '#6b21a8', usage: 'Dark purple' },
      { shade: '900', hex: '#581c87', usage: 'Darkest purple' },
    ],
  };

  return (
    <div className="space-y-8">
      {Object.entries(colorScales).map(([name, shades]) => (
        <div key={name}>
          <h3 className="font-semibold text-lg mb-4 capitalize">{name} Scale</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-2">
            {shades.map((shade) => (
              <div key={shade.shade} className="group">
                <div 
                  className="h-20 rounded-[5px] border border-black/8 group-hover:scale-105 transition-transform cursor-pointer"
                  style={{ backgroundColor: shade.hex }}
                  onClick={() => navigator.clipboard.writeText(shade.hex)}
                />
                <p className="font-mono text-xs mt-2 font-bold">{shade.shade}</p>
                <p className="font-mono text-[10px] text-black/60">{shade.hex}</p>
                <p className="text-[10px] text-black/50 mt-1">{shade.usage}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// Background Colors Demo
function BackgroundColorsDemo() {
  const backgrounds = [
    { name: 'White', value: '#ffffff', usage: 'Default, Hero, most sections', contrast: '21:1' },
    { name: 'Warm 50', value: '#fdfcfc', usage: 'About This Case Study', contrast: '21:1' },
    { name: 'Warm 100', value: '#fbf9f8', usage: 'Methodology sections', contrast: '20.8:1' },
    { name: 'Warm 200', value: '#f9f7f6', usage: 'Approach section', contrast: '20.5:1' },
    { name: 'Warm 300', value: '#f5f2f1', usage: 'Challenges section', contrast: '20.1:1' },
    { name: 'Warm 400', value: '#ede9e7', usage: 'Subtle emphasis', contrast: '19.2:1' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {backgrounds.map((bg) => (
        <div key={bg.name} className="border border-black/8 rounded-[10px] overflow-hidden">
          <div className="h-32" style={{ backgroundColor: bg.value }}></div>
          <div className="p-4 bg-white">
            <p className="font-semibold text-sm mb-1">{bg.name}</p>
            <p className="font-mono text-xs text-black/60 mb-2">{bg.value}</p>
            <p className="text-xs text-black/70 mb-2">{bg.usage}</p>
            <p className="text-xs text-black/50">Contrast: {bg.contrast}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// Border Colors Demo
function BorderColorsDemo() {
  const borders = [
    { name: 'Ultra Subtle', value: 'rgba(0,0,0,0.05)', opacity: '5%', usage: 'Very subtle dividers' },
    { name: 'Subtle', value: 'rgba(0,0,0,0.08)', opacity: '8%', usage: 'Card outlines, default borders ⭐' },
    { name: 'Standard', value: 'rgba(0,0,0,0.10)', opacity: '10%', usage: 'Section dividers, hover states' },
    { name: 'Emphasis', value: 'rgba(0,0,0,0.15)', opacity: '15%', usage: 'Input borders, active states' },
    { name: 'Strong', value: 'rgba(0,0,0,0.20)', opacity: '20%', usage: 'Focus states, important dividers' },
    { name: 'Very Strong', value: 'rgba(0,0,0,0.30)', opacity: '30%', usage: 'High emphasis borders' },
  ];

  return (
    <div className="space-y-4">
      {borders.map((border) => (
        <div key={border.name} className="flex items-center gap-6 p-4 bg-white rounded-[5px]">
          <div 
            className="w-48 h-12 rounded-[5px] border-2"
            style={{ borderColor: border.value }}
          ></div>
          <div className="flex-1">
            <p className="font-semibold text-sm">{border.name}</p>
            <p className="font-mono text-xs text-black/60">{border.opacity}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-black/70">{border.usage}</p>
            <code className="text-[10px] font-mono text-black/50">{border.value}</code>
          </div>
        </div>
      ))}
    </div>
  );
}

// Color Accessibility Matrix
function ColorAccessibilityMatrix() {
  const matrix = [
    { text: 'Primary (90%)', bg: 'White', contrast: '17.1:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Primary (90%)', bg: 'Warm 50', contrast: '17.1:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Primary (90%)', bg: 'Warm 100', contrast: '16.8:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Secondary (70%)', bg: 'White', contrast: '11.4:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Secondary (70%)', bg: 'Warm 50', contrast: '11.3:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Tertiary (60%)', bg: 'White', contrast: '8.9:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Tertiary (60%)', bg: 'Warm 100', contrast: '8.7:1', wcag: 'AAA', rating: 'Excellent' },
    { text: 'Subtle (45%)', bg: 'White', contrast: '5.9:1', wcag: 'AA', rating: 'Good (large text)' },
    { text: 'Brand Red', bg: 'White', contrast: '4.54:1', wcag: 'AA', rating: 'Good (18px+)' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-black/20">
            <th className="text-left p-3 text-sm font-bold">Text Color</th>
            <th className="text-left p-3 text-sm font-bold">Background</th>
            <th className="text-left p-3 text-sm font-bold">Contrast</th>
            <th className="text-left p-3 text-sm font-bold">WCAG Level</th>
            <th className="text-left p-3 text-sm font-bold">Rating</th>
          </tr>
        </thead>
        <tbody>
          {matrix.map((item, idx) => (
            <tr key={idx} className="border-b border-black/8">
              <td className="p-3 text-sm">{item.text}</td>
              <td className="p-3 text-sm">{item.bg}</td>
              <td className="p-3 font-mono font-bold">{item.contrast}</td>
              <td className="p-3">
                <span className={`inline-block px-2 py-1 rounded-[3px] text-xs font-bold ${
                  item.wcag === 'AAA' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                }`}>
                  {item.wcag}
                </span>
              </td>
              <td className="p-3 text-xs text-black/60">{item.rating}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================================================================
// TYPOGRAPHY HELPER COMPONENTS
// ============================================================================

function FontWeightDemo() {
  const weights = [
    { weight: 400, name: 'Normal', usage: 'Body text', example: 'This is regular body text for comfortable reading.' },
    { weight: 500, name: 'Medium', usage: 'Emphasis', example: 'This is medium weight for subtle emphasis.' },
    { weight: 700, name: 'Bold', usage: 'Headings', example: 'This is bold weight for strong hierarchy.' },
  ];

  return (
    <div className="space-y-4">
      {weights.map((w) => (
        <div key={w.weight} className="border border-black/8 rounded-[10px] p-6">
          <div className="flex items-center justify-between mb-3">
            <p className="font-mono text-sm"><strong>Weight:</strong> {w.weight} ({w.name})</p>
            <p className="text-xs text-black/60">{w.usage}</p>
          </div>
          <p style={{ fontWeight: w.weight }} className="text-base">{w.example}</p>
        </div>
      ))}
    </div>
  );
}

function FontFamilyComparison() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: 'DM Sans', sans-serif</p>
        <h3 style={{ fontFamily: 'DM Sans, sans-serif' }} className="text-2xl mb-3">DM Sans Heading</h3>
        <p style={{ fontFamily: 'DM Sans, sans-serif' }} className="text-sm mb-4">
          Geometric sans-serif. Clean, modern, perfect for UI elements.
        </p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> Navigation, buttons, labels</p>
      </div>

      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: 'Noto Serif', serif</p>
        <h3 style={{ fontFamily: 'Noto Serif, serif' }} className="text-2xl mb-3">Noto Serif Heading</h3>
        <p style={{ fontFamily: 'Noto Serif, serif' }} className="text-sm mb-4">
          Humanist serif. Warm, editorial, perfect for storytelling.
        </p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> Headings, body paragraphs</p>
      </div>
    </div>
  );
}

function RealTextExamples() {
  const examples = [
    { size: '48.8px', text: 'Revolutionizing Global Communications', usage: 'Hero H1' },
    { size: '39px', text: 'Client Context: Understanding the Problem', usage: 'Section H2' },
    { size: '31.25px', text: 'Primary Research & Discovery Phase', usage: 'Subsection H3' },
    { size: '20px', text: 'Challenge Overview Card Title', usage: 'Card Heading' },
    { size: '16px', text: 'Body text describing project details, methodology, and outcomes.', usage: 'Body Paragraph' },
    { size: '12.8px', text: 'CASE STUDY • DESIGN SYSTEM', usage: 'Section Label' },
  ];

  return (
    <div className="space-y-6">
      {examples.map((ex, idx) => (
        <div key={idx} className="border-l-4 border-[var(--brand-red)] pl-6 py-3">
          <div className="flex items-center gap-3 mb-2">
            <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded-[3px]">{ex.size}</code>
            <span className="text-xs text-black/50">• {ex.usage}</span>
          </div>
          <p style={{ fontSize: ex.size }}>{ex.text}</p>
        </div>
      ))}
    </div>
  );
}

function HeadingHierarchy() {
  return (
    <div className="space-y-6">
      <div className="border border-black/8 rounded-[10px] p-8 bg-white">
        <h1 style={{ fontSize: 'var(--text-3xl)' }} className="mb-6">H1: Hero Heading (48.8px)</h1>
        <div className="pl-6 border-l-2 border-black/10">
          <h2 style={{ fontSize: 'var(--text-2xl)' }} className="mb-4">H2: Section Heading (39px)</h2>
          <div className="pl-6 border-l-2 border-black/10">
            <h3 style={{ fontSize: 'var(--text-xl)' }} className="mb-3">H3: Subsection (31.25px)</h3>
            <p style={{ fontSize: 'var(--text-sm)' }} className="text-black/70">Body text at 16px.</p>
          </div>
        </div>
      </div>

      <div className="bg-black/[0.02] rounded-[10px] p-6">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-black/20">
              <th className="text-left p-3 text-sm font-bold">Level</th>
              <th className="text-left p-3 text-sm font-bold">Size</th>
              <th className="text-left p-3 text-sm font-bold">Usage</th>
              <th className="text-left p-3 text-sm font-bold">Frequency</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">H1</td>
              <td className="p-3 text-sm">48.8px</td>
              <td className="p-3 text-sm">Hero, Final CTA</td>
              <td className="p-3 text-xs text-black/60">1-2× per page</td>
            </tr>
            <tr className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">H2</td>
              <td className="p-3 text-sm">39px</td>
              <td className="p-3 text-sm">Major sections ⭐</td>
              <td className="p-3 text-xs text-black/60">5-8× per page</td>
            </tr>
            <tr>
              <td className="p-3 font-mono font-bold">H3</td>
              <td className="p-3 text-sm">31.25px</td>
              <td className="p-3 text-sm">Subsections</td>
              <td className="p-3 text-xs text-black/60">10-15× per page</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ResponsiveTypographyDemo() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/[0.02] rounded-[10px] p-6">
          <h4 className="font-semibold mb-4">Mobile (&lt; 768px)</h4>
          <div className="space-y-2 text-sm">
            <p>• Hero (H1): 36px</p>
            <p>• Section (H2): 28px</p>
            <p>• Subsection (H3): 24px</p>
          </div>
        </div>

        <div className="bg-black/[0.02] rounded-[10px] p-6">
          <h4 className="font-semibold mb-4">Desktop (≥ 768px)</h4>
          <div className="space-y-2 text-sm">
            <p>• Hero (H1): 48.8px ⭐</p>
            <p>• Section (H2): 39px ⭐</p>
            <p>• Subsection (H3): 31.25px</p>
          </div>
        </div>
      </div>

      <CodeExample code={`// Responsive Typography:\n@media (max-width: 767px) {\n  h1 { font-size: 36px; }\n  h2 { font-size: 28px; }\n}\n\n@media (min-width: 768px) {\n  h1 { font-size: 48.8px; }\n  h2 { font-size: 39px; }\n}`} />
    </div>
  );
}
