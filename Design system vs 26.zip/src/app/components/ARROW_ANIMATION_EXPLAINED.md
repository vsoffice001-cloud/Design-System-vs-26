# ARROW ANIMATION - COMPLETE TECHNICAL EXPLANATION

**Source:** External documentation for CSS-based arrow animation on buttons  
**Purpose:** Understanding the mechanics behind the diagonal arrow animation for urgency CTAs  
**Date Saved:** February 2, 2026

---

## TABLE OF CONTENTS

1. [Conceptual Overview](#conceptual-overview)
2. [HTML Structure](#html-structure)
3. [CSS Implementation](#css-implementation)
4. [Key Techniques](#key-techniques)
5. [Customization Tips](#customization-tips)
6. [Full Code Example](#full-code-example)
7. [Browser Compatibility](#browser-compatibility)

---

## 1. CONCEPTUAL OVERVIEW

### What Happens Visually

**Default State (No Hover):**
- Button shows text (e.g., "Submit") followed by a single arrow icon
- Horizontally aligned and centered vertically
- Second arrow is hidden (opacity: 0, positioned off-screen or overlapped)

**On Hover:**
- **First arrow:** Animates diagonally upward-right (45 degrees) while fading out (opacity → 0)
  - Creates a "flying away" or "progressing forward" feel
- **Second arrow:** Simultaneously fades in (opacity → 1) and slides into exact position of original arrow
  - Starts from slightly offset position (e.g., bottom-left) to mimic emergence
  - Creates seamless "replacement" effect

**On Hover Release (Mouse Leave):**
- **First arrow:** Reverses back to original position, fades in (opacity → 1)
- **Second arrow:** Fades out (opacity → 0), moves back to hidden offset position

### Why Two Arrows?

Using duplicates allows independent control over each element's movement and opacity, avoiding glitches in single-element animations (no need for keyframes that reset abruptly).

### Timing & Easing

- **Duration:** Typically 0.3-0.5 seconds
- **Easing:** `ease-in-out` for natural feel
- Quick enough to be responsive but smooth to avoid jank

### UX Benefits

- Signals interactivity
- Guides user toward action
- Adds polish without overwhelming the design
- Can be combined with shimmer gradient effect

---

## 2. HTML STRUCTURE

```html
<button class="animated-button">
  <span class="button-text">Submit</span>
  <span class="arrow-wrapper">
    <span class="arrow arrow-primary">→</span> <!-- First arrow (Unicode or SVG) -->
    <span class="arrow arrow-secondary">→</span> <!-- Second identical arrow -->
  </span>
</button>
```

### Structure Explanation

- **Wrapper Purpose:** Keeps arrows stacked or positioned relatively, ensuring they overlap in the same space without affecting text flow
- **Arrow Icon:** Use Unicode arrow (→) for simplicity, or SVG (e.g., from Lucide) for custom designs
- **Ensure both arrows are identical**

---

## 3. CSS IMPLEMENTATION

### Base Button Styles

```css
.animated-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 12px 24px;
  font-family: 'DM Sans', sans-serif;
  font-size: 16px;
  font-weight: 500;
  background-color: #your-brand-color;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.button-text {
  margin-right: 8px; /* Space before arrows */
}
```

### Arrow Wrapper & Positioning

```css
.arrow-wrapper {
  position: relative;
  width: 16px; /* Match arrow size */
  height: 16px;
  display: inline-block;
}

.arrow {
  position: absolute;
  top: 0;
  left: 0;
  font-size: 16px;
  transition: transform 0.4s ease-in-out, opacity 0.4s ease-in-out;
}
```

### Default State

```css
.arrow-primary {
  opacity: 1;
  transform: translate(0, 0) rotate(0deg); /* Horizontal alignment */
}

.arrow-secondary {
  opacity: 0;
  transform: translate(-8px, 4px) rotate(0deg); /* Hidden offset (bottom-left) */
}
```

### Hover State

```css
.animated-button:hover .arrow-primary {
  opacity: 0;
  transform: translate(8px, -8px) rotate(45deg); /* Move right-top at 45deg and fade */
}

.animated-button:hover .arrow-secondary {
  opacity: 1;
  transform: translate(0, 0) rotate(0deg); /* Slide into place and show */
}
```

### Optional: Shimmer Integration

```css
.animated-button:hover {
  background: linear-gradient(90deg, #your-light-tone1, #your-light-tone2);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite linear;
}

@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
```

---

## 4. KEY TECHNIQUES

### CSS Properties Explained

| Property | Purpose |
|----------|---------|
| **Positioning** | `.arrow-wrapper` is relative, arrows are absolute to overlap perfectly |
| **Transform** | Combines `translate` for movement (x/y pixels) and `rotate` for angle |
| **Opacity** | Fades elements in/out for disappearance/appearance |
| **Transition** | Applies to transform and opacity for smooth timing |
| **Reversibility** | CSS transitions automatically reverse on state change (hover → non-hover) |

### Transform Details

- **On Hover:** Primary arrow shifts 8px right and -8px up (creating 45° diagonal) while rotating to match direction
- **45° Angle:** Ensure translate values are equal (e.g., 8px right, -8px up)

---

## 5. CUSTOMIZATION TIPS

### Timing Adjustments

- **Faster (0.2s):** Snappier feel
- **Slower (0.5s+):** More emphasis
- **Stagger:** Use `transition-delay: 0.1s` on secondary arrow for sequence

### Easing Functions

- Standard: `ease-in-out`
- Bouncy: `cubic-bezier(0.4, 0, 0.2, 1)`
- Preview tool: cubic-bezier.com

### Direction/Angle

- **Exact 45°:** Equal translate values (8px right, -8px up)
- **Subtle growth:** Add `scale(1.1)` to transform

### Accessibility

- Add `aria-label` to button (e.g., "Submit Form")
- Ensure high contrast (arrow color vs. background)
- Test with keyboard (`:focus` state can mimic `:hover`)

### Responsive

- Use `em` units for sizes
- Media queries for smaller screens (reduce arrow size on mobile)

### Advanced

- **Looping on hover:** Use `@keyframes` instead of transitions
- **SVG arrows:** Animate `stroke-dashoffset` for drawing effects

---

## 6. FULL CODE EXAMPLE

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Arrow Animation Demo</title>
  <style>
    .animated-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 24px;
      font-family: 'DM Sans', sans-serif;
      font-size: 16px;
      font-weight: 500;
      background-color: #7c3aed;
      color: #fff;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .button-text {
      margin-right: 8px;
    }

    .arrow-wrapper {
      position: relative;
      width: 16px;
      height: 16px;
      display: inline-block;
    }

    .arrow {
      position: absolute;
      top: 0;
      left: 0;
      font-size: 16px;
      transition: transform 0.4s ease-in-out, opacity 0.4s ease-in-out;
    }

    .arrow-primary {
      opacity: 1;
      transform: translate(0, 0) rotate(0deg);
    }

    .arrow-secondary {
      opacity: 0;
      transform: translate(-8px, 4px) rotate(0deg);
    }

    .animated-button:hover .arrow-primary {
      opacity: 0;
      transform: translate(8px, -8px) rotate(45deg);
    }

    .animated-button:hover .arrow-secondary {
      opacity: 1;
      transform: translate(0, 0) rotate(0deg);
    }

    /* Optional Shimmer */
    .animated-button:hover {
      background: linear-gradient(90deg, #8b5cf6, #a78bfa);
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite linear;
    }

    @keyframes shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
  </style>
</head>
<body>
  <button class="animated-button">
    <span class="button-text">Submit</span>
    <span class="arrow-wrapper">
      <span class="arrow arrow-primary">→</span>
      <span class="arrow arrow-secondary">→</span>
    </span>
  </button>
</body>
</html>
```

---

## 7. BROWSER COMPATIBILITY

### Support

- ✅ Modern browsers (Chrome, Firefox, Safari, Edge)
- ✅ CSS3 transforms/transitions (supported since 2010s)

### Fallbacks

- **IE11:** Add vendor prefixes (e.g., `-webkit-transition`)

### Testing Tips

- Use browser dev tools (slow-motion animations via CSS inspector)
- Check on mobile (touch hover is tricky—use `:active` as fallback)
- Tools: CSS Animator or Animate.css for variations

### Performance

- Lightweight (no JS required)
- GPU-accelerated (transform/opacity)
- Avoid over-nesting in loop-heavy pages

---

## KEY TAKEAWAYS FOR OUR DESIGN SYSTEM

1. **Two-Arrow Technique:** Required for smooth diagonal movement without glitches
2. **Transform Properties:** `translate(8px, -8px)` + `rotate(45deg)` creates diagonal motion
3. **Shimmer Compatible:** Can layer shimmer gradient animation in same `:hover` rule
4. **300ms Duration:** Our brand standard aligns with recommended 0.3-0.5s range
5. **Accessibility:** Must include aria-labels and keyboard focus states
6. **Reversible:** CSS transitions auto-reverse on hover release (no extra code needed)

---

**Implementation Status in Our System:**
- ✅ We use hardcoded `<ArrowUpRight>` icons from Lucide
- ✅ Shimmer is always active (separate mechanism)
- ⚠️ Need to verify: Do we use two arrows or CSS-based animation?
- 🔍 Analysis needed: Current Button.tsx implementation vs. this explanation
