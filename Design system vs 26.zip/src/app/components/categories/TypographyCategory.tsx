/**
 * Typography Category - Design System
 * 
 * Complete typography system documentation
 */

import React from 'react';
import { TypeScale } from '@/design-system';
import { CodeBlockWithCopy } from '../CodeBlockWithCopy';
import { CheckCircle2, X, AlertCircle } from 'lucide-react';

export function TypographyCategory() {
  return (
    <div className="max-w-4xl">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-5xl font-bold text-black mb-4">Typography</h1>
        <p className="text-xl text-black/70 leading-relaxed">
          Our typography system uses a Major Third scale (1.25 ratio) with massive, editorial-style headings, 
          generous line-height, and intentional hierarchy to create exceptional readability and visual impact.
        </p>
      </div>

      {/* Philosophy & Principles */}
      <section className="mb-16">
        <div className="bg-black text-white rounded-[10px] p-10">
          <h2 className="text-3xl font-bold mb-6">Philosophy & Principles</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold mb-3">What is the Major Third Type Scale?</h3>
              <p className="text-white/70 leading-relaxed">
                The Major Third scale uses a 1.25 ratio between each size step, creating harmonious proportions 
                inspired by musical intervals. Starting from a 16px base, each step multiplies by 1.25, resulting 
                in sizes that feel naturally balanced and create clear visual hierarchy.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">Why This System Works</h3>
              <ul className="space-y-2 text-white/70">
                <li>• <span className="text-white font-medium">Clear Hierarchy:</span> Each size step is distinct enough to signal importance</li>
                <li>• <span className="text-white font-medium">Editorial Feel:</span> Large headings (48px+) create magazine-quality layouts</li>
                <li>• <span className="text-white font-medium">Readability First:</span> Generous line-heights (1.6 for body) reduce eye strain</li>
                <li>• <span className="text-white font-medium">Scalable:</span> Works consistently from mobile (16px base) to desktop (16px base)</li>
                <li>• <span className="text-white font-medium">Minimalist:</span> Bold/Regular weights only—no semi-bold, no light</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">Core Typography Principles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Massive Headings</div>
                  <div className="text-sm text-white/70">48px minimum for H1 hero sections—go big or go home</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Generous Whitespace</div>
                  <div className="text-sm text-white/70">Line-height 1.6 for body text, 1.2 for large headings</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Two Weights Only</div>
                  <div className="text-sm text-white/70">Bold (700) for headings, Regular (400) for body—nothing in between</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Opacity for Hierarchy</div>
                  <div className="text-sm text-white/70">100% for primary, 70% for body, 60% for captions, 40% for metadata</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Type Scale */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Type Scale</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">10-step scale from 12px to 76px based on 1.25 ratio multiplication</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Mathematical harmony creates natural, balanced spacing between sizes</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Every text element—headings, body, captions, UI labels, metadata</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Always use scale values—never arbitrary font sizes</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Use exact pixel values [48px] or scale names (4xl), never estimate</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Size Selection Decision Tree</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">1</div>
                <div>
                  <div className="font-medium text-black">Identify Content Type</div>
                  <div className="text-sm text-black/60">Hero heading? Section title? Body text? Label? Metadata?</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">2</div>
                <div>
                  <div className="font-medium text-black">Check Hierarchy Level</div>
                  <div className="text-sm text-black/60">Is it the most important thing? Second level? Supporting info?</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">3</div>
                <div>
                  <div className="font-medium text-black">Match to Scale</div>
                  <div className="text-sm text-black/60">Hero = 48px (4xl), Section = 39px (3xl), Body = 16px (base), Caption = 14px (sm), Metadata = 12px (xs)</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">4</div>
                <div>
                  <div className="font-medium text-black">Apply Weight + Opacity</div>
                  <div className="text-sm text-black/60">Bold for headings (font-bold), Regular for body—then use opacity (text-black/70) for further hierarchy</div>
                </div>
              </div>
            </div>
          </div>

          {/* Real-World Scenarios */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Real-World Decision Making</h3>
            <div className="space-y-3">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Landing page hero section</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-medium text-black">Main headline:</span> 48px (4xl) Bold | <span className="font-medium text-black">Subheadline:</span> 20px (lg) Regular with text-black/70</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Blog post layout</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-medium text-black">Article title:</span> 39px (3xl) Bold | <span className="font-medium text-black">Body:</span> 16px (base) Regular/70% | <span className="font-medium text-black">Metadata:</span> 12px (xs)/40%</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Dashboard with data cards</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-medium text-black">Page title:</span> 39px (3xl) Bold | <span className="font-medium text-black">Card titles:</span> 25px (xl) Bold | <span className="font-medium text-black">Metrics:</span> 31px (2xl) Bold | <span className="font-medium text-black">Labels:</span> 14px (sm)/60%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <p className="text-lg text-black/70 mb-8">
          Based on a 1.25 ratio (Major Third) with a 16px base. Each step multiplies by 1.25.
        </p>

        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <TypeScale />
        </div>

        <CodeBlockWithCopy
          language="tsx"
          code={`import { typography } from '@/design-system';

// Typography scale (Major Third - 1.25 ratio)
const scale = {
  xs: '12px',    // 0.75rem
  sm: '14px',    // 0.875rem
  base: '16px',  // 1rem
  lg: '20px',    // 1.25rem
  xl: '25px',    // 1.5625rem
  '2xl': '31px', // 1.953rem
  '3xl': '39px', // 2.441rem
  '4xl': '48px', // 3rem - Hero headings
  '5xl': '61px', // 3.815rem
  '6xl': '76px', // 4.768rem
};`}
        />
      </section>

      {/* Live Examples */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Live Scale Examples</h2>
        
        <div className="bg-white border border-black/10 rounded-[10px] p-8 space-y-8">
          <div>
            <div className="text-xs text-black/40 mb-2">6XL / 76px</div>
            <div className="text-[76px] leading-[1.1] font-bold text-black">Massive Impact</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">5XL / 61px</div>
            <div className="text-[61px] leading-[1.1] font-bold text-black">Large Hero</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">4XL / 48px - Hero Headings</div>
            <div className="text-[48px] leading-[1.2] font-bold text-black">Hero Section Title</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">3XL / 39px</div>
            <div className="text-[39px] leading-[1.2] font-bold text-black">Section Heading</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">2XL / 31px</div>
            <div className="text-[31px] leading-[1.3] font-bold text-black">Subsection Title</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">XL / 25px</div>
            <div className="text-[25px] leading-[1.4] font-bold text-black">Card Heading</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">LG / 20px</div>
            <div className="text-[20px] leading-[1.6] text-black">Large body text for emphasis and readability</div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">BASE / 16px</div>
            <div className="text-base leading-[1.6] text-black/70">
              Standard body text with generous line-height for comfortable reading. 
              This is the foundation of our typographic system.
            </div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">SM / 14px</div>
            <div className="text-sm leading-[1.5] text-black/60">
              Smaller text for captions, labels, and secondary information
            </div>
          </div>

          <div>
            <div className="text-xs text-black/40 mb-2">XS / 12px</div>
            <div className="text-xs leading-[1.4] text-black/40">
              Tiny text for metadata, timestamps, legal copy
            </div>
          </div>
        </div>
      </section>

      {/* Hierarchy System */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Hierarchy Guidelines</h2>
        
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-black mb-3">H1 - Hero Headings</h3>
            <div className="text-[48px] leading-[1.2] font-bold text-black mb-3">
              48px / Bold / 1.2 line-height
            </div>
            <p className="text-sm text-black/60">
              Reserved for hero sections and page titles. One per page maximum.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-3">H2 - Section Headings</h3>
            <div className="text-[39px] leading-[1.2] font-bold text-black mb-3">
              39px / Bold / 1.2 line-height
            </div>
            <p className="text-sm text-black/60">
              Major section dividers. Use to break up long content.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-3">H3 - Subsection Titles</h3>
            <div className="text-[31px] leading-[1.3] font-bold text-black mb-3">
              31px / Bold / 1.3 line-height
            </div>
            <p className="text-sm text-black/60">
              Subsection headers within major sections.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-3">H4 - Card Headings</h3>
            <div className="text-[25px] leading-[1.4] font-bold text-black mb-3">
              25px / Bold / 1.4 line-height
            </div>
            <p className="text-sm text-black/60">
              Card titles, modal headers, prominent labels.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-3">Body Large</h3>
            <div className="text-[20px] leading-[1.6] text-black mb-3">
              20px / Regular / 1.6 line-height
            </div>
            <p className="text-sm text-black/60">
              Emphasized body text, intro paragraphs, callouts.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold text-black mb-3">Body Default</h3>
            <div className="text-base leading-[1.6] text-black/70 mb-3">
              16px / Regular / 1.6 line-height
            </div>
            <p className="text-sm text-black/60">
              Standard body text for most content. Optimized for readability.
            </p>
          </div>
        </div>
      </section>

      {/* Line Height System */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Line Height System</h2>
        <p className="text-lg text-black/70 mb-8">
          Generous line-heights ensure exceptional readability across all text sizes.
        </p>

        <div className="bg-white border border-black/10 rounded-[10px] p-8">
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="text-sm font-bold text-black mb-4">Headings</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">H1, H2</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.2</code>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">H3</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.3</code>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">H4</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.4</code>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-black mb-4">Body Text</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">Large, Base</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.6</code>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">Small</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.5</code>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-black/70">Extra Small</span>
                  <code className="text-sm bg-[#f5f2f1] px-3 py-1 rounded-[5px]">1.4</code>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Font Weight System */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Font Weight System</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">Two weights only—Bold (700) and Regular (400)</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Simplicity creates consistency and prevents design bloat</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Bold for all headings, Regular for all body text</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Never use semi-bold, medium, light, or other intermediate weights</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">font-bold for emphasis, default (Regular) for everything else</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">The Two-Weight Philosophy</h3>
            <p className="text-sm text-black/70 mb-4">
              Limiting to two weights forces intentional hierarchy. Instead of reaching for "semi-bold" to create subtle emphasis, 
              we use size, color opacity, and spacing to communicate importance. This constraint makes designs stronger, not weaker.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mt-6">
              <div className="bg-white rounded-[5px] p-6 border border-black/10">
                <div className="font-bold text-black mb-4">Bold (700) - font-bold</div>
                <div className="space-y-3">
                  <div className="text-[48px] leading-[1.2] font-bold text-black">Hero Heading</div>
                  <div className="text-[31px] leading-[1.3] font-bold text-black">Section Title</div>
                  <div className="text-[20px] leading-[1.4] font-bold text-black">Card Heading</div>
                  <div className="text-base leading-[1.6] font-bold text-black">Emphasized Text</div>
                </div>
                <p className="text-xs text-black/60 mt-4">
                  Use for: All headings (H1-H6), button labels, emphasized inline text, data labels
                </p>
              </div>

              <div className="bg-white rounded-[5px] p-6 border border-black/10">
                <div className="font-bold text-black mb-4">Regular (400) - Default</div>
                <div className="space-y-3">
                  <div className="text-[20px] leading-[1.6] text-black">Large Body Text</div>
                  <div className="text-base leading-[1.6] text-black/70">Standard paragraph with comfortable reading rhythm and generous line-height.</div>
                  <div className="text-sm leading-[1.5] text-black/60">Caption or label text</div>
                  <div className="text-xs leading-[1.4] text-black/40">Metadata, timestamps, legal copy</div>
                </div>
                <p className="text-xs text-black/60 mt-4">
                  Use for: Body text, paragraphs, captions, labels, UI text, links
                </p>
              </div>
            </div>
          </div>

          {/* When to Use Each Weight */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Decision Framework: Bold vs Regular</h3>
            <div className="space-y-3">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Question: Is it a heading or title?</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70">Use <span className="font-bold">Bold</span> (font-bold)</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Question: Does it need to stand out from surrounding text?</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70">Use <span className="font-bold">Bold</span> for inline emphasis, button labels, data labels</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Question: Is it body content meant for reading?</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70">Use <span className="font-medium">Regular</span> (default weight)—then adjust hierarchy with opacity (text-black/70)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Live Examples */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8 space-y-8">
          <div>
            <div className="text-xs text-black/40 mb-3">Bold (700) Examples</div>
            <div className="space-y-4">
              <div className="text-[48px] leading-[1.2] font-bold text-black">48px Bold Hero</div>
              <div className="text-[25px] leading-[1.4] font-bold text-black">25px Bold Card Title</div>
              <div className="text-base">Regular text with <span className="font-bold">bold emphasis</span> inline</div>
            </div>
          </div>

          <div className="border-t border-black/10 pt-8">
            <div className="text-xs text-black/40 mb-3">Regular (400) with Opacity Hierarchy</div>
            <div className="space-y-4">
              <div className="text-[20px] leading-[1.6] text-black">20px Regular at 100% opacity - Primary</div>
              <div className="text-base leading-[1.6] text-black/70">16px Regular at 70% opacity - Body text</div>
              <div className="text-sm leading-[1.5] text-black/60">14px Regular at 60% opacity - Captions</div>
              <div className="text-xs leading-[1.4] text-black/40">12px Regular at 40% opacity - Metadata</div>
            </div>
          </div>
        </div>
      </section>

      {/* Best Practices - Do's and Don'ts */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Best Practices</h2>
        
        <div className="grid grid-cols-2 gap-6">
          {/* Do */}
          <div className="bg-white border border-green-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="size-5 text-green-600" />
              <h4 className="font-bold text-black">Do</h4>
            </div>
            <ul className="space-y-3 text-sm text-black/70">
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Use exact scale values (48px, 39px, 31px, etc.) - never estimate</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Apply font-bold to all headings and important labels</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Use opacity (text-black/70, text-black/60) to create hierarchy</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Maintain 1.6 line-height for body text</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Limit to one H1 per page (48px hero heading)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                <span>Use 16px (base) as default for all body text</span>
              </li>
            </ul>
          </div>

          {/* Don't */}
          <div className="bg-white border border-red-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <X className="size-5 text-red-600" />
              <h4 className="font-bold text-black">Don't</h4>
            </div>
            <ul className="space-y-3 text-sm text-black/70">
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Use arbitrary font sizes (50px, 35px, 18px) outside the scale</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Use semi-bold, medium, light, or other intermediate weights</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Set body text smaller than 16px - hurts readability</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Use tight line-heights (1.0-1.2) for body text</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Have multiple 48px headings competing for attention</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-600 font-bold flex-shrink-0">✗</span>
                <span>Mix Tailwind text utilities (text-2xl) with pixel values - stay consistent</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Usage Examples */}
      <section>
        <h2 className="text-3xl font-bold text-black mb-6">Usage Examples</h2>
        
        <CodeBlockWithCopy
          language="tsx"
          code={`// Hero section
<h1 className="text-[48px] leading-[1.2] font-bold text-black">
  Transform Your Design System
</h1>

// Section heading
<h2 className="text-[39px] leading-[1.2] font-bold text-black">
  Key Features
</h2>

// Body text with emphasis
<p className="text-[20px] leading-[1.6] text-black">
  Large intro paragraph for important content
</p>

// Standard body
<p className="text-base leading-[1.6] text-black/70">
  Regular paragraph text with optimal readability
</p>

// Caption
<p className="text-sm leading-[1.5] text-black/60">
  Small caption or metadata
</p>`}
        />
      </section>

      {/* Typography System Summary */}
      <section className="mt-16">
        <div className="bg-black text-white rounded-[10px] p-8">
          <h3 className="text-2xl font-bold mb-6">Typography System Summary</h3>
          
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-4xl font-bold mb-2">1.25</div>
              <div className="text-white/70 mb-2">Major Third Ratio</div>
              <div className="text-sm text-white/60">Mathematical harmony for size progression</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2">2</div>
              <div className="text-white/70 mb-2">Font Weights</div>
              <div className="text-sm text-white/60">Bold (700) and Regular (400) only</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2">1.6</div>
              <div className="text-white/70 mb-2">Body Line-Height</div>
              <div className="text-sm text-white/60">Generous spacing for readability</div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/20">
            <h4 className="font-bold text-white mb-3">Quick Reference</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-white/70">
                <span className="text-white font-medium">Hero (H1):</span> 48px Bold, 1.2 leading
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Section (H2):</span> 39px Bold, 1.2 leading
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Subsection (H3):</span> 31px Bold, 1.3 leading
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Card (H4):</span> 25px Bold, 1.4 leading
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Body Large:</span> 20px Regular, 1.6 leading
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Body Default:</span> 16px Regular, 1.6 leading
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}