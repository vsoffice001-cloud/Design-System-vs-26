/**
 * Buttons Category - Design System
 * 
 * Complete button component documentation with interactive playground
 */

import React from 'react';
import { Button } from '../Button';
import { ButtonPlayground } from '../ButtonPlayground';
import { CodeBlockWithCopy } from '../CodeBlockWithCopy';
import { PropertyTable } from '@/design-system';
import { ArrowRight, Download, Heart, CheckCircle2, X, AlertCircle } from 'lucide-react';

export function ButtonsCategory() {
  return (
    <div className="max-w-4xl">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-5xl font-bold text-black mb-4">Buttons</h1>
        <p className="text-xl text-black/70 leading-relaxed">
          Buttons are the primary way users interact with your application. Our button system 
          provides clear visual hierarchy with four variants, four sizes, and intentional constraints 
          to guide users toward the most important actions.
        </p>
      </div>

      {/* Philosophy & Principles */}
      <section className="mb-16">
        <div className="bg-black text-white rounded-[10px] p-10">
          <h2 className="text-3xl font-bold mb-6">Philosophy & Principles</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold mb-3">The One Primary Action Rule</h3>
              <p className="text-white/70 leading-relaxed">
                Every screen should have ONE dominant action. This is your Brand (Ken Bold Red) button. 
                If you think you have two equally important actions, one isn't actually equal—pick the 
                primary business goal. Secondary and ghost variants exist to support the primary action, 
                not compete with it.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">Visual Hierarchy Through Constraint</h3>
              <ul className="space-y-2 text-white/70">
                <li>• <span className="text-white font-medium">Brand (Red):</span> Maximum 1-2 per screen—reserved for primary CTAs only</li>
                <li>• <span className="text-white font-medium">Primary (Black):</span> Important actions that move users forward in the journey</li>
                <li>• <span className="text-white font-medium">Secondary (Outlined):</span> Alternative or complementary actions alongside primary</li>
                <li>• <span className="text-white font-medium">Ghost (Minimal):</span> Tertiary actions, cancellations, or low-priority navigation</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">Core Button Principles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Action-Oriented Labels</div>
                  <div className="text-sm text-white/70">"Get Started", "Download Report", "Continue"—not "Submit" or "Click Here"</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Loading States Matter</div>
                  <div className="text-sm text-white/70">Always show feedback for async actions—users need to know something's happening</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Icons Enhance, Not Replace</div>
                  <div className="text-sm text-white/70">Use icons to clarify actions (arrows for forward movement, downloads, etc.)</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Size Signals Importance</div>
                  <div className="text-sm text-white/70">XL for hero CTAs, LG (default) for primary actions, MD/SM for UI components</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Playground */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Interactive Playground</h2>
        <p className="text-lg text-black/70 mb-8">
          Experiment with different button configurations in real-time.
        </p>

        <div className="bg-[#f5f2f1] rounded-[10px] p-8">
          <ButtonPlayground />
        </div>
      </section>

      {/* Variant Selection Framework */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Variant Selection Framework</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">4 visual variants that communicate action hierarchy through color and weight</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Users need visual cues to understand which actions are most important</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Every interactive action point—forms, hero sections, cards, modals, navigation</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Always ask: Is this the primary action? Supporting action? Tertiary?</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Start with Brand for primary CTA, then cascade down to Primary → Secondary → Ghost</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Button Variant Decision Tree</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#b01f24] text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">1</div>
                <div>
                  <div className="font-medium text-black">Is this THE most important action on the screen?</div>
                  <div className="text-sm text-black/60">The one action you want 80% of users to take? → Use <span className="font-bold">Brand (Red)</span></div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">2</div>
                <div>
                  <div className="font-medium text-black">Is this an important action that moves the user forward?</div>
                  <div className="text-sm text-black/60">Submitting a form, confirming a choice, proceeding to next step? → Use <span className="font-bold">Primary (Black)</span></div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-white border-2 border-black text-black flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">3</div>
                <div>
                  <div className="font-medium text-black">Is this an alternative or complementary action?</div>
                  <div className="text-sm text-black/60">"Learn More", "View Details", or paired with a primary button? → Use <span className="font-bold">Secondary (Outlined)</span></div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black/5 text-black flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">4</div>
                <div>
                  <div className="font-medium text-black">Is this a low-priority or destructive action?</div>
                  <div className="text-sm text-black/60">Cancel, skip, back navigation, or tertiary actions? → Use <span className="font-bold">Ghost (Minimal)</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* Real-World Scenarios */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Real-World Decision Making</h3>
            <div className="space-y-3">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Landing page hero section</div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-bold">Primary:</span> "Get Started" (Brand, XL) | <span className="font-bold">Secondary:</span> "Watch Demo" (Secondary, LG)</span>
                </div>
                <div className="flex gap-3">
                  <Button variant="brand" size="xl">Get Started <ArrowRight className="size-6" /></Button>
                  <Button variant="secondary" size="lg">Watch Demo</Button>
                </div>
              </div>

              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Form submission (modal)</div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-bold">Submit:</span> Primary (LG) | <span className="font-bold">Cancel:</span> Ghost (LG)</span>
                </div>
                <div className="flex gap-3">
                  <Button variant="primary" size="lg">Submit Form</Button>
                  <Button variant="ghost" size="lg">Cancel</Button>
                </div>
              </div>

              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Product card with multiple actions</div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-bold">Add to Cart:</span> Brand (MD) | <span className="font-bold">View Details:</span> Secondary (MD) | <span className="font-bold">Save:</span> Ghost (SM)</span>
                </div>
                <div className="flex gap-2 items-center">
                  <Button variant="brand" size="md">Add to Cart</Button>
                  <Button variant="secondary" size="md">View Details</Button>
                  <Button variant="ghost" size="sm"><Heart className="size-4" /></Button>
                </div>
              </div>

              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Multi-step wizard navigation</div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-bold">Next Step:</span> Primary (LG) | <span className="font-bold">Previous:</span> Ghost (LG) | <span className="font-bold">Save & Exit:</span> Secondary (MD)</span>
                </div>
                <div className="flex gap-3 items-center">
                  <Button variant="ghost" size="lg">← Previous</Button>
                  <Button variant="primary" size="lg">Next Step →</Button>
                  <Button variant="secondary" size="md">Save & Exit</Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Button Hierarchy Visual */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8">
          <h3 className="text-lg font-bold text-black mb-6">Visual Hierarchy in Action</h3>
          <div className="space-y-8">
            <div>
              <div className="text-xs text-black/40 mb-3">CORRECT: Clear hierarchy with one dominant action</div>
              <div className="flex gap-4 items-center">
                <Button variant="brand" size="lg">Start Free Trial <ArrowRight className="size-5" /></Button>
                <Button variant="secondary" size="lg">View Pricing</Button>
                <Button variant="ghost" size="md">Learn More</Button>
              </div>
            </div>

            <div className="border-t border-black/10 pt-8">
              <div className="text-xs text-black/40 mb-3 flex items-center gap-2">
                <X className="size-4 text-red-600" />
                INCORRECT: Multiple competing CTAs - user doesn't know where to focus
              </div>
              <div className="flex gap-4 items-center opacity-50">
                <Button variant="brand" size="lg">Sign Up Now</Button>
                <Button variant="brand" size="lg">Get Started</Button>
                <Button variant="primary" size="lg">Try Demo</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sizes */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Sizes</h2>
        
        <div className="bg-[#f5f2f1] rounded-[10px] p-8">
          <div className="space-y-6">
            <div>
              <div className="text-xs text-black/40 mb-3">EXTRA LARGE (XL)</div>
              <Button variant="brand" size="xl">
                Extra Large Button <ArrowRight className="size-6" />
              </Button>
            </div>

            <div>
              <div className="text-xs text-black/40 mb-3">LARGE (LG) - Default</div>
              <Button variant="brand" size="lg">
                Large Button <ArrowRight className="size-5" />
              </Button>
            </div>

            <div>
              <div className="text-xs text-black/40 mb-3">MEDIUM (MD)</div>
              <Button variant="primary" size="md">
                Medium Button
              </Button>
            </div>

            <div>
              <div className="text-xs text-black/40 mb-3">SMALL (SM)</div>
              <Button variant="secondary" size="sm">
                Small Button
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <CodeBlockWithCopy
            language="tsx"
            code={`<Button variant="brand" size="xl">Extra Large</Button>
<Button variant="brand" size="lg">Large (Default)</Button>
<Button variant="primary" size="md">Medium</Button>
<Button variant="secondary" size="sm">Small</Button>`}
          />
        </div>
      </section>

      {/* Border Radius & Dimensions */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Border Radius & Exact Dimensions</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">5px border radius for all buttons—part of the button/small card system</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Consistent corner radius creates visual harmony across interactive elements</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">All button variants—Brand, Primary, Secondary, Ghost</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Always use rounded-[5px]—never rounded-md or other values</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Apply rounded-[5px] to base button class</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Border Radius System Context</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-[2.5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">2.5px - Images</div>
                <div className="text-sm text-black/60">Photos, product images, avatars</div>
                <code className="text-xs bg-black/5 px-2 py-1 rounded-[2.5px] mt-2 inline-block">rounded-[2.5px]</code>
              </div>
              <div className="bg-white rounded-[5px] p-4 border-2 border-[#b01f24]">
                <div className="font-medium text-black mb-2">5px - Buttons</div>
                <div className="text-sm text-black/60">All buttons, small cards, form inputs</div>
                <code className="text-xs bg-black/5 px-2 py-1 rounded-[5px] mt-2 inline-block">rounded-[5px]</code>
              </div>
              <div className="bg-white rounded-[10px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">10px - Big Cards</div>
                <div className="text-sm text-black/60">Large cards, modals, panels</div>
                <code className="text-xs bg-black/5 px-2 py-1 rounded-[10px] mt-2 inline-block">rounded-[10px]</code>
              </div>
            </div>
          </div>
        </div>

        {/* Exact Dimensions Table */}
        <div className="bg-white border border-black/10 rounded-[10px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#f5f2f1]">
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Size</th>
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Height</th>
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Padding (X)</th>
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Font Size</th>
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Min Width</th>
                  <th className="text-left px-6 py-4 text-sm font-bold text-black">Border Radius</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/10">
                <tr>
                  <td className="px-6 py-4">
                    <code className="text-sm font-medium bg-[#f5f2f1] px-2 py-1 rounded-[5px]">sm</code>
                  </td>
                  <td className="px-6 py-4 text-sm text-black/70">40px (2.5rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">20px (1.25rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">14px (0.875rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">80px (5rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">5px</td>
                </tr>
                <tr>
                  <td className="px-6 py-4">
                    <code className="text-sm font-medium bg-[#f5f2f1] px-2 py-1 rounded-[5px]">md</code>
                  </td>
                  <td className="px-6 py-4 text-sm text-black/70">48px (3rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">28px (1.75rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">16px (1rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">112px (7rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">5px</td>
                </tr>
                <tr className="bg-[#f5f2f1]/50">
                  <td className="px-6 py-4">
                    <code className="text-sm font-medium bg-white px-2 py-1 rounded-[5px]">lg</code>
                    <span className="ml-2 text-xs text-black/40">(default)</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-black/70">56px (3.5rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">36px (2.25rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">16px (1rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">144px (9rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">5px</td>
                </tr>
                <tr>
                  <td className="px-6 py-4">
                    <code className="text-sm font-medium bg-[#f5f2f1] px-2 py-1 rounded-[5px]">xl</code>
                  </td>
                  <td className="px-6 py-4 text-sm text-black/70">64px (4rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">40px (2.5rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">18px (1.125rem)</td>
                  <td className="px-6 py-4 text-sm text-black/70">None</td>
                  <td className="px-6 py-4 text-sm text-black/70">5px</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6">
          <CodeBlockWithCopy
            language="css"
            code={`/* Button dimensions are defined using CSS custom properties */

/* Heights */
--button-height-sm: 2.5rem;  /* 40px */
--button-height-md: 3rem;    /* 48px */
--button-height-lg: 3.5rem;  /* 56px */
--button-height-xl: 4rem;    /* 64px */

/* Horizontal Padding */
--button-px-sm: 1.25rem;     /* 20px */
--button-px-md: 1.75rem;     /* 28px */
--button-px-lg: 2.25rem;     /* 36px */
--button-px-xl: 2.5rem;      /* 40px */

/* Font Sizes */
--button-font-sm: 0.875rem;  /* 14px */
--button-font-md: 1rem;      /* 16px */
--button-font-lg: 1.125rem;  /* 18px */

/* Border Radius - Always 5px */
border-radius: 5px;  /* rounded-[5px] */`}
          />
        </div>
      </section>

      {/* States */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">States</h2>
        
        <div className="bg-white border border-black/10 rounded-[10px] p-8">
          <div className="grid grid-cols-2 gap-8">
            {/* Loading */}
            <div>
              <h4 className="text-sm font-bold text-black mb-4">Loading</h4>
              <Button variant="brand" loading>
                Processing...
              </Button>
              <CodeBlockWithCopy
                language="tsx"
                code={`<Button variant="brand" loading>
  Processing...
</Button>`}
              />
            </div>

            {/* Disabled */}
            <div>
              <h4 className="text-sm font-bold text-black mb-4">Disabled</h4>
              <Button variant="primary" disabled>
                Disabled
              </Button>
              <CodeBlockWithCopy
                language="tsx"
                code={`<Button variant="primary" disabled>
  Disabled
</Button>`}
              />
            </div>

            {/* With Icon Left */}
            <div>
              <h4 className="text-sm font-bold text-black mb-4">Icon Left</h4>
              <Button variant="secondary">
                <Download className="size-5" />
                Download
              </Button>
              <CodeBlockWithCopy
                language="tsx"
                code={`<Button variant="secondary">
  <Download className="size-5" />
  Download
</Button>`}
              />
            </div>

            {/* With Icon Right */}
            <div>
              <h4 className="text-sm font-bold text-black mb-4">Icon Right</h4>
              <Button variant="primary">
                Continue
                <ArrowRight className="size-5" />
              </Button>
              <CodeBlockWithCopy
                language="tsx"
                code={`<Button variant="primary">
  Continue
  <ArrowRight className="size-5" />
</Button>`}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Props API */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Props API</h2>
        
        <div className="bg-white border border-black/10 rounded-[10px] overflow-hidden">
          <PropertyTable
            properties={[
              {
                name: 'variant',
                type: "'brand' | 'primary' | 'secondary' | 'ghost'",
                default: "'primary'",
                description: 'Visual style variant of the button',
              },
              {
                name: 'size',
                type: "'sm' | 'md' | 'lg' | 'xl'",
                default: "'lg'",
                description: 'Size of the button',
              },
              {
                name: 'loading',
                type: 'boolean',
                default: 'false',
                description: 'Shows loading spinner and disables interaction',
              },
              {
                name: 'disabled',
                type: 'boolean',
                default: 'false',
                description: 'Disables the button',
              },
              {
                name: 'onClick',
                type: '() => void',
                default: 'undefined',
                description: 'Click handler function',
              },
              {
                name: 'children',
                type: 'React.ReactNode',
                default: 'undefined',
                description: 'Button content (text, icons, etc.)',
              },
              {
                name: 'className',
                type: 'string',
                default: "''",
                description: 'Additional CSS classes',
              },
            ]}
          />
        </div>
      </section>

      {/* How to Create These Buttons - Implementation Guide */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Implementation Guide: How to Create These Buttons</h2>
        
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-lg font-bold text-black mb-4">Complete Button Component Structure</h3>
          <p className="text-sm text-black/70 mb-6">
            Our buttons use a modular approach with CSS custom properties for dimensions and inline styles for gradients.
          </p>

          <CodeBlockWithCopy
            language="tsx"
            code={`// Import the Button component
import { Button } from '@/app/components/Button';
import { ArrowRight, Download, Heart } from 'lucide-react';

// Basic Usage
<Button variant="brand" size="lg">
  Get Started
</Button>

// With Icon (Right)
<Button variant="primary" size="lg">
  Continue <ArrowRight className="size-5" />
</Button>

// With Icon (Left)
<Button variant="secondary" size="md">
  <Download className="size-5" /> Download
</Button>

// Loading State
<Button variant="brand" loading>
  Processing...
</Button>

// Disabled State
<Button variant="primary" disabled>
  Unavailable
</Button>

// Full Width
<Button variant="brand" className="w-full">
  Continue to Checkout
</Button>`}
          />
        </div>

        {/* Base Structure */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8 mb-8">
          <h3 className="text-lg font-bold text-black mb-4">Base Button Structure</h3>
          <p className="text-sm text-black/70 mb-6">
            All buttons share these core styles—always applied regardless of variant or size.
          </p>

          <CodeBlockWithCopy
            language="css"
            code={`/* Base Styles - Always Applied */
.button-base {
  /* Layout */
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem; /* 8px */
  
  /* Typography */
  font-weight: 500; /* Medium */
  font-family: inherit;
  letter-spacing: 0.0875px;
  white-space: nowrap;
  
  /* Visual */
  border-radius: 5px; /* rounded-[5px] */
  overflow: hidden;
  
  /* Interaction */
  cursor: pointer;
  transition: all 300ms ease;
  
  /* Accessibility */
  outline: none;
  -webkit-tap-highlight-color: transparent;
}

/* Disabled State */
.button-base:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}`}
          />
        </div>

        {/* Variant Implementation */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8 mb-8">
          <h3 className="text-lg font-bold text-black mb-4">Variant-Specific Styles</h3>
          
          <div className="space-y-6">
            {/* Brand Variant */}
            <div>
              <h4 className="text-sm font-bold text-black mb-3">Brand (Red Gradient)</h4>
              <CodeBlockWithCopy
                language="css"
                code={`/* Brand Variant - Ken Bold Red with animated gradient */
.button-brand {
  color: white;
  background-image: linear-gradient(90deg, var(--red-700), var(--red-500));
  background-image: linear-gradient(90deg, #991b1f, #f43f5e);
  background-size: 200% 200%;
  background-position: 0% 50%;
  box-shadow: 0 4px 16px rgba(176, 31, 36, 0.15);
}

.button-brand:hover {
  background-position: 100% 50%;
  box-shadow: 0 12px 32px rgba(176, 31, 36, 0.25);
  transform: translateY(-1px);
}

.button-brand:active {
  transform: translateY(0);
}`}
              />
            </div>

            {/* Primary Variant */}
            <div>
              <h4 className="text-sm font-bold text-black mb-3">Primary (Black Gradient)</h4>
              <CodeBlockWithCopy
                language="css"
                code={`/* Primary Variant - Black to grey gradient */
.button-primary {
  color: white;
  background-image: linear-gradient(90deg, #0a0a0a, #6a6a6a);
  background-size: 200% 200%;
  background-position: 0% 50%;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.button-primary:hover {
  background-position: 100% 50%;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
}`}
              />
            </div>

            {/* Secondary Variant */}
            <div>
              <h4 className="text-sm font-bold text-black mb-3">Secondary (Outlined)</h4>
              <CodeBlockWithCopy
                language="css"
                code={`/* Secondary Variant - Outlined with subtle hover */
.button-secondary {
  background-color: white;
  color: black;
  border: 1px solid rgba(0, 0, 0, 0.2);
}

.button-secondary:hover {
  border-color: rgba(0, 0, 0, 0.4);
  background-color: rgba(0, 0, 0, 0.02);
}

.button-secondary:active {
  background-color: rgba(0, 0, 0, 0.04);
}`}
              />
            </div>

            {/* Ghost Variant */}
            <div>
              <h4 className="text-sm font-bold text-black mb-3">Ghost (Minimal)</h4>
              <CodeBlockWithCopy
                language="css"
                code={`/* Ghost Variant - Transparent with hover */
.button-ghost {
  background-color: transparent;
  color: black;
}

.button-ghost:hover {
  background-color: rgba(0, 0, 0, 0.05);
}

.button-ghost:active {
  background-color: rgba(0, 0, 0, 0.1);
}`}
              />
            </div>
          </div>
        </div>

        {/* Size Implementation */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8">
          <h3 className="text-lg font-bold text-black mb-4">Size-Specific Styles</h3>
          
          <CodeBlockWithCopy
            language="css"
            code={`/* Size Variants - Using CSS Custom Properties */

/* Small (SM) */
.button-sm {
  height: var(--button-height-sm);      /* 40px */
  padding-left: var(--button-px-sm);    /* 20px */
  padding-right: var(--button-px-sm);
  font-size: var(--button-font-sm);     /* 14px */
  min-width: var(--button-min-width-sm); /* 80px */
}

/* Medium (MD) */
.button-md {
  height: var(--button-height-md);      /* 48px */
  padding-left: var(--button-px-md);    /* 28px */
  padding-right: var(--button-px-md);
  font-size: var(--button-font-md);     /* 16px */
  min-width: var(--button-min-width-md); /* 112px */
}

/* Large (LG) - Default */
.button-lg {
  height: var(--button-height-lg);      /* 56px */
  padding-left: var(--button-px-lg);    /* 36px */
  padding-right: var(--button-px-lg);
  font-size: var(--button-font-md);     /* 16px */
  min-width: var(--button-min-width-lg); /* 144px */
}

/* Extra Large (XL) */
.button-xl {
  height: var(--button-height-xl);      /* 64px */
  padding-left: var(--button-px-xl);    /* 40px */
  padding-right: var(--button-px-xl);
  font-size: var(--button-font-lg);     /* 18px */
}`}
          />
        </div>
      </section>

      {/* Animation System */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Animation System</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">Smooth transitions, gradient shifts, shadows, and ripple effects</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Visual feedback confirms interaction and creates premium feel</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Hover, active, focus states—every button interaction</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">300ms for gradients/shadows, 200ms for transform, 600ms for ripples</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">CSS transitions for properties, JS for ripple effect animation</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Animation Layers</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-bold text-black mb-3">1. Gradient Shift (Brand & Primary)</h4>
                <ul className="space-y-2 text-sm text-black/70">
                  <li>• <span className="font-medium">Duration:</span> 300ms ease</li>
                  <li>• <span className="font-medium">Property:</span> background-position</li>
                  <li>• <span className="font-medium">Effect:</span> 0% → 100% horizontal shift</li>
                  <li>• <span className="font-medium">Result:</span> Color darkens on hover</li>
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-bold text-black mb-3">2. Shadow Elevation</h4>
                <ul className="space-y-2 text-sm text-black/70">
                  <li>• <span className="font-medium">Duration:</span> 300ms ease</li>
                  <li>• <span className="font-medium">Property:</span> box-shadow</li>
                  <li>• <span className="font-medium">Effect:</span> Increases blur & spread</li>
                  <li>• <span className="font-medium">Result:</span> Button appears to lift</li>
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-bold text-black mb-3">3. Vertical Lift (Brand only)</h4>
                <ul className="space-y-2 text-sm text-black/70">
                  <li>• <span className="font-medium">Duration:</span> 200ms ease</li>
                  <li>• <span className="font-medium">Property:</span> transform translateY</li>
                  <li>• <span className="font-medium">Effect:</span> -1px on hover, 0 on active</li>
                  <li>• <span className="font-medium">Result:</span> Subtle upward motion</li>
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-bold text-black mb-3">4. Ripple Effect (All variants)</h4>
                <ul className="space-y-2 text-sm text-black/70">
                  <li>• <span className="font-medium">Duration:</span> 600ms ease-out</li>
                  <li>• <span className="font-medium">Property:</span> Custom JS animation</li>
                  <li>• <span className="font-medium">Effect:</span> Expanding circle from click point</li>
                  <li>• <span className="font-medium">Result:</span> Material Design-style feedback</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Animation Code Examples */}
        <div className="bg-white border border-black/10 rounded-[10px] p-8 mb-8">
          <h3 className="text-lg font-bold text-black mb-6">Complete Animation Implementation</h3>

          {/* CSS Animations */}
          <div className="mb-8">
            <h4 className="text-sm font-bold text-black mb-4">CSS Transitions</h4>
            <CodeBlockWithCopy
              language="css"
              code={`/* Base Transition - Applied to all buttons */
.button-base {
  transition: all 300ms ease;
}

/* Brand Variant Animations */
.button-brand {
  background-image: linear-gradient(90deg, var(--red-700), var(--red-500));
  background-size: 200% 200%;
  background-position: 0% 50%;
  box-shadow: 0 4px 16px rgba(176, 31, 36, 0.15);
  transition: background-position 0.3s ease, 
              box-shadow 0.3s ease, 
              transform 0.2s ease;
}

.button-brand:hover {
  background-position: 100% 50%;
  box-shadow: 0 12px 32px rgba(176, 31, 36, 0.25);
  transform: translateY(-1px);
}

.button-brand:active {
  transform: translateY(0);
  transition-duration: 100ms; /* Faster response on click */
}

/* Primary Variant Animations */
.button-primary {
  background-image: linear-gradient(90deg, #0a0a0a, #6a6a6a);
  background-size: 200% 200%;
  background-position: 0% 50%;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: background-position 0.3s ease, box-shadow 0.3s ease;
}

.button-primary:hover {
  background-position: 100% 50%;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
}

/* Secondary & Ghost Hover */
.button-secondary:hover,
.button-ghost:hover {
  transition: background-color 0.2s ease, border-color 0.2s ease;
}

/* Ripple Effect Keyframe */
@keyframes ripple {
  from {
    transform: scale(0);
    opacity: 0.6;
  }
  to {
    transform: scale(4);
    opacity: 0;
  }
}`}
            />
          </div>

          {/* JavaScript Ripple */}
          <div>
            <h4 className="text-sm font-bold text-black mb-4">JavaScript Ripple Effect</h4>
            <CodeBlockWithCopy
              language="tsx"
              code={`// Ripple effect implementation (already built into Button component)
const createRipple = (event: React.MouseEvent<HTMLButtonElement>) => {
  const button = buttonRef.current;
  if (!button) return;

  const rect = button.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height);
  const x = event.clientX - rect.left - size / 2;
  const y = event.clientY - rect.top - size / 2;

  const ripple = {
    x,
    y,
    size,
    key: Date.now()
  };

  setRipples(prev => [...prev, ripple]);

  // Remove ripple after animation (600ms)
  setTimeout(() => {
    setRipples(prev => prev.filter(r => r.key !== ripple.key));
  }, 600);
};

// Ripple element rendering
{ripples.map((ripple) => (
  <span
    key={ripple.key}
    className="absolute rounded-full pointer-events-none"
    style={{
      left: ripple.x,
      top: ripple.y,
      width: ripple.size,
      height: ripple.size,
      backgroundColor: variant === 'primary' || variant === 'brand' 
        ? 'rgba(255, 255, 255, 0.3)' 
        : 'rgba(0, 0, 0, 0.1)',
      animation: 'ripple 600ms ease-out'
    }}
  />
))}`}
            />
          </div>
        </div>

        {/* Animation Best Practices */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8">
          <h3 className="text-lg font-bold text-black mb-4">Animation Best Practices</h3>
          <div className="space-y-3">
            <div className="bg-white rounded-[5px] p-4 border border-black/10">
              <div className="font-medium text-black mb-2">Duration Guidelines</div>
              <ul className="text-sm text-black/70 space-y-1">
                <li>• <span className="font-medium">Micro (100-200ms):</span> Active state transitions, immediate feedback</li>
                <li>• <span className="font-medium">Short (200-300ms):</span> Hover states, color changes, transforms</li>
                <li>• <span className="font-medium">Medium (300-600ms):</span> Gradients, shadows, complex transitions</li>
                <li>• <span className="font-medium">Never exceed 600ms</span> for button interactions—feels sluggish</li>
              </ul>
            </div>

            <div className="bg-white rounded-[5px] p-4 border border-black/10">
              <div className="font-medium text-black mb-2">Easing Functions</div>
              <ul className="text-sm text-black/70 space-y-1">
                <li>• <span className="font-medium">ease:</span> Default for most transitions (gradual acceleration/deceleration)</li>
                <li>• <span className="font-medium">ease-out:</span> For ripple effects (starts fast, ends slow)</li>
                <li>• <span className="font-medium">linear:</span> Never use—feels robotic and unnatural</li>
              </ul>
            </div>

            <div className="bg-white rounded-[5px] p-4 border border-black/10">
              <div className="font-medium text-black mb-2">Performance Tips</div>
              <ul className="text-sm text-black/70 space-y-1">
                <li>• Animate <span className="font-medium">transform</span> and <span className="font-medium">opacity</span> for GPU acceleration</li>
                <li>• Avoid animating <span className="font-medium">width, height, top, left</span>—causes layout thrashing</li>
                <li>• Use <span className="font-medium">will-change: transform</span> sparingly (only for frequently animated elements)</li>
                <li>• Remove ripple elements from DOM after animation completes (prevents memory leaks)</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Usage Guidelines */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Usage Guidelines</h2>
        
        <div className="grid grid-cols-2 gap-6">
          {/* Do */}
          <div className="bg-white border border-green-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="size-5 text-green-600" />
              <h4 className="font-bold text-black">Do</h4>
            </div>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Use brand variant for primary CTAs only</li>
              <li>• Limit to 1 brand button per screen</li>
              <li>• Use clear, action-oriented labels</li>
              <li>• Provide loading states for async actions</li>
              <li>• Use icons to enhance clarity</li>
              <li>• Maintain consistent sizing within groups</li>
            </ul>
          </div>

          {/* Don't */}
          <div className="bg-white border border-red-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <X className="size-5 text-red-600" />
              <h4 className="font-bold text-black">Don't</h4>
            </div>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Use multiple brand buttons together</li>
              <li>• Mix too many variants in one area</li>
              <li>• Use vague labels like "Click Here"</li>
              <li>• Forget disabled states for unavailable actions</li>
              <li>• Overcrowd with icons</li>
              <li>• Use different sizes randomly</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Common Patterns */}
      <section>
        <h2 className="text-3xl font-bold text-black mb-6">Common Patterns</h2>
        
        <div className="space-y-8">
          {/* Primary + Secondary Pair */}
          <div className="bg-[#f5f2f1] rounded-[10px] p-8">
            <h4 className="text-sm font-bold text-black mb-4">Primary + Secondary Pair</h4>
            <div className="flex gap-4 mb-6">
              <Button variant="brand">
                Get Started <ArrowRight className="size-5" />
              </Button>
              <Button variant="secondary">
                Learn More
              </Button>
            </div>
            <CodeBlockWithCopy
              language="tsx"
              code={`<div className="flex gap-4">
  <Button variant="brand">
    Get Started <ArrowRight className="size-5" />
  </Button>
  <Button variant="secondary">
    Learn More
  </Button>
</div>`}
            />
          </div>

          {/* Icon Buttons */}
          <div className="bg-[#f5f2f1] rounded-[10px] p-8">
            <h4 className="text-sm font-bold text-black mb-4">Icon Buttons</h4>
            <div className="flex gap-4 mb-6">
              <Button variant="primary">
                <Download className="size-5" />
                Download Report
              </Button>
              <Button variant="secondary">
                <Heart className="size-5" />
                Save to Favorites
              </Button>
            </div>
            <CodeBlockWithCopy
              language="tsx"
              code={`<Button variant="primary">
  <Download className="size-5" />
  Download Report
</Button>

<Button variant="secondary">
  <Heart className="size-5" />
  Save to Favorites
</Button>`}
            />
          </div>

          {/* Full Width */}
          <div className="bg-[#f5f2f1] rounded-[10px] p-8">
            <h4 className="text-sm font-bold text-black mb-4">Full Width (Mobile)</h4>
            <Button variant="brand" className="w-full">
              Continue to Checkout <ArrowRight className="size-5" />
            </Button>
            <div className="mt-6">
              <CodeBlockWithCopy
                language="tsx"
                code={`<Button variant="brand" className="w-full">
  Continue to Checkout <ArrowRight className="size-5" />
</Button>`}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Button System Summary */}
      <section className="mt-16">
        <div className="bg-black text-white rounded-[10px] p-8">
          <h3 className="text-2xl font-bold mb-6">Button System Summary</h3>
          
          <div className="grid grid-cols-4 gap-6">
            <div>
              <div className="text-4xl font-bold mb-2">4</div>
              <div className="text-white/70 mb-2">Variants</div>
              <div className="text-sm text-white/60">Brand, Primary, Secondary, Ghost</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2">4</div>
              <div className="text-white/70 mb-2">Sizes</div>
              <div className="text-sm text-white/60">XL, LG (default), MD, SM</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2">1</div>
              <div className="text-white/70 mb-2">Primary Action</div>
              <div className="text-sm text-white/60">Maximum per screen—the Brand button</div>
            </div>

            <div>
              <div className="text-4xl font-bold mb-2">5px</div>
              <div className="text-white/70 mb-2">Border Radius</div>
              <div className="text-sm text-white/60">Consistent with button/small card system</div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/20">
            <h4 className="font-bold text-white mb-3">Quick Reference: When to Use Each Variant</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-white/70">
                <span className="text-white font-medium">Brand (Red):</span> #1 CTA, maximum 1-2 per screen
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Primary (Black):</span> Important forward actions
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Secondary (Outlined):</span> Alternative or complementary actions
              </div>
              <div className="text-white/70">
                <span className="text-white font-medium">Ghost (Minimal):</span> Cancel, back, tertiary navigation
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-white/20">
            <h4 className="font-bold text-white mb-3">Remember: The One Action Rule</h4>
            <p className="text-sm text-white/70">
              Every screen should guide users toward ONE primary action. If you're using multiple brand buttons 
              or can't decide which action is most important, step back and identify your primary business goal. 
              The Brand button is your visual exclamation point—use it wisely.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}