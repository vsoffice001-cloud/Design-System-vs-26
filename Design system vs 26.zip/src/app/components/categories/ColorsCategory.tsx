/**
 * Colors Category - Design System
 * 
 * Complete color foundation documentation
 */

import React from 'react';
import { ColorSwatch, ColorSwatchGrid, GradientSwatch } from '@/design-system';
import { CodeBlockWithCopy } from '../CodeBlockWithCopy';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';

export function ColorsCategory() {
  return (
    <div className="max-w-4xl">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-5xl font-bold text-black mb-4">Colors</h1>
        <p className="text-xl text-black/70 leading-relaxed">
          Our color system follows the 92-5-3 rule: 92% foundation colors (black, white, warm off-white), 
          5% brand red for major CTAs, and 3% accent colors for subtle highlights and shadows.
        </p>
      </div>

      {/* Philosophy & Principles */}
      <section className="mb-16">
        <div className="bg-black text-white rounded-[10px] p-10">
          <h2 className="text-3xl font-bold mb-6">Philosophy & Principles</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold mb-3">What is the 92-5-3 Color System?</h3>
              <p className="text-white/70 leading-relaxed">
                The 92-5-3 system is a disciplined approach to color usage that creates visual hierarchy through 
                restraint. By limiting colorful elements to just 8% of the interface, we ensure that important 
                actions and information stand out immediately.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">Why This System Works</h3>
              <ul className="space-y-2 text-white/70">
                <li>• <span className="text-white font-medium">Visual Hierarchy:</span> When 92% is neutral, the 8% that isn't becomes impossible to ignore</li>
                <li>• <span className="text-white font-medium">Brand Recognition:</span> Ken Bold Red becomes synonymous with action and decision</li>
                <li>• <span className="text-white font-medium">Cognitive Load:</span> Neutral foundations reduce mental fatigue and improve focus</li>
                <li>• <span className="text-white font-medium">Accessibility:</span> High contrast ratios ensure readability for all users</li>
                <li>• <span className="text-white font-medium">Scalability:</span> System works consistently across all product surfaces</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3">When to Follow the Rules (and When to Break Them)</h3>
              <p className="text-white/70 leading-relaxed mb-3">
                The 92-5-3 rule is a guideline, not a hard limit. However, deviations should be intentional:
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Follow Strictly</div>
                  <div className="text-sm text-white/70">Marketing pages, dashboards, forms, documentation, product interfaces</div>
                </div>
                <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
                  <div className="font-bold text-white mb-2">Allow Flexibility</div>
                  <div className="text-sm text-white/70">Data visualizations, infographics, branded campaigns, illustrations</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Foundation Colors */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Foundation Colors (92%)</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">Black, white, and warm neutrals that form the structural foundation</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Create calm, professional environments where content and actions stand out</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Backgrounds, text, borders, cards, containers, navigation</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Always - these are your default colors for all non-accent elements</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Use opacity to create hierarchy; avoid introducing new grays</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Decision Framework</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">1</div>
                <div>
                  <div className="font-medium text-black">Choose Your Base</div>
                  <div className="text-sm text-black/60">White (#ffffff) for light sections, Black (#000000) for dark sections, Warm 300 (#f5f2f1) for highlighted areas</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">2</div>
                <div>
                  <div className="font-medium text-black">Add Hierarchy with Opacity</div>
                  <div className="text-sm text-black/60">100% for headings, 70% for body text, 40% for labels, 20% for disabled, 10% for borders</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">3</div>
                <div>
                  <div className="font-medium text-black">Use Grayscale for Depth</div>
                  <div className="text-sm text-black/60">Black 50-100 for subtle backgrounds, Black 200-300 for borders, Black 500-700 for secondary text</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">4</div>
                <div>
                  <div className="font-medium text-black">Warm Tones for Comfort</div>
                  <div className="text-sm text-black/60">Use warm scale (50-900) for highlighted sections that need to feel inviting without competing for attention</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Primary Colors</h3>
          
          <div className="grid grid-cols-3 gap-6">
            <ColorSwatch
              color="#000000"
              name="Black"
              value="#000000"
              description="Primary text, hero backgrounds"
            />
            <ColorSwatch
              color="#ffffff"
              name="White"
              value="#ffffff"
              description="Primary background"
            />
            <ColorSwatch
              color="#f5f2f1"
              name="Warm Off-White"
              value="#f5f2f1"
              description="Highlighted sections"
            />
          </div>
        </div>

        {/* Complete Grayscale (Black Tints) */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Complete Grayscale (Black Tints)</h3>
          <p className="text-sm text-black/60 mb-6">
            White mixed into black - Full 10-shade scale from near-white to pure black
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Black 50', value: '#fafafa', usage: 'Near white, subtle backgrounds' },
              { name: 'Black 100', value: '#f5f5f5', usage: 'Lightest gray, card backgrounds' },
              { name: 'Black 200', value: '#e5e5e5', usage: 'Very light gray, borders, dividers' },
              { name: 'Black 300', value: '#d4d4d4', usage: 'Light gray, disabled states' },
              { name: 'Black 400', value: '#a3a3a3', usage: 'Medium gray, placeholder text' },
              { name: 'Black 500', value: '#737373', usage: 'Gray, secondary text' },
              { name: 'Black 600', value: '#525252', usage: 'Dark gray, body text alternative' },
              { name: 'Black 700', value: '#404040', usage: 'Darker gray, headings alternative' },
              { name: 'Black 800', value: '#262626', usage: 'Very dark, strong text' },
              { name: 'Black 900', value: '#171717', usage: 'Almost black, deep backgrounds' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Pure Black */}
        <div className="bg-black rounded-[10px] p-8 mb-8">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-white mb-2">Pure Black</h3>
            <p className="text-sm text-white/60">
              #000000 - Used for primary text and hero backgrounds
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
              <div className="text-sm text-white/70 mb-2">Primary Usage</div>
              <div className="text-white font-bold">Headings, key content</div>
            </div>
            <div className="bg-white/10 rounded-[5px] p-4 border border-white/20">
              <div className="text-sm text-white/70 mb-2">Background Usage</div>
              <div className="text-white font-bold">Hero sections, dark sections</div>
            </div>
          </div>
        </div>

        {/* Warm Off-White Complete Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Warm Off-White Complete Scale</h3>
          <p className="text-sm text-black/60 mb-6">
            Subtle warm tones for highlighted sections and backgrounds - 10-shade scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Warm 50', value: '#fefdfd', usage: 'Barely there, subtle overlays' },
              { name: 'Warm 100', value: '#fcfbfa', usage: 'Very subtle, hover backgrounds' },
              { name: 'Warm 200', value: '#f9f7f6', usage: 'Soft, card backgrounds' },
              { name: 'Warm 300', value: '#f5f2f1', usage: 'BASE - Section backgrounds' },
              { name: 'Warm 400', value: '#f0ebe9', usage: 'Medium, alternative backgrounds' },
              { name: 'Warm 500', value: '#eae5e3', usage: 'Borders, current usage' },
              { name: 'Warm 600', value: '#d9d1ce', usage: 'Timeline base' },
              { name: 'Warm 700', value: '#c8bcb8', usage: 'Timeline nodes' },
              { name: 'Warm 800', value: '#b7a9a3', usage: 'Dark warm, text on light warm' },
              { name: 'Warm 900', value: '#a6968e', usage: 'Darkest warm, strong accents' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        <CodeBlockWithCopy
          language="tsx"
          code={`import { colors } from '@/design-system';

// Foundation colors - CSS Variables
--black: #000000;           /* Pure black - Primary text, hero backgrounds */
--white: #ffffff;           /* Pure white - Primary backgrounds */

// Complete Grayscale (Black Tints 50-900)
--black-50: #fafafa;        /* Near white - Very subtle backgrounds */
--black-100: #f5f5f5;       /* Lightest gray - Card backgrounds */
--black-200: #e5e5e5;       /* Very light gray - Borders, dividers */
--black-300: #d4d4d4;       /* Light gray - Disabled states */
--black-400: #a3a3a3;       /* Medium gray - Placeholder text */
--black-500: #737373;       /* Gray - Secondary text */
--black-600: #525252;       /* Dark gray - Body text alternative */
--black-700: #404040;       /* Darker gray - Headings alternative */
--black-800: #262626;       /* Very dark - Strong text */
--black-900: #171717;       /* Almost black - Deep backgrounds */

// Warm Off-White Scale (50-900)
--warm-50: #fefdfd;         /* Barely there - Subtle overlays */
--warm-100: #fcfbfa;        /* Very subtle - Hover backgrounds */
--warm-200: #f9f7f6;        /* Soft - Card backgrounds */
--warm-300: #f5f2f1;        /* BASE - Current section backgrounds */
--warm-400: #f0ebe9;        /* Medium - Alternative backgrounds */
--warm-500: #eae5e3;        /* Borders - Current usage */
--warm-600: #d9d1ce;        /* Timeline base - Current usage */
--warm-700: #c8bcb8;        /* Timeline nodes - Current usage */
--warm-800: #b7a9a3;        /* Dark warm - Text on light warm */
--warm-900: #a6968e;        /* Darkest warm - Strong accents */

// Usage in Tailwind with CSS variables
<div className="bg-white text-black">
  <div className="bg-[#f5f5f5]">Card on gray background</div>
  <div className="bg-[#f5f2f1]">Highlighted section</div>
</div>`}
        />
      </section>

      {/* Brand Red */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Brand Red - Ken Bold Red (5%)</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">Ken Bold Red (#b01f24) - our primary brand color for calls-to-action</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Demands attention, signals action, builds brand recognition through consistency</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Primary CTAs, submit buttons, key navigation elements, critical alerts</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">Only for the most important action on a screen - maximum 1-2 instances</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Use gradient (Red 700→500) with hover animation, ensure WCAG AA contrast</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">The Sacred Rules of Red</h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <div className="font-bold text-black mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#b01f24] text-white flex items-center justify-center text-xs font-bold">1</span>
                    One Primary Action
                  </div>
                  <p className="text-sm text-black/60 pl-8">
                    Each screen should have ONE dominant red CTA. If you have two "equal" actions, one isn't actually equal - pick the primary business goal.
                  </p>
                </div>
                <div>
                  <div className="font-bold text-black mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#b01f24] text-white flex items-center justify-center text-xs font-bold">2</span>
                    Measure Your Red Usage
                  </div>
                  <p className="text-sm text-black/60 pl-8">
                    If red occupies more than 5% of the viewport, you're diluting its power. Use sparingly to maintain impact.
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="font-bold text-black mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#b01f24] text-white flex items-center justify-center text-xs font-bold">3</span>
                    Never Disable Red Buttons
                  </div>
                  <p className="text-sm text-black/60 pl-8">
                    If an action isn't ready, hide the button or use validation messages. Red 300 with reduced opacity looks weak and confuses users.
                  </p>
                </div>
                <div>
                  <div className="font-bold text-black mb-2 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#b01f24] text-white flex items-center justify-center text-xs font-bold">4</span>
                    Accessibility is Non-Negotiable
                  </div>
                  <p className="text-sm text-black/60 pl-8">
                    White text on Red 600 = 4.93:1 contrast (passes WCAG AA). Never use Red 400-500 as backgrounds for text.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Real-World Scenarios */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Real-World Decision Making</h3>
            <div className="space-y-3">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Form with "Save Draft" and "Submit" buttons</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-medium text-black">"Submit"</span> gets red CTA, <span className="font-medium text-black">"Save Draft"</span> gets ghost/secondary button</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Pricing page with 3 plan tiers</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70">Only the <span className="font-medium text-black">recommended/popular plan</span> gets red CTA, others use secondary buttons</span>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-2">Scenario: Modal with "Cancel" and "Confirm Delete"</div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-black/70"><span className="font-medium text-black">"Confirm Delete"</span> gets red CTA (even for destructive actions - it's the primary intent), "Cancel" is ghost button</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Primary Brand Colors */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Primary Brand Colors</h3>
          <p className="text-sm text-black/60 mb-6">
            Core Ken Bold Red with interaction states
          </p>
          
          <div className="grid grid-cols-3 gap-6">
            <ColorSwatch
              color="#b01f24"
              name="Brand Red"
              value="#b01f24"
              description="PRIMARY BRAND - CTAs, buttons, key accents"
            />
            <ColorSwatch
              color="#8f181d"
              name="Brand Red Hover"
              value="#8f181d"
              description="Hover - Button hover states"
            />
            <ColorSwatch
              color="#771419"
              name="Brand Red Active"
              value="#771419"
              description="Active - Button active/pressed states"
            />
          </div>
        </div>

        {/* Complete Ken Bold Red Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Complete Ken Bold Red Scale (50-900)</h3>
          <p className="text-sm text-black/60 mb-6">
            Full tints & shades spectrum - Red 600 is the primary brand color
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Red 50', value: '#fef2f2', usage: 'Lightest - Subtle backgrounds, alert highlights' },
              { name: 'Red 100', value: '#fee2e2', usage: 'Very light - Notice backgrounds, hover states' },
              { name: 'Red 200', value: '#fecaca', usage: 'Light - Disabled states, soft accents' },
              { name: 'Red 300', value: '#fca5a7', usage: 'Medium light - Borders, dividers' },
              { name: 'Red 400', value: '#f87176', usage: 'Medium - Icons, secondary buttons' },
              { name: 'Red 500', value: '#dc3238', usage: 'Standard - Links, active states' },
              { name: 'Red 600', value: '#b01f24', usage: 'PRIMARY BRAND - CTAs, buttons' },
              { name: 'Red 700', value: '#8f181d', usage: 'Hover - Button hover states' },
              { name: 'Red 800', value: '#771419', usage: 'Active - Button pressed states' },
              { name: 'Red 900', value: '#5f1014', usage: 'Darkest - Text on light, deep shadows' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Gradient */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Animated CTA Gradient</h3>
          <p className="text-sm text-black/60 mb-4">
            Primary button gradient using Red 700 → Red 500
          </p>
          
          <div className="space-y-4">
            <GradientSwatch
              gradient="linear-gradient(135deg, #8f181d 0%, #dc3238 100%)"
              name="Ken Bold Red Gradient"
              description="Red 700 → Red 500 with hover animation"
            />
            
            {/* Live Button Example */}
            <div className="mt-6 p-6 bg-white rounded-[5px] border border-black/10">
              <div className="text-sm font-bold text-black mb-4">Live Example:</div>
              <button
                className="bg-gradient-to-br from-[#8f181d] to-[#dc3238] hover:from-[#b01f24] hover:to-[#f87176] text-white px-8 py-4 rounded-[5px] transition-all duration-300 font-bold"
              >
                Primary CTA Button
              </button>
            </div>
          </div>
        </div>

        <CodeBlockWithCopy
          language="tsx"
          code={`// Ken Bold Red - CSS Variables
--brand-red: #b01f24;         /* PRIMARY BRAND - Red 600 */
--brand-red-hover: #8f181d;   /* Red 700 - Hover state */
--brand-red-active: #771419;  /* Red 800 - Active state */

// Complete Red Scale (50-900)
--red-50: #fef2f2;    /* Lightest - Subtle backgrounds */
--red-100: #fee2e2;   /* Very light - Notice backgrounds */
--red-200: #fecaca;   /* Light - Disabled states */
--red-300: #fca5a7;   /* Medium light - Borders */
--red-400: #f87176;   /* Medium - Icons, secondary */
--red-500: #dc3238;   /* Standard - Links, active */
--red-600: #b01f24;   /* PRIMARY BRAND - CTAs */
--red-700: #8f181d;   /* Hover - Button hover */
--red-800: #771419;   /* Active - Button pressed */
--red-900: #5f1014;   /* Darkest - Text, shadows */

// Primary CTA Button with Gradient
<button className="
  bg-gradient-to-br from-[#8f181d] to-[#dc3238]
  hover:from-[#b01f24] hover:to-[#f87176]
  text-white px-8 py-4 rounded-[5px]
  transition-all duration-300 font-bold
">
  Primary CTA
</button>

// Solid Brand Red Button
<button className="
  bg-[#b01f24]
  hover:bg-[#8f181d]
  active:bg-[#771419]
  text-white px-6 py-3 rounded-[5px]
  transition-colors duration-200
">
  Brand Button
</button>`}
        />

        {/* Usage Guidelines */}
        <div className="mt-8 grid grid-cols-2 gap-6">
          {/* Do */}
          <div className="bg-white border border-green-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="size-5 text-green-600" />
              <h4 className="font-bold text-black">Do</h4>
            </div>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Use for primary CTAs only</li>
              <li>• Limit to 1-2 per screen</li>
              <li>• Apply gradient animation</li>
              <li>• Ensure high contrast</li>
            </ul>
          </div>

          {/* Don't */}
          <div className="bg-white border border-red-500/20 rounded-[10px] p-6">
            <div className="flex items-center gap-2 mb-4">
              <X className="size-5 text-red-600" />
              <h4 className="font-bold text-black">Don't</h4>
            </div>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Use for backgrounds</li>
              <li>• Apply to secondary actions</li>
              <li>• Overuse (max 5% of design)</li>
              <li>• Combine with other bright colors</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Accent Colors */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Accent Colors (3%)</h2>
        
        {/* What, Why, Where, When, How */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <div className="grid grid-cols-5 gap-6 mb-8">
            <div>
              <div className="text-sm font-bold text-black mb-2">WHAT</div>
              <p className="text-sm text-black/70">Subtle colors for shadows, badges, metrics, and non-critical information</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHY</div>
              <p className="text-sm text-black/70">Add visual interest and meaning without competing with CTAs or content</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHERE</div>
              <p className="text-sm text-black/70">Shadows (6-8%), status badges, metric highlights, data viz, subtle borders</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">WHEN</div>
              <p className="text-sm text-black/70">After foundation and CTAs are set - use to enhance, never to dominate</p>
            </div>
            <div>
              <div className="text-sm font-bold text-black mb-2">HOW</div>
              <p className="text-sm text-black/70">Use at low opacity (6-8% for shadows, 10% for backgrounds), full opacity for text only</p>
            </div>
          </div>

          <div className="border-t border-black/10 pt-6">
            <h3 className="text-lg font-bold text-black mb-4">Accent Color Strategy</h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-3">
                <div>
                  <div className="font-bold text-black mb-2">Custom Accents (Purple, Periwinkle, Perano)</div>
                  <p className="text-sm text-black/60">
                    Use these for brand-specific moments like premium features, trust signals, or data sections. 
                    They carry semantic meaning unique to your product.
                  </p>
                </div>
                <div>
                  <div className="font-bold text-black mb-2">Utility Colors (Rose, Green, Amber)</div>
                  <p className="text-sm text-black/60">
                    Standard colors with universal meaning - error/warning (rose), success (green), caution (amber). 
                    Use for system feedback and status indicators.
                  </p>
                </div>
              </div>
              <div className="space-y-3">
                <div>
                  <div className="font-bold text-black mb-2">The 3% Rule in Practice</div>
                  <p className="text-sm text-black/60 mb-2">
                    Measure accent usage by visible impact, not pixel count:
                  </p>
                  <ul className="text-sm text-black/60 space-y-1">
                    <li>• Shadow at 6% opacity = negligible impact</li>
                    <li>• Badge at 10% background = minimal</li>
                    <li>• Full color text/icon = high impact</li>
                    <li>• Keep high-impact accents under 3% viewport</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Strategic Usage Guide */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Strategic Usage Guide</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-3">✅ Perfect Use Cases</div>
                <ul className="text-xs text-black/70 space-y-1.5">
                  <li>• Card shadows (Purple/6-8%)</li>
                  <li>• Status badges ("Active", "Pro")</li>
                  <li>• Metric highlights (+23% in green)</li>
                  <li>• Category pills/tags</li>
                  <li>• Data visualization</li>
                  <li>• Subtle section backgrounds</li>
                </ul>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-3">⚠️ Use with Caution</div>
                <ul className="text-xs text-black/70 space-y-1.5">
                  <li>• Links (use sparingly, prefer black)</li>
                  <li>• Icons (only for status/meaning)</li>
                  <li>• Borders (prefer grayscale)</li>
                  <li>• Hover states (keep subtle)</li>
                  <li>• Secondary buttons (use ghost)</li>
                  <li>• Large background areas</li>
                </ul>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-3">❌ Never Use For</div>
                <ul className="text-xs text-black/70 space-y-1.5">
                  <li>• Primary CTAs (red only)</li>
                  <li>• Main navigation</li>
                  <li>• Hero backgrounds</li>
                  <li>• Body text</li>
                  <li>• Form inputs (grayscale)</li>
                  <li>• Competing with Ken Bold Red</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Accessibility & Combinations */}
          <div className="border-t border-black/10 pt-6 mt-6">
            <h3 className="text-lg font-bold text-black mb-4">Accessibility & Color Combinations</h3>
            <div className="space-y-3">
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium text-black">Contrast Requirements</span>
                  <span className="text-xs text-black/60">WCAG AA: 4.5:1 (text) | 3:1 (UI)</span>
                </div>
                <div className="grid grid-cols-4 gap-3 text-xs">
                  <div>
                    <div className="font-medium text-black mb-1">Purple 600</div>
                    <div className="text-black/60">White BG: 4.8:1 ✓</div>
                  </div>
                  <div>
                    <div className="font-medium text-black mb-1">Rose 600</div>
                    <div className="text-black/60">White BG: 4.7:1 ✓</div>
                  </div>
                  <div>
                    <div className="font-medium text-black mb-1">Green 600</div>
                    <div className="text-black/60">White BG: 4.8:1 ✓</div>
                  </div>
                  <div>
                    <div className="font-medium text-black mb-1">Amber 600</div>
                    <div className="text-black/60">White BG: 4.7:1 ✓</div>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-[5px] p-4 border border-black/10">
                <div className="font-medium text-black mb-3">✓ Safe Combinations (Never Clash)</div>
                <div className="text-sm text-black/60">
                  Accents can coexist on the same screen IF they serve different purposes and don't exceed 3% combined:
                  Purple shadow + Green metric + Rose badge = OK | Multiple colored CTAs = NOT OK
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Core Accents</h3>
          <div className="grid grid-cols-2 gap-6 mb-8">
            <ColorSwatch
              color="#806ce0"
              name="Purple 600"
              value="#806ce0"
              description="Premium features, innovation, insights"
            />
            <ColorSwatch
              color="#c3c6f9"
              name="Periwinkle 500"
              value="#c3c6f9"
              description="Trust indicators, reliability"
            />
            <ColorSwatch
              color="#dfeafa"
              name="Perano 500"
              value="#dfeafa"
              description="Data sections, calm professional"
            />
            <ColorSwatch
              color="#d9d1ce"
              name="Warm 600"
              value="#d9d1ce"
              description="Timeline, subtle contrasts"
            />
          </div>

          <h3 className="text-xl font-bold text-black mb-6 mt-8">Standard Utility Colors</h3>
          <div className="grid grid-cols-3 gap-6">
            <ColorSwatch
              color="#f43f5e"
              name="Rose 500"
              value="#f43f5e"
              description="Error messages, warnings"
            />
            <ColorSwatch
              color="#10b981"
              name="Green 500"
              value="#10b981"
              description="Success, positive metrics"
            />
            <ColorSwatch
              color="#f59e0b"
              name="Amber 500"
              value="#f59e0b"
              description="Warning, highlights"
            />
          </div>
        </div>

        {/* Standard Utility Blues */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-6">
          <h3 className="text-xl font-bold text-black mb-6">Rose Scale (Error/Warning)</h3>
          <p className="text-sm text-black/60 mb-6">
            Pink-toned red for form errors, validation, and warnings - Distinct from Ken Bold Red
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Rose 50', value: '#fff1f2', usage: 'Lightest - Error backgrounds' },
              { name: 'Rose 100', value: '#ffe4e6', usage: 'Very light - Alert highlights' },
              { name: 'Rose 200', value: '#fecdd3', usage: 'Light - Soft error states' },
              { name: 'Rose 300', value: '#fda4af', usage: 'Medium light - Error borders' },
              { name: 'Rose 400', value: '#fb7185', usage: 'Medium - Error icons' },
              { name: 'Rose 500', value: '#f43f5e', usage: 'BASE - Error messages' },
              { name: 'Rose 600', value: '#e11d48', usage: 'Primary - Destructive actions' },
              { name: 'Rose 700', value: '#be123c', usage: 'Deep - Hover states' },
              { name: 'Rose 800', value: '#9f1239', usage: 'Dark - Active states' },
              { name: 'Rose 900', value: '#881337', usage: 'Darkest - Text on light' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Purple Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-6">
          <h3 className="text-xl font-bold text-black mb-6">Purple Scale (True V)</h3>
          <p className="text-sm text-black/60 mb-6">
            For premium features, innovation, and insights - Full 50-900 scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Purple 50', value: '#f7f6fe', usage: 'Lightest - Subtle highlights, backgrounds' },
              { name: 'Purple 100', value: '#efedfd', usage: 'Very light - Hover states, cards' },
              { name: 'Purple 200', value: '#dfdcfb', usage: 'Light - Borders, dividers' },
              { name: 'Purple 300', value: '#c4bef7', usage: 'Medium light - Icons, badges' },
              { name: 'Purple 400', value: '#a89ff2', usage: 'Medium - Secondary accents' },
              { name: 'Purple 500', value: '#9488ec', usage: 'Standard - Interactive elements' },
              { name: 'Purple 600', value: '#806ce0', usage: 'BASE - Premium features' },
              { name: 'Purple 700', value: '#6c5bc0', usage: 'Hover - Button hover' },
              { name: 'Purple 800', value: '#5a4ba0', usage: 'Active - Button active' },
              { name: 'Purple 900', value: '#483c80', usage: 'Darkest - Text, deep accents' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Periwinkle Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-6">
          <h3 className="text-xl font-bold text-black mb-6">Periwinkle Scale</h3>
          <p className="text-sm text-black/60 mb-6">
            For trust, reliability, and soft accents - Full 50-900 scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Periwinkle 50', value: '#fafbfe', usage: 'Lightest - Subtle backgrounds' },
              { name: 'Periwinkle 100', value: '#f5f6fd', usage: 'Very light - Card backgrounds' },
              { name: 'Periwinkle 200', value: '#ebedfb', usage: 'Light - Hover states' },
              { name: 'Periwinkle 300', value: '#dfe1f9', usage: 'Medium light - Soft accents' },
              { name: 'Periwinkle 400', value: '#d3d5f9', usage: 'Medium - Borders, dividers' },
              { name: 'Periwinkle 500', value: '#c3c6f9', usage: 'BASE - Trust indicators' },
              { name: 'Periwinkle 600', value: '#a7abf0', usage: 'Standard - Interactive' },
              { name: 'Periwinkle 700', value: '#8b90e0', usage: 'Hover - Links, buttons' },
              { name: 'Periwinkle 800', value: '#7075c8', usage: 'Active - Active states' },
              { name: 'Periwinkle 900', value: '#5a5fa0', usage: 'Darkest - Text on light' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Perano Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-6">
          <h3 className="text-xl font-bold text-black mb-6">Perano Scale (Light Blue)</h3>
          <p className="text-sm text-black/60 mb-6">
            For calm, professional data sections - Full 50-900 scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Perano 50', value: '#fcfdfe', usage: 'Lightest - Barely visible' },
              { name: 'Perano 100', value: '#f9fbfe', usage: 'Very light - Subtle highlights' },
              { name: 'Perano 200', value: '#f4f8fd', usage: 'Light - Card backgrounds' },
              { name: 'Perano 300', value: '#eff5fc', usage: 'Medium light - Hover states' },
              { name: 'Perano 400', value: '#e9f2fb', usage: 'Medium - Soft accents' },
              { name: 'Perano 500', value: '#dfeafa', usage: 'BASE - Data sections' },
              { name: 'Perano 600', value: '#c8dff5', usage: 'Standard - Borders' },
              { name: 'Perano 700', value: '#a7c9ed', usage: 'Hover - Interactive' },
              { name: 'Perano 800', value: '#86b3e5', usage: 'Active - Active states' },
              { name: 'Perano 900', value: '#6b94c0', usage: 'Darkest - Text, accents' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Green Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-6">
          <h3 className="text-xl font-bold text-black mb-6">Green Scale (Utility)</h3>
          <p className="text-sm text-black/60 mb-6">
            For success states and positive metrics - Full 50-900 scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Green 50', value: '#ecfdf5', usage: 'Lightest' },
              { name: 'Green 100', value: '#d1fae5', usage: 'Very light' },
              { name: 'Green 200', value: '#a7f3d0', usage: 'Light' },
              { name: 'Green 300', value: '#6ee7b7', usage: 'Medium light' },
              { name: 'Green 400', value: '#34d399', usage: 'Medium' },
              { name: 'Green 500', value: '#10b981', usage: 'BASE' },
              { name: 'Green 600', value: '#059669', usage: 'Primary' },
              { name: 'Green 700', value: '#047857', usage: 'Deep' },
              { name: 'Green 800', value: '#065f46', usage: 'Dark' },
              { name: 'Green 900', value: '#064e3b', usage: 'Darkest' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        {/* Amber Scale */}
        <div className="bg-[#f5f2f1] rounded-[10px] p-8 mb-8">
          <h3 className="text-xl font-bold text-black mb-6">Amber Scale (Utility)</h3>
          <p className="text-sm text-black/60 mb-6">
            For warning states and attention highlights - Full 50-900 scale
          </p>
          
          <div className="grid grid-cols-10 gap-3">
            {[
              { name: 'Amber 50', value: '#fffbeb', usage: 'Lightest' },
              { name: 'Amber 100', value: '#fef3c7', usage: 'Very light' },
              { name: 'Amber 200', value: '#fde68a', usage: 'Light' },
              { name: 'Amber 300', value: '#fcd34d', usage: 'Medium light' },
              { name: 'Amber 400', value: '#fbbf24', usage: 'Medium' },
              { name: 'Amber 500', value: '#f59e0b', usage: 'BASE' },
              { name: 'Amber 600', value: '#d97706', usage: 'Primary' },
              { name: 'Amber 700', value: '#b45309', usage: 'Deep' },
              { name: 'Amber 800', value: '#92400e', usage: 'Dark' },
              { name: 'Amber 900', value: '#78350f', usage: 'Darkest' },
            ].map(({ name, value, usage }) => (
              <div key={name} className="space-y-2">
                <div 
                  className="w-full aspect-square rounded-[5px] border border-black/10"
                  style={{ backgroundColor: value }}
                />
                <div className="text-[10px] font-bold text-black leading-tight">{name}</div>
                <div className="text-[9px] text-black/60 leading-tight">{usage}</div>
                <code className="text-[9px] bg-white px-1.5 py-0.5 rounded block break-all">
                  {value}
                </code>
              </div>
            ))}
          </div>
        </div>

        <CodeBlockWithCopy
          language="tsx"
          code={`// Custom Accent Colors - Full 50-900 Scales

// Purple (True V) - Premium, Innovation, Insights
--purple-50: #f7f6fe;   --purple-100: #efedfd;  --purple-200: #dfdcfb;
--purple-300: #c4bef7;  --purple-400: #a89ff2;  --purple-500: #9488ec;
--purple-600: #806ce0;  /* BASE */
--purple-700: #6c5bc0;  --purple-800: #5a4ba0;  --purple-900: #483c80;

// Periwinkle - Trust, Reliability, Soft Accents
--periwinkle-50: #fafbfe;   --periwinkle-100: #f5f6fd;  --periwinkle-200: #ebedfb;
--periwinkle-300: #dfe1f9;  --periwinkle-400: #d3d5f9;  --periwinkle-500: #c3c6f9;
/* BASE */
--periwinkle-600: #a7abf0;  --periwinkle-700: #8b90e0;  --periwinkle-800: #7075c8;
--periwinkle-900: #5a5fa0;

// Perano (Light Blue) - Calm, Professional, Data
--perano-50: #fcfdfe;   --perano-100: #f9fbfe;  --perano-200: #f4f8fd;
--perano-300: #eff5fc;  --perano-400: #e9f2fb;  --perano-500: #dfeafa;
/* BASE */
--perano-600: #c8dff5;  --perano-700: #a7c9ed;  --perano-800: #86b3e5;
--perano-900: #6b94c0;

// Standard Utility Colors (50-900)
// Rose - Error, Warning, Validation
// Green - Success, Positive Metrics  
// Amber - Warning, Highlights

// Usage Examples:
<div className="bg-[#f7f6fe]">Purple 50 background</div>
<div className="text-[#806ce0]">Purple 600 text</div>
<div className="border-[#c3c6f9]">Periwinkle 500 border</div>
<div className="shadow-lg shadow-[#dfeafa]/20">Perano shadow</div>`}
        />
      </section>

      {/* Opacity System */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-black mb-6">Opacity Hierarchy</h2>
        <p className="text-lg text-black/70 mb-8">
          Use opacity to create visual hierarchy without introducing new colors.
        </p>

        <div className="bg-[#f5f2f1] rounded-[10px] p-8">
          <div className="space-y-4">
            {[
              { opacity: 100, label: 'Primary', usage: 'Headings, key content' },
              { opacity: 70, label: 'Secondary', usage: 'Body text, descriptions' },
              { opacity: 40, label: 'Tertiary', usage: 'Captions, labels' },
              { opacity: 20, label: 'Disabled', usage: 'Inactive states' },
              { opacity: 10, label: 'Borders', usage: 'Subtle dividers' },
              { opacity: 5, label: 'Backgrounds', usage: 'Hover states' },
            ].map(({ opacity, label, usage }) => (
              <div key={opacity} className="flex items-center gap-4">
                <div 
                  className="w-24 h-12 rounded-[5px] border border-black/10"
                  style={{ backgroundColor: `rgba(0, 0, 0, ${opacity / 100})` }}
                />
                <div className="flex-1">
                  <div className="font-bold text-black">{opacity}% - {label}</div>
                  <div className="text-sm text-black/60">{usage}</div>
                </div>
                <code className="text-sm bg-white px-3 py-1 rounded-[5px] border border-black/10">
                  text-black/{opacity}
                </code>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Color Usage Summary */}
      <section>
        <div className="bg-black text-white rounded-[10px] p-8">
          <h3 className="text-2xl font-bold mb-6">92-5-3 Rule Summary</h3>
          
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-4xl font-bold mb-2">92%</div>
              <div className="text-white/70 mb-2">Foundation</div>
              <div className="text-sm text-white/60">Black, white, warm off-white with opacity variations</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2 text-red-500">5%</div>
              <div className="text-white/70 mb-2">Brand Red</div>
              <div className="text-sm text-white/60">Major CTAs only, gradient animation</div>
            </div>
            
            <div>
              <div className="text-4xl font-bold mb-2 text-blue-400">3%</div>
              <div className="text-white/70 mb-2">Accents</div>
              <div className="text-sm text-white/60">Shadows, metrics, subtle highlights</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}