/**
 * Enhanced Design System - Single Page (Stripe-Style)
 * 
 * Comprehensive design system documentation with:
 * - Sticky table of contents
 * - Collapsible sections
 * - Interactive playgrounds
 * - Copy-to-clipboard code snippets
 * - Do/Don't examples
 * - Props tables
 */

import React, { useState, useEffect } from 'react';
import { TableOfContents, TOCSection } from './TableOfContents';
import { CodeBlockWithCopy } from './CodeBlockWithCopy';
import { ButtonPlayground } from './ButtonPlayground';
import { CollapsibleSection } from './CollapsibleSection';
import { Button } from './Button';
import { ColorSwatch, ColorSwatchGrid, GradientSwatch } from '@/design-system';
import { TypeScale } from '@/design-system';
import { SpacingScale, SpacingExample, SectionSpacingGuide } from '@/design-system';
import { DoAndDont, PropertyTable } from '@/design-system';
import { colors } from '@/design-system';
import { ArrowRight, Download, Heart, Star, User, Mail, Search } from 'lucide-react';

export function EnhancedDesignSystem() {
  const [activeSection, setActiveSection] = useState('getting-started');
  const [searchQuery, setSearchQuery] = useState('');

  // Table of Contents structure
  const tocSections: TOCSection[] = [
    {
      id: 'getting-started',
      label: 'Getting Started',
    },
    {
      id: 'foundation',
      label: 'Foundation',
      subsections: [
        { id: 'colors', label: 'Colors' },
        { id: 'typography', label: 'Typography' },
        { id: 'spacing', label: 'Spacing' },
        { id: 'shadows', label: 'Shadows' },
        { id: 'border-radius', label: 'Border Radius' },
        { id: 'motion', label: 'Motion' },
        { id: 'icons', label: 'Icons' },
      ],
    },
    {
      id: 'components',
      label: 'Components',
      subsections: [
        { id: 'buttons', label: 'Buttons' },
        { id: 'cards', label: 'Cards' },
      ],
    },
    {
      id: 'patterns',
      label: 'Patterns',
      subsections: [
        { id: 'hero-section', label: 'Hero Section' },
        { id: 'feature-grid', label: 'Feature Grid' },
        { id: 'cta-section', label: 'CTA Section' },
        { id: 'stats-grid', label: 'Stats Grid' },
      ],
    },
    {
      id: 'resources',
      label: 'Resources',
    },
  ];

  // Smooth scroll to section
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
      setActiveSection(id);
    }
  };

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = tocSections.flatMap(section => [
        section.id,
        ...(section.subsections?.map(sub => sub.id) || [])
      ]);

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= 200) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black text-white border-b border-white/10">
        <div className="max-w-[1400px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Design System</h1>
              <p className="text-sm text-white/70">Premium Editorial Design System v1.0</p>
            </div>
            
            {/* Search */}
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-[5px] text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/40"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-12">
          {/* Sidebar - Table of Contents */}
          <aside className="hidden lg:block">
            <TableOfContents
              sections={tocSections}
              activeSection={activeSection}
              onNavigate={scrollToSection}
            />
          </aside>

          {/* Content */}
          <main className="max-w-[900px]">
            
            {/* ===================================
                GETTING STARTED
                =================================== */}
            <section id="getting-started" className="mb-20 scroll-mt-24">
              <h2 className="text-4xl font-bold text-black mb-4">Getting Started</h2>
              <p className="text-lg text-black/70 mb-8">
                A comprehensive design system built on minimalist editorial principles, featuring a strict 92-5-3 color hierarchy, Major Third typography scale (1.25 ratio), and premium glass-morphism aesthetics.
              </p>

              <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5 mb-8">
                <h3 className="text-xl font-bold text-black mb-4">Installation</h3>
                <CodeBlockWithCopy
                  code={`// Import design tokens
import { colors, typography, spacing } from '@/design-system';

// Import components
import { Button } from '@/app/components/Button';
import { ColorSwatch, TypeScale } from '@/design-system';`}
                  language="typescript"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white border border-black/10 rounded-[10px] p-6">
                  <div className="text-3xl font-bold text-black mb-2">92-5-3</div>
                  <div className="text-sm font-bold text-black mb-1">Color Hierarchy</div>
                  <div className="text-xs text-black/60">Foundation 92%, Red 5%, Accents 3%</div>
                </div>
                <div className="bg-white border border-black/10 rounded-[10px] p-6">
                  <div className="text-3xl font-bold text-black mb-2">1.25x</div>
                  <div className="text-sm font-bold text-black mb-1">Major Third Scale</div>
                  <div className="text-xs text-black/60">Harmonious typography ratio</div>
                </div>
                <div className="bg-white border border-black/10 rounded-[10px] p-6">
                  <div className="text-3xl font-bold text-black mb-2">4px</div>
                  <div className="text-sm font-bold text-black mb-1">Base Spacing Unit</div>
                  <div className="text-xs text-black/60">Consistent spacing system</div>
                </div>
              </div>

              <div className="bg-black text-white rounded-[10px] p-6">
                <h4 className="text-lg font-bold mb-2">Design Philosophy</h4>
                <ul className="space-y-2 text-sm text-white/70">
                  <li>→ Minimalist editorial aesthetic with generous whitespace</li>
                  <li>→ Black and white foundation with strategic red accents</li>
                  <li>→ Premium glass-morphism and smooth transitions</li>
                  <li>→ Atomic Design methodology (Atoms → Molecules → Organisms)</li>
                  <li>→ Accessibility-first approach (WCAG 2.1 AA compliant)</li>
                </ul>
              </div>
            </section>

            {/* ===================================
                FOUNDATION - COLORS
                =================================== */}
            <section id="colors" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Colors</h2>
                <p className="text-base text-black/60">
                  Our color system follows a strict 92-5-3 hierarchy: 92% black/white/warm foundation, 5% Ken Bold Red for CTAs, and 3% accent colors for shadows and highlights only.
                </p>
              </div>

              <div className="space-y-8">
                {/* Primary Palette */}
                <CollapsibleSection 
                  title="Primary Palette (92% Usage)"
                  subtitle="Foundation colors used throughout the entire system"
                  defaultOpen={true}
                >
                  <ColorSwatchGrid
                    colors={[
                      { 
                        color: '#000000', 
                        name: 'Pure Black',
                        usage: 'Text, dark backgrounds, high contrast elements'
                      },
                      { 
                        color: '#ffffff', 
                        name: 'Pure White',
                        usage: 'Light backgrounds, text on dark backgrounds',
                        showBorder: true
                      },
                      { 
                        color: '#f5f2f1', 
                        name: 'Warm Off-White',
                        usage: 'Highlighted sections, testimonials, feature cards'
                      },
                      { 
                        color: '#eae5e3', 
                        name: 'Warm Border',
                        usage: 'Subtle borders on warm backgrounds'
                      },
                    ]}
                    columns={4}
                  />

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { colors } from '@/design-system';

// Use in your components
<div style={{ backgroundColor: colors.warmBg }}>
  <h1 style={{ color: colors.black }}>Heading</h1>
</div>

// Or with Tailwind
<div className="bg-[#f5f2f1]">
  <h1 className="text-black">Heading</h1>
</div>`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Brand Red */}
                <CollapsibleSection 
                  title="Brand Red (5% Usage - CTAs Only)"
                  subtitle="Ken Bold Red - use sparingly for maximum impact"
                  defaultOpen={true}
                >
                  <div className="bg-white border border-black/10 rounded-[5px] p-4 mb-6">
                    <div className="text-sm font-bold text-black mb-2">⚠️ Critical Rule</div>
                    <div className="text-sm text-black/70">
                      Brand red should comprise maximum 5% of your design. Use only for primary CTAs. Maximum 1 brand red button per section.
                    </div>
                  </div>

                  <ColorSwatchGrid
                    colors={[
                      { 
                        color: '#c62d31', 
                        name: 'Red 500',
                        usage: 'Gradient end point'
                      },
                      { 
                        color: '#b01f24', 
                        name: 'Red 600 (Brand)',
                        usage: 'Primary brand color, gradient start'
                      },
                      { 
                        color: '#8f181d', 
                        name: 'Red 700',
                        usage: 'Hover state'
                      },
                    ]}
                    columns={3}
                  />

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { colors } from '@/design-system';

// Brand red button (use sparingly!)
<Button 
  variant="brand"
  style={{ background: 'linear-gradient(90deg, #b01f24, #c62d31)' }}
>
  Primary CTA
</Button>`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Gradients */}
                <CollapsibleSection 
                  title="Gradients"
                  subtitle="Two core gradients used in the system"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <GradientSwatch
                      gradient="linear-gradient(90deg, #0a0a0a, #6a6a6a)"
                      name="Primary Dark-to-Grey"
                      usage="Primary buttons, dark sections"
                    />
                    <GradientSwatch
                      gradient="linear-gradient(90deg, #b01f24, #c62d31)"
                      name="Brand Red Gradient"
                      usage="Brand buttons with animated shift effect"
                    />
                  </div>

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { gradients } from '@/design-system';

// Apply gradients
<div style={{ backgroundImage: gradients.primary }}>
  Dark gradient background
</div>

<button style={{ backgroundImage: gradients.brandRed }}>
  Brand CTA
</button>`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Do's and Don'ts */}
                <CollapsibleSection 
                  title="Usage Guidelines"
                  subtitle="Best practices for color usage"
                >
                  <DoAndDont
                    do={{
                      label: "Use foundation colors for 92% of design",
                      content: (
                        <div className="space-y-3">
                          <div className="bg-[#f5f2f1] p-6 rounded-[5px]">
                            <p className="text-sm text-black">Content section with warm background</p>
                          </div>
                          <Button variant="brand" size="md">Primary CTA</Button>
                          <p className="text-xs text-black/60">One brand button per section</p>
                        </div>
                      )
                    }}
                    dont={{
                      label: "Don't overuse brand red or accent colors",
                      content: (
                        <div className="space-y-3">
                          <div className="bg-[#806ce0] p-6 rounded-[5px]">
                            <p className="text-sm text-white">Accent color as background</p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="brand" size="sm">CTA 1</Button>
                            <Button variant="brand" size="sm">CTA 2</Button>
                          </div>
                          <p className="text-xs text-black/60">Multiple brand buttons</p>
                        </div>
                      )
                    }}
                  />
                </CollapsibleSection>
              </div>
            </section>

            {/* ===================================
                FOUNDATION - TYPOGRAPHY
                =================================== */}
            <section id="typography" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Typography</h2>
                <p className="text-base text-black/60">
                  Our typography system uses a Major Third scale (1.25 ratio) with 16px base size, creating harmonious proportions and clear visual hierarchy.
                </p>
              </div>

              <div className="space-y-8">
                {/* Type Scale */}
                <CollapsibleSection 
                  title="Type Scale"
                  subtitle="Major Third ratio (1.25x) - 16px base"
                  defaultOpen={true}
                >
                  <TypeScale variant="essential" />

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { typography } from '@/design-system';

// Use in inline styles
<h1 style={{ fontSize: typography.size['3xl'] }}>
  Hero Heading
</h1>

// Or with CSS variables
<h2 style={{ fontSize: 'var(--text-2xl)' }}>
  Section Heading
</h2>

// Tailwind (use CSS variables)
<h3 className="text-[var(--text-xl)] font-bold">
  Subsection Heading
</h3>`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Usage Guidelines */}
                <CollapsibleSection 
                  title="Hierarchy Rules"
                  subtitle="When to use each type size"
                >
                  <div className="space-y-4">
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-3xl (48.8px)</div>
                      <div className="text-sm text-black/70">
                        Reserved for hero H1 only. Maximum once per page. Use for main page title or hero statement.
                      </div>
                    </div>
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-2xl (39px)</div>
                      <div className="text-sm text-black/70">
                        Standard for section H2 headings. Use for main content sections throughout the page.
                      </div>
                    </div>
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-xl (31.25px)</div>
                      <div className="text-sm text-black/70">
                        Subsection H3 headings. Use for subsections, objectives, methodology steps.
                      </div>
                    </div>
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-lg (25px)</div>
                      <div className="text-sm text-black/70">
                        Card titles when displaying 2-3 cards. Prominent call-outs.
                      </div>
                    </div>
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-base (20px)</div>
                      <div className="text-sm text-black/70">
                        Large body text, card titles when 4+ cards present, prominent paragraphs.
                      </div>
                    </div>
                    <div className="border-l-4 border-black/20 pl-4">
                      <div className="text-sm font-bold text-black mb-1">--text-sm (16px)</div>
                      <div className="text-sm text-black/70">
                        Standard body text, descriptions, paragraphs. Default for most content.
                      </div>
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Accessibility */}
                <CollapsibleSection 
                  title="Accessibility"
                  subtitle="WCAG 2.1 AA compliance"
                >
                  <div className="bg-[#f5f2f1] rounded-[5px] p-6 space-y-4">
                    <div>
                      <div className="text-sm font-bold text-black mb-2">✓ Contrast Ratios</div>
                      <ul className="text-sm text-black/70 space-y-1">
                        <li>• Black on white: 21:1 (AAA)</li>
                        <li>• Black on warm (#f5f2f1): 19.2:1 (AAA)</li>
                        <li>• White on black: 21:1 (AAA)</li>
                        <li>• Red 600 on white: 7.8:1 (AA large text)</li>
                      </ul>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-black mb-2">✓ Minimum Sizes</div>
                      <ul className="text-sm text-black/70 space-y-1">
                        <li>• Body text: 16px minimum (--text-sm)</li>
                        <li>• Touch targets: 44px minimum</li>
                        <li>• Line height: 1.5-1.6 for body text</li>
                      </ul>
                    </div>
                  </div>
                </CollapsibleSection>
              </div>
            </section>

            {/* ===================================
                FOUNDATION - SPACING
                =================================== */}
            <section id="spacing" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Spacing</h2>
                <p className="text-base text-black/60">
                  4px base unit system ensuring consistent spacing throughout the design. All spacing values are multiples of 4px.
                </p>
              </div>

              <div className="space-y-8">
                {/* Spacing Scale */}
                <CollapsibleSection 
                  title="Spacing Scale"
                  subtitle="4px base unit with 11 values"
                  defaultOpen={true}
                >
                  <SpacingScale showTailwind />

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { spacing } from '@/design-system';

// Use in inline styles
<div style={{ 
  padding: spacing.rem[8],
  gap: spacing.rem[6]
}}>
  Content
</div>

// Or use pixel values
const cardPadding = spacing.px[8]; // 32px

// Tailwind classes (standard)
<div className="p-8 gap-6">
  Content
</div>`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Layout Examples */}
                <CollapsibleSection 
                  title="Layout Examples"
                  subtitle="Spacing in context"
                >
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-bold text-black mb-3">Grid with gap-6 (24px)</h4>
                      <SpacingExample gap={6} layout="grid" itemCount={6} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-black mb-3">Horizontal stack with gap-4 (16px)</h4>
                      <SpacingExample gap={4} layout="horizontal" itemCount={3} />
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Guidelines */}
                <CollapsibleSection 
                  title="Usage Guidelines"
                  subtitle="Recommended spacing for common patterns"
                >
                  <SectionSpacingGuide />
                </CollapsibleSection>
              </div>
            </section>

            {/* ===================================
                FOUNDATION - SHADOWS
                =================================== */}
            <section id="shadows" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Shadows</h2>
                <p className="text-base text-black/60">
                  Three-level shadow system for subtle elevation and depth.
                </p>
              </div>

              <CollapsibleSection 
                title="Shadow Scale"
                subtitle="SM, MD, LG elevations"
                defaultOpen={true}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">shadow-sm</p>
                      <p className="text-xs text-black/60">Subtle elevation</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">shadow-md</p>
                      <p className="text-xs text-black/60">Standard cards</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-32 bg-white rounded-[5px]" style={{ boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">shadow-lg</p>
                      <p className="text-xs text-black/60">Prominent elements</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`import { shadows } from '@/design-system';

// Use in styles
<div style={{ boxShadow: shadows.md }}>
  Card content
</div>

// Tailwind
<div className="shadow-md">
  Card content
</div>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                FOUNDATION - BORDER RADIUS
                =================================== */}
            <section id="border-radius" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Border Radius</h2>
                <p className="text-base text-black/60">
                  Three-tier border radius system. Critical rule: Never mix radius sizes within the same component.
                </p>
              </div>

              <CollapsibleSection 
                title="Border Radius Scale"
                subtitle="2.5px, 5px, 10px"
                defaultOpen={true}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '2.5px' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">2.5px</p>
                      <p className="text-xs text-black/60">Images, Photos</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '5px' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">5px</p>
                      <p className="text-xs text-black/60">Buttons, Small Cards</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-32 bg-black/5 border border-black/10" style={{ borderRadius: '10px' }}></div>
                    <div>
                      <p className="text-sm font-mono text-black">10px</p>
                      <p className="text-xs text-black/60">Big Cards, Containers</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-[#f5f2f1] rounded-[5px] p-4">
                  <div className="text-sm font-bold text-black mb-2">⚠️ Critical Rule</div>
                  <div className="text-sm text-black/70">
                    Never mix border radius sizes within the same component. If your card uses 10px radius, all internal elements (buttons, images) should also use 10px or maintain their designated tier consistently.
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`import { borderRadius } from '@/design-system';

// Use in styles
<img 
  src="..." 
  style={{ borderRadius: borderRadius.image }}
/>

<button style={{ borderRadius: borderRadius.small }}>
  Click Me
</button>

<div style={{ borderRadius: borderRadius.large }}>
  Card container
</div>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                FOUNDATION - MOTION
                =================================== */}
            <section id="motion" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Motion & Animation</h2>
                <p className="text-base text-black/60">
                  Smooth, purposeful animations that enhance user experience without distraction.
                </p>
              </div>

              <div className="space-y-8">
                {/* Easing Functions */}
                <CollapsibleSection 
                  title="Easing Functions"
                  subtitle="Cubic-bezier curves for natural motion"
                  defaultOpen={true}
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-white border border-black/10 rounded-[5px]">
                      <div>
                        <div className="text-sm font-mono text-black">smooth</div>
                        <div className="text-xs text-black/60">cubic-bezier(0.22, 1, 0.36, 1)</div>
                      </div>
                      <div className="text-xs text-black/60">Most transitions</div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white border border-black/10 rounded-[5px]">
                      <div>
                        <div className="text-sm font-mono text-black">bounce</div>
                        <div className="text-xs text-black/60">cubic-bezier(0.34, 1.56, 0.64, 1)</div>
                      </div>
                      <div className="text-xs text-black/60">Playful interactions</div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <CodeBlockWithCopy
                      code={`import { easing, duration } from '@/design-system';

// Use in styles
<button style={{
  transition: \`all \${duration.fast} \${easing.smooth}\`
}}>
  Hover me
</button>

// CSS
.button {
  transition: all 300ms cubic-bezier(0.22, 1, 0.36, 1);
}`}
                    />
                  </div>
                </CollapsibleSection>

                {/* Duration Scale */}
                <CollapsibleSection 
                  title="Duration Scale"
                  subtitle="150ms to 900ms"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white border border-black/10 rounded-[5px]">
                      <span className="text-sm font-mono text-black">instant</span>
                      <span className="text-xs text-black/60">150ms - Quick hover states</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white border border-black/10 rounded-[5px]">
                      <span className="text-sm font-mono text-black">fast</span>
                      <span className="text-xs text-black/60">300ms - Standard transitions</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white border border-black/10 rounded-[5px]">
                      <span className="text-sm font-mono text-black">normal</span>
                      <span className="text-xs text-black/60">600ms - Page transitions</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-white border border-black/10 rounded-[5px]">
                      <span className="text-sm font-mono text-black">slow</span>
                      <span className="text-xs text-black/60">900ms - Complex animations</span>
                    </div>
                  </div>
                </CollapsibleSection>
              </div>
            </section>

            {/* ===================================
                FOUNDATION - ICONS
                =================================== */}
            <section id="icons" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Foundation</span>
                <h2 className="text-4xl font-bold text-black mb-3">Icons</h2>
                <p className="text-base text-black/60">
                  Using Lucide React - a comprehensive icon library with consistent 24x24 base size.
                </p>
              </div>

              <CollapsibleSection 
                title="Icon Library"
                subtitle="Lucide React icons"
                defaultOpen={true}
              >
                <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
                  {[
                    { Icon: ArrowRight, name: 'ArrowRight' },
                    { Icon: Download, name: 'Download' },
                    { Icon: Heart, name: 'Heart' },
                    { Icon: Star, name: 'Star' },
                    { Icon: User, name: 'User' },
                    { Icon: Mail, name: 'Mail' },
                  ].map(({ Icon, name }) => (
                    <div key={name} className="flex flex-col items-center gap-2 p-4 bg-white border border-black/10 rounded-[5px] hover:border-black/30 transition-colors">
                      <Icon className="w-6 h-6 text-black" />
                      <span className="text-xs text-black/60">{name}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`import { ArrowRight, Download, Heart } from 'lucide-react';

// Use in buttons
<Button 
  icon={<ArrowRight className="w-4 h-4" />}
  iconPosition="right"
>
  Learn More
</Button>

// Standalone
<Download className="w-6 h-6 text-black" />`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                COMPONENTS - BUTTONS
                =================================== */}
            <section id="buttons" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Components</span>
                <h2 className="text-4xl font-bold text-black mb-3">Buttons</h2>
                <p className="text-base text-black/60">
                  Interactive button components with four variants, four sizes, multiple states, and icon support.
                </p>
              </div>

              <div className="space-y-8">
                {/* Interactive Playground */}
                <div>
                  <h3 className="text-2xl font-bold text-black mb-4">Interactive Playground</h3>
                  <p className="text-sm text-black/60 mb-6">
                    Experiment with different button configurations and copy the generated code.
                  </p>
                  <ButtonPlayground />
                </div>

                {/* Variants */}
                <CollapsibleSection 
                  title="Variants"
                  subtitle="Four button variants for different use cases"
                  defaultOpen={true}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
                      <div className="mb-4">
                        <h4 className="text-lg font-bold text-black mb-1">Brand</h4>
                        <p className="text-xs text-black/60">Highest conversion priority</p>
                      </div>
                      <Button variant="brand" size="lg" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                        Primary CTA
                      </Button>
                      <div className="mt-4 text-xs text-black/60">
                        ✓ Maximum 1 per section<br />
                        ✓ Red gradient with animated shift<br />
                        ✓ Use for primary conversion actions
                      </div>
                    </div>

                    <div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
                      <div className="mb-4">
                        <h4 className="text-lg font-bold text-black mb-1">Primary</h4>
                        <p className="text-xs text-black/60">Secondary important actions</p>
                      </div>
                      <Button variant="primary" size="lg" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                        Secondary Action
                      </Button>
                      <div className="mt-4 text-xs text-black/60">
                        ✓ Dark-to-grey gradient<br />
                        ✓ Strong visual weight<br />
                        ✓ Use for important secondary actions
                      </div>
                    </div>

                    <div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
                      <div className="mb-4">
                        <h4 className="text-lg font-bold text-black mb-1">Secondary</h4>
                        <p className="text-xs text-black/60">Alternative actions</p>
                      </div>
                      <Button variant="secondary" size="lg">
                        Alternative Action
                      </Button>
                      <div className="mt-4 text-xs text-black/60">
                        ✓ Subtle border style<br />
                        ✓ Lower visual weight<br />
                        ✓ Use for tertiary actions
                      </div>
                    </div>

                    <div className="bg-black rounded-[10px] p-6">
                      <div className="mb-4">
                        <h4 className="text-lg font-bold text-white mb-1">Ghost</h4>
                        <p className="text-xs text-white/60">Subtle actions on dark</p>
                      </div>
                      <Button variant="ghost" size="lg" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                        Tertiary Action
                      </Button>
                      <div className="mt-4 text-xs text-white/60">
                        ✓ Only on dark backgrounds<br />
                        ✓ Minimal visual weight<br />
                        ✓ Use for less important actions
                      </div>
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Sizes */}
                <CollapsibleSection 
                  title="Sizes"
                  subtitle="Four size options: SM (40px), MD (48px), LG (56px), XL (64px)"
                >
                  <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                    <div className="flex flex-wrap gap-4 items-end">
                      <div className="space-y-2">
                        <Button variant="primary" size="sm">Small</Button>
                        <p className="text-xs text-black/60 text-center">40px</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="primary" size="md">Medium</Button>
                        <p className="text-xs text-black/60 text-center">48px (default)</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="primary" size="lg">Large</Button>
                        <p className="text-xs text-black/60 text-center">56px</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="primary" size="xl">Extra Large</Button>
                        <p className="text-xs text-black/60 text-center">64px</p>
                      </div>
                    </div>
                  </div>
                </CollapsibleSection>

                {/* States */}
                <CollapsibleSection 
                  title="States"
                  subtitle="Default, Hover, Loading, Disabled"
                >
                  <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                    <div className="flex flex-wrap gap-4">
                      <div className="space-y-2">
                        <Button variant="brand" size="lg">Default</Button>
                        <p className="text-xs text-black/60 text-center">Normal state</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="brand" size="lg" loading>Loading</Button>
                        <p className="text-xs text-black/60 text-center">With spinner</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="brand" size="lg" disabled>Disabled</Button>
                        <p className="text-xs text-black/60 text-center">50% opacity</p>
                      </div>
                      <div className="space-y-2">
                        <Button variant="brand" size="lg" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                          With Icon
                        </Button>
                        <p className="text-xs text-black/60 text-center">Icon right/left</p>
                      </div>
                    </div>
                  </div>
                </CollapsibleSection>

                {/* Props API */}
                <CollapsibleSection 
                  title="Props API"
                  subtitle="Component properties and types"
                >
                  <PropertyTable
                    properties={[
                      {
                        name: 'variant',
                        type: "'brand' | 'primary' | 'secondary' | 'ghost'",
                        default: "'primary'",
                        description: 'Visual style variant'
                      },
                      {
                        name: 'size',
                        type: "'sm' | 'md' | 'lg' | 'xl'",
                        default: "'md'",
                        description: 'Button size (height)'
                      },
                      {
                        name: 'loading',
                        type: 'boolean',
                        default: 'false',
                        description: 'Shows loading spinner'
                      },
                      {
                        name: 'disabled',
                        type: 'boolean',
                        default: 'false',
                        description: 'Disables interaction'
                      },
                      {
                        name: 'icon',
                        type: 'React.ReactNode',
                        default: '-',
                        description: 'Icon element (Lucide icon)'
                      },
                      {
                        name: 'iconPosition',
                        type: "'left' | 'right'",
                        default: "'left'",
                        description: 'Icon placement'
                      },
                      {
                        name: 'children',
                        type: 'React.ReactNode',
                        default: '-',
                        description: 'Button text content'
                      },
                      {
                        name: 'onClick',
                        type: '() => void',
                        default: '-',
                        description: 'Click handler'
                      },
                    ]}
                  />
                </CollapsibleSection>

                {/* Usage Guidelines */}
                <CollapsibleSection 
                  title="Usage Guidelines"
                  subtitle="Best practices and common patterns"
                >
                  <div className="space-y-6">
                    <DoAndDont
                      do={{
                        label: "Use one brand button per section",
                        content: (
                          <div className="space-y-4">
                            <Button variant="brand" size="lg">Download Report</Button>
                            <p className="text-xs text-black/60">Clear primary action with brand button</p>
                          </div>
                        )
                      }}
                      dont={{
                        label: "Don't use multiple brand buttons together",
                        content: (
                          <div className="space-y-4">
                            <div className="flex gap-2">
                              <Button variant="brand" size="md">Download</Button>
                              <Button variant="brand" size="md">Share</Button>
                            </div>
                            <p className="text-xs text-black/60">Competing calls-to-action</p>
                          </div>
                        )
                      }}
                    />

                    <div className="bg-[#f5f2f1] rounded-[5px] p-6">
                      <h4 className="text-sm font-bold text-black mb-3">Button Hierarchy</h4>
                      <div className="space-y-3 text-sm text-black/70">
                        <div className="border-l-4 border-black/20 pl-3">
                          <strong>1 Brand Button:</strong> Primary conversion action (max 1 per section)
                        </div>
                        <div className="border-l-4 border-black/20 pl-3">
                          <strong>2-3 Primary Buttons:</strong> Important secondary actions
                        </div>
                        <div className="border-l-4 border-black/20 pl-3">
                          <strong>Unlimited Secondary/Ghost:</strong> Tertiary actions, navigation
                        </div>
                      </div>
                    </div>
                  </div>
                </CollapsibleSection>
              </div>
            </section>

            {/* ===================================
                COMPONENTS - CARDS
                =================================== */}
            <section id="cards" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Components</span>
                <h2 className="text-4xl font-bold text-black mb-3">Cards</h2>
                <p className="text-base text-black/60">
                  Container components with three background variants for different contexts.
                </p>
              </div>

              <CollapsibleSection 
                title="Card Variants"
                subtitle="White, Warm, and Dark backgrounds"
                defaultOpen={true}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-[10px] p-6 shadow-md border border-black/5">
                    <h4 className="text-lg font-bold mb-2">White Card</h4>
                    <p className="text-sm text-black/60 mb-4">
                      Standard card with shadow and subtle border. Use for content on white backgrounds.
                    </p>
                    <div className="text-xs text-black/40">
                      bg-white + shadow-md + border
                    </div>
                  </div>
                  
                  <div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
                    <h4 className="text-lg font-bold mb-2">Warm Card</h4>
                    <p className="text-sm text-black/60 mb-4">
                      Warm background for highlighted sections, testimonials, feature grids.
                    </p>
                    <div className="text-xs text-black/40">
                      bg-[#f5f2f1] + border
                    </div>
                  </div>
                  
                  <div className="bg-black rounded-[10px] p-6">
                    <h4 className="text-lg font-bold mb-2 text-white">Dark Card</h4>
                    <p className="text-sm text-white/60 mb-4">
                      Dark background for contrast sections, CTAs, dramatic emphasis.
                    </p>
                    <div className="text-xs text-white/40">
                      bg-black
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`// White Card
<div className="bg-white rounded-[10px] p-6 shadow-md border border-black/5">
  Card content
</div>

// Warm Card
<div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
  Card content
</div>

// Dark Card
<div className="bg-black rounded-[10px] p-6">
  <h3 className="text-white">Card content</h3>
</div>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                PATTERNS - HERO SECTION
                =================================== */}
            <section id="hero-section" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Patterns</span>
                <h2 className="text-4xl font-bold text-black mb-3">Hero Section</h2>
                <p className="text-base text-black/60">
                  Large hero section pattern with massive typography and brand CTA.
                </p>
              </div>

              <CollapsibleSection 
                title="Hero Pattern"
                subtitle="Black background with centered content"
                defaultOpen={true}
              >
                <div className="bg-black rounded-[10px] p-12 text-center">
                  <h1 className="text-[var(--text-3xl)] font-bold text-white mb-4">
                    Hero Heading Goes Here
                  </h1>
                  <p className="text-[var(--text-base)] text-white/70 mb-8 max-w-[700px] mx-auto">
                    Supporting description text that provides context and encourages users to take action. Maximum 2-3 lines for optimal readability.
                  </p>
                  <Button variant="brand" size="xl" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                    Primary CTA
                  </Button>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`<section className="bg-black py-20">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8 text-center">
    <h1 className="text-[var(--text-3xl)] font-bold text-white mb-4">
      Hero Heading Goes Here
    </h1>
    <p className="text-[var(--text-base)] text-white/70 mb-8 max-w-[700px] mx-auto">
      Supporting description text
    </p>
    <Button 
      variant="brand" 
      size="xl"
      icon={<ArrowRight />}
      iconPosition="right"
    >
      Primary CTA
    </Button>
  </div>
</section>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                PATTERNS - FEATURE GRID
                =================================== */}
            <section id="feature-grid" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Patterns</span>
                <h2 className="text-4xl font-bold text-black mb-3">Feature Grid</h2>
                <p className="text-base text-black/60">
                  2-column or 3-column grid pattern for features, benefits, or capabilities.
                </p>
              </div>

              <CollapsibleSection 
                title="2-Column Feature Grid"
                subtitle="Warm cards with numbered badges"
                defaultOpen={true}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                    <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
                      01
                    </div>
                    <h4 className="text-xl font-bold mb-3">Feature Title One</h4>
                    <p className="text-sm text-black/60">Detailed description of the feature explaining the value proposition and key benefits to users.</p>
                  </div>
                  <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                    <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
                      02
                    </div>
                    <h4 className="text-xl font-bold mb-3">Feature Title Two</h4>
                    <p className="text-sm text-black/60">Detailed description of the feature explaining the value proposition and key benefits to users.</p>
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
  <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
    <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
      01
    </div>
    <h4 className="text-xl font-bold mb-3">Feature Title</h4>
    <p className="text-sm text-black/60">Description</p>
  </div>
  {/* More feature cards... */}
</div>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                PATTERNS - CTA SECTION
                =================================== */}
            <section id="cta-section" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Patterns</span>
                <h2 className="text-4xl font-bold text-black mb-3">CTA Section</h2>
                <p className="text-base text-black/60">
                  Call-to-action section pattern with dark background and dual buttons.
                </p>
              </div>

              <CollapsibleSection 
                title="CTA Section Pattern"
                subtitle="Black background with centered content"
                defaultOpen={true}
              >
                <div className="bg-black rounded-[10px] p-12 text-center">
                  <h3 className="text-3xl font-bold text-white mb-4">
                    Ready to Get Started?
                  </h3>
                  <p className="text-base text-white/70 mb-8 max-w-[600px] mx-auto">
                    Supporting description text that provides context and encourages users to take action.
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <Button variant="brand" size="lg" icon={<ArrowRight className="w-4 h-4" />} iconPosition="right">
                      Primary Action
                    </Button>
                    <Button variant="ghost" size="lg">
                      Secondary Action
                    </Button>
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`<section className="bg-black py-20">
  <div className="max-w-[1000px] mx-auto px-4 text-center">
    <h3 className="text-3xl font-bold text-white mb-4">
      Ready to Get Started?
    </h3>
    <p className="text-base text-white/70 mb-8 max-w-[600px] mx-auto">
      Supporting description
    </p>
    <div className="flex gap-4 justify-center">
      <Button variant="brand" size="lg">Primary Action</Button>
      <Button variant="ghost" size="lg">Secondary Action</Button>
    </div>
  </div>
</section>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                PATTERNS - STATS GRID
                =================================== */}
            <section id="stats-grid" className="mb-20 scroll-mt-24">
              <div className="mb-8">
                <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">Patterns</span>
                <h2 className="text-4xl font-bold text-black mb-3">Stats Grid</h2>
                <p className="text-base text-black/60">
                  4-column statistics grid pattern for showcasing metrics and achievements.
                </p>
              </div>

              <CollapsibleSection 
                title="Stats Grid Pattern"
                subtitle="Warm background with 4-column layout"
                defaultOpen={true}
              >
                <div className="bg-[#f5f2f1] rounded-[10px] p-12">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    {[
                      { value: '2.4K+', label: 'Active Users', description: 'Monthly active' },
                      { value: '98%', label: 'Satisfaction', description: 'Customer rate' },
                      { value: '150+', label: 'Components', description: 'Reusable elements' },
                      { value: '24/7', label: 'Support', description: 'Available hours' },
                    ].map((stat) => (
                      <div key={stat.label} className="text-center">
                        <div className="text-4xl font-bold text-black mb-2">{stat.value}</div>
                        <div className="text-sm font-bold text-black mb-1">{stat.label}</div>
                        <div className="text-xs text-black/60">{stat.description}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6">
                  <CodeBlockWithCopy
                    code={`<div className="bg-[#f5f2f1] rounded-[10px] p-12">
  <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
    <div className="text-center">
      <div className="text-4xl font-bold text-black mb-2">2.4K+</div>
      <div className="text-sm font-bold text-black mb-1">Active Users</div>
      <div className="text-xs text-black/60">Monthly active</div>
    </div>
    {/* More stats... */}
  </div>
</div>`}
                  />
                </div>
              </CollapsibleSection>
            </section>

            {/* ===================================
                RESOURCES
                =================================== */}
            <section id="resources" className="mb-20 scroll-mt-24">
              <h2 className="text-4xl font-bold text-black mb-4">Resources</h2>
              <p className="text-base text-black/60 mb-8">
                Additional documentation, downloads, and learning resources.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                  <h3 className="text-xl font-bold text-black mb-4">Documentation Files</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">MD</span>
                      <span className="text-black/70">DESIGN_TOKENS.md</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">MD</span>
                      <span className="text-black/70">COMPONENT_LIBRARY.md</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">MD</span>
                      <span className="text-black/70">PATTERN_LIBRARY.md</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">MD</span>
                      <span className="text-black/70">DESIGN_PRINCIPLES.md</span>
                    </div>
                  </div>
                </div>

                <div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
                  <h3 className="text-xl font-bold text-black mb-4">Code Resources</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">TS</span>
                      <span className="text-black/70">/src/design-system/tokens.ts</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">TSX</span>
                      <span className="text-black/70">/src/design-system/index.ts</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">MD</span>
                      <span className="text-black/70">/src/design-system/README.md</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="px-3 py-1 bg-black/10 rounded-[5px] text-xs font-mono">TSX</span>
                      <span className="text-black/70">/src/design-system/EXAMPLES.tsx</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 bg-black text-white rounded-[10px] p-8">
                <h3 className="text-xl font-bold mb-4">Quick Links</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="font-bold mb-2">Getting Started</div>
                    <div className="text-white/70">Installation guide</div>
                  </div>
                  <div>
                    <div className="font-bold mb-2">Design Philosophy</div>
                    <div className="text-white/70">Core principles</div>
                  </div>
                  <div>
                    <div className="font-bold mb-2">Component Library</div>
                    <div className="text-white/70">All components</div>
                  </div>
                </div>
              </div>
            </section>

            {/* Footer */}
            <div className="text-center py-12 border-t border-black/10">
              <p className="text-sm text-black/60">
                Design System v1.0 • Built with Atomic Design • January 2026
              </p>
              <p className="text-xs text-black/40 mt-2">
                92-5-3 Color Hierarchy • Major Third Typography • 4px Base Spacing
              </p>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
