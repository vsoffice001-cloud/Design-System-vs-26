import { useState } from 'react';
import { 
  Copy, 
  Check,
  Layout,
  Grid,
  Columns,
  Square,
  Circle,
  ChevronRight,
  Star,
  Quote,
  Image as ImageIcon,
  FileText,
  Layers,
  Eye,
  Download
} from 'lucide-react';
import { Button } from '@/app/components/Button';
import { DocSection } from '@/app/components/FoundationsContent';

/**
 * PATTERNS CONTENT
 * ================
 * All content for the Patterns tab including:
 * - Page Layouts
 * - Content Patterns
 * - Backgrounds
 */

// ============================================
// HELPER COMPONENTS
// ============================================

function PatternPreview({ 
  title, 
  description, 
  children,
  fullWidth = false
}: { 
  title: string; 
  description?: string;
  children: React.ReactNode;
  fullWidth?: boolean;
}) {
  return (
    <div className="border border-black/8 rounded-lg overflow-hidden mb-6">
      <div className="bg-black/[0.02] px-6 py-4 border-b border-black/8">
        <h3 className="font-semibold text-sm mb-1">{title}</h3>
        {description && <p className="text-xs text-black/60">{description}</p>}
      </div>
      <div className={`bg-white ${fullWidth ? '' : 'p-8'}`}>
        {children}
      </div>
    </div>
  );
}

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative bg-black/5 rounded-lg p-4 border border-black/8">
      <button
        onClick={copyCode}
        className="absolute top-3 right-3 p-2 rounded bg-white/80 hover:bg-white transition-colors"
      >
        {copied ? <Check size={16} /> : <Copy size={16} />}
      </button>
      <pre className="text-xs font-mono text-black/80 overflow-x-auto pr-12">
        {code}
      </pre>
    </div>
  );
}

function LayoutSchematic({ 
  type,
  description
}: { 
  type: 'hero' | 'two-column' | 'three-column' | 'sidebar' | 'grid' | 'centered';
  description: string;
}) {
  const layouts = {
    hero: (
      <div className="space-y-3">
        <div className="h-16 bg-black/10 rounded flex items-center justify-center text-xs text-black/40">
          Hero Content
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="h-12 bg-black/5 rounded"></div>
          <div className="h-12 bg-black/5 rounded"></div>
          <div className="h-12 bg-black/5 rounded"></div>
        </div>
      </div>
    ),
    'two-column': (
      <div className="grid grid-cols-2 gap-4">
        <div className="h-32 bg-black/10 rounded"></div>
        <div className="h-32 bg-black/5 rounded"></div>
      </div>
    ),
    'three-column': (
      <div className="grid grid-cols-3 gap-3">
        <div className="h-24 bg-black/10 rounded"></div>
        <div className="h-24 bg-black/10 rounded"></div>
        <div className="h-24 bg-black/10 rounded"></div>
      </div>
    ),
    sidebar: (
      <div className="grid grid-cols-4 gap-4">
        <div className="h-32 bg-black/10 rounded"></div>
        <div className="col-span-3 h-32 bg-black/5 rounded"></div>
      </div>
    ),
    grid: (
      <div className="grid grid-cols-4 gap-2">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="h-16 bg-black/10 rounded"></div>
        ))}
      </div>
    ),
    centered: (
      <div className="space-y-3">
        <div className="max-w-[70%] mx-auto h-12 bg-black/10 rounded"></div>
        <div className="max-w-[90%] mx-auto h-20 bg-black/5 rounded"></div>
      </div>
    ),
  };

  return (
    <div className="p-6 border border-black/8 rounded-lg hover:border-black/15 transition-colors">
      <div className="mb-4">
        {layouts[type]}
      </div>
      <p className="text-sm text-black/60">{description}</p>
    </div>
  );
}

// ============================================
// PAGE LAYOUTS CONTENT
// ============================================

export function PageLayoutsContent() {
  return (
    <div className="space-y-12">
      {/* Overview */}
      <DocSection
        title="Page Layout Patterns"
        why="Consistent page layouts create familiarity and improve usability across the experience"
        what="Common layout patterns used throughout the design system"
        when="Use these patterns as starting points for new pages and sections"
      >
        <p className="text-black/70">
          These layout patterns are battle-tested and optimized for readability, 
          responsive behavior, and visual hierarchy.
        </p>
      </DocSection>

      {/* Layout Schematics */}
      <section>
        <h3 className="text-xl font-normal mb-6">Layout Types</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <LayoutSchematic
            type="hero"
            description="Hero section with supporting content grid"
          />
          <LayoutSchematic
            type="two-column"
            description="Split layout for equal emphasis content"
          />
          <LayoutSchematic
            type="three-column"
            description="Feature showcase, card grids"
          />
          <LayoutSchematic
            type="sidebar"
            description="Main content with supplementary sidebar"
          />
          <LayoutSchematic
            type="grid"
            description="Gallery, portfolio, product grid"
          />
          <LayoutSchematic
            type="centered"
            description="Focus content, landing pages"
          />
        </div>
      </section>

      {/* Hero Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Hero Section Pattern</h3>
        
        <PatternPreview 
          title="Full-Width Hero with CTA" 
          description="Primary landing pattern with strong visual hierarchy"
          fullWidth
        >
          <div className="max-w-[1200px] mx-auto px-8 py-20">
            <div className="max-w-2xl">
              <div className="inline-block px-3 py-1 bg-black/5 rounded-full text-xs font-medium mb-4">
                CASE STUDY
              </div>
              <h1 className="text-5xl font-normal mb-6 leading-tight">
                Transforming Digital Experiences
              </h1>
              <p className="text-xl text-black/70 mb-8 leading-relaxed">
                A comprehensive approach to modernizing enterprise software 
                with user-centered design principles.
              </p>
              <div className="flex gap-4">
                <Button variant="primary" size="lg">
                  View Case Study
                </Button>
                <Button variant="secondary" size="lg">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </PatternPreview>

        <CodeBlock code={`<section className="max-w-[1200px] mx-auto px-8 py-20">
  <div className="max-w-2xl">
    <div className="inline-block px-3 py-1 bg-black/5 rounded-full text-xs font-medium mb-4">
      CASE STUDY
    </div>
    <h1 className="text-5xl font-normal mb-6">
      Transforming Digital Experiences
    </h1>
    <p className="text-xl text-black/70 mb-8">
      A comprehensive approach to modernizing enterprise software.
    </p>
    <div className="flex gap-4">
      <Button variant="primary" size="lg">View Case Study</Button>
      <Button variant="secondary" size="lg">Learn More</Button>
    </div>
  </div>
</section>`} />
      </section>

      {/* Content Section Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Standard Content Section</h3>
        
        <PatternPreview 
          title="Section with Label, Heading, and Description"
          description="Most common section pattern with clear hierarchy"
          fullWidth
        >
          <div className="max-w-[1200px] mx-auto px-8 py-16">
            <div className="max-w-3xl mb-12">
              <div className="text-xs font-medium tracking-wider text-black/60 mb-3 uppercase">
                Our Approach
              </div>
              <h2 className="text-4xl font-normal mb-4">
                User-Centered Methodology
              </h2>
              <p className="text-lg text-black/70">
                We combine data-driven insights with creative problem-solving 
                to deliver solutions that resonate with users.
              </p>
            </div>
            
            <div className="grid grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="p-6 border border-black/8 rounded-lg">
                  <div className="text-2xl font-normal mb-2">0{i}</div>
                  <h3 className="font-semibold mb-2">Key Step {i}</h3>
                  <p className="text-sm text-black/60">
                    Description of this important methodology step.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </PatternPreview>

        <CodeBlock code={`<section className="max-w-[1200px] mx-auto px-8 py-16">
  {/* Section Header */}
  <div className="max-w-3xl mb-12">
    <div className="text-xs font-medium tracking-wider text-black/60 mb-3 uppercase">
      Our Approach
    </div>
    <h2 className="text-4xl font-normal mb-4">
      User-Centered Methodology
    </h2>
    <p className="text-lg text-black/70">
      We combine data-driven insights...
    </p>
  </div>
  
  {/* Content Grid */}
  <div className="grid grid-cols-3 gap-8">
    {/* Cards */}
  </div>
</section>`} />
      </section>

      {/* Two Column Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Two-Column Layout</h3>
        
        <PatternPreview 
          title="Split Content Layout"
          description="Equal or weighted column layouts for side-by-side content"
          fullWidth
        >
          <div className="max-w-[1200px] mx-auto px-8 py-16">
            <div className="grid grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-normal mb-4">
                  The Challenge
                </h2>
                <p className="text-black/70 mb-4">
                  Legacy systems were creating friction in the user experience, 
                  leading to decreased engagement and satisfaction.
                </p>
                <p className="text-black/70">
                  Our goal was to modernize while maintaining familiarity for existing users.
                </p>
              </div>
              <div className="h-64 bg-black/5 rounded-lg flex items-center justify-center">
                <ImageIcon size={48} className="text-black/20" />
              </div>
            </div>
          </div>
        </PatternPreview>
      </section>

      {/* Centered Content Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Centered Content Layout</h3>
        
        <PatternPreview 
          title="Focused Content Pattern"
          description="For testimonials, quotes, or focused messaging"
          fullWidth
        >
          <div className="max-w-[800px] mx-auto px-8 py-20 text-center">
            <Quote size={32} className="mx-auto text-black/20 mb-6" />
            <blockquote className="text-2xl font-normal mb-6 leading-relaxed">
              "This transformed how we approach digital experiences. 
              The results exceeded all expectations."
            </blockquote>
            <div className="text-sm text-black/60">
              <div className="font-medium text-black">Sarah Johnson</div>
              <div>VP of Digital Experience</div>
            </div>
          </div>
        </PatternPreview>
      </section>

      {/* Responsive Behavior */}
      <section>
        <h3 className="text-xl font-normal mb-6">Responsive Layout Strategy</h3>
        
        <div className="space-y-4">
          <div className="p-6 border border-black/8 rounded-lg">
            <h4 className="font-semibold mb-3">Mobile (&lt; 768px)</h4>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Single column layout for all content</li>
              <li>• Stack hero content vertically</li>
              <li>• Reduce padding/margins (16-24px)</li>
              <li>• Hide decorative elements</li>
            </ul>
          </div>
          
          <div className="p-6 border border-black/8 rounded-lg">
            <h4 className="font-semibold mb-3">Tablet (768px - 1023px)</h4>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• 2-column grids for cards</li>
              <li>• Maintain side-by-side for key content</li>
              <li>• Medium padding (32-40px)</li>
            </ul>
          </div>
          
          <div className="p-6 border border-black/8 rounded-lg">
            <h4 className="font-semibold mb-3">Desktop (1024px+)</h4>
            <ul className="space-y-2 text-sm text-black/70">
              <li>• Full 3-4 column grids</li>
              <li>• Maximum spacing (48-64px)</li>
              <li>• Show all decorative elements</li>
              <li>• Wider max-width containers (1200-1400px)</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}

// ============================================
// CONTENT PATTERNS CONTENT
// ============================================

export function ContentPatternsContent() {
  return (
    <div className="space-y-12">
      <DocSection
        title="Content Organization Patterns"
        why="Consistent content patterns make interfaces scannable and predictable"
        what="Reusable patterns for displaying different types of content"
        when="Use these patterns to maintain consistency across features"
      >
        <p className="text-black/70">
          These patterns have been optimized for readability and user engagement.
        </p>
      </DocSection>

      {/* Card Grid Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Card Grid Pattern</h3>
        
        <PatternPreview 
          title="3-Column Feature Grid"
          description="Most common pattern for features, benefits, or services"
        >
          <div className="grid grid-cols-3 gap-6">
            {[
              { icon: <Layout size={24} />, title: 'Structured', desc: 'Organized content hierarchy' },
              { icon: <Grid size={24} />, title: 'Flexible', desc: 'Adapts to any content type' },
              { icon: <Layers size={24} />, title: 'Scalable', desc: 'Grows with your needs' },
            ].map((item, i) => (
              <div key={i} className="p-6 border border-black/8 rounded-lg hover:shadow-lg transition-all">
                <div className="w-12 h-12 bg-black/5 rounded-lg flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-black/60">{item.desc}</p>
              </div>
            ))}
          </div>
        </PatternPreview>

        <CodeBlock code={`<div className="grid grid-cols-3 gap-6">
  {features.map((feature) => (
    <div key={feature.id} 
         className="p-6 border border-black/8 rounded-lg hover:shadow-lg transition-all">
      <div className="w-12 h-12 bg-black/5 rounded-lg flex items-center justify-center mb-4">
        {feature.icon}
      </div>
      <h3 className="font-semibold mb-2">{feature.title}</h3>
      <p className="text-sm text-black/60">{feature.description}</p>
    </div>
  ))}
</div>`} />
      </section>

      {/* Numbered List Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Numbered Step Pattern</h3>
        
        <PatternPreview 
          title="Sequential Process Steps"
          description="Clear progression for processes, methodologies, or instructions"
        >
          <div className="space-y-6">
            {[
              { num: '01', title: 'Discovery', desc: 'Research and understand user needs' },
              { num: '02', title: 'Design', desc: 'Create solutions based on insights' },
              { num: '03', title: 'Delivery', desc: 'Implement and iterate based on feedback' },
            ].map((step) => (
              <div key={step.num} className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-mono text-sm flex-shrink-0">
                  {step.num}
                </div>
                <div className="pt-1">
                  <h3 className="font-semibold mb-1">{step.title}</h3>
                  <p className="text-sm text-black/60">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </PatternPreview>
      </section>

      {/* Stats Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Stats Display Pattern</h3>
        
        <PatternPreview 
          title="Metrics and Key Numbers"
          description="Highlight important statistics or achievements"
        >
          <div className="grid grid-cols-4 gap-8 py-8">
            {[
              { number: '250K+', label: 'Active Users' },
              { number: '99.9%', label: 'Uptime' },
              { number: '4.8/5', label: 'User Rating' },
              { number: '50+', label: 'Countries' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-4xl font-normal mb-2">{stat.number}</div>
                <div className="text-sm text-black/60">{stat.label}</div>
              </div>
            ))}
          </div>
        </PatternPreview>

        <CodeBlock code={`<div className="grid grid-cols-4 gap-8 py-8">
  {stats.map((stat) => (
    <div key={stat.label} className="text-center">
      <div className="text-4xl font-normal mb-2">{stat.number}</div>
      <div className="text-sm text-black/60">{stat.label}</div>
    </div>
  ))}
</div>`} />
      </section>

      {/* Testimonial Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Testimonial Pattern</h3>
        
        <PatternPreview 
          title="User Testimonial Card"
          description="Social proof and user feedback"
        >
          <div className="max-w-2xl mx-auto p-8 border border-black/8 rounded-lg">
            <div className="flex gap-4 mb-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star key={i} size={20} className="fill-amber-400 text-amber-400" />
              ))}
            </div>
            <blockquote className="text-lg mb-6 leading-relaxed">
              "The attention to detail and user experience is exceptional. 
              This has significantly improved our team's workflow."
            </blockquote>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-black/10 rounded-full"></div>
              <div>
                <div className="font-medium">Alex Chen</div>
                <div className="text-sm text-black/60">Product Manager, TechCorp</div>
              </div>
            </div>
          </div>
        </PatternPreview>
      </section>

      {/* List with Icons Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Icon List Pattern</h3>
        
        <PatternPreview 
          title="Feature List with Icons"
          description="Scannable list of features or benefits"
        >
          <div className="grid grid-cols-2 gap-6">
            {[
              { icon: <Check size={20} />, text: 'Unlimited projects' },
              { icon: <Check size={20} />, text: 'Priority support' },
              { icon: <Check size={20} />, text: 'Advanced analytics' },
              { icon: <Check size={20} />, text: 'Custom branding' },
              { icon: <Check size={20} />, text: 'API access' },
              { icon: <Check size={20} />, text: 'Team collaboration' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600 flex-shrink-0">
                  {item.icon}
                </div>
                <span className="text-sm">{item.text}</span>
              </div>
            ))}
          </div>
        </PatternPreview>
      </section>

      {/* Image + Text Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Media + Text Pattern</h3>
        
        <PatternPreview 
          title="Alternating Image and Text"
          description="Engaging layout for storytelling content"
          fullWidth
        >
          <div className="max-w-[1200px] mx-auto px-8 py-16 space-y-16">
            {/* Left Image */}
            <div className="grid grid-cols-2 gap-12 items-center">
              <div className="h-64 bg-black/5 rounded-lg flex items-center justify-center">
                <ImageIcon size={48} className="text-black/20" />
              </div>
              <div>
                <h3 className="text-2xl font-normal mb-4">Research Phase</h3>
                <p className="text-black/70 mb-4">
                  We conducted extensive user research to understand pain points 
                  and opportunities in the current experience.
                </p>
                <Button variant="ghost" size="sm" icon={<ChevronRight size={16} />}>
                  Learn more
                </Button>
              </div>
            </div>

            {/* Right Image */}
            <div className="grid grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-normal mb-4">Design Solution</h3>
                <p className="text-black/70 mb-4">
                  Based on our findings, we created a streamlined interface 
                  that reduced complexity while maintaining functionality.
                </p>
                <Button variant="ghost" size="sm" icon={<ChevronRight size={16} />}>
                  View designs
                </Button>
              </div>
              <div className="h-64 bg-black/5 rounded-lg flex items-center justify-center">
                <ImageIcon size={48} className="text-black/20" />
              </div>
            </div>
          </div>
        </PatternPreview>
      </section>

      {/* CTA Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Call-to-Action Pattern</h3>
        
        <PatternPreview 
          title="Section CTA Block"
          description="Drive action at natural break points"
          fullWidth
        >
          <div className="max-w-[1200px] mx-auto px-8 py-20 text-center">
            <h2 className="text-4xl font-normal mb-4">
              Ready to get started?
            </h2>
            <p className="text-xl text-black/70 mb-8 max-w-2xl mx-auto">
              Join thousands of teams already using our platform to build better products.
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="primary" size="lg">
                Start Free Trial
              </Button>
              <Button variant="secondary" size="lg">
                Schedule Demo
              </Button>
            </div>
            <p className="text-sm text-black/40 mt-4">
              No credit card required • 14-day free trial
            </p>
          </div>
        </PatternPreview>
      </section>
    </div>
  );
}

// ============================================
// BACKGROUNDS CONTENT
// ============================================

export function BackgroundsContent() {
  return (
    <div className="space-y-12">
      <DocSection
        title="Background Patterns"
        why="Strategic use of backgrounds creates visual rhythm and section differentiation"
        what="Pure white, warm tints, and alternating patterns for minimalist aesthetic"
        when="Use to separate sections, create emphasis, or establish visual flow"
        whenNot="Never use saturated colors or patterns that compete with content"
      >
        <p className="text-black/70">
          Our background system uses ultra-subtle warm tints (2-3% opacity) 
          to create depth without overwhelming the content.
        </p>
      </DocSection>

      {/* Color Backgrounds */}
      <section>
        <h3 className="text-xl font-normal mb-6">Background Colors</h3>
        
        <div className="space-y-6">
          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-32 bg-white flex items-center justify-center">
              <span className="text-sm text-black/40">Pure White (#FFFFFF)</span>
            </div>
            <div className="p-4 bg-black/[0.02]">
              <p className="text-sm font-medium mb-1">Pure White</p>
              <p className="text-xs text-black/60">Default background, maximum contrast</p>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-32 flex items-center justify-center" style={{ background: '#f5f2f1' }}>
              <span className="text-sm text-black/40">Warm Tint (#f5f2f1)</span>
            </div>
            <div className="p-4 bg-black/[0.02]">
              <p className="text-sm font-medium mb-1">Warm Tint</p>
              <p className="text-xs text-black/60">Subtle warmth, creates gentle separation</p>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-32 flex items-center justify-center" style={{ background: '#f9f7f6' }}>
              <span className="text-sm text-black/40">Subtle Warm (#f9f7f6)</span>
            </div>
            <div className="p-4 bg-black/[0.02]">
              <p className="text-sm font-medium mb-1">Subtle Warm</p>
              <p className="text-xs text-black/60">Ultra-light tint, barely perceptible warmth</p>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-32 bg-black flex items-center justify-center">
              <span className="text-sm text-white/60">Pure Black (#000000)</span>
            </div>
            <div className="p-4 bg-black/[0.02]">
              <p className="text-sm font-medium mb-1">Pure Black</p>
              <p className="text-xs text-black/60">Maximum contrast, dramatic sections (use sparingly)</p>
            </div>
          </div>
        </div>
      </section>

      {/* Alternating Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Alternating Section Pattern</h3>
        
        <PatternPreview 
          title="White / Warm Alternating Sections"
          description="Creates visual rhythm throughout long pages"
          fullWidth
        >
          <div>
            {/* White Section */}
            <div className="bg-white px-8 py-16 border-b border-black/8">
              <div className="max-w-[1200px] mx-auto">
                <div className="text-xs font-medium tracking-wider text-black/60 mb-3 uppercase">
                  Section 01
                </div>
                <h2 className="text-3xl font-normal mb-4">White Background</h2>
                <p className="text-black/70 max-w-2xl">
                  Default background color for primary content sections.
                </p>
              </div>
            </div>

            {/* Warm Section */}
            <div className="px-8 py-16 border-b border-black/8" style={{ background: '#f5f2f1' }}>
              <div className="max-w-[1200px] mx-auto">
                <div className="text-xs font-medium tracking-wider text-black/60 mb-3 uppercase">
                  Section 02
                </div>
                <h2 className="text-3xl font-normal mb-4">Warm Tint Background</h2>
                <p className="text-black/70 max-w-2xl">
                  Subtle variation creates visual interest and section separation.
                </p>
              </div>
            </div>

            {/* White Section */}
            <div className="bg-white px-8 py-16">
              <div className="max-w-[1200px] mx-auto">
                <div className="text-xs font-medium tracking-wider text-black/60 mb-3 uppercase">
                  Section 03
                </div>
                <h2 className="text-3xl font-normal mb-4">White Background</h2>
                <p className="text-black/70 max-w-2xl">
                  Return to white maintains rhythm and consistency.
                </p>
              </div>
            </div>
          </div>
        </PatternPreview>

        <CodeBlock code={`{/* Alternating sections */}
<section className="bg-white py-16">
  {/* Content */}
</section>

<section className="py-16" style={{ background: '#f5f2f1' }}>
  {/* Content */}
</section>

<section className="bg-white py-16">
  {/* Content */}
</section>`} />
      </section>

      {/* Dark Section Pattern */}
      <section>
        <h3 className="text-xl font-normal mb-6">Dark Section (Special Use)</h3>
        
        <PatternPreview 
          title="Black Background Section"
          description="High contrast for special emphasis or final CTAs"
          fullWidth
        >
          <div className="bg-black px-8 py-20">
            <div className="max-w-[800px] mx-auto text-center text-white">
              <h2 className="text-4xl font-normal mb-4">
                Ready to Transform Your Experience?
              </h2>
              <p className="text-xl text-white/70 mb-8">
                Join the growing number of teams building better products.
              </p>
              <Button variant="brand" size="lg">
                Get Started Now
              </Button>
            </div>
          </div>
        </PatternPreview>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
          <div className="flex items-start gap-3">
            <div className="text-amber-600 flex-shrink-0">⚠️</div>
            <div>
              <h4 className="font-semibold text-amber-900 mb-1">Use Sparingly</h4>
              <p className="text-sm text-amber-800">
                Black backgrounds create strong contrast but should be limited to 1-2 sections 
                per page (typically final CTA or special emphasis areas). Overuse can feel heavy.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Background Rules */}
      <section>
        <h3 className="text-xl font-normal mb-6">Background Best Practices</h3>
        
        <div className="grid grid-cols-2 gap-6">
          <div className="p-6 border-2 border-green-200 bg-green-50 rounded-lg">
            <h4 className="font-semibold mb-3 flex items-center gap-2 text-green-900">
              <Check size={18} />
              Do
            </h4>
            <ul className="space-y-2 text-sm text-green-800">
              <li>• Use white as primary background (70-80% of page)</li>
              <li>• Alternate with warm tints for visual rhythm</li>
              <li>• Maintain WCAG AAA contrast ratios</li>
              <li>• Use consistent tints throughout project</li>
              <li>• Test readability on all backgrounds</li>
            </ul>
          </div>
          
          <div className="p-6 border-2 border-red-200 bg-red-50 rounded-lg">
            <h4 className="font-semibold mb-3 flex items-center gap-2 text-red-900">
              <Circle size={18} />
              Don't
            </h4>
            <ul className="space-y-2 text-sm text-red-800">
              <li>• Use saturated or bright background colors</li>
              <li>• Mix multiple background tints randomly</li>
              <li>• Use black for more than 10% of page</li>
              <li>• Add patterns or textures that distract</li>
              <li>• Sacrifice text readability for aesthetics</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Implementation */}
      <section>
        <h3 className="text-xl font-normal mb-6">Implementation Guide</h3>
        
        <CodeBlock code={`/* Define background colors in theme.css */
:root {
  --bg-primary: #ffffff;
  --bg-warm: #f5f2f1;
  --bg-warm-subtle: #f9f7f6;
  --bg-dark: #000000;
}

/* Apply to sections */
.section-white {
  background: var(--bg-primary);
}

.section-warm {
  background: var(--bg-warm);
}

.section-dark {
  background: var(--bg-dark);
  color: white;
}

/* Alternating pattern */
section:nth-child(odd) {
  background: var(--bg-primary);
}

section:nth-child(even) {
  background: var(--bg-warm);
}`} />
      </section>
    </div>
  );
}