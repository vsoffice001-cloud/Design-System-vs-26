// THIS IS THE NEW COLORS SECTION - TO BE MERGED INTO FoundationsContent.tsx
// Replace the entire ColorsContent() function (lines 188-587) with this

export function ColorsContent() {
  return (
    <div className="space-y-12">
      {/* Core Principle */}
      <DocSection
        title="Color System - Core Principle"
        why="Every color has semantic meaning. Using defined design tokens ensures consistency, accessibility (WCAG AAA), and maintains the minimalist editorial aesthetic through color restraint."
        what="Pure black/white foundation (92%+) with strategic Ken Bold Red accent (5% max) and accent colors for gradients only (3% max)"
        when="Use for all components, sections, and interactive elements. Always reference design tokens, never arbitrary colors."
        whenNot="Never use random Tailwind colors (text-gray-600, bg-blue-100), hardcoded hex values, or create new gray shades outside the system"
        where="Throughout entire design system - backgrounds, text, accents, borders, shadows, gradients"
        how="Start with semantic tokens (var(--brand-red), var(--text-tertiary)), limit brand red to 5% of page, use accent colors in gradients at 5-20% opacity only"
      >
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="font-semibold mb-3 text-blue-900">🎨 Color Usage Rules</h3>
          <ul className="space-y-2 text-sm text-blue-900">
            <li className="flex items-start gap-2">
              <span className="text-red-600 font-mono font-bold">•</span>
              <span><strong>Brand Red (#b01f24):</strong> Maximum 5% of any page - CTAs, critical alerts only</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-mono font-bold">•</span>
              <span><strong>Accent Colors:</strong> Maximum 3% total - gradients at 5-20% opacity, shadows only</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-black font-mono font-bold">•</span>
              <span><strong>Black/White/Warm:</strong> 92%+ of design - backgrounds, text, borders, structure</span>
            </li>
          </ul>
        </div>
      </DocSection>

      {/* 1. BRAND RED - PRIMARY IDENTITY */}
      <DocSection
        title="1. Brand Red (#b01f24) - PRIMARY IDENTITY"
        why="Ken Bold Red is our brand identity color. It conveys confidence, action, and urgency. By limiting its use to 5% of the page, it maintains maximum impact and draws attention to conversion points."
        what="Primary brand red (#b01f24 / RGB: 176, 31, 36) with hover and active states for interaction feedback"
        when="✅ Primary CTA buttons ('Schedule Consultation', 'Download Report'), Critical alerts, Hover states for primary actions, InlineLink text color, Active navigation states"
        whenNot="❌ Section backgrounds (too overwhelming), Large content areas (too dominant), Body text (insufficient contrast on white), Decorative elements (competes with CTAs)"
        where="Hero CTAs, Sticky CTA, Primary buttons, Inline links (on hover), Hero badge ('CASE STUDY'), Form validation errors"
        how="Use as button background (var(--brand-red)), apply hover state on interaction, combine with white text for contrast. USAGE LIMIT: Maximum 5% of any page"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ColorCard
            name="Brand Red"
            token="--brand-red"
            value="#b01f24"
            usage="Primary CTAs, brand identity"
            wcag="4.54:1 on white"
          />
          <ColorCard
            name="Brand Red Hover"
            token="--brand-red-hover"
            value="#8f191e"
            usage="Button hover states"
            wcag="5.77:1 on white"
          />
          <ColorCard
            name="Brand Red Active"
            token="--brand-red-active"
            value="#6e1317"
            usage="Button active/pressed states"
            wcag="7.41:1 on white"
          />
        </div>
        <CodeExample
          code={`// Primary CTA Button
<Button variant="brand" size="lg">
  Schedule Consultation
</Button>

// Inline Link
<InlineLink href="#">transformer bushings</InlineLink>

// Hero Badge
<span style={{ color: 'var(--brand-red)' }}>CASE STUDY</span>

// With hover/active states
.cta-button {
  background: var(--brand-red);
}
.cta-button:hover {
  background: var(--brand-red-hover);
}
.cta-button:active {
  background: var(--brand-red-active);
}`}
        />
      </DocSection>

      {/* 2. WARM EDITORIAL COLORS */}
      <DocSection
        title="2. Warm Editorial Colors - SOPHISTICATED BACKGROUNDS"
        why="Warm neutrals add sophistication and editorial feel without being distracting. They create visual rhythm when alternated with white sections, making content easier to scan and navigate."
        what="Subtle section backgrounds that add warmth without distraction - 5 specific tokens from near-white to warm borders"
        when="✅ Section backgrounds for subtle highlighting, Alternative to pure white for visual rhythm, Borders and separators, Background gradients (low opacity)"
        whenNot="❌ Primary text color (insufficient contrast), Interactive elements (not actionable), More than 2-3 sections per page (overuse loses impact)"
        where="Challenges section (--warm-300), Methodology section (--warm-200), Final CTA (--warm-50), Borders/dividers (--warm-500), Timeline nodes (--warm-700)"
        how="Alternate with pure white sections for rhythm, use lighter values for backgrounds, darker values for borders/structural elements"
      >
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-black/20">
                <th className="text-left p-3 text-sm font-bold">Token</th>
                <th className="text-left p-3 text-sm font-bold">Hex</th>
                <th className="text-left p-3 text-sm font-bold">Usage</th>
                <th className="text-left p-3 text-sm font-bold">Section</th>
                <th className="text-left p-3 text-sm font-bold">Visual</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--warm-50</code>
                </td>
                <td className="p-3"><code className="font-mono text-xs text-black/60">#fefdfd</code></td>
                <td className="p-3 text-sm">Final CTA background</td>
                <td className="p-3 text-sm text-black/60">Section 8</td>
                <td className="p-3">
                  <div className="w-16 h-8 border border-black/8 rounded" style={{ background: '#fefdfd' }}></div>
                </td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--warm-200</code>
                </td>
                <td className="p-3"><code className="font-mono text-xs text-black/60">#f9f7f6</code></td>
                <td className="p-3 text-sm">Methodology section</td>
                <td className="p-3 text-sm text-black/60">Section 5</td>
                <td className="p-3">
                  <div className="w-16 h-8 border border-black/8 rounded" style={{ background: '#f9f7f6' }}></div>
                </td>
              </tr>
              <tr className="border-b border-black/8 bg-yellow-50">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--warm-300</code>
                  <span className="ml-2 text-xs">⭐</span>
                </td>
                <td className="p-3"><code className="font-mono text-xs text-black/60">#f5f2f1</code></td>
                <td className="p-3 text-sm font-semibold">Challenges section ⭐</td>
                <td className="p-3 text-sm text-black/60">Section 3</td>
                <td className="p-3">
                  <div className="w-16 h-8 border border-black/8 rounded" style={{ background: '#f5f2f1' }}></div>
                </td>
              </tr>
              <tr className="border-b border-black/8 bg-yellow-50">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--warm-500</code>
                  <span className="ml-2 text-xs">⭐</span>
                </td>
                <td className="p-3"><code className="font-mono text-xs text-black/60">#eae5e3</code></td>
                <td className="p-3 text-sm font-semibold">Borders, separators ⭐</td>
                <td className="p-3 text-sm text-black/60">Dividers</td>
                <td className="p-3">
                  <div className="w-16 h-8 border border-black/8 rounded" style={{ background: '#eae5e3' }}></div>
                </td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--warm-700</code>
                </td>
                <td className="p-3"><code className="font-mono text-xs text-black/60">#c8bcb8</code></td>
                <td className="p-3 text-sm">Timeline nodes, accents</td>
                <td className="p-3 text-sm text-black/60">Components</td>
                <td className="p-3">
                  <div className="w-16 h-8 border border-black/8 rounded" style={{ background: '#c8bcb8' }}></div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <CodeExample
          code={`// Challenges Section Background
<section style={{ background: 'var(--warm-300)' }}>
  {/* Content */}
</section>

// Methodology Section Background
<section style={{ background: 'var(--warm-200)' }}>
  {/* Content */}
</section>

// Border/Separator
<div style={{ borderBottom: '1px solid var(--warm-500)' }} />`}
        />
      </DocSection>

      {/* 3. TEXT COLORS - WCAG AAA COMPLIANT */}
      <DocSection
        title="3. Text Colors - WCAG AAA COMPLIANT"
        why="Using semantic text tokens ensures WCAG AAA compliance automatically. The 60% black (--text-tertiary) for labels creates clear hierarchy while remaining fully accessible. All colors pass 7:1+ contrast ratio."
        what="4-tier opacity system using black base - all passing 7:1+ contrast ratio for maximum accessibility"
        when="All text content - headings, body, labels, metadata. Use appropriate tier for content hierarchy."
        whenNot="Don't use --text-subtle for critical information (it's decorative only). Never use random gray shades outside this system."
        where="--text-primary (headings, body), --text-secondary (supporting text), --text-tertiary (labels ⭐ MOST USED), --text-subtle (decorative only)"
        how="Apply via CSS variables (var(--text-tertiary)), choose tier based on content importance, test contrast ratios automatically maintained"
      >
        <div className="overflow-x-auto mb-8">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-black/20">
                <th className="text-left p-3 text-sm font-bold">Token</th>
                <th className="text-left p-3 text-sm font-bold">Value</th>
                <th className="text-left p-3 text-sm font-bold">Contrast</th>
                <th className="text-left p-3 text-sm font-bold">Usage</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--text-primary</code>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.90)</code>
                </td>
                <td className="p-3">
                  <span className="text-xs text-green-600 font-semibold">✓ WCAG AAA</span>
                  <br />
                  <span className="text-xs text-black/50">17.1:1</span>
                </td>
                <td className="p-3 text-sm">Main headings, body text</td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--text-secondary</code>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.70)</code>
                </td>
                <td className="p-3">
                  <span className="text-xs text-green-600 font-semibold">✓ WCAG AAA</span>
                  <br />
                  <span className="text-xs text-black/50">11.4:1</span>
                </td>
                <td className="p-3 text-sm">Supporting paragraphs</td>
              </tr>
              <tr className="border-b border-black/8 bg-yellow-50">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--text-tertiary</code>
                  <span className="ml-2 text-xs">⭐</span>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.60)</code>
                </td>
                <td className="p-3">
                  <span className="text-xs text-green-600 font-semibold">✓ WCAG AAA</span>
                  <br />
                  <span className="text-xs text-black/50">8.9:1</span>
                </td>
                <td className="p-3 text-sm font-semibold">Labels, metadata ⭐ MOST USED</td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--text-subtle</code>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.45)</code>
                </td>
                <td className="p-3">
                  <span className="text-xs text-green-600 font-semibold">✓ WCAG AA</span>
                  <br />
                  <span className="text-xs text-black/50">5.9:1</span>
                </td>
                <td className="p-3 text-sm">Decorative text only</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6">
          <h3 className="font-semibold mb-4">📋 Detailed Usage Rules</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <p className="font-semibold text-black mb-2">Use --text-primary for:</p>
              <ul className="list-disc list-inside text-black/70 space-y-1">
                <li>Hero headings</li>
                <li>Section headings (h1, h2, h3)</li>
                <li>Main body paragraphs</li>
                <li>Critical content that must be read</li>
              </ul>
            </div>
            
            <div>
              <p className="font-semibold text-black mb-2">Use --text-secondary for:</p>
              <ul className="list-disc list-inside text-black/70 space-y-1">
                <li>Supporting paragraphs</li>
                <li>Card descriptions</li>
                <li>Secondary information</li>
                <li>General body text</li>
              </ul>
            </div>
            
            <div className="md:col-span-2 bg-yellow-50 border border-yellow-200 rounded p-4">
              <p className="font-semibold text-black mb-2">Use --text-tertiary for: ⭐ MOST COMMON</p>
              <ul className="list-disc list-inside text-black/70 space-y-1">
                <li>"CASE STUDY", "CLIENT CONTEXT" labels</li>
                <li>Section labels (all caps, 1.8px letter-spacing)</li>
                <li>Metadata (read time, category)</li>
                <li>Timestamps, dates</li>
                <li>Input placeholders</li>
              </ul>
            </div>
            
            <div className="md:col-span-2">
              <p className="font-semibold text-black mb-2">Use --text-subtle for:</p>
              <ul className="list-disc list-inside text-black/70 space-y-1">
                <li>Decorative elements only</li>
                <li>Background text</li>
                <li>Disabled states</li>
                <li><strong>Never for critical information</strong></li>
              </ul>
            </div>
          </div>
        </div>

        <CodeExample
          code={`// Section Label (MOST COMMON PATTERN)
<span style={{
  fontSize: 'var(--text-xs)',
  letterSpacing: '1.8px',
  textTransform: 'uppercase',
  color: 'var(--text-tertiary)'  // ← 60% black ⭐ MOST USED
}}>
  CLIENT CONTEXT
</span>

// Section Heading
<h2 style={{
  fontSize: 'var(--text-2xl)',
  color: 'var(--text-primary)'  // ← 90% black
}}>
  Challenges We Addressed
</h2>

// Body Paragraph
<p style={{
  fontSize: 'var(--text-sm)',
  lineHeight: 1.7,
  color: 'var(--text-secondary)'  // ← 70% black
}}>
  Supporting paragraph text...
</p>`}
        />
      </DocSection>

      {/* 4. ACCENT COLORS - STRATEGIC USE */}
      <DocSection
        title="4. Accent Colors - STRATEGIC USE (3% Maximum)"
        why="Accent colors add visual interest, depth, and emotional nuance without overwhelming the minimalist aesthetic. Used primarily in gradients at 5-20% opacity for subtle sophistication."
        what="Five accent colors (Purple, Periwinkle, Coral, Amber, Green) used ONLY in gradients, shadows, and subtle backgrounds - never as solid fills"
        when="✅ Background gradients (low opacity), Card shadows, Button elevation effects, Glassmorphism overlays, Success states (green only)"
        whenNot="❌ Text color, solid backgrounds, borders, icons, or any primary visual elements. Maximum 3% usage per page total."
        where="BackgroundHighlight gradients, Brand button shadows, Modal overlays, Success metrics (green), Trust indicators (periwinkle), Warm accents (coral)"
        how="Apply in gradients at 5-20% opacity, combine with black shadows for depth, use sparingly. RULE: Accent colors are used primarily in gradients, NOT as solid fills."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-24 bg-gradient-to-br from-purple-600 to-purple-400"></div>
            <div className="p-4 bg-white">
              <p className="font-semibold text-sm mb-1">Purple</p>
              <p className="font-mono text-xs text-black/60 mb-2">#9488ec</p>
              <p className="text-xs text-black/50 mb-2">RGB: 148, 136, 236</p>
              <p className="text-xs text-black/60 mb-2"><strong>Meaning:</strong> Premium, innovation, insights</p>
              <p className="text-xs text-black/60 mb-3"><strong>Usage:</strong> Endorsement hover effects, premium content gradients</p>
              <code className="block bg-black/5 rounded px-2 py-1 text-[10px] font-mono text-black/80 break-all">
                var(--purple-600) or rgba(148, 136, 236, 0.05)
              </code>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-24" style={{ background: 'linear-gradient(135deg, #c3c6f9, #9da1f5)' }}></div>
            <div className="p-4 bg-white">
              <p className="font-semibold text-sm mb-1">Periwinkle</p>
              <p className="font-mono text-xs text-black/60 mb-2">#c3c6f9</p>
              <p className="text-xs text-black/50 mb-2">RGB: 195, 198, 249</p>
              <p className="text-xs text-black/60 mb-2"><strong>Meaning:</strong> Trust, reliability, stability</p>
              <p className="text-xs text-black/60 mb-3"><strong>Usage:</strong> Multi-color gradients, subtle trust indicators</p>
              <code className="block bg-black/5 rounded px-2 py-1 text-[10px] font-mono text-black/80">
                var(--periwinkle-500)
              </code>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-24" style={{ background: 'linear-gradient(135deg, #ea7a5f, #e85e45)' }}></div>
            <div className="p-4 bg-white">
              <p className="font-semibold text-sm mb-1">Coral</p>
              <p className="font-mono text-xs text-black/60 mb-2">#ea7a5f</p>
              <p className="text-xs text-black/50 mb-2">RGB: 234, 122, 95</p>
              <p className="text-xs text-black/60 mb-2"><strong>Meaning:</strong> Warmth, approachability, creativity</p>
              <p className="text-xs text-black/60 mb-3"><strong>Usage:</strong> Background gradients, warm accents</p>
              <code className="block bg-black/5 rounded px-2 py-1 text-[10px] font-mono text-black/80">
                var(--coral-600) at 5-10% opacity
              </code>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-24" style={{ background: 'linear-gradient(135deg, #eab308, #f59e0b)' }}></div>
            <div className="p-4 bg-white">
              <p className="font-semibold text-sm mb-1">Amber</p>
              <p className="font-mono text-xs text-black/60 mb-2">#eab308</p>
              <p className="text-xs text-black/50 mb-2">RGB: 234, 179, 8</p>
              <p className="text-xs text-black/60 mb-2"><strong>Meaning:</strong> Energy, optimism, action</p>
              <p className="text-xs text-black/60 mb-3"><strong>Usage:</strong> Objectives section gradients, success metrics</p>
              <code className="block bg-black/5 rounded px-2 py-1 text-[10px] font-mono text-black/80">
                var(--amber-500) in gradients
              </code>
            </div>
          </div>

          <div className="border border-black/8 rounded-lg overflow-hidden">
            <div className="h-24" style={{ background: 'linear-gradient(135deg, #059669, #047857)' }}></div>
            <div className="p-4 bg-white">
              <p className="font-semibold text-sm mb-1">Green</p>
              <p className="font-mono text-xs text-black/60 mb-2">#059669</p>
              <p className="text-xs text-black/50 mb-2">RGB: 5, 150, 105</p>
              <p className="text-xs text-black/60 mb-2"><strong>Meaning:</strong> Success, growth, positive metrics</p>
              <p className="text-xs text-black/60 mb-3"><strong>Usage:</strong> Success states, positive metrics ONLY</p>
              <code className="block bg-black/5 rounded px-2 py-1 text-[10px] font-mono text-black/80">
                var(--green-600) for success icons
              </code>
            </div>
          </div>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mt-6">
          <h3 className="font-semibold mb-2 text-red-900">⚠️ CRITICAL RULE</h3>
          <p className="text-sm text-red-800">
            Accent colors are used primarily in gradients at 5-20% opacity, <strong>NOT as solid fills</strong>. 
            Maximum 3% usage per page total. Never use for text, borders, or primary visual elements.
          </p>
        </div>

        <CodeExample
          code={`// Purple gradient background (5% opacity)
<div style={{
  background: 'linear-gradient(135deg, rgba(148,136,236,0.05), transparent)'
}}>
  {/* Content */}
</div>

// Brand button shadow with purple accent
<button style={{
  background: 'var(--brand-red)',
  boxShadow: '0 8px 24px rgba(148,136,236,0.24), 0 2px 8px rgba(0,0,0,0.12)'
}}>
  Primary CTA
</button>

// Success state with green
<div style={{ color: 'var(--green-600)' }}>
  ✓ Success message
</div>`}
        />
      </DocSection>

      {/* 5. BORDER COLORS */}
      <DocSection
        title="5. Border Colors & Dividers"
        why="Subtle borders create separation without harsh lines - essential for card-based layouts. Consistent opacity levels maintain hierarchy and prevent visual noise."
        what="Black opacity variants (8%, 10%, 15%) with semantic tokens for different emphasis levels"
        when="✅ Card outlines, Section dividers, Input borders, Subtle separations, Focus states, Hover states"
        whenNot="❌ Don't use for text decoration or as primary visual elements"
        where="Card borders (--border-card at 8% ⭐ MOST USED), Section dividers (--border-default at 10%), Input focus/hover (--border-interactive at 15%)"
        how="Apply via border property with semantic tokens, increase opacity for more emphasis, use --warm-500 (#eae5e3) for borders on warm backgrounds"
      >
        <div className="overflow-x-auto mb-6">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-black/20">
                <th className="text-left p-3 text-sm font-bold">Token</th>
                <th className="text-left p-3 text-sm font-bold">Value</th>
                <th className="text-left p-3 text-sm font-bold">Opacity</th>
                <th className="text-left p-3 text-sm font-bold">Usage</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-black/8 bg-yellow-50">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--border-card</code>
                  <span className="ml-2 text-xs">⭐</span>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.08)</code>
                </td>
                <td className="p-3 text-sm">8%</td>
                <td className="p-3 text-sm font-semibold">Card borders ⭐ MOST USED</td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--border-default</code>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.10)</code>
                </td>
                <td className="p-3 text-sm">10%</td>
                <td className="p-3 text-sm">Standard borders</td>
              </tr>
              <tr className="border-b border-black/8">
                <td className="p-3">
                  <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded">--border-interactive</code>
                </td>
                <td className="p-3">
                  <code className="font-mono text-xs text-black/60">rgba(0,0,0,0.15)</code>
                </td>
                <td className="p-3 text-sm">15%</td>
                <td className="p-3 text-sm">Hover states</td>
              </tr>
            </tbody>
          </table>
        </div>

        <CodeExample
          code={`// Standard card border (MOST COMMON)
<div style={{
  border: '1px solid var(--border-card)',  // 8% opacity ⭐
  borderRadius: '10px'
}}>
  {/* Card content */}
</div>

// Hover state
<div className="border border-[var(--border-card)] 
                hover:border-[var(--border-interactive)]
                transition-colors duration-300">
  {/* Hover changes 8% → 15% */}
</div>`}
        />
      </DocSection>

      {/* ❌ NEVER DO / ✅ ALWAYS DO */}
      <DocSection title="Critical Color Rules Summary">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h3 className="font-semibold text-red-900 mb-4">❌ NEVER DO:</h3>
            <ul className="space-y-2 text-sm text-red-800">
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Use random Tailwind colors (<code>text-gray-600</code>, <code>bg-blue-100</code>)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Use hardcoded hex values like <code>#666666</code></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Create new gray shades - use defined tokens</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Use brand red for backgrounds</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Use colors that fail WCAG AAA</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">❌</span>
                <span>Use accent colors as solid fills</span>
              </li>
            </ul>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="font-semibold text-green-900 mb-4">✅ ALWAYS DO:</h3>
            <ul className="space-y-2 text-sm text-green-800">
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Use CSS variables: <code>var(--brand-red)</code>, <code>var(--text-tertiary)</code></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Check contrast ratios (aim for 7:1+)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Limit brand red to 5% of page</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Use semantic tokens for text colors</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Use accent colors in gradients at 5-20% opacity</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold">✅</span>
                <span>Follow section background alternating pattern</span>
              </li>
            </ul>
          </div>
        </div>
      </DocSection>
    </div>
  );
}
