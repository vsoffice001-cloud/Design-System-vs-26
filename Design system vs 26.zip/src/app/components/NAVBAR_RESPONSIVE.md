# 📱 Navbar Responsive Design System

## Overview
The navbar is fully responsive across all screen sizes with optimized layouts for mobile, tablet, and desktop experiences.

---

## 🎯 Responsive Breakpoints

### **Mobile (< 640px)**
- **Logo**: Scaled to 18px height (compact)
- **Main Nav**: Hidden - replaced with hamburger menu
- **Secondary Bar**: Hidden
- **CTA Button**: Hidden in header, appears in mobile menu
- **Search**: Icon-only button in mobile menu
- **Menu**: Full-screen dropdown with:
  - Main navigation links
  - Company submenu
  - Login/Procurement links
  - Search button
  - Schedule Demo CTA

### **Small Tablet (640px - 768px)**
- **Logo**: Full size (20px height)
- **Main Nav**: Still hidden - hamburger menu
- **Secondary Bar**: Hidden
- **CTA Button**: Visible in header
- **Search**: Icon in mobile menu
- **Menu**: Expanded mobile menu with better spacing

### **Tablet (768px - 1024px)**
- **Logo**: Full size
- **Main Nav**: Still hamburger menu
- **Secondary Bar**: Hidden
- **CTA Button**: ✅ Visible "Schedule a Demo"
- **Search**: Icon button (between nav and CTA)
- **Menu**: Full mobile menu available

### **Desktop (1024px - 1280px)**
- **Logo**: Full size, left-aligned
- **Main Nav**: ✅ Services, Industries, Resources (center)
- **Secondary Bar**: Hidden
- **CTA Button**: ✅ "Schedule a Demo" (right side)
- **Search**: Icon button only (search bar hidden)
- **Menu**: Hover dropdowns for navigation

### **Large Desktop (1280px - 1536px)**
- **Logo**: Full size
- **Main Nav**: ✅ All items visible
- **Secondary Bar**: ✅ Visible with Latest Reports, Procurement, Company, Login
- **CTA Button**: ✅ Full "Schedule a Demo"
- **Search**: ✅ Full search bar with gradient effect
- **Menu**: All features active

### **Extra Large (> 1536px)**
- **All elements**: Maximum spacing and padding
- **Secondary Bar**: ✅ Shows all content including "CTA here" link
- **Full Feature Set**: Everything visible

---

## 📐 Layout Strategy

### **Positioning System**

#### **Logo (Left Side)**
```css
Mobile:   left-4    (16px)
Tablet:   left-6    (24px)
Desktop:  left-10   (40px)
XL:       left-12   (48px)
```

#### **Right Side Actions**
```css
Mobile:   right-4   (16px)
Tablet:   right-6   (24px)
Desktop:  right-10  (40px)
XL:       right-12  (48px)
```

#### **Center Navigation**
```css
Desktop: absolute left-1/2 -translate-x-1/2
Hidden:  < lg (1024px)
```

---

## 🎨 Component Visibility Matrix

| Component | Mobile | Tablet | Desktop (lg) | Desktop (xl) | 2XL |
|-----------|--------|--------|--------------|--------------|-----|
| **Secondary Bar** | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Logo** | ✅ Small | ✅ | ✅ | ✅ | ✅ |
| **Services Nav** | 🍔 Menu | 🍔 Menu | ✅ | ✅ | ✅ |
| **Industries Nav** | 🍔 Menu | 🍔 Menu | ✅ | ✅ | ✅ |
| **Resources Nav** | 🍔 Menu | 🍔 Menu | ✅ | ✅ | ✅ |
| **Search Icon** | 🍔 Menu | 🍔 Menu | ✅ | ❌ | ❌ |
| **Search Bar** | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Schedule Demo** | 🍔 Menu | ✅ | ✅ | ✅ | ✅ |
| **Hamburger Menu** | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Latest Reports** | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Procurement** | 🍔 Menu | 🍔 Menu | ❌ | ✅ | ✅ |
| **Company Dropdown** | 🍔 Menu | 🍔 Menu | ❌ | ✅ | ✅ |
| **Login** | 🍔 Menu | 🍔 Menu | ❌ | ✅ | ✅ |

**Legend:**
- ✅ = Visible
- ❌ = Hidden
- 🍔 Menu = Available in mobile menu

---

## 🎭 Interaction States

### **Desktop Hover Effects**
```tsx
// Navigation items
hover:opacity-70 transition-opacity

// Dropdowns
group-hover:translate-y-0.5 (chevrons)

// Company dropdown
opacity-0 → opacity-100 with translate-y animation
```

### **Mobile Touch Targets**
```tsx
// Minimum touch target: 40px (10 = 2.5rem)
w-10 h-10 for hamburger button

// Links have padding for easier tapping
py-3 px-2 (48px height target area)
```

---

## 📱 Mobile Menu Features

### **Layout**
- Full width dropdown below navbar
- Max height: `calc(100vh - 60px)` with scroll
- Animated entry: `slide-in-from-top-2`
- Shadow: `shadow-xl` for elevation

### **Structure**
1. **Main Navigation** (bordered section)
   - Services, Industries, Resources
   - Chevron indicators for dropdowns

2. **Company Submenu** (bordered section)
   - Label: "COMPANY" (uppercase, small)
   - Our Story, Our Experts, Careers, Contact Us

3. **Additional Links** (bordered section, hidden on xl+)
   - Procurement
   - Login (with icon)

4. **CTA Section**
   - Search button (mobile only)
   - Schedule Demo (always visible)

---

## 🎨 Button System Integration

### **Desktop CTA**
```tsx
<Button
  variant="brand"
  size="sm"
  className="font-['DM_Sans',sans-serif] font-bold text-[13px] xl:text-[14px]"
>
  Schedule a Demo
</Button>
```

### **Mobile Menu CTA**
```tsx
<Button 
  variant="brand" 
  size="md" 
  fullWidth={true}
  className="font-['DM_Sans',sans-serif] font-bold"
>
  Schedule a Demo
</Button>
```

### **Mobile Search Button**
```tsx
<Button 
  variant="secondary" 
  size="md" 
  fullWidth={true}
  icon={<Search className="w-4 h-4" />}
  iconPosition="left"
>
  Search
</Button>
```

---

## ⚡ Performance Optimizations

### **Conditional Rendering**
- Secondary bar only renders on `xl:` breakpoint
- Mobile menu conditionally rendered based on state
- Desktop nav hidden completely on mobile (not just `display: none`)

### **Icons**
- Using `lucide-react` for:
  - `Menu` - Hamburger icon
  - `X` - Close icon
  - `Search` - Search functionality
  - `ChevronDown` - Dropdown indicators

### **Transitions**
```css
transition-opacity     /* Hover effects */
transition-colors      /* Link states */
transition-transform   /* Chevron animations */
duration-300          /* Mobile menu slide */
```

---

## 🔍 Search Component Variants

### **Large Desktop (xl+)**
Full search bar with gradient effect:
```tsx
<button className="bg-[#f5f5fd] h-[30px] px-3 rounded-full">
  <span>Search</span>
  <Search icon />
</button>
```

### **Desktop (lg only)**
Icon button:
```tsx
<button className="w-8 h-8 rounded-full hover:bg-black/5">
  <Search className="w-4 h-4" />
</button>
```

### **Mobile/Tablet**
Full-width button in mobile menu:
```tsx
<Button variant="secondary" fullWidth icon={<Search />}>
  Search
</Button>
```

---

## 🎯 Accessibility Features

### **ARIA Labels**
```tsx
aria-label={showMobileMenu ? "Close menu" : "Open menu"}
```

### **Keyboard Navigation**
- All buttons are `<button>` elements (keyboard accessible)
- Links are `<a>` elements with `href`
- Dropdowns use proper focus management

### **Touch Targets**
- Minimum 40px × 40px for mobile buttons
- Adequate padding on links (py-3 = 12px top/bottom)
- Spacing between interactive elements

---

## 🚀 Future Enhancements

### **Potential Additions**
- [ ] Search functionality with modal
- [ ] Mega menus for Services/Industries
- [ ] Sticky scroll behavior options
- [ ] Dark mode variant
- [ ] Notification badges
- [ ] User profile dropdown (when logged in)
- [ ] Multi-language support
- [ ] Shopping cart integration

---

## 📊 Tailwind Breakpoints Reference

```css
sm:  640px   /* Small tablet */
md:  768px   /* Tablet */
lg:  1024px  /* Desktop */
xl:  1280px  /* Large desktop */
2xl: 1536px  /* Extra large desktop */
```

---

## 🎨 Design Tokens Used

### **Spacing**
```css
gap-1: 0.25rem (4px)
gap-2: 0.5rem  (8px)
gap-3: 0.75rem (12px)
gap-4: 1rem    (16px)
gap-6: 1.5rem  (24px)
```

### **Typography**
```css
text-[11px]  /* Secondary bar (mobile) */
text-[12px]  /* Secondary bar (desktop) */
text-[13px]  /* Main nav (desktop) */
text-[14px]  /* Main nav (xl+) */
text-[15px]  /* Mobile menu (tablet) */
```

### **Colors**
```css
bg-[#141016]  /* Secondary bar dark */
bg-[#f5f5fd]  /* Search bar background */
text-[#141016] /* Primary text */
border-black/10 /* Subtle borders */
```

---

## ✅ Testing Checklist

- [ ] Mobile (375px - iPhone SE)
- [ ] Mobile (414px - iPhone Pro Max)
- [ ] Tablet (768px - iPad)
- [ ] Tablet Landscape (1024px)
- [ ] Desktop (1280px)
- [ ] Large Desktop (1440px)
- [ ] Ultra Wide (1920px+)
- [ ] Mobile menu open/close
- [ ] Desktop dropdowns
- [ ] Search functionality
- [ ] CTA button click
- [ ] Logo clickable
- [ ] All links functional
- [ ] Scroll hide/show behavior
- [ ] Touch targets adequate
- [ ] No horizontal scroll

---

**Last Updated:** Button System Integration v2.0
**Component:** `/src/app/components/Navbar.tsx`
**Dependencies:** Button, lucide-react icons
