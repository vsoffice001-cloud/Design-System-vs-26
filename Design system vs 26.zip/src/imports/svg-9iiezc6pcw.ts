export default {
p287b410: "M4 12L12 4M12 4H5.5M12 4V10.5",
}
