export default function Component1stBg() {
  return <div className="bg-gradient-to-r from-[#b01f24] size-full to-[#b01f24] via-[#eb484e] via-[49.483%]" data-name="1st bg" />;
}