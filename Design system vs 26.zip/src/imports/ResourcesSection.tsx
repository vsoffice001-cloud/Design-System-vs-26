import svgPaths from "./svg-qr93jqxq2j";
import imgImageTheFutureOfAiInSupplyChainManagement from "figma:asset/52dc2d242efb6fec4b3045208719c859f0824631.png";
import imgImageBuildingResilientSupplyChainsIn2024 from "figma:asset/4fe63e827054e6912bad635b5391ff745e22d77f.png";
import imgImageWarehouseAutomationRoiAndImplementation from "figma:asset/a44aa28887331d03c4dafe9f372fdb0febcdaf66.png";
import imgImageDigitalTransformationInLogistics from "figma:asset/2b0467c7313458787fc41f08fd635142dde3ac18.png";
import imgImageSustainableTransportationSolutions from "figma:asset/62c347c2bc4229776df858579ceda831fbe8f8a2.png";
import imgImageIndustry40AndSmartManufacturing from "figma:asset/3537476d7254fe993352d1d092ac755b514bb596.png";
import imgImageOptimizingLastMileDelivery from "figma:asset/34997642bce0299c69bbed7c2bf1ad28601f1a57.png";
import imgImageBuildingHighPerformanceLogisticsTeams from "figma:asset/701feef993c39372216e98938187e7a5ba9e78d9.png";

function Text() {
  return (
    <div className="absolute h-[19.195px] left-0 top-0 w-[1036px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[2.94px] uppercase">Related Resources</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[56.148px] left-0 top-[51.2px] w-[1036px]" data-name="Heading 2">
      <p className="absolute css-ew64yg font-['Noto_Serif:Display_Light',sans-serif] font-light leading-[56.157px] left-0 text-[48.832px] text-white top-[-0.5px] tracking-[-1.2208px]" style={{ fontVariationSettings: "'CTGR' 100, 'wdth' 100" }}>{`Industry Insights & Resources`}</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute h-[54.391px] left-0 top-[131.34px] w-[700px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[668px]">Expert perspectives and thought leadership on market intelligence, strategic consulting, and transformative business solutions</p>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute h-[185.734px] left-[81.5px] top-[80px] w-[1036px]" data-name="Container">
      <Text />
      <Heading />
      <Paragraph />
    </div>
  );
}

function Text1() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[108.859px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">TECHNOLOGY</p>
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute h-[24px] left-[120.86px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text3() {
  return (
    <div className="absolute h-[19.195px] left-[140.09px] top-[2.4px] w-[64.75px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 15, '24`}</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text1 />
      <Text2 />
      <Text3 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[97.523px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[184px]">The Future of AI in Supply Chain Management</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="absolute h-[108.781px] left-0 top-[353.77px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[209px]">Exploring how artificial intelligence is revolutionizing logistics operations and predictive analytics.</p>
    </div>
  );
}

function ImageTheFutureOfAiInSupplyChainManagement() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (The Future of AI in Supply Chain Management)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageTheFutureOfAiInSupplyChainManagement} />
    </div>
  );
}

function Container2() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container3() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageTheFutureOfAiInSupplyChainManagement />
      <Container2 />
    </div>
  );
}

function Article() {
  return (
    <div className="absolute h-[462.555px] left-0 top-0 w-[235px]" data-name="Article">
      <Container1 />
      <Heading1 />
      <Paragraph1 />
      <Container3 />
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[76.57px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">INSIGHTS</p>
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute h-[24px] left-[88.57px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute h-[19.195px] left-[107.8px] top-[2.4px] w-[64.813px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 12, '24`}</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text4 />
      <Text5 />
      <Text6 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[65.016px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[231px]">Building Resilient Supply Chains in 2024</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute h-[81.586px] left-0 top-[321.27px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[229px]">Key strategies for creating agile and resilient logistics networks in an uncertain global economy.</p>
    </div>
  );
}

function ImageBuildingResilientSupplyChainsIn() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Building Resilient Supply Chains in 2024)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageBuildingResilientSupplyChainsIn2024} />
    </div>
  );
}

function Container5() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container6() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageBuildingResilientSupplyChainsIn />
      <Container5 />
    </div>
  );
}

function Article1() {
  return (
    <div className="absolute h-[462.555px] left-[267px] top-0 w-[235px]" data-name="Article">
      <Container4 />
      <Heading2 />
      <Paragraph2 />
      <Container6 />
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[106.016px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">AUTOMATION</p>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute h-[24px] left-[118.02px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute h-[19.195px] left-[137.25px] top-[2.4px] w-[64.836px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 10, '24`}</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text7 />
      <Text8 />
      <Text9 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[97.523px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[210px]">Warehouse Automation: ROI and Implementation</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[108.781px] left-0 top-[353.77px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[221px]">A comprehensive guide to implementing robotic systems and measuring their impact on operations.</p>
    </div>
  );
}

function ImageWarehouseAutomationRoiAndImplementation() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Warehouse Automation: ROI and Implementation)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageWarehouseAutomationRoiAndImplementation} />
    </div>
  );
}

function Container8() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container9() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageWarehouseAutomationRoiAndImplementation />
      <Container8 />
    </div>
  );
}

function Article2() {
  return (
    <div className="absolute h-[462.555px] left-[534px] top-0 w-[235px]" data-name="Article">
      <Container7 />
      <Heading3 />
      <Paragraph3 />
      <Container9 />
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[82.43px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">STRATEGY</p>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute h-[24px] left-[94.43px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[19.195px] left-[113.66px] top-[2.4px] w-[59.133px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 8, '24`}</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text10 />
      <Text11 />
      <Text12 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[65.016px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[221px]">Digital Transformation in Logistics</p>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute h-[81.586px] left-0 top-[321.27px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[217px]">How leading companies are leveraging digital tools to gain competitive advantages.</p>
    </div>
  );
}

function ImageDigitalTransformationInLogistics() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Digital Transformation in Logistics)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageDigitalTransformationInLogistics} />
    </div>
  );
}

function Container11() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container12() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageDigitalTransformationInLogistics />
      <Container11 />
    </div>
  );
}

function Article3() {
  return (
    <div className="absolute h-[462.555px] left-[801px] top-0 w-[235px]" data-name="Article">
      <Container10 />
      <Heading4 />
      <Paragraph4 />
      <Container12 />
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[131.617px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">SUSTAINABILITY</p>
    </div>
  );
}

function Text14() {
  return (
    <div className="absolute h-[24px] left-[143.62px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text15() {
  return (
    <div className="absolute h-[19.195px] left-[162.85px] top-[2.4px] w-[58.875px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 5, '24`}</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text13 />
      <Text14 />
      <Text15 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="absolute h-[97.523px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[147px]">Sustainable Transportation Solutions</p>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="absolute h-[108.781px] left-0 top-[353.77px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[222px]">The shift to electric and hybrid fleets: challenges, opportunities, and environmental impact.</p>
    </div>
  );
}

function ImageSustainableTransportationSolutions() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Sustainable Transportation Solutions)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageSustainableTransportationSolutions} />
    </div>
  );
}

function Container14() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container15() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageSustainableTransportationSolutions />
      <Container14 />
    </div>
  );
}

function Article4() {
  return (
    <div className="absolute h-[462.555px] left-0 top-[494.55px] w-[235px]" data-name="Article">
      <Container13 />
      <Heading5 />
      <Paragraph5 />
      <Container15 />
    </div>
  );
}

function Text16() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[138.164px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">MANUFACTURING</p>
    </div>
  );
}

function Text17() {
  return (
    <div className="absolute h-[24px] left-[150.16px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text18() {
  return (
    <div className="absolute h-[19.195px] left-[169.4px] top-[2.4px] w-[58.984px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Jan 3, '24`}</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text16 />
      <Text17 />
      <Text18 />
    </div>
  );
}

function Heading6() {
  return (
    <div className="absolute h-[65.016px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[233px]">Industry 4.0 and Smart Manufacturing</p>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="absolute h-[81.586px] left-0 top-[321.27px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[204px]">Integrating IoT and machine learning into production and distribution processes.</p>
    </div>
  );
}

function ImageIndustry40AndSmartManufacturing() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Industry 4.0 and Smart Manufacturing)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageIndustry40AndSmartManufacturing} />
    </div>
  );
}

function Container17() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container18() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageIndustry40AndSmartManufacturing />
      <Container17 />
    </div>
  );
}

function Article5() {
  return (
    <div className="absolute h-[462.555px] left-[267px] top-[494.55px] w-[235px]" data-name="Article">
      <Container16 />
      <Heading6 />
      <Paragraph6 />
      <Container18 />
    </div>
  );
}

function Text19() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[101.492px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">OPERATIONS</p>
    </div>
  );
}

function Text20() {
  return (
    <div className="absolute h-[24px] left-[113.49px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text21() {
  return (
    <div className="absolute h-[19.195px] left-[132.73px] top-[2.4px] w-[69.258px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Dec 30, '23`}</p>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text19 />
      <Text20 />
      <Text21 />
    </div>
  );
}

function Heading7() {
  return (
    <div className="absolute h-[65.016px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[213px]">Optimizing Last-Mile Delivery</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="absolute h-[81.586px] left-0 top-[321.27px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[230px]">Innovative approaches to solving the most expensive part of the delivery chain.</p>
    </div>
  );
}

function ImageOptimizingLastMileDelivery() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Optimizing Last-Mile Delivery)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageOptimizingLastMileDelivery} />
    </div>
  );
}

function Container20() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container21() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageOptimizingLastMileDelivery />
      <Container20 />
    </div>
  );
}

function Article6() {
  return (
    <div className="absolute h-[462.555px] left-[534px] top-[494.55px] w-[235px]" data-name="Article">
      <Container19 />
      <Heading7 />
      <Paragraph7 />
      <Container21 />
    </div>
  );
}

function Text22() {
  return (
    <div className="absolute h-[19.195px] left-0 top-[2.4px] w-[98.992px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[1.94px] uppercase">LEADERSHIP</p>
    </div>
  );
}

function Text23() {
  return (
    <div className="absolute h-[24px] left-[110.99px] top-0 w-[7.234px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.2)] top-[-0.5px] tracking-[-0.3125px]">•</p>
    </div>
  );
}

function Text24() {
  return (
    <div className="absolute h-[19.195px] left-[130.23px] top-[2.4px] w-[69.133px]" data-name="Text">
      <p className="absolute css-ew64yg font-['Inter:Regular',sans-serif] font-normal leading-[19.2px] left-0 not-italic text-[12.8px] text-[rgba(255,255,255,0.4)] top-0 tracking-[-0.06px]">{`Dec 28, '23`}</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute h-[24px] left-0 top-[200.25px] w-[235px]" data-name="Container">
      <Text22 />
      <Text23 />
      <Text24 />
    </div>
  );
}

function Heading8() {
  return (
    <div className="absolute h-[97.523px] left-0 top-[240.25px] w-[235px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[32.51px] left-0 not-italic text-[25.008px] text-white top-[0.5px] tracking-[-0.4842px] w-[226px]">Building High-Performance Logistics Teams</p>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="absolute h-[81.586px] left-0 top-[353.77px] w-[235px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['Inter:Regular',sans-serif] font-normal leading-[27.2px] left-0 not-italic text-[16px] text-[rgba(255,255,255,0.6)] top-0 tracking-[-0.3125px] w-[232px]">Best practices for recruiting, training, and retaining top talent in the logistics industry.</p>
    </div>
  );
}

function ImageBuildingHighPerformanceLogisticsTeams() {
  return (
    <div className="absolute h-[176.25px] left-0 top-0 w-[235px]" data-name="Image (Building High-Performance Logistics Teams)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageBuildingHighPerformanceLogisticsTeams} />
    </div>
  );
}

function Container23() {
  return <div className="absolute bg-[rgba(0,0,0,0)] h-[176.25px] left-0 top-0 w-[235px]" data-name="Container" />;
}

function Container24() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.05)] h-[176.25px] left-0 overflow-clip rounded-[2.5px] top-0 w-[235px]" data-name="Container">
      <ImageBuildingHighPerformanceLogisticsTeams />
      <Container23 />
    </div>
  );
}

function Article7() {
  return (
    <div className="absolute h-[462.555px] left-[801px] top-[494.55px] w-[235px]" data-name="Article">
      <Container22 />
      <Heading8 />
      <Paragraph8 />
      <Container24 />
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute h-[957.109px] left-[81.5px] top-[345.73px] w-[1036px]" data-name="Container">
      <Article />
      <Article1 />
      <Article2 />
      <Article3 />
      <Article4 />
      <Article5 />
      <Article6 />
      <Article7 />
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[199.85px] size-[16px] top-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1d405500} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute border border-[rgba(255,255,255,0.2)] border-solid h-[66px] left-[470.57px] top-[1366.84px] w-[257.852px]" data-name="Button">
      <p className="absolute css-ew64yg font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[114px] not-italic text-[16px] text-center text-white top-[19.5px] tracking-[0.0875px] translate-x-[-50%]">View All Resources</p>
      <Icon />
    </div>
  );
}

export default function ResourcesSection() {
  return (
    <div className="bg-black relative size-full" data-name="ResourcesSection">
      <Container />
      <Container25 />
      <Button />
    </div>
  );
}