import svgPaths from "./svg-y9b0h1ep1a";

function Paragraph() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[11px] text-white top-[-0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Case Study
      </p>
    </div>
  );
}

function Hero() {
  return (
    <div className="bg-[#1a1a1a] h-[28px] relative rounded-[16777200px] shrink-0 w-[97.563px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[12px] relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function Hero1() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[777px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[56px] left-0 text-[42px] text-white top-0 tracking-[-1.5px] w-[777px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>{`Evaluating India's Transformer Bushing Market for IPO Readiness—₹110 Cr TAM and Competitive Positioning Insights`}</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[204px] items-start left-0 top-0 w-[840px]" data-name="Container">
      <Hero />
      <Hero1 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[184.367px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Client
        </p>
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[184.367px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Yash Highvoltage Insulators
        </p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[184.367px]" data-name="Container">
      <Paragraph1 />
      <Paragraph2 />
    </div>
  );
}

function IconBase() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1f577900} fill="var(--fill-0, #1976D2)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3048fe00} fill="var(--fill-0, #1976D2)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute bg-[#e3f2fd] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase />
    </div>
  );
}

function Hero2() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-0 rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-0 w-[278.359px]" data-name="Hero">
      <Container1 />
      <Container2 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[16px] relative shrink-0 w-[424.961px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Industry
        </p>
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[424.961px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Power Transmission • Electrical Equipment • Grid Infrastructure
        </p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[424.961px]" data-name="Container">
      <Paragraph3 />
      <Paragraph4 />
    </div>
  );
}

function IconBase1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1becfb00} fill="var(--fill-0, #F57C00)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3b796f80} fill="var(--fill-0, #F57C00)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute bg-[#fff3e0] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase1 />
    </div>
  );
}

function Hero3() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-[302.37px] rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-0 w-[518.961px]" data-name="Hero">
      <Container3 />
      <Container4 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[16px] relative shrink-0 w-[68.641px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Geography
        </p>
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[68.641px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          India
        </p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[68.641px]" data-name="Container">
      <Paragraph5 />
      <Paragraph6 />
    </div>
  );
}

function IconBase2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1aa5600} fill="var(--fill-0, #388E3C)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3217d300} fill="var(--fill-0, #388E3C)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-[#e8f5e9] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase2 />
    </div>
  );
}

function Hero4() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-0 rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-[116px] w-[200px]" data-name="Hero">
      <Container5 />
      <Container6 />
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[16px] relative shrink-0 w-[129.727px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Engagement Owner
        </p>
      </div>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[129.727px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Director – Strategy
        </p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[129.727px]" data-name="Container">
      <Paragraph7 />
      <Paragraph8 />
    </div>
  );
}

function IconBase3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p2965ba00} fill="var(--fill-0, #7B1FA2)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p72bac00} fill="var(--fill-0, #7B1FA2)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute bg-[#f3e5f5] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase3 />
    </div>
  );
}

function Hero5() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-[224px] rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-[116px] w-[223.727px]" data-name="Hero">
      <Container7 />
      <Container8 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[208px] left-0 top-[324.5px] w-[840px]" data-name="Container">
      <Hero2 />
      <Hero3 />
      <Hero4 />
      <Hero5 />
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute h-[633px] left-[132px] top-[48px] w-[938px]" data-name="Container">
      <Container />
      <Container9 />
    </div>
  );
}

function Hero6() {
  return (
    <div className="h-[18px] relative shrink-0 w-[99.688px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[18px] left-0 text-[12px] text-[rgba(255,255,255,0.7)] top-0 tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Scroll to explore
        </p>
      </div>
    </div>
  );
}

function Hero7() {
  return (
    <div className="h-[19.422px] overflow-clip relative shrink-0 w-full" data-name="Hero">
      <div className="absolute bottom-[29.98%] left-[calc(50%+0.33px)] top-[27.12%] translate-x-[-50%] w-[16.667px]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4444 11.1111">
            <path d={svgPaths.p24ba1b00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="2.77778" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[19.422px] relative shrink-0 w-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Hero7 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.939px] h-[46px] items-center left-[535px] top-[643px] w-[112px]" data-name="Container">
      <Hero6 />
      <Container11 />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[729px] left-0 top-0 w-[1440px]" data-name="Container">
      <Container10 />
      <Container12 />
    </div>
  );
}

export default function Hero8() {
  return (
    <div className="relative size-full" data-name="Hero" style={{ backgroundImage: "linear-gradient(148.487deg, rgb(107, 95, 181) 0%, rgb(124, 95, 181) 100%)" }}>
      <Container13 />
    </div>
  );
}