import svgPaths from "./svg-yymkswet8x";
import imgImageYashIndustries from "figma:asset/faa51f6035eb6438eb4b8b0be770366215f25dc2.png";
import imgImageKenResearch from "figma:asset/f7db7bffa5ba5f13263e0371c49745dc500870f6.png";

function Paragraph() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[11px] text-white top-[-0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Case Study
      </p>
    </div>
  );
}

function Hero() {
  return (
    <div className="bg-[#1a1a1a] h-[28px] relative rounded-[16777200px] shrink-0 w-[97.563px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[12px] relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function Hero1() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[777px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[56px] left-0 text-[42px] text-white top-0 tracking-[-1.5px] w-[777px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>{`Evaluating India's Transformer Bushing Market for IPO Readiness—₹110 Cr TAM and Competitive Positioning Insights`}</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[204px] items-start left-0 top-0 w-[840px]" data-name="Container">
      <Hero />
      <Hero1 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[184.367px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Client
        </p>
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[184.367px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Yash Highvoltage Insulators
        </p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[184.367px]" data-name="Container">
      <Paragraph1 />
      <Paragraph2 />
    </div>
  );
}

function IconBase() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1f577900} fill="var(--fill-0, #1976D2)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3048fe00} fill="var(--fill-0, #1976D2)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute bg-[#e3f2fd] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase />
    </div>
  );
}

function Hero2() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-0 rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-0 w-[278.359px]" data-name="Hero">
      <Container1 />
      <Container2 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[16px] relative shrink-0 w-[424.961px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Industry
        </p>
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[424.961px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Power Transmission • Electrical Equipment • Grid Infrastructure
        </p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[424.961px]" data-name="Container">
      <Paragraph3 />
      <Paragraph4 />
    </div>
  );
}

function IconBase1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1becfb00} fill="var(--fill-0, #F57C00)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3b796f80} fill="var(--fill-0, #F57C00)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute bg-[#fff3e0] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase1 />
    </div>
  );
}

function Hero3() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-[302.37px] rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-0 w-[518.961px]" data-name="Hero">
      <Container3 />
      <Container4 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[16px] relative shrink-0 w-[68.641px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Geography
        </p>
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[68.641px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          India
        </p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[68.641px]" data-name="Container">
      <Paragraph5 />
      <Paragraph6 />
    </div>
  );
}

function IconBase2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1aa5600} fill="var(--fill-0, #388E3C)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p3217d300} fill="var(--fill-0, #388E3C)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-[#e8f5e9] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase2 />
    </div>
  );
}

function Hero4() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-0 rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-[116px] w-[200px]" data-name="Hero">
      <Container5 />
      <Container6 />
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[16px] relative shrink-0 w-[129.727px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[10px] text-[rgba(255,255,255,0.7)] top-[0.5px] tracking-[0.8px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
          Engagement Owner
        </p>
      </div>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[129.727px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[20px] left-0 text-[14px] text-white top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Director – Strategy
        </p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[40px] items-start left-[73px] top-[25px] w-[129.727px]" data-name="Container">
      <Paragraph7 />
      <Paragraph8 />
    </div>
  );
}

function IconBase3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p2965ba00} fill="var(--fill-0, #7B1FA2)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p72bac00} fill="var(--fill-0, #7B1FA2)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute bg-[#f3e5f5] content-stretch flex items-center justify-center left-[21px] rounded-[10px] size-[40px] top-[25px]" data-name="Container">
      <IconBase3 />
    </div>
  );
}

function Hero5() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.2)] border-solid h-[92px] left-[224px] rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] top-[116px] w-[223.727px]" data-name="Hero">
      <Container7 />
      <Container8 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[208px] left-0 top-[324.5px] w-[840px]" data-name="Container">
      <Hero2 />
      <Hero3 />
      <Hero4 />
      <Hero5 />
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute h-[633px] left-[132px] top-[48px] w-[938px]" data-name="Container">
      <Container />
      <Container9 />
    </div>
  );
}

function Hero6() {
  return (
    <div className="h-[18px] relative shrink-0 w-[99.688px]" data-name="Hero">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[18px] left-[-52.84px] text-[12px] text-[rgba(255,255,255,0.7)] top-0 tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Scroll to explore
        </p>
      </div>
    </div>
  );
}

function Hero7() {
  return (
    <div className="h-[19.422px] overflow-clip relative shrink-0 w-full" data-name="Hero">
      <div className="absolute inset-[27.12%_273.94%_29.98%_-257.27%]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-8.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.4444 11.1111">
            <path d={svgPaths.p24ba1b00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="2.77778" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[19.422px] relative shrink-0 w-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Hero7 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.939px] h-[46px] items-center left-[545px] pb-[-3.361px] pt-0 px-0 top-[643px] w-[112px]" data-name="Container">
      <Hero6 />
      <Container11 />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[729px] left-0 top-0 w-[1440px]" data-name="Container">
      <Container10 />
      <Container12 />
    </div>
  );
}

function Hero8() {
  return (
    <div className="h-[729px] overflow-clip relative shrink-0 w-full" data-name="Hero" style={{ backgroundImage: "linear-gradient(148.487deg, rgb(107, 95, 181) 0%, rgb(124, 95, 181) 100%)" }}>
      <Container13 />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute bg-[#1a1a1a] content-stretch flex h-[32px] items-start left-0 px-[16px] py-[8px] rounded-[16777200px] top-0 w-[140.039px]" data-name="Text">
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[12px] text-white tracking-[0.6px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Client Context
      </p>
    </div>
  );
}

function Container14() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[32px] left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.4)] w-[140.039px]" data-name="Container" />;
}

function ShimmerTag() {
  return (
    <div className="absolute h-[32px] left-0 overflow-clip top-0 w-[140.039px]" data-name="ShimmerTag">
      <Text />
      <Container14 />
    </div>
  );
}

function ImageYashIndustries() {
  return (
    <div className="absolute h-[48px] left-0 top-[54.5px] w-[109.711px]" data-name="Image (Yash Industries)">
      <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImageYashIndustries} />
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[102.5px] relative shrink-0 w-full" data-name="Container">
      <ShimmerTag />
      <ImageYashIndustries />
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[56px] left-0 top-0 w-[981px]" data-name="Heading 2">
      <p className="absolute css-4hzbpn font-['Noto_Serif:Display_Medium',sans-serif] font-medium leading-[28px] left-0 text-[#111] text-[18px] top-[-0.5px] w-[955px]" style={{ fontVariationSettings: "'CTGR' 100, 'wdth' 100" }}>
        A vertically integrated manufacturer of high-voltage condenser and non-condenser bushings serving utilities, transformer OEMs, and EPC companies across India.
      </p>
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="absolute h-[72px] left-0 top-[72px] w-[981px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#111] text-[15px] top-0 w-[957px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`India's power transmission sector is undergoing accelerated modernization, driven by utility expansions, renewable energy integration, and grid reliability mandates. In this environment, the demand for transformer bushings—especially high-voltage and condenser variants—has become increasingly strategic.`}</p>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="absolute h-[24px] left-0 top-[156px] w-[981px]" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#111] text-[15px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        Yash Highvoltage Insulators is positioned as one of the few domestic players with:
      </p>
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[26px] left-0 text-[#111] text-[15px] top-0 w-[389px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        • Deep engineering capability in HV condenser bushings
      </p>
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[26px] left-0 text-[#111] text-[15px] top-0 w-[504px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        • Vertical integration across ceramic, insulation, and assembly processes
      </p>
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[26px] left-0 text-[#111] text-[15px] top-0 w-[526px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        • Faster turnaround relative to imported alternatives, especially from Europe
      </p>
    </div>
  );
}

function ListItem3() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[26px] left-0 text-[#111] text-[15px] top-0 w-[438px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        • Ability to deliver fully customized and retrofit-grade products
      </p>
    </div>
  );
}

function List() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[6px] h-[122px] items-start left-0 top-[188px] w-[981px]" data-name="List">
      <ListItem />
      <ListItem1 />
      <ListItem2 />
      <ListItem3 />
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="absolute h-[48px] left-0 top-[322px] w-[981px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#111] text-[15px] top-0 w-[940px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Despite strong product and technical maturity, the leadership faced strategic blind spots around market sizing, competitive positioning, supply chain risks, and investor narrative development.
      </p>
    </div>
  );
}

function ClientContext() {
  return (
    <div className="absolute h-[21px] left-[139.75px] top-0 w-[14px]" data-name="ClientContext">
      <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#111] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        →
      </p>
    </div>
  );
}

function Link() {
  return (
    <div className="absolute border-[#111] border-b border-solid h-[24px] left-0 top-[388.5px] w-[153.75px]" data-name="Link">
      <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[21px] left-0 text-[#111] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        About the company
      </p>
      <ClientContext />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[412.5px] relative shrink-0 w-full" data-name="Container">
      <Heading />
      <Paragraph9 />
      <Paragraph10 />
      <List />
      <Paragraph11 />
      <Link />
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[523px] items-start relative shrink-0 w-full" data-name="Container">
      <Container15 />
      <Container16 />
    </div>
  );
}

function ClientContext1() {
  return (
    <div className="bg-white h-[607px] relative shrink-0 w-full" data-name="ClientContext">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start pb-0 pt-[42px] px-[104px] relative size-full">
          <Container17 />
        </div>
      </div>
    </div>
  );
}

function Container18() {
  return <div className="absolute blur-[64px] left-[-80px] rounded-[16777200px] size-[500px] top-[80px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 500 500\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -35.355 -35.355 0 250 250)\\\'><stop stop-color=\\\'rgba(78,127,227,0.08)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(58,99,214,0.04)\\\' offset=\\\'0.5\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container19() {
  return <div className="absolute blur-[64px] left-[789px] rounded-[16777200px] size-[500px] top-[390px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 500 500\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -35.355 -35.355 0 250 250)\\\'><stop stop-color=\\\'rgba(163,154,235,0.15)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(128,108,224,0.08)\\\' offset=\\\'0.5\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container20() {
  return <div className="absolute blur-[64px] left-[294.5px] opacity-50 rounded-[16777200px] size-[600px] top-[185px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 600 600\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -42.426 -42.426 0 300 300)\\\'><stop stop-color=\\\'rgba(148,24,255,0.06)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'0.7\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container21() {
  return (
    <div className="absolute h-[970px] left-0 overflow-clip top-0 w-[1189px]" data-name="Container">
      <Container18 />
      <Container19 />
      <Container20 />
    </div>
  );
}

function Text1() {
  return (
    <div className="absolute bg-[#1a1a1a] content-stretch flex h-[32px] items-start left-0 px-[16px] py-[8px] rounded-[16777200px] top-0 w-[115.695px]" data-name="Text">
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[12px] text-white tracking-[0.6px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        CHALLENGES
      </p>
    </div>
  );
}

function Container22() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[32px] left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.4)] w-[115.695px]" data-name="Container" />;
}

function ShimmerTag1() {
  return (
    <div className="absolute h-[32px] left-[104px] overflow-clip top-0 w-[115.695px]" data-name="ShimmerTag">
      <Text1 />
      <Container22 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[40px] left-[104px] top-[46.5px] w-[933px]" data-name="Heading 2">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[40px] left-0 text-[#0f172a] text-[34px] top-[-0.5px] tracking-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        Key Problem Statements
      </p>
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="absolute h-[52px] left-[104px] top-[90.5px] w-[768px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[26px] left-0 text-[#111] text-[16px] top-[0.5px] w-[750px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Critical challenges that required immediate attention and strategic intervention for successful market positioning
      </p>
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute h-[142.5px] left-0 top-0 w-[1141px]" data-name="Container">
      <ShimmerTag1 />
      <Heading3 />
      <Paragraph12 />
    </div>
  );
}

function Container24() {
  return <div className="absolute bg-[#6b9bd1] h-[5px] left-0 rounded-tl-[14px] rounded-tr-[14px] top-0 w-0" data-name="Container" />;
}

function Text2() {
  return (
    <div className="h-[17px] relative shrink-0 w-[24.18px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[19.5px] relative shrink-0 text-[#94a3b8] text-[13px] tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          001
        </p>
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[52px] relative shrink-0 w-[162.25px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[26px] left-0 text-[#0f172a] text-[18px] top-0 tracking-[-0.2px] w-[137px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Market Visibility Gaps
        </p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph13() {
  return (
    <div className="absolute h-[84px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[132px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        What is the actual size of the Indian transformer bushing market?
      </p>
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[84px] relative shrink-0 w-full" data-name="Container">
      <Text3 />
      <Paragraph13 />
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph14() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[125px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        How much is addressable by the client today?
      </p>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text4 />
      <Paragraph14 />
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph15() {
  return (
    <div className="absolute h-[84px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[109px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Which segments represent the highest-value opportunities?
      </p>
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[84px] relative shrink-0 w-full" data-name="Container">
      <Text5 />
      <Paragraph15 />
    </div>
  );
}

function Container28() {
  return (
    <div className="h-[255px] relative shrink-0 w-[162.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Container25 />
        <Container26 />
        <Container27 />
      </div>
    </div>
  );
}

function ProblemStatements() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[26.5px] h-[491.5px] items-start left-0 pb-0 pl-[28px] pr-0 pt-[32.5px] top-0 w-[218.25px]" data-name="ProblemStatements">
      <Text2 />
      <Heading1 />
      <Container28 />
    </div>
  );
}

function Container29() {
  return (
    <div className="bg-white col-[1] css-3foyfs overflow-clip relative rounded-[14px] row-[1] self-stretch shadow-[0px_2px_8px_-2px_rgba(0,0,0,0.08),0px_0px_0px_1px_rgba(0,0,0,0.04)] shrink-0" data-name="Container">
      <Container24 />
      <ProblemStatements />
    </div>
  );
}

function Container30() {
  return <div className="absolute bg-[#6b9bd1] h-[5px] left-0 rounded-tl-[14px] rounded-tr-[14px] top-0 w-0" data-name="Container" />;
}

function Text6() {
  return (
    <div className="h-[17px] relative shrink-0 w-[27.078px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[19.5px] relative shrink-0 text-[#94a3b8] text-[13px] tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          002
        </p>
      </div>
    </div>
  );
}

function Heading4() {
  return (
    <div className="h-[52px] relative shrink-0 w-[162.25px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[26px] left-0 text-[#0f172a] text-[18px] top-0 tracking-[-0.2px] w-[152px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Competitive Blind Spots
        </p>
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph16() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[119px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`How does Yash's portfolio compare with competitors?`}</p>
    </div>
  );
}

function Container31() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text7 />
      <Paragraph16 />
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph17() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[128px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        What differentiated the fastest-growing players?
      </p>
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text8 />
      <Paragraph17 />
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph18() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[131px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Where are the white spaces in product range?
      </p>
    </div>
  );
}

function Container33() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text9 />
      <Paragraph18 />
    </div>
  );
}

function Container34() {
  return (
    <div className="h-[213px] relative shrink-0 w-[162.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Container31 />
        <Container32 />
        <Container33 />
      </div>
    </div>
  );
}

function ProblemStatements1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[26.5px] h-[491.5px] items-start left-0 pb-0 pl-[28px] pr-0 pt-[32.5px] top-0 w-[218.25px]" data-name="ProblemStatements">
      <Text6 />
      <Heading4 />
      <Container34 />
    </div>
  );
}

function Container35() {
  return (
    <div className="bg-white col-[2] css-3foyfs overflow-clip relative rounded-[14px] row-[1] self-stretch shadow-[0px_2px_8px_-2px_rgba(0,0,0,0.08),0px_0px_0px_1px_rgba(0,0,0,0.04)] shrink-0" data-name="Container">
      <Container30 />
      <ProblemStatements1 />
    </div>
  );
}

function Container36() {
  return <div className="absolute bg-[#6b9bd1] h-[5px] left-0 rounded-tl-[14px] rounded-tr-[14px] top-0 w-0" data-name="Container" />;
}

function Text10() {
  return (
    <div className="h-[17px] relative shrink-0 w-[27.453px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[19.5px] relative shrink-0 text-[#94a3b8] text-[13px] tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          003
        </p>
      </div>
    </div>
  );
}

function Heading5() {
  return (
    <div className="h-[26px] relative shrink-0 w-[162.25px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[26px] left-0 text-[#0f172a] text-[18px] top-0 tracking-[-0.2px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Supply Chain Risks
        </p>
      </div>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph19() {
  return (
    <div className="absolute h-[84px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[132px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        What percentage depends on imports vs domestic production?
      </p>
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[84px] relative shrink-0 w-full" data-name="Container">
      <Text11 />
      <Paragraph19 />
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph20() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[137px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Which suppliers pose pricing or lead-time risks?
      </p>
    </div>
  );
}

function Container38() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text12 />
      <Paragraph20 />
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph21() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[85px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        What are the procurement bottlenecks?
      </p>
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text13 />
      <Paragraph21 />
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[234px] relative shrink-0 w-[162.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Container37 />
        <Container38 />
        <Container39 />
      </div>
    </div>
  );
}

function ProblemStatements2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[26.5px] h-[491.5px] items-start left-0 pb-0 pl-[28px] pr-0 pt-[32.5px] top-0 w-[218.25px]" data-name="ProblemStatements">
      <Text10 />
      <Heading5 />
      <Container40 />
    </div>
  );
}

function Container41() {
  return (
    <div className="bg-white col-[3] css-3foyfs overflow-clip relative rounded-[14px] row-[1] self-stretch shadow-[0px_2px_8px_-2px_rgba(0,0,0,0.08),0px_0px_0px_1px_rgba(0,0,0,0.04)] shrink-0" data-name="Container">
      <Container36 />
      <ProblemStatements2 />
    </div>
  );
}

function Container42() {
  return <div className="absolute bg-[#6b9bd1] h-[5px] left-0 rounded-tl-[14px] rounded-tr-[14px] top-0 w-0" data-name="Container" />;
}

function Text14() {
  return (
    <div className="h-[17px] relative shrink-0 w-[27.945px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[19.5px] relative shrink-0 text-[#94a3b8] text-[13px] tracking-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          004
        </p>
      </div>
    </div>
  );
}

function Heading6() {
  return (
    <div className="h-[52px] relative shrink-0 w-[162.25px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[26px] left-0 text-[#0f172a] text-[18px] top-0 tracking-[-0.2px] w-[152px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Investor Narrative Weakness
        </p>
      </div>
    </div>
  );
}

function Text15() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph22() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[127px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        How to articulate market opportunity clearly?
      </p>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text15 />
      <Paragraph22 />
    </div>
  );
}

function Text16() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph23() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[132px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Which growth levers matter to stakeholders?
      </p>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text16 />
      <Paragraph23 />
    </div>
  );
}

function Text17() {
  return (
    <div className="absolute h-[21px] left-0 top-[2px] w-[10.922px]" data-name="Text">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#64748b] text-[14px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        →
      </p>
    </div>
  );
}

function Paragraph24() {
  return (
    <div className="absolute h-[63px] left-[22.92px] top-0 w-[139.328px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[101px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        What pathways justify capacity expansion?
      </p>
    </div>
  );
}

function Container45() {
  return (
    <div className="h-[63px] relative shrink-0 w-full" data-name="Container">
      <Text17 />
      <Paragraph24 />
    </div>
  );
}

function Container46() {
  return (
    <div className="h-[213px] relative shrink-0 w-[162.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Container43 />
        <Container44 />
        <Container45 />
      </div>
    </div>
  );
}

function ProblemStatements3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[26.5px] h-[491.5px] items-start left-0 pb-0 pl-[28px] pr-0 pt-[32.5px] top-0 w-[218.25px]" data-name="ProblemStatements">
      <Text14 />
      <Heading6 />
      <Container46 />
    </div>
  );
}

function Container47() {
  return (
    <div className="bg-white col-[4] css-3foyfs overflow-clip relative rounded-[14px] row-[1] self-stretch shadow-[0px_2px_8px_-2px_rgba(0,0,0,0.08),0px_0px_0px_1px_rgba(0,0,0,0.04)] shrink-0" data-name="Container">
      <Container42 />
      <ProblemStatements3 />
    </div>
  );
}

function Container48() {
  return (
    <div className="absolute gap-[20px] grid grid-cols-[repeat(4,_minmax(0,_1fr))] grid-rows-[repeat(1,_minmax(0,_1fr))] h-[491.5px] left-[104px] top-[222.5px] w-[933px]" data-name="Container">
      <Container29 />
      <Container35 />
      <Container41 />
      <Container47 />
    </div>
  );
}

function Container49() {
  return (
    <div className="absolute h-[714px] left-[24px] top-[128px] w-[1141px]" data-name="Container">
      <Container23 />
      <Container48 />
    </div>
  );
}

function ProblemStatements4() {
  return (
    <div className="h-[970px] overflow-clip relative shrink-0 w-full" data-name="ProblemStatements" style={{ backgroundImage: "linear-gradient(140.792deg, rgb(241, 245, 253) 0%, rgb(223, 234, 250) 25%, rgb(255, 255, 255) 50%, rgb(241, 245, 253) 75%, rgb(227, 236, 249) 100%)" }}>
      <Container21 />
      <Container49 />
    </div>
  );
}

function Heading7() {
  return (
    <div className="absolute h-[48px] left-0 top-[47px] w-[261px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['DM_Sans:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#111] text-[17px] top-[-0.5px] w-[237px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Build a High-Resolution TAM–SAM–SOM Model
      </p>
    </div>
  );
}

function Paragraph25() {
  return (
    <div className="absolute h-[142.781px] left-0 top-[107px] w-[261px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[23.8px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[260px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Develop a voltage-wise, application-wise, and customer-cluster-wise mapping of the transformer bushing market, grounded in primary interviews, utility procurement cycles, and OEM expansion plans.
      </p>
    </div>
  );
}

function Text18() {
  return (
    <div className="absolute h-[16px] left-[20px] top-[8px] w-[78.031px]" data-name="Text">
      <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[#6b9bd1] text-[12px] top-0 tracking-[0.6px] uppercase w-[79px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Objective 1
      </p>
    </div>
  );
}

function Container50() {
  return (
    <div className="absolute border-[#6b9bd1] border-[1.5px] border-solid h-[35px] left-0 overflow-clip rounded-[16777200px] top-0 w-[121.031px]" data-name="Container">
      <Text18 />
    </div>
  );
}

function EngagementObjectives() {
  return (
    <div className="h-[249.781px] relative shrink-0 w-full" data-name="EngagementObjectives">
      <Heading7 />
      <Paragraph25 />
      <Container50 />
    </div>
  );
}

function EngagementObjectives1() {
  return <div className="bg-gradient-to-b from-[rgba(0,0,0,0)] h-px shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="EngagementObjectives" />;
}

function Container51() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[261px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start relative size-full">
        <EngagementObjectives />
        <EngagementObjectives1 />
      </div>
    </div>
  );
}

function Heading8() {
  return (
    <div className="absolute h-[48px] left-0 top-[47px] w-[261px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['DM_Sans:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#111] text-[17px] top-[-0.5px] w-[192px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Construct a Competitor Intelligence System
      </p>
    </div>
  );
}

function Paragraph26() {
  return (
    <div className="absolute h-[118.984px] left-0 top-[107px] w-[261px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[23.8px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[254px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`Evaluate 10+ manufacturers—domestic & international—on product depth, price competitiveness, certifications, reliability KPIs, and strategic differentiators.`}</p>
    </div>
  );
}

function Text19() {
  return (
    <div className="absolute h-[16px] left-[20px] top-[8px] w-[80.773px]" data-name="Text">
      <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[#9fa8da] text-[12px] top-0 tracking-[0.6px] uppercase w-[81px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Objective 2
      </p>
    </div>
  );
}

function Container52() {
  return (
    <div className="absolute border-[#9fa8da] border-[1.5px] border-solid h-[35px] left-0 overflow-clip rounded-[16777200px] top-0 w-[123.773px]" data-name="Container">
      <Text19 />
    </div>
  );
}

function EngagementObjectives2() {
  return (
    <div className="h-[225.984px] relative shrink-0 w-full" data-name="EngagementObjectives">
      <Heading8 />
      <Paragraph26 />
      <Container52 />
    </div>
  );
}

function EngagementObjectives3() {
  return <div className="bg-gradient-to-b from-[rgba(0,0,0,0)] h-px shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="EngagementObjectives" />;
}

function Container53() {
  return (
    <div className="h-[242.984px] relative shrink-0 w-[261px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start relative size-full">
        <EngagementObjectives2 />
        <EngagementObjectives3 />
      </div>
    </div>
  );
}

function Heading9() {
  return (
    <div className="absolute h-[48px] left-0 top-[47px] w-[261px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['DM_Sans:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#111] text-[17px] top-[-0.5px] w-[211px]" style={{ fontVariationSettings: "'opsz' 14" }}>{`Conduct a Supply Chain & Import Dependency Audit`}</p>
    </div>
  );
}

function Paragraph27() {
  return (
    <div className="absolute h-[95.188px] left-0 top-[107px] w-[261px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[23.8px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[257px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Analyze sourcing flows for key ceramic, condenser, and insulation components; benchmark supplier ecosystems; assess risks and cost levers.
      </p>
    </div>
  );
}

function Text20() {
  return (
    <div className="absolute h-[16px] left-[20px] top-[8px] w-[81.047px]" data-name="Text">
      <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[#5b8dbe] text-[12px] top-0 tracking-[0.6px] uppercase w-[82px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Objective 3
      </p>
    </div>
  );
}

function Container54() {
  return (
    <div className="absolute border-[#5b8dbe] border-[1.5px] border-solid h-[35px] left-0 overflow-clip rounded-[16777200px] top-0 w-[124.047px]" data-name="Container">
      <Text20 />
    </div>
  );
}

function EngagementObjectives4() {
  return (
    <div className="h-[202.188px] relative shrink-0 w-full" data-name="EngagementObjectives">
      <Heading9 />
      <Paragraph27 />
      <Container54 />
    </div>
  );
}

function EngagementObjectives5() {
  return <div className="bg-gradient-to-b from-[rgba(0,0,0,0)] h-px shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="EngagementObjectives" />;
}

function Container55() {
  return (
    <div className="h-[219.188px] relative shrink-0 w-[261px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start relative size-full">
        <EngagementObjectives4 />
        <EngagementObjectives5 />
      </div>
    </div>
  );
}

function Heading10() {
  return (
    <div className="absolute h-[48px] left-0 top-[47px] w-[261px]" data-name="Heading 3">
      <p className="absolute css-4hzbpn font-['DM_Sans:Medium',sans-serif] font-medium leading-[24px] left-0 text-[#111] text-[17px] top-[-0.5px] w-[207px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Deliver an Investor-Ready Strategic Narrative
      </p>
    </div>
  );
}

function Paragraph28() {
  return (
    <div className="absolute h-[118.984px] left-0 top-[107px] w-[261px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[23.8px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[243px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Translate insights into a growth story that strengthens valuation logic and provides a credible roadmap for capacity planning and market penetration.
      </p>
    </div>
  );
}

function Text21() {
  return (
    <div className="absolute h-[16px] left-[20px] top-[8px] w-[81.508px]" data-name="Text">
      <p className="absolute css-4hzbpn font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] left-0 text-[#8b9dc8] text-[12px] top-0 tracking-[0.6px] uppercase w-[82px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Objective 4
      </p>
    </div>
  );
}

function Container56() {
  return (
    <div className="absolute border-[#8b9dc8] border-[1.5px] border-solid h-[35px] left-0 overflow-clip rounded-[16777200px] top-0 w-[124.508px]" data-name="Container">
      <Text21 />
    </div>
  );
}

function Container57() {
  return (
    <div className="h-[225.984px] relative shrink-0 w-[261px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Heading10 />
        <Paragraph28 />
        <Container56 />
      </div>
    </div>
  );
}

function EngagementObjectives6() {
  return (
    <div className="bg-white h-[1290.938px] relative shrink-0 w-full" data-name="EngagementObjectives">
      <div className="content-stretch flex flex-col gap-[48px] items-start pl-[764px] pr-0 py-[96px] relative size-full">
        <Container51 />
        <Container53 />
        <Container55 />
        <Container57 />
      </div>
    </div>
  );
}

function Container58() {
  return <div className="absolute h-[1327.5px] left-0 top-0 w-[1189px]" data-name="Container" style={{ backgroundImage: "linear-gradient(131.85deg, rgb(241, 245, 253) 0%, rgb(255, 255, 255) 20%, rgb(254, 242, 242) 40%, rgb(255, 255, 255) 60%, rgb(223, 234, 250) 80%, rgb(241, 245, 253) 100%)" }} />;
}

function Container59() {
  return <div className="absolute blur-[64px] left-[449px] rounded-[16777200px] size-[700px] top-[80px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 700 700\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -49.497 -49.497 0 350 350)\\\'><stop stop-color=\\\'rgba(78,127,227,0.12)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(158,194,242,0.06)\\\' offset=\\\'0.5\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container60() {
  return <div className="absolute blur-[64px] left-[40px] rounded-[16777200px] size-[700px] top-[587.5px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 700 700\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -49.497 -49.497 0 350 350)\\\'><stop stop-color=\\\'rgba(235,72,78,0.08)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(253,203,205,0.04)\\\' offset=\\\'0.5\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container61() {
  return <div className="absolute blur-[64px] left-[144.5px] rounded-[16777200px] size-[900px] top-[213.75px]" data-name="Container" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\\'0 0 900 900\\\' xmlns=\\\'http://www.w3.org/2000/svg\\\' preserveAspectRatio=\\\'none\\\'><rect x=\\\'0\\\' y=\\\'0\\\' height=\\\'100%\\\' width=\\\'100%\\\' fill=\\\'url(%23grad)\\\' opacity=\\\'1\\\'/><defs><radialGradient id=\\\'grad\\\' gradientUnits=\\\'userSpaceOnUse\\\' cx=\\\'0\\\' cy=\\\'0\\\' r=\\\'10\\\' gradientTransform=\\\'matrix(0 -63.64 -63.64 0 450 450)\\\'><stop stop-color=\\\'rgba(179,205,245,0.08)\\\' offset=\\\'0\\\'/><stop stop-color=\\\'rgba(253,227,228,0.04)\\\' offset=\\\'0.5\\\'/><stop stop-color=\\\'rgba(0,0,0,0)\\\' offset=\\\'1\\\'/></radialGradient></defs></svg>')" }} />;
}

function Container62() {
  return (
    <div className="absolute h-[1327.5px] left-0 overflow-clip top-0 w-[1189px]" data-name="Container">
      <Container59 />
      <Container60 />
      <Container61 />
    </div>
  );
}

function Text22() {
  return (
    <div className="absolute bg-[#1a1a1a] content-stretch flex h-[32px] items-start left-0 px-[16px] py-[8px] rounded-[16777200px] top-0 w-[160.32px]" data-name="Text">
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[12px] text-white tracking-[0.6px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        OUR METHODOLOGY
      </p>
    </div>
  );
}

function Container63() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[32px] left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.4)] w-[160.32px]" data-name="Container" />;
}

function ShimmerTag2() {
  return (
    <div className="absolute h-[32px] left-[104px] overflow-clip top-0 w-[160.32px]" data-name="ShimmerTag">
      <Text22 />
      <Container63 />
    </div>
  );
}

function Heading11() {
  return (
    <div className="absolute h-[40px] left-[104px] top-[46.5px] w-[933px]" data-name="Heading 2">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[40px] left-0 text-[#111] text-[34px] top-[-0.5px] tracking-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>{`Consulting Approach & Initiatives`}</p>
    </div>
  );
}

function Paragraph29() {
  return (
    <div className="absolute h-[48px] left-[104px] top-[90.5px] w-[768px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#111] text-[15px] top-0 w-[727px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        A systematic, multi-faceted approach combining rigorous research with strategic consulting expertise to deliver measurable results
      </p>
    </div>
  );
}

function Container64() {
  return (
    <div className="h-[138.5px] relative shrink-0 w-full" data-name="Container">
      <ShimmerTag2 />
      <Heading11 />
      <Paragraph29 />
    </div>
  );
}

function Container65() {
  return (
    <div className="absolute h-[52px] left-0 top-0 w-[58.141px]" data-name="Container">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[52px] left-0 text-[#4e7fe3] text-[52px] top-[0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        01
      </p>
    </div>
  );
}

function Heading12() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0f172a] text-[17px] top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Function-Level Integration Mapping
      </p>
    </div>
  );
}

function Paragraph30() {
  return (
    <div className="h-[66px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[22px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[681px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`Conducted comprehensive mapping across Finance, HR, Supply Chain, Sales, Quality & Regulatory Affairs. Identified cultural, process, and compliance gaps between entities. Developed harmonization pathways aligned with Dexa's group-level controls and operational standards.`}</p>
    </div>
  );
}

function Container66() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[151px] items-start left-[239.25px] top-0 w-[693.75px]" data-name="Container">
      <Heading12 />
      <Paragraph30 />
    </div>
  );
}

function ConsultingApproach() {
  return (
    <div className="h-[151px] relative shrink-0 w-full" data-name="ConsultingApproach">
      <Container65 />
      <Container66 />
    </div>
  );
}

function Container67() {
  return <div className="bg-gradient-to-r from-[#2b7fff] h-px shrink-0 to-[#155dfc] w-full" data-name="Container" />;
}

function Container68() {
  return (
    <div className="bg-gradient-to-r from-[rgba(0,0,0,0)] h-px relative shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start pl-0 pr-[933px] py-0 relative size-full">
        <Container67 />
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div className="content-stretch flex flex-col gap-[47px] h-[199px] items-start relative shrink-0 w-full" data-name="Container">
      <ConsultingApproach />
      <Container68 />
    </div>
  );
}

function Container70() {
  return (
    <div className="absolute h-[52px] left-0 top-0 w-[58.141px]" data-name="Container">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[52px] left-0 text-[#4e7fe3] text-[52px] top-[0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        02
      </p>
    </div>
  );
}

function Heading13() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0f172a] text-[17px] top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>{`SOP & Risk Practice Benchmarking`}</p>
    </div>
  );
}

function Paragraph31() {
  return (
    <div className="h-[66px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[22px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[670px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`Benchmarked existing SOPs, audit findings, risk controls, and compliance mechanisms of the acquired entity against Dexa's governance standards. Highlighted high-priority remediation areas and designed a unified compliance framework.`}</p>
    </div>
  );
}

function Container71() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[151px] items-start left-[239.25px] top-0 w-[693.75px]" data-name="Container">
      <Heading13 />
      <Paragraph31 />
    </div>
  );
}

function ConsultingApproach1() {
  return (
    <div className="h-[151px] relative shrink-0 w-full" data-name="ConsultingApproach">
      <Container70 />
      <Container71 />
    </div>
  );
}

function Container72() {
  return <div className="bg-gradient-to-r from-[#ad46ff] h-px shrink-0 to-[#9810fa] w-full" data-name="Container" />;
}

function Container73() {
  return (
    <div className="bg-gradient-to-r from-[rgba(0,0,0,0)] h-px relative shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start pl-0 pr-[933px] py-0 relative size-full">
        <Container72 />
      </div>
    </div>
  );
}

function Container74() {
  return (
    <div className="content-stretch flex flex-col gap-[47px] h-[199px] items-start relative shrink-0 w-full" data-name="Container">
      <ConsultingApproach1 />
      <Container73 />
    </div>
  );
}

function Container75() {
  return (
    <div className="absolute h-[52px] left-0 top-0 w-[58.141px]" data-name="Container">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[52px] left-0 text-[#4e7fe3] text-[52px] top-[0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        03
      </p>
    </div>
  );
}

function Heading14() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#0f172a] text-[17px] top-[-0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        SEBI Compliance Support
      </p>
    </div>
  );
}

function Paragraph32() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[22px] left-0 text-[#111] text-[14px] top-[-0.5px] w-[689px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Developed a comprehensive IPO-readiness report aligned with SEBI disclosure requirements. Built investor inputs across market potential, business strengths, risk factors, and long-term opportunity mapping.
      </p>
    </div>
  );
}

function Container76() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[129px] items-start left-[239.25px] top-0 w-[693.75px]" data-name="Container">
      <Heading14 />
      <Paragraph32 />
    </div>
  );
}

function ConsultingApproach2() {
  return (
    <div className="h-[129px] relative shrink-0 w-full" data-name="ConsultingApproach">
      <Container75 />
      <Container76 />
    </div>
  );
}

function Container77() {
  return <div className="bg-gradient-to-r from-[#fe9a00] h-px shrink-0 to-[#e17100] w-full" data-name="Container" />;
}

function Container78() {
  return (
    <div className="bg-gradient-to-r from-[rgba(0,0,0,0)] h-px relative shrink-0 to-[rgba(0,0,0,0)] via-1/2 via-[#e5e7eb] w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start pl-0 pr-[933px] py-0 relative size-full">
        <Container77 />
      </div>
    </div>
  );
}

function Container79() {
  return (
    <div className="content-stretch flex flex-col gap-[47px] h-[177px] items-start relative shrink-0 w-full" data-name="Container">
      <ConsultingApproach2 />
      <Container78 />
    </div>
  );
}

function Container80() {
  return (
    <div className="content-stretch flex flex-col gap-[48px] h-[671px] items-start relative shrink-0 w-full" data-name="Container">
      <Container69 />
      <Container74 />
      <Container79 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[672px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#101828] text-[16px] top-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Ready to Transform Your Business Strategy?
        </p>
      </div>
    </div>
  );
}

function Paragraph33() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-[672px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#111] text-[14px] top-0 w-[671px]" style={{ fontVariationSettings: "'opsz' 9" }}>
          Our proven consulting methodologies have helped leading companies achieve their strategic objectives and market leadership.
        </p>
      </div>
    </div>
  );
}

function Container81() {
  return (
    <div className="h-[70px] relative shrink-0 w-[672px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Heading2 />
        <Paragraph33 />
      </div>
    </div>
  );
}

function ConsultingApproach3() {
  return (
    <div className="flex-[1_0_0] h-[21px] min-h-px min-w-px relative" data-name="ConsultingApproach">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[21px] left-[68.5px] text-[14px] text-center text-white top-0 translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Explore Our Services
        </p>
      </div>
    </div>
  );
}

function IconBase4() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="IconBase">
          <path d={svgPaths.p124bf100} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#b01f24] h-[45px] relative rounded-[10px] shadow-[0px_4px_6px_-1px_rgba(0,0,0,0.1),0px_2px_4px_-2px_rgba(0,0,0,0.1)] shrink-0 w-[208.859px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[24px] py-0 relative size-full">
        <ConsultingApproach3 />
        <IconBase4 />
      </div>
    </div>
  );
}

function Container82() {
  return (
    <div className="content-stretch flex h-[70px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container81 />
      <Button />
    </div>
  );
}

function Container83() {
  return (
    <div className="h-[853px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col gap-[112px] items-start px-[104px] py-0 relative size-full">
        <Container80 />
        <Container82 />
      </div>
    </div>
  );
}

function Container84() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[80px] h-[1071.5px] items-start left-[24px] top-[128px] w-[1141px]" data-name="Container">
      <Container64 />
      <Container83 />
    </div>
  );
}

function ConsultingApproach4() {
  return (
    <div className="h-[1327.5px] overflow-clip relative shrink-0 w-full" data-name="ConsultingApproach">
      <Container58 />
      <Container62 />
      <Container84 />
    </div>
  );
}

function Container85() {
  return <div className="absolute blur-[64px] left-[297.25px] rounded-[16777200px] size-[600px] top-0" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(190, 219, 255, 0.2) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container86() {
  return <div className="absolute blur-[64px] left-[291.75px] rounded-[16777200px] size-[600px] top-[-20.5px]" data-name="Container" style={{ backgroundImage: "linear-gradient(-45deg, rgba(233, 212, 255, 0.2) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container87() {
  return (
    <div className="absolute h-[579.5px] left-0 overflow-clip top-0 w-[1189px]" data-name="Container">
      <Container85 />
      <Container86 />
    </div>
  );
}

function Text23() {
  return (
    <div className="absolute bg-[#1a1a1a] content-stretch flex h-[32px] items-start left-0 px-[16px] py-[8px] rounded-[16777200px] top-0 w-[255.273px]" data-name="Text">
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[12px] text-white tracking-[0.6px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Measurable Business Outcomes
      </p>
    </div>
  );
}

function Container88() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[32px] left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.4)] w-[255.273px]" data-name="Container" />;
}

function ShimmerTag3() {
  return (
    <div className="absolute h-[32px] left-0 overflow-clip top-0 w-[255.273px]" data-name="ShimmerTag">
      <Text23 />
      <Container88 />
    </div>
  );
}

function Heading15() {
  return (
    <div className="absolute h-[40px] left-0 top-[46.5px] w-[933px]" data-name="Heading 2">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[40px] left-0 text-[#0f172a] text-[34px] top-[-0.5px] tracking-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        Impact Delivered
      </p>
    </div>
  );
}

function Container89() {
  return (
    <div className="h-[86.5px] relative shrink-0 w-full" data-name="Container">
      <ShimmerTag3 />
      <Heading15 />
    </div>
  );
}

function IconBase5() {
  return (
    <div className="h-[32px] overflow-clip relative shrink-0 w-full" data-name="IconBase">
      <div className="absolute bottom-[18.75%] left-[28.13%] right-1/4 top-[18.75%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 20">
          <path d={svgPaths.p366c1b00} fill="var(--fill-0, #0A0A0A)" id="Vector" opacity="0.2" />
        </svg>
      </div>
      <div className="absolute inset-[6.25%_21.88%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 28">
          <path d={svgPaths.p116b43a0} fill="var(--fill-0, #0A0A0A)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Container90() {
  return (
    <div className="absolute content-stretch flex flex-col h-[32px] items-start left-[25px] pl-0 pr-[133.25px] py-0 top-[25px] w-[165.25px]" data-name="Container">
      <IconBase5 />
    </div>
  );
}

function AnimatedCounter() {
  return (
    <div className="absolute h-[99.5px] left-[25px] top-[65px] w-[92.367px]" data-name="AnimatedCounter">
      <p className="absolute css-4hzbpn font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[42px] left-0 text-[#68a828] text-[42px] top-[8px] tracking-[-0.5px] w-[93px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        ₹110 Cr+
      </p>
    </div>
  );
}

function ResultsAndImpact() {
  return (
    <div className="absolute h-[63px] left-[25px] top-[165px] w-[165.25px]" data-name="ResultsAndImpact">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#666] text-[14px] top-0 w-[130px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Market Potential Unlocked (Validated TAM-SAM-SOM)
      </p>
    </div>
  );
}

function Container91() {
  return (
    <div className="bg-white col-[1] css-3foyfs relative rounded-[16px] row-[1] self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#f3f4f6] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.04),0px_1px_3px_0px_rgba(0,0,0,0.02)]" />
      <Container90 />
      <AnimatedCounter />
      <ResultsAndImpact />
    </div>
  );
}

function IconBase6() {
  return (
    <div className="h-[32px] overflow-clip relative shrink-0 w-full" data-name="IconBase">
      <div className="absolute inset-[15.63%_18.75%_18.75%_59.38%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 21">
          <path d="M7 0V21H0V0H7Z" fill="var(--fill-0, #0A0A0A)" id="Vector" opacity="0.2" />
        </svg>
      </div>
      <div className="absolute inset-[12.5%_9.38%_15.63%_9.38%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 23">
          <path d={svgPaths.p2b6de300} fill="var(--fill-0, #0A0A0A)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Container92() {
  return (
    <div className="absolute content-stretch flex flex-col h-[32px] items-start left-[25px] pl-0 pr-[133.25px] py-0 top-[25px] w-[165.25px]" data-name="Container">
      <IconBase6 />
    </div>
  );
}

function AnimatedCounter1() {
  return (
    <div className="absolute content-stretch flex h-[57.5px] items-start left-[25px] top-[65px] w-[69.391px]" data-name="AnimatedCounter">
      <p className="css-ew64yg font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[42px] relative shrink-0 text-[#68a828] text-[42px] tracking-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        10+
      </p>
    </div>
  );
}

function ResultsAndImpact1() {
  return (
    <div className="absolute h-[63px] left-[25px] top-[123px] w-[165.25px]" data-name="ResultsAndImpact">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#666] text-[14px] top-0 w-[146px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Competitors Decoded with Intelligence Framework
      </p>
    </div>
  );
}

function Container93() {
  return (
    <div className="bg-white col-[2] css-3foyfs relative rounded-[16px] row-[1] self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#f3f4f6] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.04),0px_1px_3px_0px_rgba(0,0,0,0.02)]" />
      <Container92 />
      <AnimatedCounter1 />
      <ResultsAndImpact1 />
    </div>
  );
}

function IconBase7() {
  return (
    <div className="h-[32px] overflow-clip relative shrink-0 w-full" data-name="IconBase">
      <div className="absolute bottom-1/4 left-[12.5%] right-1/4 top-[12.5%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
          <path d={svgPaths.p2fbcbc80} fill="var(--fill-0, #0A0A0A)" id="Vector" opacity="0.2" />
        </svg>
      </div>
      <div className="absolute inset-[9.21%_9.37%_9.37%_9.23%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26.0455 26.053">
          <path d={svgPaths.paf1e000} fill="var(--fill-0, #0A0A0A)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Container94() {
  return (
    <div className="absolute content-stretch flex flex-col h-[32px] items-start left-[25px] pl-0 pr-[133.25px] py-0 top-[25px] w-[165.25px]" data-name="Container">
      <IconBase7 />
    </div>
  );
}

function AnimatedCounter2() {
  return (
    <div className="absolute content-stretch flex h-[57.5px] items-start left-[25px] top-[65px] w-[83.648px]" data-name="AnimatedCounter">
      <p className="css-ew64yg font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[42px] relative shrink-0 text-[#68a828] text-[42px] tracking-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        25%
      </p>
    </div>
  );
}

function ResultsAndImpact2() {
  return (
    <div className="absolute h-[42px] left-[25px] top-[123px] w-[165.25px]" data-name="ResultsAndImpact">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#666] text-[14px] top-0 w-[150px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Improvement in Supply Chain Visibility
      </p>
    </div>
  );
}

function Container95() {
  return (
    <div className="bg-white col-[3] css-3foyfs relative rounded-[16px] row-[1] self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#f3f4f6] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.04),0px_1px_3px_0px_rgba(0,0,0,0.02)]" />
      <Container94 />
      <AnimatedCounter2 />
      <ResultsAndImpact2 />
    </div>
  );
}

function IconBase8() {
  return (
    <div className="h-[32px] overflow-clip relative shrink-0 w-full" data-name="IconBase">
      <div className="absolute inset-[21.88%_9.38%_53.13%_65.63%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d="M8 0V8L0 0H8Z" fill="var(--fill-0, #0A0A0A)" id="Vector" opacity="0.2" />
        </svg>
      </div>
      <div className="absolute bottom-1/4 left-[6.25%] right-[6.25%] top-[18.75%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.0006 18.0006">
          <path d={svgPaths.p31730400} fill="var(--fill-0, #0A0A0A)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Container96() {
  return (
    <div className="absolute content-stretch flex flex-col h-[32px] items-start left-[25px] pl-0 pr-[133.25px] py-0 top-[25px] w-[165.25px]" data-name="Container">
      <IconBase8 />
    </div>
  );
}

function AnimatedCounter3() {
  return (
    <div className="absolute h-[99.5px] left-[25px] top-[65px] w-[125.344px]" data-name="AnimatedCounter">
      <p className="absolute css-4hzbpn font-['Noto_Serif:SemiBold',sans-serif] font-semibold leading-[42px] left-0 text-[#68a828] text-[42px] top-[8px] tracking-[-0.5px] w-[126px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        IPO Ready
      </p>
    </div>
  );
}

function ResultsAndImpact3() {
  return (
    <div className="absolute h-[42px] left-[25px] top-[165px] w-[165.25px]" data-name="ResultsAndImpact">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[21px] left-0 text-[#666] text-[14px] top-0 w-[144px]" style={{ fontVariationSettings: "'opsz' 9" }}>{`Strengthened Investor Narrative & Valuation`}</p>
    </div>
  );
}

function Container97() {
  return (
    <div className="bg-white col-[4] css-3foyfs relative rounded-[16px] row-[1] self-stretch shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#f3f4f6] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.04),0px_1px_3px_0px_rgba(0,0,0,0.02)]" />
      <Container96 />
      <AnimatedCounter3 />
      <ResultsAndImpact3 />
    </div>
  );
}

function Container98() {
  return (
    <div className="gap-[24px] grid grid-cols-[repeat(4,_minmax(0,_1fr))] grid-rows-[repeat(1,_minmax(0,_1fr))] h-[253px] relative shrink-0 w-full" data-name="Container">
      <Container91 />
      <Container93 />
      <Container95 />
      <Container97 />
    </div>
  );
}

function Container99() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[48px] h-[387.5px] items-start left-[128px] top-[96px] w-[933px]" data-name="Container">
      <Container89 />
      <Container98 />
    </div>
  );
}

function ResultsAndImpact4() {
  return (
    <div className="bg-white h-[579.5px] overflow-clip relative shrink-0 w-full" data-name="ResultsAndImpact">
      <Container87 />
      <Container99 />
    </div>
  );
}

function Container100() {
  return <div className="blur-[64px] h-[800px] rounded-[16777200px] shrink-0 w-full" data-name="Container" style={{ backgroundImage: "linear-gradient(135deg, rgba(254, 243, 198, 0.1) 0%, rgba(0, 0, 0, 0) 100%)" }} />;
}

function Container101() {
  return (
    <div className="absolute content-stretch flex flex-col h-[546px] items-start left-0 overflow-clip pb-0 pt-[-127px] px-[194.5px] top-0 w-[1189px]" data-name="Container">
      <Container100 />
    </div>
  );
}

function Heading16() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[18px] left-0 text-[#999] text-[12px] top-0 tracking-[1.5px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Client Endorsement
      </p>
    </div>
  );
}

function TypewriterText() {
  return (
    <div className="h-[160.5px] relative shrink-0 w-full" data-name="TypewriterText">
      <p className="absolute css-4hzbpn font-['Noto_Serif:Display_Medium',sans-serif] font-medium leading-[32px] left-0 text-[#101828] text-[24px] top-px tracking-[-0.5px] w-[611px]" style={{ fontVariationSettings: "'CTGR' 100, 'wdth' 100" }}>
        Ken Research helped us quantify our addressable opportunity, build a sharper product strategy, and clearly articulate our competitive strengths. Their analysis played a key role in our next-stage discussions with investors.
      </p>
    </div>
  );
}

function Quote() {
  return (
    <div className="h-[160px] relative shrink-0 w-full" data-name="Quote">
      <div className="content-stretch flex flex-col items-start pb-0 pl-0 pr-[11.563px] pt-[-0.5px] relative size-full">
        <TypewriterText />
      </div>
    </div>
  );
}

function ClientEndorsement() {
  return (
    <div className="flex-[1_0_0] h-[202px] min-h-px min-w-px relative" data-name="ClientEndorsement">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start relative size-full">
        <Heading16 />
        <Quote />
      </div>
    </div>
  );
}

function IconBase9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="IconBase">
          <path d={svgPaths.p349ca00} fill="var(--fill-0, #FFB900)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function IconBase10() {
  return (
    <div className="flex-[1_0_0] h-[16px] min-h-px min-w-px relative" data-name="IconBase">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute inset-[6.25%_6.28%_9.38%_6.27%]" data-name="Vector">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9919 13.4978">
            <path d={svgPaths.p1578f000} fill="var(--fill-0, #FFB900)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function ClientEndorsement1() {
  return (
    <div className="flex-[1_0_0] h-[16px] min-h-px min-w-px relative" data-name="ClientEndorsement">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-start relative size-full">
        {[...Array(4).keys()].map((_, i) => (
          <IconBase9 key={i} />
        ))}
        <IconBase10 />
      </div>
    </div>
  );
}

function ClientEndorsement2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[46.742px]" data-name="ClientEndorsement">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[24px] left-0 text-[#101828] text-[16px] top-[0.5px]" style={{ fontVariationSettings: "'opsz' 14" }}>
          4.97/5
        </p>
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="h-[24px] relative shrink-0 w-[150.742px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <ClientEndorsement1 />
        <ClientEndorsement2 />
      </div>
    </div>
  );
}

function Container103() {
  return (
    <div className="content-stretch flex h-[202px] items-start justify-between relative shrink-0 w-full" data-name="Container">
      <ClientEndorsement />
      <Container102 />
    </div>
  );
}

function Paragraph34() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#666] text-[15px] top-0" style={{ fontVariationSettings: "'opsz' 9" }}>
        — Director, Yash Highvoltage Insulators
      </p>
    </div>
  );
}

function Container104() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[32px] h-[354px] items-start left-[128px] pb-0 pt-[48px] px-[56px] rounded-[24px] shadow-[0px_4px_20px_0px_rgba(0,0,0,0.08),0px_1px_3px_0px_rgba(0,0,0,0.06)] top-[96px] w-[933px]" data-name="Container">
      <Container103 />
      <Paragraph34 />
    </div>
  );
}

function ClientEndorsement3() {
  return (
    <div className="bg-white h-[546px] overflow-clip relative shrink-0 w-full" data-name="ClientEndorsement">
      <Container101 />
      <Container104 />
    </div>
  );
}

function Container105() {
  return <div className="absolute bg-[rgba(254,154,0,0.1)] blur-[64px] left-[297.1px] opacity-10 rounded-[16777200px] size-[500.291px] top-[-0.15px]" data-name="Container" />;
}

function Container106() {
  return <div className="absolute bg-[rgba(43,127,255,0.1)] blur-[64px] left-[311.36px] opacity-13 rounded-[16777200px] size-[660.785px] top-[-188px]" data-name="Container" />;
}

function Container107() {
  return (
    <div className="absolute h-[392.391px] left-0 overflow-clip top-0 w-[1189px]" data-name="Container">
      <Container105 />
      <Container106 />
    </div>
  );
}

function Text24() {
  return (
    <div className="absolute bg-gradient-to-r content-stretch flex from-[rgba(43,127,255,0.15)] h-[37.5px] items-start left-[294.32px] px-[21px] py-[11px] rounded-[16777200px] to-[rgba(21,93,252,0.15)] top-[-5.5px] w-[307.352px]" data-name="Text">
      <div aria-hidden="true" className="absolute border border-[rgba(81,162,255,0.3)] border-solid inset-0 pointer-events-none rounded-[16777200px]" />
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[18px] relative shrink-0 text-[#9fc4e7] text-[12px] text-center tracking-[1px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Ready to Transform Your Business?
      </p>
    </div>
  );
}

function Heading17() {
  return (
    <div className="absolute h-[119.594px] left-0 top-[56px] w-[896px]" data-name="Heading 2">
      <p className="absolute css-4hzbpn font-['Noto_Serif:Display_Light',sans-serif] font-light leading-[59.8px] left-[448.3px] text-[52px] text-center text-white top-[0.5px] tracking-[-0.5px] translate-x-[-50%] w-[871px]" style={{ fontVariationSettings: "'CTGR' 100, 'wdth' 100" }}>
        Ready to Unlock Strategic Insights for Your Business?
      </p>
    </div>
  );
}

function Paragraph35() {
  return (
    <div className="absolute h-[64.797px] left-[64px] top-[183.59px] w-[768px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[32.4px] left-[384.06px] text-[#efefef] text-[18px] text-center top-0 translate-x-[-50%] w-[754px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Partner with Ken Research to gain comprehensive market intelligence, competitive insights, and strategic positioning guidance tailored to your business objectives.
      </p>
    </div>
  );
}

function PrimaryButton() {
  return (
    <div className="h-[24px] relative shrink-0 w-[176.828px]" data-name="PrimaryButton">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[24px] left-[88.5px] text-[16px] text-center text-white top-[0.5px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Get Customized Report
        </p>
      </div>
    </div>
  );
}

function IconBase11() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="IconBase">
      <div className="absolute inset-[20.31%_20.31%_20.31%_20.3%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.8774 11.8758">
          <path d={svgPaths.p2a1a1b20} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Container108() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <IconBase11 />
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#b01f24] h-[56px] relative rounded-[5px] shadow-[0px_4px_12px_0px_rgba(176,31,36,0.25)] shrink-0 w-[268.828px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10.532px] items-center justify-center pl-[2.532px] pr-0 py-0 relative size-full">
        <PrimaryButton />
        <Container108 />
      </div>
    </div>
  );
}

function SecondaryButton() {
  return (
    <div className="h-[22px] relative shrink-0 w-[148.234px]" data-name="SecondaryButton">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['DM_Sans:Medium',sans-serif] font-medium leading-[22px] left-[74.5px] text-[#b01f24] text-[16px] text-center top-[0.5px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Book Discovery Call
        </p>
      </div>
    </div>
  );
}

function IconBase12() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="IconBase">
          <path d={svgPaths.p1739080} fill="var(--fill-0, #B01F24)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-white h-[54px] relative rounded-[5px] shrink-0 w-[240.234px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-2 border-[#961e22] border-solid inset-0 pointer-events-none rounded-[5px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center p-[2px] relative size-full">
        <SecondaryButton />
        <IconBase12 />
      </div>
    </div>
  );
}

function Container109() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[56px] items-center justify-center left-0 top-[264.39px] w-[896px]" data-name="Container">
      <Button1 />
      <Button2 />
    </div>
  );
}

function Container110() {
  return (
    <div className="absolute h-[320.391px] left-[146.5px] top-[36px] w-[896px]" data-name="Container">
      <Text24 />
      <Heading17 />
      <Paragraph35 />
      <Container109 />
    </div>
  );
}

function CtaSection() {
  return (
    <div className="bg-gradient-to-b from-[#0f172a] h-[392.391px] overflow-clip relative shrink-0 to-[#0f172a] via-1/2 via-[#1e293b] w-full" data-name="CTASection">
      <Container107 />
      <Container110 />
    </div>
  );
}

function App() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[6503.328px] items-start left-0 pb-0 pt-[61px] px-0 top-0 w-[1189px]" data-name="App">
      <Hero8 />
      <ClientContext1 />
      <ProblemStatements4 />
      <EngagementObjectives6 />
      <ConsultingApproach4 />
      <ResultsAndImpact4 />
      <ClientEndorsement3 />
      <CtaSection />
    </div>
  );
}

function Text25() {
  return (
    <div className="absolute bg-[#1a1a1a] content-stretch flex h-[32px] items-start left-0 px-[16px] py-[8px] rounded-[16777200px] top-0 w-[217.633px]" data-name="Text">
      <p className="css-ew64yg font-['DM_Sans:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[12px] text-white tracking-[0.6px] uppercase" style={{ fontVariationSettings: "'opsz' 14" }}>
        Engagement Value Pillars
      </p>
    </div>
  );
}

function Container111() {
  return <div className="absolute bg-gradient-to-r from-[rgba(0,0,0,0)] h-[32px] left-0 to-[rgba(0,0,0,0)] top-0 via-1/2 via-[rgba(255,255,255,0.4)] w-[217.633px]" data-name="Container" />;
}

function ShimmerTag4() {
  return (
    <div className="absolute h-[32px] left-0 overflow-clip top-0 w-[217.633px]" data-name="ShimmerTag">
      <Text25 />
      <Container111 />
    </div>
  );
}

function Heading18() {
  return (
    <div className="absolute h-[40px] left-0 top-[50.5px] w-[450px]" data-name="Heading 2">
      <p className="absolute css-ew64yg font-['Noto_Serif:Regular',sans-serif] font-normal leading-[40px] left-0 text-[#111] text-[34px] top-[-0.5px]" style={{ fontVariationSettings: "'CTGR' 0, 'wdth' 100" }}>
        Engagement Objectives
      </p>
    </div>
  );
}

function Paragraph36() {
  return (
    <div className="absolute h-[48px] left-0 top-[94.5px] w-[450px]" data-name="Paragraph">
      <p className="absolute css-4hzbpn font-['DM_Sans:9pt_Regular',sans-serif] font-normal leading-[24px] left-0 text-[#111] text-[15px] top-0 w-[435px]" style={{ fontVariationSettings: "'opsz' 9" }}>
        Strategic consulting objectives designed to provide actionable insights and sustainable competitive advantages
      </p>
    </div>
  );
}

function EngagementObjectives7() {
  return (
    <div className="absolute h-[142.5px] left-[164px] top-[2463px] w-[450px]" data-name="EngagementObjectives">
      <ShimmerTag4 />
      <Heading18 />
      <Paragraph36 />
    </div>
  );
}

function ImageKenResearch() {
  return (
    <div className="h-[18.273px] relative shrink-0 w-full" data-name="Image (Ken Research)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageKenResearch} />
    </div>
  );
}

function Container112() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip relative shrink-0 w-[189.336px]" data-name="Container">
      <ImageKenResearch />
    </div>
  );
}

function IconBase13() {
  return (
    <div className="relative shrink-0 size-[14.672px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.6719 14.6719">
        <g id="IconBase">
          <path d={svgPaths.p3aad3d80} fill="var(--fill-0, #E8EAED)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0" data-name="Button">
      <p className="css-ew64yg font-['Manrope:Regular',sans-serif] font-normal leading-[21px] relative shrink-0 text-[14px] text-center text-white tracking-[0.62px]">Report store</p>
      <IconBase13 />
    </div>
  );
}

function IconBase14() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="IconBase">
          <path d={svgPaths.pc5e4080} fill="var(--fill-0, #E8EAED)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0" data-name="Button">
      <p className="css-ew64yg font-['Manrope:Regular',sans-serif] font-normal leading-[21px] relative shrink-0 text-[14px] text-center text-white tracking-[0.62px]">Insights</p>
      <IconBase14 />
    </div>
  );
}

function Button5() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Button">
      <p className="css-ew64yg font-['Manrope:Regular',sans-serif] font-normal leading-[21px] relative shrink-0 text-[14px] text-center text-white tracking-[0.62px]">Market Survey</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[14px] items-center relative">
        <Button3 />
        <Button4 />
        <Button5 />
      </div>
    </div>
  );
}

function Container113() {
  return (
    <div className="content-stretch flex h-[62px] items-center relative shrink-0" data-name="Container">
      <Frame />
    </div>
  );
}

function Container114() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[40px] items-center pl-0 pr-[12px] py-0 relative">
        <Container112 />
        <Container113 />
      </div>
    </div>
  );
}

function IconBase15() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="IconBase">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="IconBase">
          <path d={svgPaths.pc71b800} fill="var(--fill-0, #FA2D34)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function TextInput() {
  return (
    <div className="flex-[1_0_0] h-[21px] min-h-px min-w-px relative" data-name="Text Input">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center overflow-clip relative rounded-[inherit] size-full">
        <p className="css-ew64yg font-['Lato:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[14px] text-white tracking-[0.62px]">Search here</p>
      </div>
    </div>
  );
}

function Container115() {
  return (
    <div className="bg-[rgba(255,255,255,0.1)] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[4px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center px-[17px] py-px relative size-full">
          <IconBase15 />
          <TextInput />
        </div>
      </div>
    </div>
  );
}

function Container116() {
  return <div className="bg-[rgba(255,255,255,0.2)] h-[30px] rounded-[16777200px] shrink-0 w-[0.805px]" data-name="Container" />;
}

function Navigation() {
  return (
    <div className="relative shrink-0" data-name="Navigation">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-px py-0 relative">
        <p className="css-4hzbpn font-['Manrope:SemiBold',sans-serif] font-semibold leading-[21px] relative shrink-0 text-[14px] text-center text-white tracking-[0.62px] w-[141px]">Book discovery call</p>
      </div>
    </div>
  );
}

function Navigation1() {
  return (
    <div className="relative shrink-0 size-[15.977px]" data-name="Navigation">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9766 15.9766">
        <g id="Navigation">
          <path d={svgPaths.p2fec0800} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-[#b01f24] h-[46px] relative rounded-[4px] shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] h-full items-center justify-center px-[24px] py-0 relative">
        <Navigation />
        <Navigation1 />
      </div>
    </div>
  );
}

function Container117() {
  return (
    <div className="flex-[1_0_0] h-[66px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center justify-end relative size-full">
        <Container115 />
        <Container116 />
        <Button6 />
      </div>
    </div>
  );
}

function Container118() {
  return (
    <div className="content-stretch flex h-[60px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container114 />
      <Container117 />
    </div>
  );
}

function Navigation2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.7)] content-stretch flex flex-col h-[61px] items-start left-0 pb-px pt-0 px-[24px] top-0 w-[1189px]" data-name="Navigation">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.1)] border-b border-solid inset-0 pointer-events-none" />
      <Container118 />
    </div>
  );
}

export default function InteractiveCaseStudyPage() {
  return (
    <div className="bg-white relative size-full" data-name="Interactive Case Study Page">
      <App />
      <EngagementObjectives7 />
      <Navigation2 />
    </div>
  );
}