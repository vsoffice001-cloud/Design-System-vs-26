export default {
p1d405500: "M8 3.33333L12.6667 8L8 12.6667",
}
