# ✅ FONT SIZE DECISIONS - EXECUTIVE SUMMARY

## 🎯 **TL;DR**

**Most "hardcoded" font sizes are intentional design decisions, not mistakes.**

They exist because:
1. **Spatial constraints** - Sidebar layouts need smaller text
2. **Real content wrapping** - Metrics like "₹110 Cr" need precise max sizes
3. **Visual hierarchy** - Need in-between sizes (13px, 14px, 17px) not in scale
4. **Client requirements** - Navbar must match Figma pixel-perfect
5. **Responsive precision** - Need specific min/max ranges (19-24px)

---

## 📊 **CURRENT STATE**

| Component | Variables | Hardcoded | Reason |
|-----------|-----------|-----------|--------|
| Hero | 100% ✅ | 0% | Perfect |
| Engagement Objectives | 100% ✅ | 0% | Perfect |
| Methodology | 100% ✅ | 0% | Perfect |
| **Client Context** | 40% | **60%** | **Intentional - spatial constraints** |
| Impact | 90% | 10% | 1px difference (wrapping prevention) |
| Challenges | 85% | 15% | Dynamic sizing based on card count |
| Navbar | 0% | 100% | **Intentional - Figma precision** |

---

## 🔍 **ISSUES FOUND (WITH REASONS)**

### **1. Client Context - Many Hardcoded Sizes** ⚠️

**What we see:**
```tsx
fontSize: '9.5px'   // Labels
fontSize: '17px'    // Company name
fontSize: '13px'    // Industry text
fontSize: 'clamp(19px, 2.8vw, 24px)'  // Overview
```

**Why it's this way:**
- **9.5px:** Sidebar only 33% wide - 12.8px labels too large
- **17px:** Long company name needs to fit single line
- **13px:** Creates hierarchy (label < industry < name)
- **19-24px:** Responsive lead paragraph between body (16px) and heading (25px)

**Verdict:** ✅ **KEEP AS IS** - Intentional optical tuning for narrow sidebar

---

### **2. Impact Metrics - 40px Instead of 39px** ⚠️

**What we see:**
```tsx
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 28px → 40px
// Design system: var(--text-2xl) = 39px
```

**Why it's this way:**
- Testing showed "₹110 Cr" wraps at 39px in 4-column cards
- 40px (round number) prevents edge-case wrapping
- 1px difference matters for real content

**Verdict:** ⚠️ **TEST BOTH** - Could use `var(--text-2xl)` if wrapping is OK

---

### **3. Challenges Questions - 14px for Compact** ⚠️

**What we see:**
```tsx
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'
//         14px compact        16px spacious
```

**Why it's this way:**
- Content-aware typography
- 4+ cards = tight space, use 14px
- 2-3 cards = spacious, use 16px
- Dynamic behavior based on content amount

**Verdict:** ✅ **KEEP AS IS** - Smart responsive behavior

---

### **4. Navbar - All Hardcoded (12px, 14px, 11px)** ✅

**What we see:**
```tsx
text-[12px]  // Secondary nav
text-[14px]  // Main nav
text-[11px]  // Mobile labels
```

**Why it's this way:**
- **Client requirement:** Match Figma pixel-perfect
- Uses sub-pixel positioning (49.71px, 47.84px)
- Brand consistency requirement

**Verdict:** ✅ **KEEP AS IS** - Intentionally outside design system

---

### **5. Missing --text-4xl Variable** ❌ **BUG**

**What we see:**
```tsx
// ChallengesSection.tsx references:
fontSize: cardCount >= 4 ? 'var(--text-3xl)' : 'var(--text-4xl)'
//                                              ^^^^^^^^^^^^^^
//                                              NOT DEFINED!
```

**Why this is an issue:**
- Variable doesn't exist in theme.css
- Falls back to browser default
- Inconsistent rendering

**Verdict:** ❌ **FIX THIS** - Add missing variable to design system

---

---

## 💡 **WHAT TO FIX**

### **HIGH PRIORITY - Actual Bugs** 🚨

1. **Add missing --text-4xl to theme.css**
   ```css
   --text-4xl: 3.815rem;   /* 61px - Extra large headings */
   ```
   **Impact:** Currently broken reference

---

### **MEDIUM PRIORITY - Could Standardize** ⚠️

2. **Impact metrics - Test design system value**
   ```tsx
   // BEFORE:
   fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 40px
   
   // AFTER:
   fontSize: 'clamp(var(--text-lg), 5vw, var(--text-2xl))'  // 39px
   ```
   **Impact:** 1px smaller, test if wrapping occurs

3. **Add --text-2xs for consistency** (optional)
   ```css
   --text-2xs: 0.75rem;    /* 12px - Micro labels */
   ```
   **Impact:** Could replace some 12px navbar values

---

### **LOW PRIORITY - Keep As Is** ✅

4. **Client Context micro-sizes** (9.5px, 13px, 17px)
   - Intentional optical tuning
   - Sidebar spatial constraints
   - **DO NOT CHANGE**

5. **Navbar hardcoded values** (11px, 12px, 14px)
   - Client requirement for Figma precision
   - **DO NOT CHANGE**

6. **Company overview clamp** (19-24px)
   - Responsive range is intentional
   - **DO NOT CHANGE**

7. **Challenges dynamic sizing** (14px/16px)
   - Content-aware behavior
   - **DO NOT CHANGE**

---

---

## 🎯 **FINAL RECOMMENDATION**

### **✅ DO FIX (Required):**

1. **Add missing --text-4xl to theme.css**
   ```css
   --text-4xl: 3.815rem;   /* 61px */
   ```

---

### **⚠️ CONSIDER TESTING:**

2. **Impact metrics - Use design system variable**
   - Change from 40px to 39px
   - Test if "₹110 Cr" still wraps
   - If wraps, keep current value

---

### **❌ DO NOT CHANGE:**

3. Client Context sidebar sizes (9.5px, 13px, 17px)
4. Navbar pixel values (11px, 12px, 14px)
5. Company overview clamp (19-24px)
6. Challenges dynamic questions (14px/16px)

**Reason:** These are intentional design decisions with documented rationale.

---

---

## 📝 **NEXT STEPS**

### **Option 1: Minimal Fix** (5 minutes)
- Add `--text-4xl` to theme.css
- Done!

### **Option 2: Test & Refine** (30 minutes)
- Add `--text-4xl`
- Change Impact metrics to `var(--text-2xl)`
- Test for wrapping issues
- Rollback if problems occur

### **Option 3: Full Documentation** (1 hour)
- Add `--text-4xl`
- Add code comments explaining rationale
- Update design system documentation
- Create "font size decision guide" for future developers

---

## 💬 **YOUR CALL**

**Which approach do you want?**

1. **Just fix the bug** (--text-4xl) ← Quick win
2. **Fix + test Impact metrics** ← Optimize further
3. **Fix + full documentation** ← Best for long-term

Let me know! 🎯
