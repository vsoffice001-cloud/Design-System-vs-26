# Case Study Design System Documentation
**Version 1.0** | Premium Editorial Aesthetic

---

## Table of Contents
1. [Overview](#overview)
2. [Color System](#color-system)
3. [Typography](#typography)
4. [Spacing System](#spacing-system)
5. [Border Radius System](#border-radius-system)
6. [Layout System](#layout-system)
7. [Component Library](#component-library)
8. [Interaction Patterns](#interaction-patterns)
9. [Responsive Design](#responsive-design)
10. [Code Structure](#code-structure)

---

## Overview

This design system powers a premium case study web page with a minimalist editorial aesthetic. It features black/white alternating sections, massive typography, generous whitespace, and sophisticated micro-interactions.

### Design Principles
- **Minimalist Editorial**: Clean, content-focused layouts with ample breathing room
- **Hierarchy Through Scale**: Major Third typography scale (1.25 ratio) for clear visual hierarchy
- **Sophisticated Interactions**: Subtle, refined animations that enhance user experience
- **Scalability**: All components handle varying content volumes (2-10+ items)
- **Accessibility**: Semantic HTML, proper contrast ratios, motion-safe preferences

---

## Color System

### Background Colors

#### Pure Colors (Black/White Sections)
```css
--bg-pure-black: #000000;    /* Hero, Resources sections */
--bg-pure-white: #ffffff;    /* Standard white sections */
```

#### Warm Off-White System (Highlighted Sections)
Base color: `#f5f2f1` - Used for Challenges and Methodology sections

**Tints (Lighter - adding white):**
```css
--bg-warm-50: #fdfcfc;       /* Lightest tint - 95% lighter */
--bg-warm-100: #faf9f8;      /* Very light tint - 75% lighter */
--bg-warm-200: #f8f6f5;      /* Light tint - 50% lighter */
--bg-warm-300: #f6f4f3;      /* Subtle tint - 25% lighter */
--bg-warm-400: #f5f2f1;      /* Base color (--bg-warm) */
```

**Shades (Darker - adding black):**
```css
--bg-warm-500: #eae5e3;      /* Subtle shade - 10% darker (borders, dividers) */
--bg-warm-600: #d9d1ce;      /* Light shade - 25% darker (timeline lines) */
--bg-warm-700: #c8bcb8;      /* Medium shade - 40% darker (node borders) */
--bg-warm-800: #b7a7a2;      /* Dark shade - 55% darker */
--bg-warm-900: #a6928c;      /* Darkest shade - 70% darker */
```

### Text Colors

#### On Light Backgrounds (Black sections, White cards)
```css
--text-primary: rgba(0, 0, 0, 0.90);      /* Primary headings */
--text-secondary: rgba(0, 0, 0, 0.60);    /* Body text */
--text-tertiary: rgba(0, 0, 0, 0.40);     /* Meta info, labels */
--text-disabled: rgba(0, 0, 0, 0.20);     /* Disabled state */
```

#### On Dark Backgrounds (Black sections)
```css
--text-on-dark-primary: rgba(255, 255, 255, 0.95);   /* Headings */
--text-on-dark-secondary: rgba(255, 255, 255, 0.70); /* Body text */
--text-on-dark-tertiary: rgba(255, 255, 255, 0.50);  /* Meta info */
```

#### Specific Use Cases
```css
/* Challenges Section - Warm Background */
- Headings: text-black (100% black)
- Body: text-black/70
- Meta: text-black/30
- Large Numbers: text-black/[0.08] → hover: text-black/[0.12]

/* Methodology Section - Warm Background */
- Headings: text-black
- Body: text-black/70
- Timeline: #d9d1ce, #c8bcb8
- Badges: text-black/50

/* Resources Section - Pure Black */
- Headings: text-white
- Body: text-white/60 → hover: text-white/80
- Meta: text-white/30-40
```

### UI Element Colors

#### Borders
```css
--ui-border-subtle: rgba(0, 0, 0, 0.05);    /* Barely visible */
--ui-border-light: rgba(0, 0, 0, 0.10);     /* Standard border */
--ui-border-medium: rgba(0, 0, 0, 0.20);    /* Emphasized border */
--ui-border-strong: rgba(0, 0, 0, 0.40);    /* Strong dividers */

/* Warm Background Cards */
border-black/[0.08] → hover: border-black/[0.15]
Specific: #eae5e3 (--bg-warm-500)
```

#### Glassmorphism Effects
```css
--glass-light: rgba(255, 255, 255, 0.05);   /* Subtle glass */
--glass-medium: rgba(255, 255, 255, 0.10);  /* Medium glass */
--glass-strong: rgba(255, 255, 255, 0.20);  /* Strong glass */
```

#### Shadows
```css
/* Subtle Card Shadow (Warm sections) */
boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)'

/* Hover Card Shadow */
hover:shadow-sm   /* Challenges cards */
hover:shadow-md   /* Methodology cards */
hover:shadow-lg   /* Enhanced hover */
```

### Section Background Pattern
```
Hero Section          → Pure Black (#000000)
Client Context        → Pure White (#ffffff)
Challenges            → Warm Off-White (#f5f2f1)
Engagement Objectives → Pure White (#ffffff)
Value Pillars         → Pure White (#ffffff)
Methodology           → Warm Off-White (#f5f2f1)
Impact (variants)     → Pure Black or White
Testimonial           → Pure White (#ffffff)
Resources             → Pure Black (#000000)
Final CTA             → Pure White (#ffffff)
```

---

## Typography

### Font Families
```css
/* Serif - Editorial Headlines */
font-family: 'Noto Serif', serif;
/* Used for: Large headings, hero titles, section numbers */

/* Sans-Serif - Body & UI */
font-family: 'DM Sans', sans-serif;
/* Used for: Body text, buttons, labels, navigation */

/* System Fallback */
font-family: 'Inter', sans-serif;
```

### Typography Scale - Major Third (1.25 ratio)
Base size: 16px

```css
--font-size: 16px;

/* Scale */
--text-xs: 0.8rem;      /* 12.8px - Small labels, meta */
--text-sm: 1rem;        /* 16px - Body text (base) */
--text-base: 1.25rem;   /* 20px - Large body, small headings */
--text-lg: 1.563rem;    /* 25px - H3 headings */
--text-xl: 1.953rem;    /* 31.25px - H2 headings */
--text-2xl: 2.441rem;   /* 39px - H1 headings */
--text-3xl: 3.052rem;   /* 48.8px ≈ 48px - Hero headings */
--text-4xl: 3.815rem;   /* 61px - Extra large headings */
--text-5xl: 4.768rem;   /* 76px - Massive headings */
```

### Font Weights
```css
--font-weight-normal: 400;   /* Body text */
--font-weight-medium: 500;   /* Buttons, labels, emphasis */

/* Specific Uses */
font-light (300)   → Hero headings, large serif titles
font-normal (400)  → Body text, descriptions
font-medium (500)  → Section labels, badges, meta
font-bold (700)    → CTA buttons, navigation
```

### Line Heights
```css
/* Headlines */
leading-[1.15]  → Hero, large headings
leading-[1.25]  → Card titles, medium headings
leading-[1.3]   → Methodology step titles
leading-[1.35]  → Resource card titles

/* Body Text */
leading-[1.5]   → Standard body
leading-[1.6]   → Resource descriptions
leading-[1.7]   → Long-form content
leading-none    → Large display numbers
```

### Letter Spacing
```css
tracking-tight         → Headlines (-0.025em)
tracking-normal        → Body text (0)
tracking-[2px]         → Step labels (0.125em)
tracking-[3px]         → Section labels (0.1875em)
tracking-[1.5px]       → Resource categories
```

### Typography Patterns by Section

#### Hero Section
```tsx
// Eyebrow
fontSize: 'var(--text-xs)', tracking: '[3px]', weight: 'medium'

// Headline
fontSize: 'clamp(2rem, 6vw, var(--text-3xl))'
fontFamily: "'Noto Serif', serif", weight: 'light'

// Subheading
fontSize: 'var(--text-sm)', opacity: 0.60
```

#### Section Headers
```tsx
// Label
fontSize: 'var(--text-xs)', tracking: '[3px]', uppercase

// Title
fontSize: 'var(--text-3xl)', fontFamily: "'Noto Serif', serif"
```

#### Card Components
```tsx
// Card Title
fontSize: 'var(--text-base)' (4+ cards) or 'var(--text-lg)' (2-3 cards)
weight: 'medium'

// Card Description
fontSize: 'var(--text-sm)' or '0.875rem' (for compact layouts)
```

---

## Spacing System

### Container & Layout Spacing
```css
/* Max Width Constraints */
max-w-[1000px]   → Main content container
max-w-[1200px]   → Navbar container
max-w-[700px]    → Text content (paragraphs)
max-w-[800px]    → Testimonial content

/* Horizontal Padding (Responsive) */
px-4 sm:px-6 md:px-8   → Standard section padding
px-5 md:px-6           → Card internal padding
px-8                   → CTA buttons
```

### Vertical Spacing

#### Section Padding
```css
py-12 sm:py-16 md:py-20    → Standard section padding
py-8 sm:py-12 md:py-16     → Compact sections
py-16 sm:py-20 md:py-24    → Hero sections
```

#### Internal Component Spacing
```css
/* Gaps */
gap-2, gap-3, gap-4        → Small element spacing
gap-4 md:gap-6             → Card grids (responsive)
gap-6 md:gap-8             → Resource grids
gap-8 md:gap-10            → Value Pillars grid

/* Margins */
mb-3, mb-4, mb-5, mb-6     → Element stacking
mb-8 md:mb-10              → Section internal spacing
mb-12 sm:mb-16 md:mb-20    → Major section divisions
```

### Grid Spacing Patterns
```tsx
// Challenges - Horizontal Scroll
gap-4 md:gap-6

// Value Pillars - Grid
gap-8 md:gap-10
grid-cols-1 md:grid-cols-2 lg:grid-cols-3

// Resources - Grid
gap-6 md:gap-8
grid-cols-1 sm:grid-cols-2 lg:grid-cols-4

// Engagement Objectives - Flex
gap-6 md:gap-8
```

---

## Border Radius System

### Strict Border Radius Rules
```css
/* Images & Photos */
rounded-[2.5px]    → All images, thumbnails, photos

/* Buttons & Small Cards */
rounded-[5px]      → Buttons, badges, small UI cards
                   → Challenge cards, Methodology cards
                   → Input fields, small components

/* Large Cards */
rounded-[10px]     → Large feature cards, impact cards
                   → Major content containers

/* Special Cases */
rounded-full       → Pills, tags, circular elements
                   → Search bar (99px)
```

### Application Examples
```tsx
// Challenge Cards
className="rounded-[5px]"

// Resource Images
className="rounded-[2.5px]"

// Impact Large Cards
className="rounded-[10px]"

// CTA Buttons
className="rounded-[5px]"

// Methodology Node Circles
className="rounded-full"
```

---

## Layout System

### Container Pattern
```tsx
<section className="py-12 sm:py-16 md:py-20" style={{ background: 'var(--bg-warm)' }}>
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Content */}
  </div>
</section>
```

### Section Anatomy
```
1. Section Background (alternating)
2. Container (max-w-[1000px], centered)
3. Section Header
   - Label (eyebrow)
   - Title (H2)
   - Description (optional)
4. Main Content
5. CTA or Footer (optional)
```

### Grid Patterns

#### Auto-Responsive Grid (Resources)
```tsx
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
```

#### Manual Responsive Grid (Value Pillars)
```tsx
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10"
```

#### Horizontal Scroll (Challenges)
```tsx
className="flex gap-4 md:gap-6 overflow-x-auto scroll-smooth snap-x"
// With fade gradients and dynamic width calculation
```

#### Vertical Timeline (Methodology)
```tsx
className="relative space-y-0"
// With absolute positioned timeline line
```

---

## Component Library

### 1. **HeroSection**
**Purpose:** Landing section with project title and key info

**Features:**
- Eyebrow label with tracking
- Large serif headline (responsive clamp)
- Subheading with opacity
- CTA button
- Pure black background

**Props:**
```tsx
interface HeroSectionProps {
  eyebrow: string;
  title: string;
  subtitle: string;
  ctaText: string;
}
```

---

### 2. **ClientContextSection**
**Purpose:** Company background and context

**Features:**
- Glassmorphism card design
- Image with border radius 2.5px
- Structured content layout
- Pure white background

**Props:**
```tsx
interface ClientContextSectionProps {
  companyName: string;
  tagline: string;
  description: string;
  image: string;
  highlights: {
    label: string;
    value: string;
  }[];
}
```

---

### 3. **ChallengesSection**
**Purpose:** Horizontal scrolling challenge cards

**Features:**
- Dynamic card width (2-4 cards: full width, 5+: scroll)
- Fade gradients (left/right)
- Scroll indicators (index/total)
- Lift hover effect
- Warm off-white background

**Props:**
```tsx
interface Challenge {
  number: string;
  title: string;
  questions: string[];
}

interface ChallengesSectionProps {
  challenges: Challenge[];
}
```

**Card Width Logic:**
```tsx
cardCount <= 2: w-full
cardCount === 3: w-full lg:w-[calc(33.333%-1rem)]
cardCount === 4: w-full lg:w-[calc(25%-1.125rem)]
cardCount >= 5: w-[85vw] sm:w-[70vw] md:w-[45vw] lg:w-[280px]
```

---

### 4. **EngagementObjectivesSection**
**Purpose:** Project objectives in card layout

**Features:**
- Flexible grid (2-4+ items)
- Icon support
- Clean card design
- Pure white background

**Props:**
```tsx
interface Objective {
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface EngagementObjectivesSectionProps {
  objectives: Objective[];
}
```

---

### 5. **ValuePillarsSection**
**Purpose:** Service/value propositions grid

**Features:**
- 3-column grid (responsive)
- Numbered cards
- Icon integration
- Pure white background

**Props:**
```tsx
interface ValuePillar {
  number: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface ValuePillarsSectionProps {
  pillars: ValuePillar[];
}
```

---

### 6. **MethodologySection**
**Purpose:** Vertical timeline of process steps

**Features:**
- Timeline with nodes and connectors
- Step badges (1 of N)
- Progress arrows
- Lift hover effect
- Warm off-white background

**Props:**
```tsx
interface MethodologyStep {
  number: string;
  title: string;
  description: string;
}

interface MethodologySectionProps {
  steps: MethodologyStep[];
}
```

**Timeline Colors:**
```css
Vertical Line: #d9d1ce (--bg-warm-600)
Node Border: #c8bcb8 (--bg-warm-700)
Connector Gradient: #c8bcb8 → #d9d1ce → transparent
```

---

### 7. **ImpactSection** (with Variants)
**Purpose:** Results and outcomes showcase

**Variants:**
- **Grid Cards**: 2-column metric grid
- **Big Cards**: Large 2-column feature cards
- **Stats Row**: Horizontal statistics bar
- **Full Width Hero**: Single large impact statement

**Features:**
- VariantSwitcher for preview
- Flexible backgrounds (black or white)
- Number counter animations (ready)
- Responsive layouts

**Props:**
```tsx
interface ImpactSectionProps {
  variant: 'grid-cards' | 'big-cards' | 'stats-row' | 'full-width-hero';
  metrics: Array<{
    number: string;
    label: string;
    description?: string;
  }>;
}
```

---

### 8. **TestimonialSection**
**Purpose:** Client testimonial with quote styling

**Features:**
- Large quote marks
- Centered layout
- Author info with role
- Pure white background

**Props:**
```tsx
interface TestimonialSectionProps {
  quote: string;
  author: string;
  role: string;
  company: string;
}
```

---

### 9. **ResourcesSection**
**Purpose:** Related content/articles grid

**Features:**
- 4-column grid (responsive)
- Image zoom on hover
- Category badges
- Date stamps
- Pure black background

**Props:**
```tsx
interface Resource {
  image: string;
  category: string;
  date: string;
  title: string;
  description: string;
}

// Uses internal resources array (8 items)
```

---

### 10. **FinalCTASection**
**Purpose:** Closing call-to-action

**Features:**
- Centered layout
- Primary CTA button
- Subtle styling
- Pure white background

**Props:**
```tsx
interface FinalCTASectionProps {
  title: string;
  description: string;
  ctaText: string;
}
```

---

### 11. **Navbar**
**Purpose:** Fixed header navigation

**Features:**
- Reading progress bar
- Two-tier navigation (desktop)
- Mobile responsive menu
- Dropdown menus
- CTA button

**Props:** None (static content)

**Special Features:**
```tsx
// Reading Progress
const progress = useReadingProgress();
// Red bar: width: `${progress}%`
```

---

### 12. **VariantSwitcher**
**Purpose:** Development tool for previewing variants

**Features:**
- Button group for variant selection
- Active state highlighting
- Developer utility (not for production)

**Props:**
```tsx
interface VariantSwitcherProps {
  currentVariant: string;
  variants: Array<{
    id: string;
    label: string;
  }>;
  onVariantChange: (variantId: string) => void;
}
```

---

## Interaction Patterns

### Custom Hooks

#### 1. **useScrollAnimation**
```tsx
import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

const { ref, isVisible } = useScrollAnimation({ 
  threshold: 0.1,
  rootMargin: '0px',
  triggerOnce: true 
});

// Apply to element
<div ref={ref} className={isVisible ? 'animate-in' : ''}>
```

#### 2. **useReadingProgress**
```tsx
import { useReadingProgress } from '@/app/hooks/useReadingProgress';

const progress = useReadingProgress();

// Apply to progress bar
<div style={{ width: `${progress}%` }} />
```

#### 3. **useCounter**
```tsx
import { useCounter } from '@/app/hooks/useCounter';

const { count, startCounting } = useCounter({ 
  end: 110,
  duration: 2000,
  startOnView: true 
});

// Display animated count
<span>{count}</span>
```

#### 4. **useMagneticEffect**
```tsx
import { useMagneticEffect } from '@/app/hooks/useMagneticEffect';

const { ref, position } = useMagneticEffect({ 
  strength: 0.3,
  disabled: false 
});

// Apply magnetic effect
<button 
  ref={ref}
  style={{ transform: `translate(${position.x}px, ${position.y}px)` }}
>
```

### Hover Effects

#### Card Lift
```tsx
// Challenges & Methodology cards
className="hover:-translate-y-1 hover:shadow-lg transition-all duration-300"
style={{ willChange: 'transform' }}
```

#### Image Zoom
```tsx
// Resources section images
className="transition-all duration-500 group-hover:scale-110"
style={{ willChange: 'transform' }}

// Overlay
className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"
```

#### Border & Shadow Enhancement
```tsx
// Warm background cards
className="border-black/[0.08] hover:border-black/[0.15] hover:shadow-sm"
```

#### Text Color Transitions
```tsx
// Resources cards
className="text-white/60 group-hover:text-white/80 transition-colors"
```

### Transition Timings
```css
/* Standard */
duration-300    → Card hovers, border changes, text colors

/* Slow */
duration-500    → Image zooms, large movements

/* Fast */
duration-150    → Progress bar, quick UI feedback
```

### Performance Optimization
```tsx
// Always add to animated elements
style={{ willChange: 'transform' }}

// Smooth scroll
html { scroll-behavior: smooth; }

// Passive listeners (in hooks)
{ passive: true }
```

---

## Responsive Design

### Breakpoints (Tailwind Defaults)
```css
sm: 640px   → Small tablets, large phones
md: 768px   → Tablets
lg: 1024px  → Small laptops
xl: 1280px  → Large laptops
2xl: 1536px → Desktops
```

### Mobile-First Patterns

#### Typography
```tsx
// Responsive clamp
fontSize: 'clamp(2rem, 6vw, var(--text-3xl))'

// Breakpoint specific
className="text-base md:text-lg lg:text-xl"
```

#### Spacing
```tsx
// Padding
className="py-12 sm:py-16 md:py-20"
className="px-4 sm:px-6 md:px-8"

// Gaps
className="gap-4 md:gap-6"
className="gap-6 md:gap-8"

// Margins
className="mb-8 md:mb-10"
className="mb-12 sm:mb-16 md:mb-20"
```

#### Grids
```tsx
// Resources (4-column)
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"

// Value Pillars (3-column)
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3"

// Objectives (flexible)
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${count >= 4 ? '2' : '3'}"
```

#### Visibility Toggles
```tsx
// Hide on mobile
className="hidden md:block"
className="hidden lg:flex"

// Show only on mobile
className="md:hidden"
className="lg:hidden"
```

### Horizontal Scroll Pattern (Challenges)
```tsx
// Mobile: Full-width scroll
w-[85vw] sm:w-[70vw] md:w-[45vw]

// Desktop: Fixed width or justified
lg:w-[280px]
lg:justify-center lg:overflow-x-visible (when cardCount <= 4)
```

### Responsive Image Sizing
```tsx
// Aspect ratios
className="aspect-[4/3]"     → Resources
className="aspect-[16/9]"    → Client Context
className="aspect-square"    → Icons, avatars
```

---

## Code Structure

### File Organization
```
/src
  /app
    /components
      AboutSection.tsx
      CTASection.tsx
      ChallengesSection.tsx
      ClientContextSection.tsx
      EngagementObjectivesSection.tsx
      FinalCTASection.tsx
      HeroSection.tsx
      ImpactSection.tsx
      MethodologySection.tsx
      Navbar.tsx
      ResourcesSection.tsx
      TestimonialSection.tsx
      ValuePillarsSection.tsx
      VariantSwitcher.tsx
    /hooks
      useScrollAnimation.ts
      useReadingProgress.ts
      useCounter.ts
      useMagneticEffect.ts
    App.tsx
  /imports
    [Figma-imported assets]
  /styles
    fonts.css
    globals.css
    theme.css
  main.tsx
```

### Import Patterns

#### Components
```tsx
import { ComponentName } from '@/app/components/ComponentName';
```

#### Hooks
```tsx
import { useHookName } from '@/app/hooks/useHookName';
```

#### Assets
```tsx
// Raster images (PNG, JPG)
import imgName from "figma:asset/hash.png";

// SVGs
import svgPaths from "@/imports/svg-id";
```

#### Icons
```tsx
import { IconName } from 'lucide-react';
```

### Component Template
```tsx
import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

interface ComponentNameProps {
  // Props definition
}

export function ComponentName({ prop1, prop2 }: ComponentNameProps) {
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });
  
  return (
    <section 
      ref={ref}
      className="py-12 sm:py-16 md:py-20" 
      style={{ background: 'var(--bg-warm)' }}
    >
      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
        {/* Section Header */}
        <div className="mb-12 sm:mb-16 md:mb-20">
          <span className="font-medium text-black/40 uppercase tracking-[3px] mb-6 md:mb-8 block" style={{ fontSize: 'var(--text-xs)' }}>
            Section Label
          </span>
          
          <h2 className="leading-[1.15] font-light text-black tracking-tight mb-4 md:mb-6" style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}>
            Section Title
          </h2>
          
          <p className="leading-[1.7] text-black/70 max-w-[700px]" style={{ fontSize: 'var(--text-sm)' }}>
            Description text
          </p>
        </div>

        {/* Main Content */}
        {/* ... */}
      </div>
    </section>
  );
}
```

---

## Best Practices

### ✅ DO
- Use CSS custom properties from `theme.css`
- Apply responsive patterns consistently
- Use semantic HTML elements
- Add `willChange` to animated elements
- Provide `key` props for lists
- Use Tailwind classes for spacing/layout
- Keep max-width at 1000px for content
- Use tracking for uppercase text
- Apply proper opacity for hierarchy

### ❌ DON'T
- Create custom font sizes (use scale)
- Mix border radius values (stick to 2.5px, 5px, 10px)
- Use arbitrary colors (use design tokens)
- Forget responsive breakpoints
- Use inline styles for simple utilities
- Create new spacing values
- Skip hover/focus states
- Use heavy animations

### Performance
```tsx
// ✅ Good
style={{ willChange: 'transform' }}
className="transition-all duration-300"

// ✅ Good - Passive listeners
window.addEventListener('scroll', handler, { passive: true });

// ✅ Good - Conditional rendering
{showContent && <ExpensiveComponent />}

// ❌ Avoid
style={{ transition: 'all 0.3s ease, color 0.5s, transform 0.2s' }}
```

### Accessibility
```tsx
// ✅ Semantic HTML
<section>, <article>, <nav>, <header>, <footer>

// ✅ ARIA labels
<button aria-label="Close menu">

// ✅ Focus states
className="focus:ring-2 focus:ring-black/20"

// ✅ Alt text
<img src={src} alt="Descriptive text" />
```

---

## Usage Examples

### Creating a New Section
```tsx
// 1. Create component file
// /src/app/components/NewSection.tsx

import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

interface NewSectionProps {
  items: Array<{ title: string; description: string }>;
}

export function NewSection({ items }: NewSectionProps) {
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });
  
  return (
    <section 
      ref={ref}
      className="py-12 sm:py-16 md:py-20" 
      style={{ background: 'var(--bg-pure-white)' }}
    >
      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
        {/* Content */}
      </div>
    </section>
  );
}

// 2. Import in App.tsx
import { NewSection } from '@/app/components/NewSection';

// 3. Add to page
<NewSection items={data} />
```

### Adding a New Color Variant
```css
/* In theme.css */
:root {
  --bg-custom: #f0f0f0;
  --bg-custom-dark: #d0d0d0;
}

/* In component */
style={{ background: 'var(--bg-custom)' }}
```

### Creating a Card Component
```tsx
<div 
  className="bg-white border border-black/[0.08] rounded-[5px] p-6 hover:-translate-y-1 hover:border-black/[0.15] hover:shadow-lg transition-all duration-300 group"
  style={{ 
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
    willChange: 'transform'
  }}
>
  <h3 className="font-medium text-black mb-4" style={{ fontSize: 'var(--text-base)' }}>
    Card Title
  </h3>
  <p className="text-black/70" style={{ fontSize: 'var(--text-sm)' }}>
    Card description
  </p>
</div>
```

---

## Design Tokens Quick Reference

```css
/* COLORS */
--bg-pure-black: #000000
--bg-pure-white: #ffffff
--bg-warm: #f5f2f1
--bg-warm-500: #eae5e3 (borders)
--bg-warm-600: #d9d1ce (lines)
--bg-warm-700: #c8bcb8 (strong borders)

/* TYPOGRAPHY */
--text-xs: 0.8rem (12.8px)
--text-sm: 1rem (16px)
--text-base: 1.25rem (20px)
--text-lg: 1.563rem (25px)
--text-xl: 1.953rem (31px)
--text-2xl: 2.441rem (39px)
--text-3xl: 3.052rem (48px)

/* SPACING */
Section: py-12 sm:py-16 md:py-20
Container: px-4 sm:px-6 md:px-8
Cards: p-5 md:p-6 or p-6 md:p-8

/* BORDER RADIUS */
Images: 2.5px
Buttons/Small Cards: 5px
Large Cards: 10px

/* OPACITY */
Primary: 90% (0.90)
Secondary: 60-70% (0.60-0.70)
Tertiary: 40% (0.40)
Disabled: 20% (0.20)
```

---

## Version History

**v1.0** - January 2025
- Initial design system documentation
- Complete component library
- Interaction patterns established
- Responsive design system
- Color system finalized (warm off-white + pure black/white)

---

## Support & Maintenance

### To Update Components
1. Modify component file in `/src/app/components/`
2. Update props interface if needed
3. Test responsive breakpoints
4. Verify color scheme matches section background
5. Update this documentation

### To Add New Interactions
1. Create hook in `/src/app/hooks/`
2. Import and apply in component
3. Document in Interaction Patterns section
4. Test performance with `willChange`

### To Modify Design Tokens
1. Update `/src/styles/theme.css`
2. Search and update all references
3. Test across all sections
4. Update Quick Reference section

---

**End of Design System Documentation**
