// ============================================================================
// TYPOGRAPHY HELPER COMPONENTS
// ============================================================================

// Font Weight Demo
function FontWeightDemo() {
  const weights = [
    { weight: '400', name: 'Normal', usage: 'Body text', example: 'This is regular body text for comfortable reading and extended paragraphs.' },
    { weight: '500', name: 'Medium', usage: 'Emphasis', example: 'This is medium weight for subtle emphasis and important labels.' },
    { weight: '700', name: 'Bold', usage: 'Headings', example: 'This is bold weight for strong hierarchy and headings.' },
  ];

  return (
    <div className="space-y-4">
      {weights.map((w) => (
        <div key={w.weight} className="border border-black/8 rounded-[10px] p-6">
          <div className="flex items-center justify-between mb-3">
            <p className="font-mono text-sm"><strong>Weight:</strong> {w.weight} ({w.name})</p>
            <p className="text-xs text-black/60">{w.usage}</p>
          </div>
          <p style={{ fontWeight: Number(w.weight) }} className="text-base">{w.example}</p>
        </div>
      ))}
    </div>
  );
}

// Font Family Comparison
function FontFamilyComparison() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: 'DM Sans', sans-serif</p>
        <h3 style={{ fontFamily: 'DM Sans, sans-serif' }} className="text-2xl mb-3">DM Sans Heading</h3>
        <p style={{ fontFamily: 'DM Sans, sans-serif' }} className="text-sm mb-4">
          Geometric sans-serif. Clean, modern, perfect for UI elements, buttons, and system text.
        </p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> Navigation, buttons, labels, forms</p>
      </div>

      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: 'Noto Serif', serif</p>
        <h3 style={{ fontFamily: 'Noto Serif, serif' }} className="text-2xl mb-3">Noto Serif Heading</h3>
        <p style={{ fontFamily: 'Noto Serif, serif' }} className="text-sm mb-4">
          Humanist serif. Warm, editorial, perfect for storytelling and long-form content.
        </p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> Headings, body paragraphs, editorial</p>
      </div>
    </div>
  );
}

// Real Text Examples
function RealTextExamples() {
  const examples = [
    { size: '48.8px', text: 'Revolutionizing Global Communications', usage: 'Hero H1' },
    { size: '39px', text: 'Client Context: Understanding the Problem', usage: 'Section H2' },
    { size: '31.25px', text: 'Primary Research & Discovery Phase', usage: 'Subsection H3' },
    { size: '20px', text: 'Challenge Overview Card Title', usage: 'Card Heading' },
    { size: '16px', text: 'Body text describing project details, methodology, and outcomes in comfortable reading format.', usage: 'Body Paragraph' },
    { size: '12.8px', text: 'CASE STUDY • DESIGN SYSTEM', usage: 'Section Label' },
  ];

  return (
    <div className="space-y-6">
      {examples.map((ex, idx) => (
        <div key={idx} className="border-l-4 border-[var(--brand-red)] pl-6 py-3">
          <div className="flex items-center gap-3 mb-2">
            <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded-[3px]">{ex.size}</code>
            <span className="text-xs text-black/50">• {ex.usage}</span>
          </div>
          <p style={{ fontSize: ex.size }}>{ex.text}</p>
        </div>
      ))}
    </div>
  );
}

// Heading Hierarchy
function HeadingHierarchy() {
  return (
    <div className="space-y-6">
      <div className="border border-black/8 rounded-[10px] p-8 bg-white">
        <h1 style={{ fontSize: 'var(--text-3xl)' }} className="mb-6">H1: Hero Heading (48.8px)</h1>
        <div className="pl-6 border-l-2 border-black/10">
          <h2 style={{ fontSize: 'var(--text-2xl)' }} className="mb-4">H2: Section Heading (39px)</h2>
          <div className="pl-6 border-l-2 border-black/10">
            <h3 style={{ fontSize: 'var(--text-xl)' }} className="mb-3">H3: Subsection Heading (31.25px)</h3>
            <p style={{ fontSize: 'var(--text-sm)' }} className="text-black/70">Body text follows at 16px with comfortable reading.</p>
          </div>
        </div>
      </div>

      <div className="bg-black/[0.02] rounded-[10px] p-6">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-black/20">
              <th className="text-left p-3 text-sm font-bold">Level</th>
              <th className="text-left p-3 text-sm font-bold">Size</th>
              <th className="text-left p-3 text-sm font-bold">Usage</th>
              <th className="text-left p-3 text-sm font-bold">Frequency</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">H1</td>
              <td className="p-3 text-sm">48.8px (3xl)</td>
              <td className="p-3 text-sm">Hero heading, Final CTA</td>
              <td className="p-3 text-xs text-black/60">1-2× per page</td>
            </tr>
            <tr className="border-b border-black/8">
              <td className="p-3 font-mono font-bold">H2</td>
              <td className="p-3 text-sm">39px (2xl)</td>
              <td className="p-3 text-sm">Major section headings ⭐</td>
              <td className="p-3 text-xs text-black/60">5-8× per page</td>
            </tr>
            <tr>
              <td className="p-3 font-mono font-bold">H3</td>
              <td className="p-3 text-sm">31.25px (xl)</td>
              <td className="p-3 text-sm">Subsections, steps</td>
              <td className="p-3 text-xs text-black/60">10-15× per page</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Responsive Typography Demo
function ResponsiveTypographyDemo() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/[0.02] rounded-[10px] p-6">
          <h4 className="font-semibold mb-4">Mobile (< 768px)</h4>
          <div className="space-y-2 text-sm">
            <p>• Base: 16px</p>
            <p>• Hero (H1): 36px</p>
            <p>• Section (H2): 28px</p>
            <p>• Subsection (H3): 24px</p>
          </div>
        </div>

        <div className="bg-black/[0.02] rounded-[10px] p-6">
          <h4 className="font-semibold mb-4">Desktop (≥ 768px)</h4>
          <div className="space-y-2 text-sm">
            <p>• Base: 16px</p>
            <p>• Hero (H1): 48.8px ⭐</p>
            <p>• Section (H2): 39px ⭐</p>
            <p>• Subsection (H3): 31.25px</p>
          </div>
        </div>
      </div>

      <CodeExample code={`// Responsive Typography in CSS:\n@media (max-width: 767px) {\n  h1 { font-size: 36px; }  /* Hero */\n  h2 { font-size: 28px; }  /* Sections */\n  h3 { font-size: 24px; }  /* Subsections */\n}\n\n@media (min-width: 768px) {\n  h1 { font-size: 48.8px; } /* var(--text-3xl) */\n  h2 { font-size: 39px; }   /* var(--text-2xl) */\n  h3 { font-size: 31.25px; }/* var(--text-xl) */\n}`} />
    </div>
  );
}
