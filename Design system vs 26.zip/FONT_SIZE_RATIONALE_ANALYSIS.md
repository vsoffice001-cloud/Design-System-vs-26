# 🔍 FONT SIZE RATIONALE ANALYSIS
**Understanding Why We Made Specific Design Decisions**

---

## 📚 **CONTEXT: What We're Building**

We're building a **premium case study website** with:
- **Editorial aesthetic** - Magazine-quality typography
- **Major Third scale (1.25 ratio)** - Mathematical harmony in font sizes
- **Visual hierarchy through scale** - Massive headings, precise body text
- **Responsive design** - Font sizes adapt to screen width

---

## 🎯 **THE DESIGN SYSTEM INTENT**

From `/DESIGN_SYSTEM.md` and `/theme.css`:

```css
/* Major Third Scale (1.25 ratio) - Pure Mathematical Progression */
--text-xs: 0.8rem;      /* 12.8px - Labels, metadata */
--text-sm: 1rem;        /* 16px - Body text */
--text-base: 1.25rem;   /* 20px - Large body */
--text-lg: 1.563rem;    /* 25px - Subsection headings */
--text-xl: 1.953rem;    /* 31.25px - Section headings */
--text-2xl: 2.441rem;   /* 39px - Major titles */
--text-3xl: 3.052rem;   /* 48.8px - Hero headings */
```

**Intent:** Create harmonious, predictable typography that scales beautifully across all devices.

---

---

## 🔍 **WHY WE HAVE HARDCODED VALUES**

### **REASON #1: Visual Fine-Tuning Over Mathematical Purity**

#### **Client Context Section - The "Card-in-Sidebar" Layout**

**Location:** Left sidebar with logo + company info

```tsx
// HARDCODED VALUES:
fontSize: '9.5px'   // Section labels (Client Company, Industry)
fontSize: '17px'    // Company name
fontSize: '13px'    // Industry text
```

**Why?**

1. **Sidebar Constraint** - Limited width (33% on desktop)
2. **Information Density** - Need to fit logo + 2 fields + labels
3. **Visual Balance** - Smaller text prevents overwhelming small space
4. **Optical Sizing** - 17px for company name feels "right" in that space

**Design System would give us:**
```tsx
fontSize: 'var(--text-xs)'    // 12.8px - Too large for micro labels
fontSize: 'var(--text-base)'  // 20px - WAY too large for company name
fontSize: 'var(--text-sm)'    // 16px - Too large for industry text
```

**The Problem:** Mathematical scale doesn't account for **spatial constraints**.

---

#### **Company Overview Heading - Responsive Typography**

```tsx
fontSize: 'clamp(19px, 2.8vw, 24px)'  // Hardcoded responsive range
```

**Why?**

1. **Viewport-Based Sizing** - Needs to grow smoothly from mobile to desktop
2. **Precise Control** - 19px minimum prevents text from being too small on mobile
3. **Maximum Constraint** - 24px prevents it from dominating on large screens
4. **The "Lead Paragraph" Pattern** - Larger than body (16px), smaller than heading (25px)

**Design System would give us:**
```tsx
fontSize: 'var(--text-base)'  // 20px - Fixed, not responsive
// OR
fontSize: 'clamp(1rem, 2.5vw, var(--text-lg))'  // 16px → 25px (too wide a range)
```

**The Problem:** Need a **specific sweet spot** between 19-24px that design system doesn't provide.

---

---

### **REASON #2: Preventing Text Wrapping in Cards**

#### **Impact Section Metrics - Display Numbers**

```tsx
// HARDCODED:
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 28px → 40px

// COMMENT IN CODE:
{/* Metric Value - Reduced size to prevent wrapping */}
```

**Why?**

1. **Real Data Issue** - Metrics like "₹110 Cr" can wrap awkwardly
2. **Card Width Constraint** - Cards are 4 across on desktop (tight!)
3. **Visual Hierarchy** - Still need metrics to be LARGE, but not TOO large
4. **Testing Result** - 40px (2.5rem) was sweet spot after testing with real content

**Design System would give us:**
```tsx
fontSize: 'var(--text-2xl)'  // 39px - Fixed, might wrap on smaller cards
fontSize: 'var(--text-3xl)'  // 48.8px - Definitely wraps!
```

**The Problem:** Real content + card constraints = need **precise maximum** to prevent wrapping.

---

#### **Challenges Section Questions - Compact Layouts**

```tsx
// HARDCODED for 4+ cards:
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'
//         14px for compact layouts    16px for spacious layouts

// COMMENT IN CODE:
{/* Questions - Conditional sizing based on card count */}
```

**Why?**

1. **Density Management** - When displaying 4+ challenge cards, space is tight
2. **Readability Balance** - 14px (0.875rem) is minimum readable size for body text
3. **Dynamic Behavior** - Different content amounts need different treatments
4. **User Testing** - 16px questions made 4-card layouts feel cramped

**Design System would give us:**
```tsx
fontSize: 'var(--text-sm)'  // 16px - No dynamic sizing
fontSize: 'var(--text-xs)'  // 12.8px - Too small for body text
```

**The Problem:** Need **dynamic sizing** based on content amount (2-10+ items).

---

---

### **REASON #3: Specific Visual Hierarchy Within Components**

#### **Capabilities List Numbers - Subtle Visual Accent**

```tsx
fontSize: '13px'  // List numbers in capability cards
fontFamily: "'Noto Serif', serif"  // Serif for elegance
```

**Why?**

1. **Hierarchical Difference** - Numbers smaller than text (16px) to be secondary
2. **Serif Choice** - Elegant serif numbers complement the editorial aesthetic
3. **Not Too Small** - 12.8px (--text-xs) would be too diminutive
4. **Not Body Size** - 16px (--text-sm) would compete with actual content

**Visual Logic:**
```
01  Deep engineering capability...  ← 13px number + 16px text
02  Vertical integration...         ← Clear hierarchy
```

**Design System would give us:**
```tsx
fontSize: 'var(--text-xs)'  // 12.8px - Too small, hard to read
fontSize: 'var(--text-sm)'  // 16px - Same as text, no hierarchy
```

**The Problem:** Need **in-between size** (13px) for visual hierarchy.

---

---

### **REASON #4: Optical Corrections vs Mathematical Precision**

#### **The "1px Difference" Philosophy**

```tsx
// Impact metrics: 2.5rem (40px) instead of var(--text-2xl) (39px)
// Client overview: clamp(19px, 2.8vw, 24px) instead of var(--text-base) (20px)
```

**Why These Seemingly Small Differences Matter:**

1. **Optical Balance** - Typography is about **perception**, not just math
2. **Viewport Scaling** - Round pixel values (40px) scale better than decimals (39.06px)
3. **Browser Rendering** - Some browsers handle integer pixels better than fractional
4. **Design Tool Precision** - Designers work in integer pixels in Figma/Sketch

**Typographic Truth:**
> "Good typography is invisible. When it works, you don't notice it."

Sometimes **40px looks more balanced than 39px** even though the math says 39px is "correct."

---

---

### **REASON #5: Navbar - Figma Precision Requirement**

```tsx
// ALL HARDCODED:
text-[12px]  // Secondary nav
text-[14px]  // Main nav
text-[11px]  // Mobile labels
```

**Why?**

1. **Pixel-Perfect Figma Fidelity** - Client requirement: match Figma EXACTLY
2. **Sub-Pixel Measurements** - Navbar uses 49.71px, 47.84px positioning
3. **Visual Precision** - Navigation needs to feel "tight" and "professional"
4. **Brand Consistency** - Navbar typography matches company brand guidelines

**Design System would give us:**
```tsx
fontSize: 'var(--text-xs)'  // 12.8px - Not exact 12px match
```

**The Problem:** Client specifically requested **exact Figma pixel values**.

**Decision:** Navbar intentionally exists **outside** design system for precision.

---

---

---

## 📊 **SUMMARY: WHEN TO USE HARDCODED VS DESIGN SYSTEM**

### ✅ **USE DESIGN SYSTEM VARIABLES:**

1. **Section headings** - Major typography (h1, h2, h3)
2. **Body paragraphs** - Standard reading text
3. **Section labels** - Uppercase metadata
4. **Consistent contexts** - Same usage across multiple sections

**Examples:**
```tsx
✅ style={{ fontSize: 'var(--text-3xl)' }}  // Hero headings
✅ style={{ fontSize: 'var(--text-sm)' }}   // Body text
✅ style={{ fontSize: 'var(--text-xs)' }}   // Meta labels
```

---

### ⚠️ **USE HARDCODED VALUES WHEN:**

1. **Spatial constraints** - Sidebar, narrow columns, tight cards
2. **Preventing wrapping** - Display numbers, metrics in cards
3. **Dynamic layouts** - Content amount varies (2-10+ items)
4. **Optical corrections** - Visual balance over mathematical precision
5. **Responsive ranges** - Need specific min/max pixel values
6. **Client precision** - Exact Figma match required (e.g., navbar)
7. **In-between hierarchy** - Need 13px, 14px, 17px (not in scale)

**Examples:**
```tsx
⚠️ fontSize: '13px'                           // List numbers (hierarchy)
⚠️ fontSize: 'clamp(19px, 2.8vw, 24px)'      // Lead paragraph (responsive range)
⚠️ fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'  // Dynamic sizing
⚠️ fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'   // Metrics (wrapping prevention)
```

---

---

## 🎯 **SPECIFIC DECISIONS EXPLAINED**

### **9.5px Label Size**
```tsx
fontSize: '9.5px'  // "Client Company", "Industry" labels
```

**Why not 12.8px (--text-xs)?**
- Sidebar is only 33% width
- 12.8px labels would dominate small space
- 9.5px creates subtle, elegant micro-labels
- Follows "the smaller the space, the smaller the type" principle

**Real-world analogy:** Like ingredient labels on food packaging—purposely tiny but readable.

---

### **17px Company Name**
```tsx
fontSize: '17px'  // "Yash Highvoltage Insulators"
```

**Why not 20px (--text-base)?**
- Name is relatively long (24 characters)
- 20px would force wrapping in sidebar
- 17px allows single line on most screens
- Still prominent enough to be primary info

**Alternative considered:** 16px was too small, 20px too large → 17px is Goldilocks zone.

---

### **13px Industry Text**
```tsx
fontSize: '13px'  // "Power Transmission & Electrical Equipment"
```

**Why not 16px (--text-sm)?**
- Secondary information (less important than name)
- Text is descriptive and long
- Creates visual hierarchy: Name (17px) > Industry (13px)
- Keeps sidebar balanced and uncluttered

**Visual hierarchy achieved:** 9.5px label < 13px value < 17px name

---

### **19-24px Company Overview Range**
```tsx
fontSize: 'clamp(19px, 2.8vw, 24px)'
```

**Why this specific range?**

**Minimum 19px:**
- Larger than body text (16px) to signify importance
- Small enough for mobile without wrapping
- Readable on smallest supported screens (360px wide)

**Maximum 24px:**
- Smaller than subheadings (25px = --text-lg)
- Large enough to feel like a "lead paragraph"
- Doesn't overpower the section on wide screens

**Why not var(--text-base) (20px)?**
- Fixed size doesn't scale responsively
- Need smooth transition from mobile to desktop

**Testing showed:**
- 16px-25px range: Too wide, felt disjointed
- 18px-22px range: Too narrow, not enough scale
- **19px-24px: Perfect balance** ✨

---

### **40px Metric Values**
```tsx
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 28px → 40px
```

**Why not var(--text-2xl) (39px)?**

**Testing revealed:**
1. ₹110 Cr wraps awkwardly at 39px in 4-column grid
2. 40px gives just enough breathing room
3. 48.8px (--text-3xl) way too large, forces wrapping
4. 1px difference (39px → 40px) prevents wrapping edge cases

**Browser rendering:**
- 40px = Clean integer, renders consistently
- 39.06px (2.441rem) = Fractional, may cause sub-pixel rendering issues

**Conclusion:** Sometimes **1px matters** for real-world content.

---

### **14px Questions (0.875rem)**
```tsx
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'
```

**Why dynamic sizing?**

**With 2-3 cards (spacious):**
- Plenty of space: Use 16px (--text-sm)
- Comfortable reading experience
- No density concerns

**With 4+ cards (compact):**
- Tight horizontal space
- 16px questions make cards feel cramped
- 14px maintains readability while saving space
- Users can still read comfortably

**Why 14px specifically?**
- Industry standard for "small body text"
- Google Material Design uses 14px for dense layouts
- Still above 12px minimum for accessibility

---

---

## 🎨 **THE "MISSING SIZES" PROBLEM**

### **What the Design System Doesn't Provide:**

```
9.5px  ← Micro labels (too small for scale)
11px   ← Mobile menu labels (Navbar specific)
12px   ← Navbar text (Figma requirement)
13px   ← Secondary info, list numbers
14px   ← Compact body text
17px   ← Medium-emphasis titles
19px   ← Lead paragraphs (min)
24px   ← Lead paragraphs (max)
```

### **What the Design System DOES Provide:**

```
12.8px (--text-xs)
16px   (--text-sm)
20px   (--text-base)
25px   (--text-lg)
31.25px (--text-xl)
39px   (--text-2xl)
48.8px (--text-3xl)
```

### **The Gap:**

Between **12.8px and 16px**, we need **14px** for compact layouts.
Between **16px and 20px**, we need **17px, 19px** for specific hierarchies.
Between **20px and 25px**, we need **24px** for lead paragraph maximums.

**This is why hardcoded values exist!**

---

---

## 💡 **SHOULD WE FIX THIS?**

### **Option A: Keep Status Quo** ⚠️
**Pros:**
- Values were chosen intentionally for visual reasons
- Real-world testing proved they work
- Maintains optical precision

**Cons:**
- Inconsistent with design system
- Harder to maintain
- New developers might not understand why

---

### **Option B: Force Everything to Design System** ❌
**Pros:**
- Perfect consistency
- Easier to remember

**Cons:**
- **Will break visual balance in sidebars**
- **Will cause text wrapping in Impact cards**
- **Will make navbar imprecise (client requirement)**
- **Will lose hierarchical nuance (13px list numbers)**

---

### **Option C: Extend Design System** ✅ **RECOMMENDED**
Add missing sizes that we actually need:

```css
--text-2xs: 0.75rem;    /* 12px - Navbar, micro labels */
--text-xs: 0.875rem;    /* 14px - Compact body (shift from 12.8px) */
--text-sm: 1rem;        /* 16px - Body (stays the same) */
--text-md: 1.125rem;    /* 18px - Medium emphasis (NEW) */
--text-base: 1.25rem;   /* 20px - Large body (stays) */
```

**Then map hardcoded values:**
- 9.5px → Stay as is (too small for scale, optical choice)
- 11px → Stay as is (Navbar precision)
- 12px → var(--text-2xs) (12px)
- 13px → Stay as is OR shift to 14px (--text-xs)
- 14px → var(--text-xs) (14px)
- 17px → Stay as is OR shift to 18px (--text-md)
- 19-24px → Stay as clamp() (responsive precision needed)

---

---

## 🎯 **FINAL RECOMMENDATION**

### **DO FIX:**
1. ✅ **Impact metrics** - Use `var(--text-2xl)` (39px) and test if wrapping is OK
2. ✅ **Missing --text-4xl** - Add to design system for completeness

### **DO NOT FIX:**
1. ❌ **Client Context micro-sizes** (9.5px, 13px, 17px) - Intentional optical tuning
2. ❌ **Navbar hardcoded values** - Client requirement for Figma precision
3. ❌ **Company overview clamp** - Responsive range is intentional
4. ❌ **Dynamic question sizing** - Content-aware behavior is a feature

### **CONSIDER:**
1. ⚠️ **Add --text-2xs (12px)** if we want consistency for navbar/micro-labels
2. ⚠️ **Document rationale** in code comments so future devs understand

---

---

## 📝 **DOCUMENTATION FOR CODE COMMENTS**

Add these comments to preserve knowledge:

```tsx
// Client Context - Sidebar Typography
// Using custom sizes for optical balance in narrow sidebar (33% width)
// 9.5px labels: Subtle micro-labels (--text-xs 12.8px too large)
// 17px name: Prevents wrapping of long company names
// 13px industry: Creates hierarchy (label < industry < name)
fontSize: '9.5px'  // Intentional - see FONT_SIZE_RATIONALE_ANALYSIS.md

// Impact Section - Display Metrics
// Using 40px max to prevent wrapping of currency values (₹110 Cr)
// Tested: 39px causes wrapping edge cases in 4-column layout
// Note: 1px difference matters for real-world content stability
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 40px prevents wrapping

// Challenges - Dynamic Typography
// Adaptive sizing based on content density (2-10+ cards)
// 4+ cards: 14px for compact layout | <4 cards: 16px for spacious layout
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'

// Company Overview - Lead Paragraph
// Responsive range: 19px (mobile) → 24px (desktop)
// Sits between body (16px) and heading (25px) in hierarchy
// Smooth viewport scaling for editorial "lead paragraph" treatment
fontSize: 'clamp(19px, 2.8vw, 24px)'
```

---

**Analysis Complete** ✅  
**Recommendation:** Most hardcoded values are intentional and should stay. Fix only the obvious gaps (missing --text-4xl) and test if Impact metrics can use design system variable.

