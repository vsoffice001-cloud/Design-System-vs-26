# 🎯 UX/UI FIX ACTION PLAN
**Prioritized Implementation Roadmap**

---

## 📊 **EXECUTIVE SUMMARY**

**Total Issues:** 23 (8 Critical, 10 Moderate, 5 Minor)  
**Estimated Fix Time:** 4 weeks  
**Priority:** Start with Critical (Week 1)  
**Goal:** 95+ Lighthouse score, WCAG AA compliant

---

## 🚨 **PHASE 1: CRITICAL FIXES (Week 1)**
**Priority:** 🔴 **URGENT** - Must fix for production launch  
**Estimated Time:** 5-7 days  
**Impact:** Accessibility, Legal compliance (ADA/WCAG)

### **1.1 Accessibility - Focus States** ⏱️ 4 hours
**Issue:** No focus indicators on interactive elements  
**Impact:** Keyboard users can't navigate  
**WCAG:** 2.4.7 (Focus Visible)

**Files to Update:**
- `Navbar.tsx`
- `ClientContextSection.tsx` (CTA button)
- `ChallengesSection.tsx` (cards)
- `EngagementObjectivesSection.tsx` (cards)
- `MethodologySection.tsx` (timeline)
- `ResourcesSection.tsx` (cards)
- `FinalCTASection.tsx` (button)

**Implementation:**
```tsx
// Add to ALL interactive elements (buttons, links, cards)
className="focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2 transition-all"

// For dark backgrounds
className="focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-black transition-all"

// Example: Navbar link
<a 
  href="#section" 
  className="hover:text-black transition-colors focus:outline-none focus:ring-2 focus:ring-black focus:rounded px-2 py-1"
>
  Section
</a>

// Example: Button
<button
  className="px-6 py-3 bg-black text-white rounded-[5px] hover:bg-black/90 focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2 transition-all"
>
  Click Me
</button>
```

---

### **1.2 Accessibility - Color Contrast** ⏱️ 2 hours
**Issue:** `text-black/60` and `text-white/40` fail WCAG AA  
**Impact:** Hard to read for visually impaired users  
**WCAG:** 1.4.3 (Contrast Minimum)

**Required Changes:**
```tsx
// FIND AND REPLACE across all components

// BEFORE
text-black/60  // Contrast ratio: 4.2:1 ❌ (needs 4.5:1)
text-white/40  // Contrast ratio: 3.1:1 ❌

// AFTER
text-black/70  // Contrast ratio: 5.8:1 ✅
text-white/60  // Contrast ratio: 6.2:1 ✅
```

**Files to Update:**
- `ClientContextSection.tsx` - Lines with `text-black/60`
- `EngagementObjectivesSection.tsx` - Description text
- `MethodologySection.tsx` - Description text
- `ImpactSection.tsx` - Description text
- `FinalCTASection.tsx` - Description text
- `HeroSection.tsx` - Card text `text-white/70` is okay

**Quick Fix Script:**
```bash
# Find all instances
grep -r "text-black/60" src/app/components/

# Replace (manually review each)
# text-black/60 → text-black/70
```

---

### **1.3 Accessibility - ARIA Labels** ⏱️ 3 hours
**Issue:** Missing ARIA labels on icons, decorative elements  
**Impact:** Screen readers can't understand content  
**WCAG:** 1.1.1 (Non-text Content)

**Required Updates:**

#### **Navbar:**
```tsx
// Add skip link
<a 
  href="#main-content" 
  className="sr-only focus:not-sr-only focus:absolute focus:top-0 focus:left-0 focus:z-50 focus:px-4 focus:py-2 focus:bg-white focus:text-black"
>
  Skip to main content
</a>

// Add aria-label to nav
<nav aria-label="Main navigation">
  {/* nav content */}
</nav>
```

#### **Main Content:**
```tsx
// Add to App.tsx
<main id="main-content">
  {/* All sections */}
</main>
```

#### **Challenges Scroll Arrow:**
```tsx
<p 
  className="text-black/40 items-center gap-2" 
  role="status" 
  aria-live="polite"
>
  <span>Scroll to explore</span>
  <svg 
    className="w-4 h-4" 
    aria-hidden="true" // Decorative icon
    fill="none" 
    viewBox="0 0 24 24" 
    stroke="currentColor"
  >
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
</p>
```

#### **Testimonial Stars:**
```tsx
<div className="flex items-center gap-2">
  <span className="sr-only">Rating: 4.97 out of 5 stars</span>
  <div className="flex gap-1" aria-hidden="true">
    {[1, 2, 3, 4, 5].map((star) => (
      <svg key={star} className="w-4 h-4 fill-black" viewBox="0 0 20 20">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
    ))}
  </div>
  <span className="font-medium text-black/60" style={{ fontSize: 'var(--text-xs)' }}>
    4.97 / 5
  </span>
</div>
```

---

### **1.4 Mobile - Touch Target Sizes** ⏱️ 3 hours
**Issue:** Touch targets < 44x44px (WCAG 2.5.5)  
**Impact:** Hard to tap on mobile  
**WCAG:** 2.5.5 (Target Size)

**Files to Update:**

#### **Navbar:**
```tsx
// BEFORE
<a 
  href="#section" 
  className="text-black/50 hover:text-black transition-colors" 
  style={{ fontSize: 'var(--text-2xs)' }} // 12px
>

// AFTER
<a 
  href="#section" 
  className="text-black/50 hover:text-black transition-colors py-3 px-4" // Increased padding
  style={{ fontSize: 'var(--text-2xs)' }}
>
```

#### **Challenge Cards (Mobile):**
```tsx
// Cards already have good padding (p-5 md:p-6)
// But card index indicator is small:

// BEFORE
<div className="text-black/30 font-medium mt-1" style={{ fontSize: 'var(--text-xs)' }}>
  {index + 1} / {challenges.length}
</div>

// AFTER
<div className="text-black/30 font-medium mt-1 py-2" style={{ fontSize: 'var(--text-xs)' }}>
  {index + 1} / {challenges.length}
</div>
```

#### **Methodology Timeline Nodes:**
```tsx
// BEFORE (Mobile)
<div className="w-3 h-3 rounded-full..."> // 12x12px ❌

// AFTER (Mobile)
<div className="w-5 h-5 sm:w-4 sm:h-4 rounded-full..."> // 20x20px mobile, 16x16px tablet ✅
```

---

### **1.5 Keyboard Navigation - Timeline & Horizontal Scroll** ⏱️ 4 hours
**Issue:** Timeline and horizontal scroll not keyboard accessible  
**Impact:** Keyboard users can't navigate  
**WCAG:** 2.1.1 (Keyboard)

#### **Methodology Timeline:**
```tsx
// Add to MethodologySection.tsx
import { useState, useEffect } from 'react';

export function MethodologySection({ steps }: MethodologySectionProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.preventDefault();
        setCurrentStepIndex((prev) => Math.min(prev + 1, steps.length - 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault();
        setCurrentStepIndex((prev) => Math.max(prev - 1, 0));
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [steps.length]);
  
  return (
    <section 
      className="..." 
      tabIndex={0} // Make focusable
      aria-label="Methodology timeline"
      role="region"
    >
      {/* Timeline content */}
      <div aria-live="polite" aria-atomic="true" className="sr-only">
        Step {currentStepIndex + 1} of {steps.length}: {steps[currentStepIndex].title}
      </div>
    </section>
  );
}
```

#### **Challenges Horizontal Scroll:**
```tsx
// Add keyboard nav to ChallengesSection.tsx
const scrollContainerRef = useRef<HTMLDivElement>(null);

const handleKeyDown = (e: KeyboardEvent) => {
  if (!scrollContainerRef.current) return;
  
  if (e.key === 'ArrowRight') {
    e.preventDefault();
    scrollContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
  } else if (e.key === 'ArrowLeft') {
    e.preventDefault();
    scrollContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
  }
};

return (
  <div 
    ref={scrollContainerRef}
    className="flex gap-4 md:gap-6 overflow-x-auto..."
    onKeyDown={handleKeyDown}
    tabIndex={0}
    role="region"
    aria-label="Challenges list"
  >
    {/* Cards */}
  </div>
);
```

---

### **1.6 Navbar Scroll Offset** ⏱️ 1 hour
**Issue:** Fixed navbar covers content when scrolling to sections  
**Impact:** First line hidden behind navbar  
**Fix:** Add scroll-margin-top

**Update theme.css:**
```css
@layer base {
  /* Add scroll margin for all sections */
  section {
    scroll-margin-top: 120px; /* Navbar height + buffer */
  }
  
  /* Or target specific elements */
  [id] {
    scroll-margin-top: 120px;
  }
}
```

---

### **1.7 Final CTA - Form Implementation** ⏱️ 6 hours
**Issue:** "Contact Our Team" button goes nowhere  
**Impact:** Dead end for interested users  
**Priority:** 🔴 Critical for conversion

**Option A: Modal Form (Recommended)**
```tsx
// Create ContactModal.tsx
import { useState } from 'react';
import { X } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ContactModal({ isOpen, onClose }: ContactModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // TODO: Replace with actual API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsSuccess(true);
    setIsSubmitting(false);
    
    setTimeout(() => {
      onClose();
      setIsSuccess(false);
    }, 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-[10px] max-w-[500px] w-full p-6 md:p-8 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-black/40 hover:text-black transition-colors"
          aria-label="Close modal"
        >
          <X className="w-6 h-6" />
        </button>

        {isSuccess ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-xl font-medium mb-2">Thank you!</h3>
            <p className="text-black/70">We'll get back to you within 24 hours.</p>
          </div>
        ) : (
          <>
            <h3 className="text-2xl font-medium mb-2">Get in Touch</h3>
            <p className="text-black/70 mb-6">Tell us about your project and we'll respond within 24 hours.</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-2">
                  Name *
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 border border-black/10 rounded-[5px] focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="Your name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 border border-black/10 rounded-[5px] focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label htmlFor="company" className="block text-sm font-medium mb-2">
                  Company
                </label>
                <input
                  type="text"
                  id="company"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full px-4 py-3 border border-black/10 rounded-[5px] focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="Your company"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-2">
                  Message *
                </label>
                <textarea
                  id="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 border border-black/10 rounded-[5px] focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent resize-none"
                  placeholder="Tell us about your project..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full px-6 py-3.5 bg-black text-white rounded-[5px] font-medium hover:bg-black/90 focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Sending...
                  </>
                ) : (
                  'Send Message'
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
```

**Update FinalCTASection.tsx:**
```tsx
import { useState } from 'react';
import { ContactModal } from '@/app/components/ContactModal';

export function FinalCTASection() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <section className="py-12 sm:py-16 md:py-20 bg-white border-t border-black/10">
        {/* ... existing content ... */}
        
        <button
          onClick={() => setIsModalOpen(true)}
          className="px-8 py-4 bg-black text-white rounded-[5px] font-medium hover:bg-black/90 hover:shadow-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2"
          style={{ fontSize: 'var(--text-sm)', letterSpacing: '0.3px' }}
        >
          Contact Our Team
        </button>
      </section>

      <ContactModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
```

---

## 🎯 **PHASE 1 SUMMARY**

### **Completed Tasks:**
- [ ] Add focus states to all interactive elements
- [ ] Fix color contrast (text-black/60 → text-black/70)
- [ ] Add ARIA labels and landmarks
- [ ] Increase mobile touch targets
- [ ] Add keyboard navigation (timeline, horizontal scroll)
- [ ] Fix navbar scroll offset
- [ ] Implement Final CTA modal form

### **Time Estimate:** 23 hours (3 days)
### **Priority:** 🔴 Critical
### **Impact:** Legal compliance, accessibility, usability

---

## 🟡 **PHASE 2: UX IMPROVEMENTS (Week 2)**
**Priority:** 🟡 High - Improves user experience  
**Estimated Time:** 5-7 days

### **2.1 Loading States** ⏱️ 3 hours
### **2.2 Active Nav Indicator** ⏱️ 2 hours
### **2.3 Dot Navigation (Challenges)** ⏱️ 3 hours
### **2.4 "Next Section" CTAs** ⏱️ 4 hours
### **2.5 Testimonial Author Photo** ⏱️ 1 hour
### **2.6 External Link Icons** ⏱️ 2 hours
### **2.7 Timeline Mobile Improvements** ⏱️ 4 hours

---

## 🟢 **PHASE 3: POLISH (Week 3)**
**Priority:** 🟢 Medium - Nice to have  
**Estimated Time:** 5-7 days

### **3.1 Skeleton Loaders** ⏱️ 6 hours
### **3.2 Error Boundaries** ⏱️ 4 hours
### **3.3 Lazy Loading Images** ⏱️ 2 hours
### **3.4 Smooth Animations** ⏱️ 4 hours
### **3.5 Print Styles** ⏱️ 3 hours

---

## 📈 **PHASE 4: SEO & PERFORMANCE (Week 4)**
**Priority:** 🟢 Medium - Long-term benefit  
**Estimated Time:** 5-7 days

### **4.1 Meta Tags & Open Graph** ⏱️ 2 hours
### **4.2 Structured Data (JSON-LD)** ⏱️ 3 hours
### **4.3 Sitemap & Robots.txt** ⏱️ 1 hour
### **4.4 Performance Optimization** ⏱️ 6 hours
### **4.5 Analytics Integration** ⏱️ 3 hours

---

## ✅ **SUCCESS METRICS**

### **Before Fixes:**
- Lighthouse Accessibility: 75/100
- Lighthouse Performance: 85/100
- WCAG AA Compliance: 60%
- Mobile Usability: 70%

### **After Phase 1 (Target):**
- Lighthouse Accessibility: 90+/100
- Lighthouse Performance: 85/100
- WCAG AA Compliance: 95%
- Mobile Usability: 90%

### **After All Phases (Target):**
- Lighthouse Accessibility: 95+/100
- Lighthouse Performance: 95+/100
- WCAG AA Compliance: 100%
- Mobile Usability: 95+%

---

**Ready to start implementation?** Begin with Phase 1, Task 1.1 (Focus States).

