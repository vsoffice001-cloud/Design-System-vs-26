# Pattern Library Reference

**Last Updated:** January 21, 2026  
**Version:** 1.0.0

---

## Overview

This document catalogs all **Organisms** - complex UI patterns that combine multiple molecules and atoms into complete interface sections. Each pattern includes layout specifications, responsive behavior, content guidelines, and implementation examples.

---

## 🦸 Hero Section Pattern

The first impression. Sets tone for entire experience.

### Standard Hero Layout

```tsx
<section className="bg-black text-white min-h-[600px] flex items-center py-20">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8 text-center">
    <h1 className="text-[var(--text-3xl)] font-bold mb-6">
      Main Headline Goes Here
    </h1>
    <p className="text-[var(--text-base)] text-white/70 mb-8 max-w-[700px] mx-auto">
      Supporting description that explains value proposition in 1-2 sentences.
    </p>
    <div className="flex flex-wrap gap-4 justify-center">
      <Button variant="brand" size="lg" icon={<ArrowRight />} iconPosition="right">
        Primary CTA
      </Button>
      <Button variant="ghost" size="lg">
        Secondary Action
      </Button>
    </div>
  </div>
</section>
```

### Specifications

| Element | Value | Token Reference |
|---------|-------|-----------------|
| Background | `#000000` | `--color-black` |
| Min Height | `600px` | Desktop hero |
| Vertical Padding | `py-20` (80px) | `--spacing-20` |
| Max Width | `1000px` | `--max-width-content` |
| Heading | `--text-3xl` (48.8px) | Reserved for hero |
| Body Text | `--text-base` (20px) | Large body |
| Body Opacity | `70%` | `--opacity-secondary` |
| CTA Spacing | `gap-4` (16px) | `--spacing-4` |

### Content Guidelines

- **Heading:** 5-10 words max, action-oriented
- **Description:** 15-25 words, value proposition
- **CTAs:** Maximum 2 buttons (brand + ghost)
- **Alignment:** Center for impact

### Responsive Behavior

```tsx
/* Mobile (< 768px) */
- min-h-[500px]
- py-16 (instead of py-20)
- text-[2.5rem] heading (adjust for mobile)
- Stack buttons vertically on very small screens

/* Tablet (768px - 1024px) */
- min-h-[600px]
- Standard sizing

/* Desktop (> 1024px) */
- min-h-[600px]
- Consider min-h-[80vh] for full-screen impact
```

---

## 📑 Section Header Pattern

Introduces content sections with consistent hierarchy.

### Standard Section Header

```tsx
<div className="mb-12">
  <span className="text-xs uppercase tracking-wider text-black/40 mb-2 block">
    SECTION CATEGORY
  </span>
  <h2 className="text-4xl font-bold text-black mb-3">
    Section Heading
  </h2>
  <p className="text-base text-black/60 max-w-[700px]">
    Optional section description providing context for the content below.
  </p>
</div>
```

### Specifications

| Element | Value | Notes |
|---------|-------|-------|
| Eyebrow | `--text-xs`, uppercase, 40% opacity | Optional category label |
| Heading | `--text-2xl` (39px) | Standard H2 |
| Description | `--text-base` (20px), 60% opacity | Optional context |
| Max Width | `700px` | Prevents wide paragraphs |
| Bottom Margin | `mb-12` (48px) | Space before content |

---

## 🎯 CTA Section Pattern

Black background sections designed for conversion.

### Centered CTA Layout

```tsx
<section className="bg-black py-20">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    <div className="bg-black rounded-[10px] p-12 text-center">
      <h3 className="text-3xl font-bold text-white mb-4">
        Ready to Get Started?
      </h3>
      <p className="text-base text-white/70 mb-8 max-w-[600px] mx-auto">
        Supporting description text that provides context and encourages action.
      </p>
      <div className="flex flex-wrap gap-4 justify-center">
        <Button 
          variant="brand" 
          size="lg"
          icon={<ArrowRight className="w-4 h-4" />}
          iconPosition="right"
        >
          Primary Action
        </Button>
        <Button variant="ghost" size="lg">
          Secondary Action
        </Button>
      </div>
    </div>
  </div>
</section>
```

### Specifications

- **Background:** Pure black (`#000000`)
- **Padding:** `py-20` (80px vertical)
- **Container Padding:** `p-12` (48px all sides)
- **Heading:** `--text-3xl` (48.8px), white
- **Description:** `--text-base` (20px), 70% white
- **Description Max Width:** `600px` (centered)
- **Button Spacing:** `gap-4` (16px)

### Usage Rules

- ✅ Place at end of major sections
- ✅ Use brand button for primary action
- ✅ Pair with ghost button for alternatives
- ✅ Keep heading action-oriented (question or imperative)
- ❌ Never use more than 2 buttons
- ❌ Avoid in consecutive sections

---

## 📊 Stats Grid Pattern

Displays key metrics in organized grid.

### 4-Column Stats Grid (Highlighted)

```tsx
<section className="py-20 bg-white">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Section Header */}
    <div className="mb-12">
      <h2 className="text-4xl font-bold text-black mb-3">Key Metrics</h2>
      <p className="text-base text-black/60 max-w-[700px]">
        Overview of our impact and achievements.
      </p>
    </div>
    
    {/* Stats Container */}
    <div className="bg-[#f5f2f1] rounded-[10px] p-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <div className="text-4xl font-bold text-black mb-2">
              {stat.value}
            </div>
            <div className="text-sm font-bold text-black mb-1">
              {stat.label}
            </div>
            <div className="text-xs text-black/60">
              {stat.description}
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
</section>
```

### Specifications

| Element | Specification |
|---------|--------------|
| Container Background | `#f5f2f1` (warm) |
| Container Radius | `10px` |
| Container Padding | `p-12` (48px) |
| Grid Columns | 1 → 2 (md) → 4 (lg) |
| Grid Gap | `gap-8` (32px) |
| Value Size | `--text-4xl` (61px) |
| Label Size | `--text-sm` (16px), bold |
| Description Size | `--text-xs` (12.8px), 60% opacity |
| Alignment | Center |

### Responsive Grid

```css
/* Mobile (< 768px) */
grid-cols-1 (stacked)

/* Tablet (768px - 1024px) */
grid-cols-2 (2 columns)

/* Desktop (> 1024px) */
grid-cols-4 (4 columns)
```

### Content Guidelines

- **Values:** Use compact formats (2.4K+, 98%, $1.2M)
- **Labels:** 2-4 words max
- **Descriptions:** Optional, 3-6 words explaining context
- **Optimal Count:** 4 stats (fits grid perfectly)
- **Acceptable Range:** 2-6 stats

---

### Alternative: Simple Metric Cards

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
  {metrics.map((metric) => (
    <div key={metric.label} className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
      <div className="text-3xl font-bold text-black mb-2">{metric.value}</div>
      <div className="text-sm text-black/60">{metric.label}</div>
    </div>
  ))}
</div>
```

**When to use:**
- Individual card emphasis
- Simpler layouts
- Fewer stats (2-3)

---

## 🎴 Feature Grid Pattern

Showcases features or benefits in organized grid.

### Numbered Feature Grid (2x2)

```tsx
<section className="py-20 bg-white">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Section Header */}
    <div className="mb-12">
      <h2 className="text-4xl font-bold text-black mb-3">Key Features</h2>
    </div>
    
    {/* Feature Grid */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {features.map((feature) => (
        <div 
          key={feature.number} 
          className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5"
        >
          <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
            {feature.number}
          </div>
          <h4 className="text-xl font-bold mb-3">{feature.title}</h4>
          <p className="text-sm text-black/60">{feature.description}</p>
        </div>
      ))}
    </div>
  </div>
</section>
```

### Specifications

| Element | Specification |
|---------|--------------|
| Grid Layout | 1 col → 2 cols (md) |
| Card Background | `#f5f2f1` |
| Card Radius | `10px` |
| Card Padding | `p-8` (32px) |
| Grid Gap | `gap-6` (24px) |
| Number Badge | 48x48px, black, 5px radius |
| Title Size | `--text-xl` (31.25px) |
| Description Size | `--text-sm` (16px) |

### Content Guidelines

- **Number:** 01, 02, 03, etc. (leading zeros for alignment)
- **Title:** 3-6 words, benefit-focused
- **Description:** 15-30 words explaining value
- **Optimal Count:** 4 features (2x2 grid)
- **Acceptable Range:** 2-6 features

### Grid Variations

**3-Column Layout (6 features):**
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
```

**1-Column Layout (detailed features):**
```tsx
<div className="grid grid-cols-1 gap-6 max-w-[700px] mx-auto">
```

---

## ❓ Challenge/Question Card Pattern

Presents problems or exploratory questions.

### Challenge Card Grid

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
  {challenges.map((challenge) => (
    <div 
      key={challenge.number} 
      className="bg-white rounded-[10px] p-8 shadow-md border border-black/5"
    >
      <div className="text-5xl font-bold text-black/5 mb-4">
        {challenge.number}
      </div>
      <h4 className="text-xl font-bold mb-4">{challenge.title}</h4>
      <ul className="space-y-2">
        {challenge.questions.map((question, idx) => (
          <li key={idx} className="text-sm text-black/70 flex gap-2">
            <span className="text-black/30">→</span>
            <span>{question}</span>
          </li>
        ))}
      </ul>
    </div>
  ))}
</div>
```

### Specifications

- **Background:** White with shadow
- **Large Number:** `--text-5xl`, 5% opacity (watermark)
- **Title:** `--text-xl` (31.25px)
- **Questions:** `--text-sm` (16px), 70% opacity
- **Bullet:** Arrow (→), 30% opacity
- **Question Count:** 3-5 per card

### Usage

- Problem exploration
- Strategic questions
- Challenge presentation
- Discovery processes

---

## 🎨 Alternating Section Pattern

Black/white alternating backgrounds for visual rhythm.

### Pattern Structure

```tsx
{/* Section 1 - White */}
<section className="py-20 bg-white">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Content */}
  </div>
</section>

{/* Section 2 - Warm */}
<section className="py-20 bg-[#f5f2f1]">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Content */}
  </div>
</section>

{/* Section 3 - Black */}
<section className="py-20 bg-black text-white">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Content */}
  </div>
</section>
```

### Background Sequence Rules

**Standard Rhythm:**
1. **Black** - Hero (first impression)
2. **White** - Content section
3. **Warm** (`#f5f2f1`) - Highlighted content/stats
4. **White** - Content section
5. **Black** - CTA section
6. **Warm** - Testimonials/features
7. **Black** - Final CTA/Footer

**Guidelines:**
- ✅ Alternate for visual rhythm
- ✅ Use warm for "special" content (stats, testimonials)
- ✅ Black sections for CTAs and high contrast
- ❌ Never use 3+ consecutive white sections
- ❌ Never alternate black-white-black-white without warm

---

## 🗣️ Testimonial Pattern

Social proof and validation.

### Single Testimonial Card

```tsx
<div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
  <div className="mb-6">
    <p className="text-base text-black/80 italic leading-relaxed">
      "Testimonial quote goes here. Keep it authentic and specific to build trust."
    </p>
  </div>
  <div className="flex items-center gap-4">
    <div className="w-12 h-12 rounded-full bg-black/10 flex items-center justify-center">
      <User className="w-6 h-6 text-black/40" />
    </div>
    <div>
      <div className="font-bold text-sm">Person Name</div>
      <div className="text-xs text-black/60">Title, Company</div>
    </div>
  </div>
</div>
```

### Specifications

- **Background:** Warm (`#f5f2f1`)
- **Quote Size:** `--text-base` (20px), italic
- **Quote Opacity:** 80%
- **Name:** `--text-sm` (16px), bold
- **Title:** `--text-xs` (12.8px), 60% opacity
- **Avatar:** 48x48px circle

### Content Guidelines

- **Quote Length:** 15-40 words
- **Specificity:** Include specific results/benefits
- **Attribution:** Full name + title + company
- **Authenticity:** Real quotes only

---

## 📱 Responsive Container Pattern

Standard responsive wrapper for all sections.

### Container Template

```tsx
<section className="py-16 md:py-20">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Section content */}
  </div>
</section>
```

### Breakpoint Behavior

| Breakpoint | Padding X | Container Width |
|------------|-----------|-----------------|
| Mobile (< 640px) | `px-4` (16px) | Full width - 32px |
| Tablet (640px+) | `sm:px-6` (24px) | Full width - 48px |
| Desktop (768px+) | `md:px-8` (32px) | Max 1000px centered |

### Vertical Padding

```tsx
/* Mobile */
py-16 (64px)

/* Desktop */
md:py-20 (80px)
```

---

## 🎬 Animation Patterns

### Scroll-triggered Fade In

```tsx
<div className="opacity-0 animate-fadeIn">
  {/* Content */}
</div>
```

```css
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fadeIn {
  animation: fadeIn 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
}
```

### Stagger Children Animation

```tsx
{items.map((item, index) => (
  <div 
    key={item.id}
    style={{ animationDelay: `${index * 100}ms` }}
    className="opacity-0 animate-fadeIn"
  >
    {/* Item content */}
  </div>
))}
```

---

## 🏗️ Layout Patterns

### Two-Column Content Layout

```tsx
<div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
  {/* Left: Content */}
  <div>
    <h3 className="text-3xl font-bold mb-4">Heading</h3>
    <p className="text-base text-black/70">Description</p>
  </div>
  
  {/* Right: Visual/Stats */}
  <div>
    {/* Image or stats grid */}
  </div>
</div>
```

### Three-Column Feature Layout

```tsx
<div className="grid grid-cols-1 md:grid-cols-3 gap-8">
  {features.map((feature) => (
    <div key={feature.id} className="text-center">
      <div className="w-16 h-16 mx-auto mb-4 bg-black/5 rounded-[5px] flex items-center justify-center">
        <Icon className="w-8 h-8" />
      </div>
      <h4 className="text-lg font-bold mb-2">{feature.title}</h4>
      <p className="text-sm text-black/60">{feature.description}</p>
    </div>
  ))}
</div>
```

---

## ✅ Pattern Usage Checklist

Before implementing a pattern:

- [ ] **Background color** follows alternating rhythm
- [ ] **Vertical padding** is consistent (py-16 or py-20)
- [ ] **Max width** is enforced (1000px for content)
- [ ] **Responsive behavior** is defined for all breakpoints
- [ ] **Grid gaps** use standard spacing (gap-6 or gap-8)
- [ ] **Typography hierarchy** flows naturally
- [ ] **CTA placement** is logical and not overwhelming
- [ ] **Content guidelines** are followed (word counts, specificity)

---

## 🔗 Related Documentation

- [Design Tokens](./DESIGN_TOKENS.md) - Values used in patterns
- [Component Library](./COMPONENT_LIBRARY.md) - Building blocks of patterns
- [Design Principles](./DESIGN_PRINCIPLES.md) - Why patterns are structured this way

---

**End of Pattern Library Reference**
