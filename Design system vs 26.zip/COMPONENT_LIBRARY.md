# Component Library Reference

**Last Updated:** January 21, 2026  
**Version:** 1.0.0

---

## Overview

This document catalogs all **Molecules** - reusable UI components that combine design tokens (atoms) into functional building blocks. Each component specification includes props, variants, states, usage guidelines, and code examples.

---

## 🔘 Button Component

The most critical component in the design system. Handles all user actions and conversions.

### Location
`/src/app/components/Button.tsx`

### Component Signature

```typescript
interface ButtonProps {
  children: React.ReactNode;
  variant?: 'brand' | 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  loading?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
}
```

---

### Button Variants

#### 1. Brand Variant (`variant="brand"`)

**Visual Specification:**
- **Background:** Red gradient `linear-gradient(90deg, #b01f24, #c62d31)`
- **Background Size:** `200% 200%` for animation
- **Text Color:** White
- **Border:** None
- **Border Radius:** `5px`
- **Shadow (Default):** `0 8px 24px rgba(176, 31, 36, 0.15)`
- **Shadow (Hover):** `0 12px 32px rgba(176, 31, 36, 0.25)`
- **Transition:** `all 0.6s cubic-bezier(0.22, 1, 0.36, 1)`

**States:**
```css
/* Default */
background: linear-gradient(90deg, #b01f24, #c62d31);
background-position: 0% 50%;

/* Hover */
background-position: 100% 50%;
transform: translateY(-2px);
box-shadow: 0 12px 32px rgba(176, 31, 36, 0.25);

/* Active */
transform: translateY(0);
box-shadow: 0 6px 16px rgba(176, 31, 36, 0.2);

/* Disabled */
opacity: 0.5;
cursor: not-allowed;
```

**Usage Rules:**
- ✅ **ONLY** for highest-priority CTAs
- ✅ Maximum 1 per viewport section
- ✅ Primary conversion actions (Schedule Demo, Get Report, Contact Us)
- ❌ Never for secondary actions
- ❌ Never for navigation
- ❌ Never multiple brand buttons in same view

**Example:**
```tsx
<Button 
  variant="brand" 
  size="lg"
  icon={<ArrowRight className="w-4 h-4" />}
  iconPosition="right"
>
  Schedule a Demo
</Button>
```

---

#### 2. Primary Variant (`variant="primary"`)

**Visual Specification:**
- **Background:** Dark-to-grey gradient `linear-gradient(90deg, #0a0a0a, #6a6a6a)`
- **Text Color:** White
- **Border:** None
- **Border Radius:** `5px`
- **Shadow:** `0 4px 12px rgba(0, 0, 0, 0.15)`

**States:**
```css
/* Default */
background: linear-gradient(90deg, #0a0a0a, #6a6a6a);

/* Hover */
transform: translateY(-1px);
box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);

/* Active */
transform: translateY(0);
```

**Usage Rules:**
- ✅ Secondary important actions
- ✅ When brand variant is already present
- ✅ Form submissions
- ✅ Download actions

**Example:**
```tsx
<Button 
  variant="primary" 
  size="lg"
  icon={<Download className="w-4 h-4" />}
  iconPosition="right"
>
  Download Report
</Button>
```

---

#### 3. Secondary Variant (`variant="secondary"`)

**Visual Specification:**
- **Background:** White `#ffffff`
- **Text Color:** Black `#000000`
- **Border:** `1px solid rgba(0, 0, 0, 0.2)`
- **Border Radius:** `5px`
- **Shadow:** None (or very subtle)

**States:**
```css
/* Default */
background: #ffffff;
border: 1px solid rgba(0, 0, 0, 0.2);

/* Hover */
background: #f5f5f5;
border-color: rgba(0, 0, 0, 0.3);

/* Active */
background: #ebebeb;
```

**Usage Rules:**
- ✅ Alternative actions paired with primary/brand
- ✅ "Learn More" or "View Details"
- ✅ Lower-priority CTAs
- ✅ Works on both light and warm backgrounds

**Example:**
```tsx
<Button variant="secondary" size="lg">
  Learn More
</Button>
```

---

#### 4. Ghost Variant (`variant="ghost"`)

**Visual Specification:**
- **Background:** Transparent
- **Text Color:** White `#ffffff` (on dark) or Black `#000000` (on light)
- **Border:** `1px solid rgba(255, 255, 255, 0.2)` (on dark)
- **Border Radius:** `5px`

**States:**
```css
/* Default */
background: transparent;
border: 1px solid rgba(255, 255, 255, 0.2);

/* Hover */
background: rgba(255, 255, 255, 0.1);
border-color: rgba(255, 255, 255, 0.3);

/* Active */
background: rgba(255, 255, 255, 0.05);
```

**Usage Rules:**
- ✅ Tertiary actions
- ✅ **ONLY** on dark backgrounds (black sections)
- ✅ Paired with brand button in CTAs
- ✅ "View All Resources" type links
- ❌ Never use on light backgrounds

**Example:**
```tsx
{/* On black background */}
<div className="bg-black p-12">
  <Button 
    variant="ghost" 
    size="lg"
    icon={<ArrowRight className="w-4 h-4" />}
    iconPosition="right"
  >
    View All Resources
  </Button>
</div>
```

---

### Button Sizes

| Size | Height | Padding X | Font Size | Icon Size | Usage |
|------|--------|-----------|-----------|-----------|-------|
| `sm` | 40px | 16px | 14px | 16px | Compact UIs, secondary actions |
| `md` | 48px | 20px | 16px | 18px | Standard buttons, forms |
| `lg` | 56px | 24px | 16px | 18px | **Primary CTAs, hero sections** |
| `xl` | 64px | 32px | 18px | 20px | Extra prominent CTAs (rare) |

**Standard Size:** `lg` for all major CTAs

**Example:**
```tsx
<Button variant="brand" size="sm">Small</Button>
<Button variant="brand" size="md">Medium</Button>
<Button variant="brand" size="lg">Large (Default)</Button>
<Button variant="brand" size="xl">Extra Large</Button>
```

---

### Button States

#### Loading State
```tsx
<Button variant="brand" size="lg" loading>
  Processing...
</Button>
```

**Visual:**
- Shows spinner animation
- Text changes to loading message
- Button disabled during loading
- Maintains width to prevent layout shift

#### Disabled State
```tsx
<Button variant="brand" size="lg" disabled>
  Unavailable
</Button>
```

**Visual:**
- `opacity: 0.5`
- `cursor: not-allowed`
- No hover effects
- Maintains visual structure

#### With Icon
```tsx
{/* Icon Right (Standard for CTAs) */}
<Button 
  variant="brand" 
  size="lg"
  icon={<ArrowRight className="w-4 h-4" />}
  iconPosition="right"
>
  Get Started
</Button>

{/* Icon Left (Downloads, Actions) */}
<Button 
  variant="primary" 
  size="lg"
  icon={<Download className="w-4 h-4" />}
  iconPosition="left"
>
  Download Report
</Button>
```

**Icon Rules:**
- ✅ Arrow right for forward actions (Get Started, Continue)
- ✅ Arrow left for back actions
- ✅ Download icon for downloads
- ✅ Icon size matches button size (see table above)
- ❌ Don't use decorative icons

---

### Button Combinations

#### Paired Buttons (Primary + Secondary)
```tsx
<div className="flex gap-4">
  <Button variant="brand" size="lg">
    Schedule Demo
  </Button>
  <Button variant="secondary" size="lg">
    Learn More
  </Button>
</div>
```

#### Dark Background Pairing (Brand + Ghost)
```tsx
<div className="bg-black p-12 flex gap-4">
  <Button variant="brand" size="lg">
    Get Started
  </Button>
  <Button variant="ghost" size="lg">
    View Resources
  </Button>
</div>
```

---

## 🏷️ Badge Component

Small labels for categorization, numbering, and status indication.

### Badge Variants

#### 1. Number Badge (Black)
```tsx
<div className="inline-flex items-center justify-center bg-black text-white px-4 py-2 rounded-[5px] text-sm font-bold">
  01
</div>
```

**Usage:** Step numbers, ordered features, sequential items

#### 2. Featured Badge (Brand Red)
```tsx
<div className="inline-flex items-center justify-center bg-[#b01f24] text-white px-4 py-2 rounded-[5px] text-sm font-bold">
  Featured
</div>
```

**Usage:** Highlight special items, premium features
**⚠️ WARNING:** Use sparingly - red should remain rare

#### 3. Outlined Badge (Border)
```tsx
<div className="inline-flex items-center justify-center border border-black/20 text-black px-4 py-2 rounded-[5px] text-sm">
  Label
</div>
```

**Usage:** Tags, categories, filters

#### 4. Subtle Badge (Light Background)
```tsx
<div className="inline-flex items-center justify-center bg-black/5 text-black/70 px-4 py-2 rounded-[5px] text-xs uppercase tracking-wider">
  CATEGORY
</div>
```

**Usage:** Section eyebrows, metadata, timestamps

---

## 📊 Metric Display Component

Shows numerical data with labels. Two main patterns:

### Pattern 1: Simple Metric Card

```tsx
<div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
  <div className="text-3xl font-bold text-black mb-2">₹110 Cr</div>
  <div className="text-sm text-black/60">Total Market</div>
</div>
```

**Specifications:**
- **Container:** Warm background (`#f5f2f1`), 10px radius, subtle border
- **Value:** `--text-3xl` (48.8px), bold, pure black
- **Label:** `--text-sm` (16px), 60% opacity
- **Padding:** `p-6` (24px)

**Usage:** Stats grids, metric highlights, data visualization

**Grid Layout:**
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
  {metrics.map((metric) => (
    <div key={metric.label} className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
      <div className="text-3xl font-bold text-black mb-2">{metric.value}</div>
      <div className="text-sm text-black/60">{metric.label}</div>
    </div>
  ))}
</div>
```

---

### Pattern 2: Centered Metric (No Background)

```tsx
<div className="text-center">
  <div className="text-4xl font-bold text-black mb-2">₹68 Cr</div>
  <div className="text-sm font-bold text-black mb-1">Serviceable Market</div>
  <div className="text-xs text-black/60">High-voltage segment opportunity</div>
</div>
```

**Specifications:**
- **Value:** `--text-4xl` (61px), bold
- **Primary Label:** `--text-sm` (16px), bold
- **Description:** `--text-xs` (12.8px), 60% opacity
- **Alignment:** Center
- **Background:** Usually on warm (`#f5f2f1`) container

**Usage:** Featured stats in highlighted sections, hero stats

---

## 🃏 Card Components

### Card Variant 1: White Card (Default)

```tsx
<div className="bg-white rounded-[10px] p-6 shadow-md border border-black/5">
  <h4 className="text-lg font-bold mb-2">Card Title</h4>
  <p className="text-sm text-black/60">
    Card description text goes here.
  </p>
</div>
```

**Specifications:**
- **Background:** Pure white
- **Border Radius:** `10px` (large)
- **Padding:** `p-6` (24px) for small cards, `p-8` (32px) for large
- **Shadow:** `shadow-md` for elevation
- **Border:** Very subtle `border-black/5`
- **Title:** `--text-lg` (25px), bold
- **Body:** `--text-sm` (16px), 60% opacity

**Usage:** Feature cards, content blocks, standard containers

---

### Card Variant 2: Warm Card (Highlighted)

```tsx
<div className="bg-[#f5f2f1] rounded-[10px] p-6 border border-black/5">
  <h4 className="text-lg font-bold mb-2">Warm Card</h4>
  <p className="text-sm text-black/60">
    Card with warm off-white background for highlighted sections.
  </p>
</div>
```

**Specifications:**
- **Background:** Warm off-white (`#f5f2f1`)
- **Shadow:** Usually none, relies on subtle border
- **Border:** `border-black/5`
- **Other specs:** Same as white card

**Usage:** Testimonials, stats sections, highlighted features, special content

---

### Card Variant 3: Dark Card (Contrast)

```tsx
<div className="bg-black rounded-[10px] p-6">
  <h4 className="text-lg font-bold mb-2 text-white">Dark Card</h4>
  <p className="text-sm text-white/60">
    Card with dark background for contrast sections.
  </p>
</div>
```

**Specifications:**
- **Background:** Pure black
- **Text Color:** White
- **Body Opacity:** `text-white/60`
- **Border:** None (or very subtle white/10)
- **Shadow:** Optional subtle glow

**Usage:** CTA sections, high-contrast features, premium content

---

### Numbered Feature Card

```tsx
<div className="bg-[#f5f2f1] rounded-[10px] p-8 border border-black/5">
  <div className="inline-flex items-center justify-center bg-black text-white w-12 h-12 rounded-[5px] text-sm font-bold mb-4">
    01
  </div>
  <h4 className="text-xl font-bold mb-3">Feature Title</h4>
  <p className="text-sm text-black/60">
    Detailed description of the feature explaining value proposition.
  </p>
</div>
```

**Specifications:**
- **Container:** Warm background, large padding `p-8`
- **Number Badge:** 48x48px, black, 5px radius
- **Title:** `--text-xl` (31.25px), bold
- **Body:** `--text-sm` (16px), 60% opacity
- **Spacing:** 16px between number and title, 12px between title and body

**Usage:** Step-by-step features, ordered processes, sequential content

---

### Challenge/Question Card

```tsx
<div className="bg-white rounded-[10px] p-8 shadow-md border border-black/5">
  <div className="text-5xl font-bold text-black/5 mb-4">001</div>
  <h4 className="text-xl font-bold mb-4">Challenge Title</h4>
  <ul className="space-y-2">
    {questions.map((question, idx) => (
      <li key={idx} className="text-sm text-black/70 flex gap-2">
        <span className="text-black/30">→</span>
        <span>{question}</span>
      </li>
    ))}
  </ul>
</div>
```

**Specifications:**
- **Large Number:** `--text-5xl` (76.3px), 5% opacity (watermark effect)
- **Title:** `--text-xl` (31.25px), bold
- **List Items:** `--text-sm` (16px), 70% opacity
- **Bullet:** Arrow (→), 30% opacity

**Usage:** Problem statements, exploratory questions, challenges

---

## 📋 Form Components

### Input Field

```tsx
<div className="space-y-2">
  <label className="text-sm font-medium text-black">
    Field Label
  </label>
  <input 
    type="text"
    className="w-full px-4 py-3 border border-black/20 rounded-[5px] text-sm
               focus:outline-none focus:border-black focus:ring-2 focus:ring-black/10"
    placeholder="Enter text..."
  />
</div>
```

**Specifications:**
- **Height:** 48px (md button equivalent)
- **Padding:** `px-4 py-3`
- **Border:** `1px solid rgba(0,0,0,0.2)`
- **Border Radius:** `5px`
- **Focus State:** Black border + subtle ring
- **Font Size:** `--text-sm` (16px)

---

### Text Area

```tsx
<textarea 
  className="w-full px-4 py-3 border border-black/20 rounded-[5px] text-sm
             focus:outline-none focus:border-black focus:ring-2 focus:ring-black/10
             min-h-[120px]"
  placeholder="Enter message..."
/>
```

**Specifications:**
- **Min Height:** 120px
- **Resize:** Vertical only
- **Other specs:** Same as input field

---

## 🎯 Icon Usage

### Lucide React Icons

Recommended icons from the lucide-react library:

| Icon | Component | Usage |
|------|-----------|-------|
| `ArrowRight` | `<ArrowRight />` | Forward actions, CTAs, next steps |
| `ArrowLeft` | `<ArrowLeft />` | Back actions, previous |
| `Download` | `<Download />` | Download buttons |
| `Mail` | `<Mail />` | Contact, email |
| `Phone` | `<Phone />` | Call actions |
| `User` | `<User />` | Profile, account |
| `Star` | `<Star />` | Ratings, favorites |
| `Heart` | `<Heart />` | Likes, favorites |
| `ExternalLink` | `<ExternalLink />` | External links |
| `Check` | `<Check />` | Success, completed |
| `X` | `<X />` | Close, cancel |

**Icon Sizing:**
```tsx
/* Match button size */
<ArrowRight className="w-4 h-4" />  {/* 16px - sm/md buttons */}
<ArrowRight className="w-5 h-5" />  {/* 20px - lg buttons */}
<ArrowRight className="w-6 h-6" />  {/* 24px - xl buttons */}
```

---

## ✅ Component Usage Checklist

Before implementing a component:

- [ ] **Variant selection** matches action priority
- [ ] **Size is appropriate** for context (lg for major CTAs)
- [ ] **States are handled** (hover, active, disabled, loading)
- [ ] **Spacing is consistent** with design tokens
- [ ] **Border radius matches** component type
- [ ] **Colors follow 92-5-3 rule**
- [ ] **Typography hierarchy** is respected
- [ ] **Icons are meaningful**, not decorative

---

## 🔗 Related Documentation

- [Design Tokens](./DESIGN_TOKENS.md) - Foundational values used in components
- [Pattern Library](./PATTERN_LIBRARY.md) - How components combine into patterns
- [Design Principles](./DESIGN_PRINCIPLES.md) - Philosophy behind component design

---

**End of Component Library Reference**
