
  # Design system vs 26

  This is a code bundle for Design system vs 26. The original project is available at https://www.figma.com/design/ZXU4pnaL4AXFH6UXbftbBC/Design-system-vs-26.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  