# Quick Reference Guide
**Case Study Design System - Cheat Sheet**

---

## 🎨 Color Tokens

### Backgrounds
```css
var(--bg-pure-black)      /* #000000 - Hero, Resources */
var(--bg-pure-white)      /* #ffffff - Standard sections */
var(--bg-warm)            /* #f5f2f1 - Challenges, Methodology */
var(--bg-warm-500)        /* #eae5e3 - Borders on warm bg */
var(--bg-warm-600)        /* #d9d1ce - Timeline lines */
var(--bg-warm-700)        /* #c8bcb8 - Node borders */
```

### Text Colors (Quick Reference)
```tsx
// On Light/White
text-black              /* Primary headings */
text-black/70           /* Body text */
text-black/40           /* Meta, labels */
text-black/[0.08]       /* Large decorative numbers */

// On Dark/Black
text-white              /* Primary headings */
text-white/60           /* Body text */
text-white/40           /* Meta, labels */
text-white/30           /* Subtle elements */
```

### Borders (Warm Backgrounds)
```tsx
border-black/[0.08]           /* Default */
hover:border-black/[0.15]     /* Hover state */
borderColor: '#eae5e3'        /* Internal dividers */
```

---

## 📐 Typography Scale

```css
--text-xs: 0.8rem       /* 12.8px - Labels */
--text-sm: 1rem         /* 16px - Body */
--text-base: 1.25rem    /* 20px - Large body */
--text-lg: 1.563rem     /* 25px - H3 */
--text-xl: 1.953rem     /* 31px - H2 */
--text-2xl: 2.441rem    /* 39px - H1 */
--text-3xl: 3.052rem    /* 48px - Hero */
--text-4xl: 3.815rem    /* 61px - XL */
--text-5xl: 4.768rem    /* 76px - XXL */
```

### Quick Apply
```tsx
style={{ fontSize: 'var(--text-sm)' }}
style={{ fontSize: 'var(--text-3xl)' }}
```

---

## 📏 Spacing Patterns

### Section Wrapper
```tsx
className="py-12 sm:py-16 md:py-20"
style={{ background: 'var(--bg-warm)' }}
```

### Container
```tsx
className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8"
```

### Section Header
```tsx
className="mb-12 sm:mb-16 md:mb-20"
```

### Card Padding
```tsx
className="p-5 md:p-6"     /* Small cards */
className="p-6 md:p-8"     /* Large cards */
```

### Gaps
```tsx
gap-4 md:gap-6     /* Cards, small grids */
gap-6 md:gap-8     /* Medium grids */
gap-8 md:gap-10    /* Large grids */
```

---

## 🔲 Border Radius

```tsx
rounded-[2.5px]    /* Images, photos */
rounded-[5px]      /* Buttons, small cards */
rounded-[10px]     /* Large cards */
rounded-full       /* Pills, circles */
```

---

## 🎯 Section Header Pattern

```tsx
<div className="mb-12 sm:mb-16 md:mb-20">
  {/* Label */}
  <span 
    className="font-medium text-black/40 uppercase tracking-[3px] mb-6 md:mb-8 block" 
    style={{ fontSize: 'var(--text-xs)' }}
  >
    Section Label
  </span>
  
  {/* Title */}
  <h2 
    className="leading-[1.15] font-light text-black tracking-tight mb-4 md:mb-6" 
    style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
  >
    Section Title
  </h2>
  
  {/* Description */}
  <p 
    className="leading-[1.7] text-black/70 max-w-[700px]" 
    style={{ fontSize: 'var(--text-sm)' }}
  >
    Section description text
  </p>
</div>
```

---

## 🃏 Card Pattern (Warm Background)

```tsx
<div 
  className="bg-white border border-black/[0.08] rounded-[5px] p-6 hover:-translate-y-1 hover:border-black/[0.15] hover:shadow-lg transition-all duration-300"
  style={{ 
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
    willChange: 'transform'
  }}
>
  {/* Card content */}
</div>
```

---

## 🎬 Hover Effects

### Card Lift
```tsx
className="hover:-translate-y-1 hover:shadow-lg transition-all duration-300"
style={{ willChange: 'transform' }}
```

### Image Zoom
```tsx
// Image
className="transition-all duration-500 group-hover:scale-110"

// Overlay
className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"
```

### Text Fade
```tsx
className="text-white/60 group-hover:text-white/80 transition-colors"
```

### Border Enhancement
```tsx
className="border-black/[0.08] hover:border-black/[0.15]"
```

---

## 📱 Responsive Grids

### 4-Column (Resources)
```tsx
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
```

### 3-Column (Value Pillars)
```tsx
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10"
```

### 2-Column (Flexible)
```tsx
className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
```

---

## 🔤 Font Patterns

### Serif Headlines
```tsx
style={{ fontFamily: "'Noto Serif', serif" }}
className="font-light"  /* For large headlines */
```

### Sans-Serif Body
```tsx
// Default body text uses DM Sans (no need to specify)
// For explicit usage in inline styles:
font-['DM_Sans',sans-serif]

className="font-normal"  /* Body text */
className="font-medium"  /* Labels, buttons */
className="font-bold"    /* Navigation, CTAs */
```

### Font System
**Only two fonts used:**
- ✅ Noto Serif: Headlines, large numbers, quotes
- ✅ DM Sans: Navigation, body text, UI elements
- ❌ No other fonts (Inter removed from active use)

---

## 🎨 Section Background Order

```
1. Hero              → Pure Black
2. Client Context    → Pure White
3. Challenges        → Warm (#f5f2f1)
4. Objectives        → Pure White
5. Value Pillars     → Pure White
6. Methodology       → Warm (#f5f2f1)
7. Impact            → Black or White (variant)
8. Testimonial       → Pure White
9. Resources         → Pure Black
10. Final CTA        → Pure White
```

---

## 🪝 Custom Hooks

### Scroll Animation
```tsx
import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });

<div ref={ref} className={isVisible ? 'fade-in' : ''}>
```

### Reading Progress
```tsx
import { useReadingProgress } from '@/app/hooks/useReadingProgress';

const progress = useReadingProgress();

<div style={{ width: `${progress}%` }} />
```

### Counter Animation
```tsx
import { useCounter } from '@/app/hooks/useCounter';

const { count, startCounting } = useCounter({ end: 110, duration: 2000 });

<span>{count}</span>
```

---

## ⚡ Performance Optimizations

### Animated Elements
```tsx
style={{ willChange: 'transform' }}
```

### Transition Timing
```tsx
duration-150    /* Fast - Progress bars */
duration-300    /* Standard - Cards, borders */
duration-500    /* Slow - Image zooms */
```

### Passive Listeners (in hooks)
```tsx
{ passive: true }
```

---

## 🎯 Common Utilities

### Center Container
```tsx
className="max-w-[1000px] mx-auto"
```

### Flex Center
```tsx
className="flex items-center justify-center"
```

### Smooth Scroll
```css
scroll-behavior: smooth;  /* Already in theme.css */
```

### Hide Scrollbar
```tsx
className="scrollbar-hide"
style={{
  scrollbarWidth: 'none',
  msOverflowStyle: 'none',
  WebkitOverflowScrolling: 'touch'
}}
```

---

## 🔧 Component Template

```tsx
import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

interface MyComponentProps {
  title: string;
  items: Array<{ id: string; name: string }>;
}

export function MyComponent({ title, items }: MyComponentProps) {
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });
  
  return (
    <section 
      ref={ref}
      className="py-12 sm:py-16 md:py-20" 
      style={{ background: 'var(--bg-warm)' }}
    >
      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
        {/* Section Header */}
        <div className="mb-12 sm:mb-16 md:mb-20">
          <span 
            className="font-medium text-black/40 uppercase tracking-[3px] mb-6 md:mb-8 block" 
            style={{ fontSize: 'var(--text-xs)' }}
          >
            Section Label
          </span>
          
          <h2 
            className="leading-[1.15] font-light text-black tracking-tight" 
            style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
          >
            {title}
          </h2>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {items.map((item) => (
            <div 
              key={item.id}
              className="bg-white border border-black/[0.08] rounded-[5px] p-6 hover:-translate-y-1 hover:shadow-lg transition-all duration-300"
              style={{ 
                boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
                willChange: 'transform'
              }}
            >
              {item.name}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

## 📦 Import Patterns

### Components
```tsx
import { ComponentName } from '@/app/components/ComponentName';
```

### Hooks
```tsx
import { useHookName } from '@/app/hooks/useHookName';
```

### Figma Assets
```tsx
// Raster images
import imgName from "figma:asset/hash.png";

// SVGs
import svgPaths from "@/imports/svg-id";
```

### Lucide Icons
```tsx
import { IconName, ArrowRight, Target } from 'lucide-react';
```

---

## ✅ Component Checklist

Before finalizing any component:

- [ ] TypeScript props interface defined
- [ ] Responsive breakpoints applied (sm, md, lg)
- [ ] Correct background color for section
- [ ] Border radius matches system (2.5/5/10px)
- [ ] Typography uses design tokens (var(--text-*))
- [ ] Spacing uses standard patterns
- [ ] Hover states with 300ms transitions
- [ ] `willChange` on animated elements
- [ ] Semantic HTML elements
- [ ] `key` props for all lists
- [ ] Proper export statement
- [ ] Import uses `@` alias

---

## 🎨 Design Token CSS Variables

```css
/* Copy/Paste Ready */

/* Backgrounds */
background: var(--bg-pure-black);
background: var(--bg-pure-white);
background: var(--bg-warm);

/* Typography */
fontSize: 'var(--text-xs)'
fontSize: 'var(--text-sm)'
fontSize: 'var(--text-base)'
fontSize: 'var(--text-lg)'
fontSize: 'var(--text-xl)'
fontSize: 'var(--text-2xl)'
fontSize: 'var(--text-3xl)'

/* Fonts */
fontFamily: "'Noto Serif', serif"
fontFamily: "'DM Sans', sans-serif"

/* Specific Colors */
borderColor: '#eae5e3'   /* Warm dividers */
background: '#d9d1ce'    /* Timeline lines */
borderColor: '#c8bcb8'   /* Node borders */
```

---

## 🚀 Quick Commands

### Create New Component
```bash
# Create file
touch /src/app/components/NewComponent.tsx

# Import in App.tsx
import { NewComponent } from '@/app/components/NewComponent';
```

### Create New Hook
```bash
# Create file
touch /src/app/hooks/useNewHook.ts

# Import in component
import { useNewHook } from '@/app/hooks/useNewHook';
```

---

## 🎯 Most Common Patterns

### 1. Section Wrapper (Pure White)
```tsx
<section className="py-12 sm:py-16 md:py-20" style={{ background: 'var(--bg-pure-white)' }}>
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
```

### 2. Section Wrapper (Warm)
```tsx
<section className="py-12 sm:py-16 md:py-20" style={{ background: 'var(--bg-warm)' }}>
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
```

### 3. Section Wrapper (Pure Black)
```tsx
<section className="py-12 sm:py-16 md:py-20" style={{ background: 'var(--bg-pure-black)' }}>
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
```

### 4. Card (on Warm Background)
```tsx
<div 
  className="bg-white border border-black/[0.08] rounded-[5px] p-6 hover:-translate-y-1 hover:border-black/[0.15] hover:shadow-lg transition-all duration-300"
  style={{ boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)', willChange: 'transform' }}
>
```

### 5. Glassmorphism Card (on White Background)
```tsx
<div className="border border-black/10 rounded-[10px] p-6 md:p-8 bg-white/80 backdrop-blur-sm hover:bg-white/90 transition-all duration-300">
```

---

**End of Quick Reference**