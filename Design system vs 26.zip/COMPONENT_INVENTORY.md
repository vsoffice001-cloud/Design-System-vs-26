# Component Inventory & Usage Guide

Complete listing of all components with props, variants, and code examples.

---

## Table of Contents
1. [Navbar](#navbar)
2. [HeroSection](#herosection)
3. [ClientContextSection](#clientcontextsection)
4. [ChallengesSection](#challengessection)
5. [EngagementObjectivesSection](#engagementobjectivessection)
6. [ValuePillarsSection](#valuepillarssection)
7. [MethodologySection](#methodologysection)
8. [ImpactSection](#impactsection)
9. [TestimonialSection](#testimonialsection)
10. [ResourcesSection](#resourcessection)
11. [FinalCTASection](#finalctasection)
12. [VariantSwitcher](#variantswitcher)

---

## Navbar

### Import
```tsx
import { Navbar } from '@/app/components/Navbar';
```

### Props
```tsx
// No props - uses internal state
```

### Features
- ✅ Reading progress bar (red, 2px height)
- ✅ Two-tier navigation (desktop)
- ✅ Mobile responsive hamburger menu
- ✅ Dropdown menus with hover states
- ✅ Schedule a Demo CTA button
- ✅ Search bar with glassmorphism
- ✅ Fixed positioning with shadow

### Usage
```tsx
<Navbar />
```

### Dependencies
- `useState` for menu state
- `useReadingProgress` hook for progress bar
- SVG imports for icons

### Responsive Behavior
- **Desktop (lg+)**: Full two-tier nav with all options
- **Tablet (md)**: Show CTA, hide secondary bar
- **Mobile**: Hamburger menu with dropdown

---

## HeroSection

### Import
```tsx
import { HeroSection } from '@/app/components/HeroSection';
```

### Props
```tsx
interface HeroSectionProps {
  eyebrow: string;        // Small label above title
  title: string;          // Main headline
  subtitle: string;       // Supporting text
  ctaText: string;        // Button text
}
```

### Features
- Pure black background (#000000)
- Large serif typography
- Responsive clamp sizing
- CTA button with hover effect
- Centered alignment

### Usage
```tsx
<HeroSection
  eyebrow="CASE STUDY"
  title="Evaluating India's Transformer Bushing Market for IPO Readiness - ₹110 Cr."
  subtitle="Comprehensive market intelligence and strategic assessment for YASH, a vertically integrated manufacturer of high-voltage transformer bushings."
  ctaText="Download Full Case Study"
/>
```

### Styling Details
```tsx
// Eyebrow
fontSize: 'var(--text-xs)'
tracking: '[3px]'
color: white/40

// Title
fontSize: 'clamp(2rem, 6vw, var(--text-3xl))'
fontFamily: "'Noto Serif', serif"
color: white

// Subtitle
fontSize: 'var(--text-sm)'
color: white/60
```

---

## ClientContextSection

### Import
```tsx
import { ClientContextSection } from '@/app/components/ClientContextSection';
```

### Props
```tsx
interface ClientContextSectionProps {
  companyName: string;
  tagline: string;
  description: string;
  image: string;
  highlights: Array<{
    label: string;
    value: string;
  }>;
}
```

### Features
- Pure white background
- Glassmorphism card design
- Image with 2.5px border radius
- Highlight metrics in grid
- Responsive two-column layout

### Usage
```tsx
<ClientContextSection
  companyName="YASH High Voltage Transformers Pvt. Ltd."
  tagline="Powering India's electrical infrastructure since 1963"
  description="YASH is a vertically integrated manufacturer..."
  image={companyImage}
  highlights={[
    { label: "Founded", value: "1963" },
    { label: "Location", value: "Vadodara, Gujarat" },
    { label: "Employees", value: "500+" },
    { label: "Export Markets", value: "15+ Countries" }
  ]}
/>
```

### Layout Structure
```
Desktop: Image (40%) | Content (60%)
Mobile: Stacked (Image → Content)
```

---

## ChallengesSection

### Import
```tsx
import { ChallengesSection } from '@/app/components/ChallengesSection';
```

### Props
```tsx
interface Challenge {
  number: string;         // Large display number
  title: string;          // Challenge title
  questions: string[];    // Sub-questions/details
}

interface ChallengesSectionProps {
  challenges: Challenge[];
}
```

### Features
- Warm off-white background (#f5f2f1)
- Horizontal scroll (mobile) / Grid (desktop when ≤4 cards)
- Fade gradients on edges
- Card index indicators (1/5)
- Lift hover effect
- Dynamic card sizing based on count

### Usage
```tsx
<ChallengesSection
  challenges={[
    {
      number: "01",
      title: "Market Size & Growth Assessment",
      questions: [
        "What is the current market size?",
        "What are the growth projections?",
        "What are the key market drivers?"
      ]
    },
    // ... more challenges
  ]}
/>
```

### Card Width Logic
```tsx
cardCount <= 2: Full width (w-full)
cardCount === 3: 33.333% on desktop
cardCount === 4: 25% on desktop
cardCount >= 5: Horizontal scroll (280px fixed width)
```

### Styling Details
```tsx
// Card
bg-white
border: border-black/[0.08]
hover:border-black/[0.15]
rounded-[5px]
hover:-translate-y-1
boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)'

// Large Number
fontSize: cardCount >= 4 ? 'var(--text-3xl)' : 'var(--text-4xl)'
color: text-black/[0.08]
fontFamily: "'Noto Serif', serif"
```

---

## EngagementObjectivesSection

### Import
```tsx
import { EngagementObjectivesSection } from '@/app/components/EngagementObjectivesSection';
```

### Props
```tsx
interface Objective {
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface EngagementObjectivesSectionProps {
  objectives: Objective[];
}
```

### Features
- Pure white background
- Responsive grid (2-3 columns based on count)
- Icon integration with Lucide React
- Glassmorphism cards
- Clean minimal design

### Usage
```tsx
import { Target, TrendingUp, Shield, DollarSign } from 'lucide-react';

<EngagementObjectivesSection
  objectives={[
    {
      icon: <Target className="w-8 h-8" />,
      title: "Market Opportunity Assessment",
      description: "Evaluate the transformer bushing market..."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Growth Potential Analysis",
      description: "Analyze future growth trajectories..."
    },
    // ... more objectives
  ]}
/>
```

### Grid Logic
```tsx
count < 4: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
count >= 4: grid-cols-1 md:grid-cols-2 lg:grid-cols-2
```

---

## ValuePillarsSection

### Import
```tsx
import { ValuePillarsSection } from '@/app/components/ValuePillarsSection';
```

### Props
```tsx
interface ValuePillar {
  number: string;         // Display number (01, 02, etc.)
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface ValuePillarsSectionProps {
  pillars: ValuePillar[];
}
```

### Features
- Pure white background
- 3-column grid (always)
- Numbered cards (01, 02, 03...)
- Icon integration
- Glassmorphism with hover states

### Usage
```tsx
import { Database, Users, FileText, TrendingUp, Shield, Zap } from 'lucide-react';

<ValuePillarsSection
  pillars={[
    {
      number: "01",
      icon: <Database className="w-8 h-8" />,
      title: "Primary Research",
      description: "In-depth interviews with industry experts..."
    },
    {
      number: "02",
      icon: <Users className="w-8 h-8" />,
      title: "Stakeholder Engagement",
      description: "Direct engagement with manufacturers..."
    },
    // ... up to 6 pillars
  ]}
/>
```

### Card Structure
```
┌────────────────────┐
│ 01        [Icon]   │
│                    │
│ Title              │
│                    │
│ Description text   │
│ goes here...       │
└────────────────────┘
```

---

## MethodologySection

### Import
```tsx
import { MethodologySection } from '@/app/components/MethodologySection';
```

### Props
```tsx
interface MethodologyStep {
  number: string;         // Step number (1, 2, 3...)
  title: string;
  description: string;
}

interface MethodologySectionProps {
  steps: MethodologyStep[];
}
```

### Features
- Warm off-white background (#f5f2f1)
- Vertical timeline with nodes
- Step badges (Step 1 of 5)
- Progress arrows between steps
- Lift hover effect on cards
- Timeline hidden on mobile

### Usage
```tsx
<MethodologySection
  steps={[
    {
      number: "1",
      title: "Market Landscape Mapping",
      description: "Conducted comprehensive research to identify all key players..."
    },
    {
      number: "2",
      title: "Primary Research & Data Collection",
      description: "Engaged directly with industry stakeholders..."
    },
    // ... more steps
  ]}
/>
```

### Timeline Colors
```tsx
Vertical Line: #d9d1ce (--bg-warm-600)
Node Circle Border: #c8bcb8 (--bg-warm-700)
Node Background: white
Connector Gradient: #c8bcb8 → #d9d1ce → transparent
```

### Responsive Behavior
- **Desktop**: Timeline visible with circular nodes
- **Mobile**: Timeline hidden, cards full-width

---

## ImpactSection

### Import
```tsx
import { ImpactSection } from '@/app/components/ImpactSection';
```

### Props
```tsx
interface ImpactMetric {
  number: string;
  label: string;
  description?: string;  // Optional for some variants
}

interface ImpactSectionProps {
  variant: 'grid-cards' | 'big-cards' | 'stats-row' | 'full-width-hero';
  backgroundColor?: 'black' | 'white';
  metrics: ImpactMetric[];
}
```

### Variants

#### 1. Grid Cards (2-column metric grid)
```tsx
<ImpactSection
  variant="grid-cards"
  backgroundColor="black"
  metrics={[
    { number: "₹110 Cr", label: "Projected Valuation", description: "Conservative market assessment" },
    { number: "12-15%", label: "Annual Growth Rate", description: "Projected over next 5 years" },
    { number: "8", label: "Key Market Drivers", description: "Identified growth catalysts" },
    { number: "25+", label: "Competitor Analysis", description: "Comprehensive landscape mapping" }
  ]}
/>
```

#### 2. Big Cards (Large feature cards)
```tsx
<ImpactSection
  variant="big-cards"
  backgroundColor="white"
  metrics={[
    { number: "₹110 Cr", label: "Projected Valuation" },
    { number: "12-15%", label: "Annual Growth" }
  ]}
/>
```

#### 3. Stats Row (Horizontal bar)
```tsx
<ImpactSection
  variant="stats-row"
  backgroundColor="black"
  metrics={[
    { number: "₹110 Cr", label: "Valuation" },
    { number: "12-15%", label: "Growth Rate" },
    { number: "8", label: "Market Drivers" },
    { number: "25+", label: "Competitors" }
  ]}
/>
```

#### 4. Full Width Hero (Single large statement)
```tsx
<ImpactSection
  variant="full-width-hero"
  backgroundColor="black"
  metrics={[
    { number: "₹110 Crore", label: "Projected Market Valuation" }
  ]}
/>
```

### Features
- 4 distinct layout variants
- Switchable backgrounds (black/white)
- Ready for counter animations
- Glassmorphism effects
- Responsive layouts

---

## TestimonialSection

### Import
```tsx
import { TestimonialSection } from '@/app/components/TestimonialSection';
```

### Props
```tsx
interface TestimonialSectionProps {
  quote: string;
  author: string;
  role: string;
  company: string;
}
```

### Features
- Pure white background
- Large quote marks
- Centered layout
- Author attribution
- Serif typography for quote

### Usage
```tsx
<TestimonialSection
  quote="The comprehensive market analysis provided by the team was instrumental in our IPO preparation. Their deep industry knowledge and meticulous research gave us the confidence and data we needed to move forward with our public offering."
  author="Rajesh Patel"
  role="Managing Director"
  company="YASH High Voltage Transformers Pvt. Ltd."
/>
```

### Styling
```tsx
// Quote
fontSize: 'clamp(1.25rem, 3vw, var(--text-xl))'
fontFamily: "'Noto Serif', serif"
color: text-black/80

// Author
fontSize: 'var(--text-base)'
fontWeight: medium
color: text-black

// Role & Company
fontSize: 'var(--text-sm)'
color: text-black/60
```

---

## ResourcesSection

### Import
```tsx
import { ResourcesSection } from '@/app/components/ResourcesSection';
```

### Props
```tsx
// No props - uses internal resources array
```

### Features
- Pure black background (#000000)
- 4-column responsive grid
- Image zoom on hover
- Category badges
- Date stamps
- "View All Resources" CTA
- 8 pre-configured resources

### Usage
```tsx
<ResourcesSection />
```

### Internal Structure
```tsx
const resources: Resource[] = [
  {
    image: importedImage,
    category: "TECHNOLOGY",
    date: "Jan 15, '24",
    title: "The Future of AI in Supply Chain Management",
    description: "Exploring how artificial intelligence..."
  },
  // ... 7 more resources
];
```

### Card Hover Effects
```tsx
// Image zoom
className="group-hover:scale-110 transition-all duration-500"

// Overlay
className="bg-black/0 group-hover:bg-black/20"

// Text
className="group-hover:text-white/80 transition-colors"
```

### Grid Breakpoints
```tsx
Mobile: 1 column
Tablet (sm): 2 columns
Desktop (lg): 4 columns
```

---

## FinalCTASection

### Import
```tsx
import { FinalCTASection } from '@/app/components/FinalCTASection';
```

### Props
```tsx
interface FinalCTASectionProps {
  title: string;
  description: string;
  ctaText: string;
}
```

### Features
- Pure white background
- Centered layout
- Single CTA button
- Minimal design
- Hover effects

### Usage
```tsx
<FinalCTASection
  title="Ready to Transform Your Business?"
  description="Let's discuss how our market intelligence and strategic consulting services can help you achieve your goals."
  ctaText="Schedule a Consultation"
/>
```

### Button Styling
```tsx
className="px-8 py-5 border border-black/20 hover:border-black/40 hover:bg-black/5"
fontSize: 'var(--text-sm)'
fontWeight: medium
```

---

## VariantSwitcher

### Import
```tsx
import { VariantSwitcher } from '@/app/components/VariantSwitcher';
```

### Props
```tsx
interface VariantSwitcherProps {
  currentVariant: string;
  variants: Array<{
    id: string;
    label: string;
  }>;
  onVariantChange: (variantId: string) => void;
}
```

### Features
- Developer utility component
- Button group for variant selection
- Active state highlighting
- Sticky positioning
- Glassmorphism background

### Usage
```tsx
const [variant, setVariant] = useState('grid-cards');

<VariantSwitcher
  currentVariant={variant}
  variants={[
    { id: 'grid-cards', label: 'Grid Cards' },
    { id: 'big-cards', label: 'Big Cards' },
    { id: 'stats-row', label: 'Stats Row' },
    { id: 'full-width-hero', label: 'Full Width Hero' }
  ]}
  onVariantChange={setVariant}
/>
```

### Styling
```tsx
// Container
className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50"
background: rgba(0, 0, 0, 0.8)
backdropFilter: blur(12px)

// Active Button
background: white
color: black

// Inactive Button
color: white/70
hover: white
```

---

## Custom Hooks

### useScrollAnimation
```tsx
import { useScrollAnimation } from '@/app/hooks/useScrollAnimation';

const { ref, isVisible } = useScrollAnimation({
  threshold: 0.1,        // Trigger when 10% visible
  rootMargin: '0px',     // Margin around viewport
  triggerOnce: true      // Only trigger once
});

<div ref={ref} className={isVisible ? 'animate-in' : ''}>
  {/* Content */}
</div>
```

### useReadingProgress
```tsx
import { useReadingProgress } from '@/app/hooks/useReadingProgress';

const progress = useReadingProgress();

<div 
  className="h-[2px] bg-red-600" 
  style={{ width: `${progress}%` }} 
/>
```

### useCounter
```tsx
import { useCounter } from '@/app/hooks/useCounter';

const { count, startCounting } = useCounter({
  end: 110,              // End value
  duration: 2000,        // Animation duration (ms)
  startOnView: true      // Auto-start when visible
});

<span>₹{count} Cr</span>
```

### useMagneticEffect
```tsx
import { useMagneticEffect } from '@/app/hooks/useMagneticEffect';

const { ref, position } = useMagneticEffect({
  strength: 0.3,         // Movement strength (0-1)
  disabled: false        // Disable effect
});

<button 
  ref={ref}
  style={{ 
    transform: `translate(${position.x}px, ${position.y}px)` 
  }}
>
  Magnetic Button
</button>
```

---

## Complete App.tsx Structure

```tsx
import { Navbar } from '@/app/components/Navbar';
import { HeroSection } from '@/app/components/HeroSection';
import { ClientContextSection } from '@/app/components/ClientContextSection';
import { ChallengesSection } from '@/app/components/ChallengesSection';
import { EngagementObjectivesSection } from '@/app/components/EngagementObjectivesSection';
import { ValuePillarsSection } from '@/app/components/ValuePillarsSection';
import { MethodologySection } from '@/app/components/MethodologySection';
import { ImpactSection } from '@/app/components/ImpactSection';
import { TestimonialSection } from '@/app/components/TestimonialSection';
import { ResourcesSection } from '@/app/components/ResourcesSection';
import { FinalCTASection } from '@/app/components/FinalCTASection';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection {...heroData} />
      <ClientContextSection {...clientData} />
      <ChallengesSection challenges={challengesData} />
      <EngagementObjectivesSection objectives={objectivesData} />
      <ValuePillarsSection pillars={pillarsData} />
      <MethodologySection steps={methodologyData} />
      <ImpactSection variant="grid-cards" metrics={impactData} />
      <TestimonialSection {...testimonialData} />
      <ResourcesSection />
      <FinalCTASection {...ctaData} />
    </div>
  );
}

export default App;
```

---

## Component Checklist

When creating/modifying components, ensure:

- [ ] Props interface is defined with TypeScript
- [ ] Responsive breakpoints are applied
- [ ] Color scheme matches section background
- [ ] Border radius follows system (2.5px/5px/10px)
- [ ] Typography uses design tokens
- [ ] Spacing uses standard patterns
- [ ] Hover effects are smooth (300ms)
- [ ] `willChange` is added to animated elements
- [ ] Semantic HTML is used
- [ ] `key` props are provided for lists
- [ ] Component is exported with proper naming
- [ ] Import path uses `@/app/components/`

---

**End of Component Inventory**
