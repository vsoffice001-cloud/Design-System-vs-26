# 🎨 TYPOGRAPHY SYSTEM - COMPLETE DOCUMENTATION
**Production-Ready Design System with Rationale**

---

## 📋 **TABLE OF CONTENTS**

1. [Quick Reference](#quick-reference)
2. [Design System Variables](#design-system-variables)
3. [Section-by-Section Guide](#section-by-section-guide)
4. [When to Use What](#when-to-use-what)
5. [Hardcoded Values Explained](#hardcoded-values-explained)
6. [Common Patterns](#common-patterns)
7. [Decision Tree](#decision-tree)

---

---

## 🚀 **QUICK REFERENCE**

### **Use Design System Variables For:**
```tsx
✅ Section headings      → var(--text-3xl) (48.8px)
✅ Subsection titles     → var(--text-xl) (31.25px)
✅ Body paragraphs       → var(--text-sm) (16px)
✅ Section labels        → var(--text-xs) (12.8px)
✅ Card titles (4+ cards) → var(--text-base) (20px)
✅ Card titles (2-3 cards) → var(--text-lg) (25px)
```

### **Hardcode Font Sizes For:**
```tsx
⚠️ Sidebar layouts       → 9.5px, 13px, 17px (spatial constraints)
⚠️ Display metrics       → clamp(1.75rem, 5vw, 2.5rem) (wrapping prevention)
⚠️ Dynamic layouts       → 0.875rem vs var(--text-sm) (content-aware)
⚠️ Lead paragraphs       → clamp(19px, 2.8vw, 24px) (responsive range)
⚠️ Navbar                → 11px, 12px, 14px (client Figma precision)
```

---

---

## 🎨 **DESIGN SYSTEM VARIABLES**

### **Complete Typography Scale**

```css
/* ========================================
   PRIMARY SCALE - Major Third (1.25 ratio)
   ======================================== */

--text-xs: 0.8rem;      /* 12.8px - Labels, metadata, section eyebrows */
--text-sm: 1rem;        /* 16px - Body text, descriptions, paragraphs */
--text-base: 1.25rem;   /* 20px - Large body, card titles (4+ cards) */
--text-lg: 1.563rem;    /* 25px - Subsection headings, card titles (2-3 cards) */
--text-xl: 1.953rem;    /* 31.25px - Section headings, objective titles */
--text-2xl: 2.441rem;   /* 39px - Major titles, impact metrics */
--text-3xl: 3.052rem;   /* 48.8px - Hero headings, main section headers */
--text-4xl: 3.815rem;   /* 61px - Extra large (challenge numbers <4 cards) */
--text-5xl: 4.768rem;   /* 76.3px - Massive headings (future use) */

/* ========================================
   UTILITY SIZES (Outside Scale)
   ======================================== */

--text-2xs: 0.75rem;     /* 12px - Navbar, micro labels */
--text-compact: 0.875rem; /* 14px - Compact body (challenges 4+ cards) */
```

### **Usage Guidelines**

| Variable | Size | Use Cases |
|----------|------|-----------|
| `--text-xs` | 12.8px | Section labels (uppercase), metadata, timestamps |
| `--text-sm` | 16px | Body text, descriptions, list items |
| `--text-base` | 20px | Large body text, card titles in dense layouts |
| `--text-lg` | 25px | Subsection headings, card titles in spacious layouts |
| `--text-xl` | 31.25px | Main section headings, engagement objective titles |
| `--text-2xl` | 39px | Major section titles, large metrics |
| `--text-3xl` | 48.8px | Hero headings, primary section headers |
| `--text-4xl` | 61px | Challenge card numbers (when <4 cards) |
| `--text-2xs` | 12px | Navbar text, micro labels (optional) |
| `--text-compact` | 14px | Compact body text (adaptive layouts) |

---

---

## 📖 **SECTION-BY-SECTION GUIDE**

### **1. HERO SECTION** ✅

**All typography uses design system variables**

```tsx
// Case Study Label
fontSize: 'var(--text-xs)'  // 12.8px

// Hero Title
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px

// Meta Cards (Client, Industry, etc.)
fontSize: 'var(--text-xs)'  // Labels
fontSize: 'var(--text-sm)'  // Values
```

**Status:** ✅ **100% Design System Compliant**

---

### **2. CLIENT CONTEXT SECTION** ⚠️

**Mixed: Design system + intentional hardcoded values**

#### **Sidebar (Left Column - 33% width)**

```tsx
// Micro Labels (Client Company, Industry)
fontSize: '9.5px'  // HARDCODED
```
**Reason:** Sidebar constraint - 12.8px too large for narrow space

```tsx
// Company Name
fontSize: '17px'  // HARDCODED
```
**Reason:** Prevents wrapping of long company names, maintains hierarchy

```tsx
// Industry Text
fontSize: '13px'  // HARDCODED
```
**Reason:** Creates 3-tier hierarchy (9.5px < 13px < 17px)

#### **Main Content (Right Column - 67% width)**

```tsx
// Company Overview (Lead Paragraph)
fontSize: 'clamp(19px, 2.8vw, 24px)'  // HARDCODED RANGE
```
**Reason:** Responsive editorial treatment, sits between body (16px) and heading (25px)

```tsx
// Market Context Paragraphs
fontSize: 'var(--text-sm)'  // 16px - DESIGN SYSTEM ✅
```

```tsx
// Capabilities List
fontSize: 'var(--text-sm)'  // 16px - DESIGN SYSTEM ✅
```

```tsx
// List Numbers
fontSize: '13px'  // HARDCODED
```
**Reason:** Creates hierarchy (number < text), elegant serif accent

**Status:** ⚠️ **60% Hardcoded - All Intentional**
**See:** Inline comments in `/src/app/components/ClientContextSection.tsx`

---

### **3. CHALLENGES SECTION** ⚠️

**Mostly design system with adaptive typography**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px - DESIGN SYSTEM ✅

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // DESIGN SYSTEM ✅

// Card Numbers (Large Background Numbers)
fontSize: cardCount >= 4 ? 'var(--text-3xl)' : 'var(--text-4xl)'
//       4+ cards: 48.8px               <4 cards: 61px
```

```tsx
// Card Titles
fontSize: cardCount >= 4 ? 'var(--text-base)' : 'var(--text-lg)'
//       4+ cards: 20px                 <4 cards: 25px
```

```tsx
// Card Questions - ADAPTIVE TYPOGRAPHY
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'
//       4+ cards: 14px (compact)      <4 cards: 16px (spacious)
```
**Reason:** Content-aware typography - adapts to layout density

**Status:** ⚠️ **15% Hardcoded - Smart Adaptive Feature**
**Pattern:** Dynamic sizing based on content count (2-10+ items)

---

### **4. ENGAGEMENT OBJECTIVES SECTION** ✅

**All typography uses design system variables**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px

// Objective Badge
fontSize: 'var(--text-xs)'  // 12.8px

// Objective Title
fontSize: 'var(--text-xl)'  // 31.25px

// Objective Description
fontSize: 'var(--text-sm)'  // 16px
```

**Status:** ✅ **100% Design System Compliant**

---

### **5. METHODOLOGY SECTION** ✅

**All typography uses design system variables**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px

// Timeline Node Numbers
fontSize: 'var(--text-base)'  // 20px

// Step Badge
fontSize: 'var(--text-xs)'  // 12.8px

// Step Title
fontSize: 'var(--text-xl)'  // 31.25px

// Step Description
fontSize: 'var(--text-sm)'  // 16px
```

**Status:** ✅ **100% Design System Compliant**

---

### **6. IMPACT SECTION** ⚠️

**Mostly design system with one strategic hardcoded value**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px - DESIGN SYSTEM ✅

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // DESIGN SYSTEM ✅

// Metric Values - STRATEGIC HARDCODE
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 28px → 40px
```
**Reason:** Prevents wrapping of "₹110 Cr" in 4-column grid (40px vs 39px = 1px matters!)

**Alternative:** Could use `var(--text-2xl)` (39px) if willing to accept occasional wrapping

```tsx
// Metric Labels
fontSize: 'var(--text-xs)'  // 12.8px - DESIGN SYSTEM ✅

// Metric Descriptions
fontSize: 'var(--text-sm)'  // 16px - DESIGN SYSTEM ✅
```

**Status:** ⚠️ **10% Hardcoded - Wrapping Prevention**
**See:** Inline comments in `/src/app/components/ImpactSection.tsx`

---

### **7. TESTIMONIAL SECTION** ✅

**All typography uses design system variables**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px

// Testimonial Quote
fontSize: 'clamp(1rem, 2.5vw, var(--text-lg))'  // 16px → 25px

// Attribution
fontSize: 'var(--text-xs)'  // 12.8px

// Rating
fontSize: 'var(--text-xs)'  // 12.8px
```

**Status:** ✅ **100% Design System Compliant**

---

### **8. FINAL CTA SECTION** ✅

**All typography uses design system variables**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px

// Description
fontSize: 'var(--text-base)'  // 20px
```

**Status:** ✅ **100% Design System Compliant**

---

### **9. RESOURCES SECTION** ✅

**All typography uses design system variables**

```tsx
// Section Label
fontSize: 'var(--text-xs)'  // 12.8px

// Section Heading
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px

// Description
fontSize: 'var(--text-sm)'  // 16px

// Resource Category
fontSize: 'var(--text-xs)'  // 12.8px
```

**Status:** ✅ **100% Design System Compliant**

---

### **10. NAVBAR** ❌

**Intentionally outside design system - Client requirement**

```tsx
// Secondary Nav (Latest Reports)
text-[12px]  // HARDCODED - Figma precision

// Main Nav (Services, Industries)
text-[14px]  // HARDCODED - Figma precision

// Mobile Menu Labels
text-[11px]  // HARDCODED - Figma precision
```

**Reason:** Client requirement for pixel-perfect Figma match. Uses sub-pixel positioning.

**Status:** ❌ **100% Hardcoded - Intentional (Client Spec)**

---

---

## 🎯 **WHEN TO USE WHAT**

### **Decision Matrix**

| Scenario | Solution | Variable/Value |
|----------|----------|----------------|
| **Standard section heading** | Use design system | `var(--text-3xl)` |
| **Body paragraph** | Use design system | `var(--text-sm)` |
| **Section label (uppercase)** | Use design system | `var(--text-xs)` |
| **Card title (4+ cards)** | Use design system | `var(--text-base)` |
| **Card title (2-3 cards)** | Use design system | `var(--text-lg)` |
| **Sidebar (narrow width)** | Hardcode smaller | `9.5px`, `13px`, `17px` |
| **Display metric** | Test both | `2.5rem` or `var(--text-2xl)` |
| **Responsive range** | Use clamp() | `clamp(19px, 2.8vw, 24px)` |
| **Content-aware sizing** | Dynamic conditional | `cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'` |
| **Navbar** | Hardcode (client spec) | `12px`, `14px` |

---

---

## 📐 **HARDCODED VALUES EXPLAINED**

### **Complete Inventory**

| Size | Location | Reason | Keep/Change |
|------|----------|--------|-------------|
| **9.5px** | Client Context sidebar labels | Sidebar spatial constraint | ✅ KEEP |
| **11px** | Navbar mobile labels | Figma precision requirement | ✅ KEEP |
| **12px** | Navbar text | Figma precision requirement | ✅ KEEP |
| **13px** | Client Context industry, list numbers | Visual hierarchy creation | ✅ KEEP |
| **14px** | Challenges questions (4+ cards) | Adaptive density management | ✅ KEEP |
| **17px** | Client Context company name | Wrapping prevention | ✅ KEEP |
| **19-24px** | Company overview (clamp range) | Responsive editorial treatment | ✅ KEEP |
| **40px** | Impact metrics (clamp max) | Wrapping prevention (1px matters) | ⚠️ TEST |

---

### **Why These Exist**

#### **1. Spatial Constraints** (9.5px, 13px, 17px)
- **Problem:** Sidebar is only 33% width
- **Design system:** 12.8px, 16px, 20px are too large
- **Solution:** Optical sizing for narrow spaces

#### **2. Wrapping Prevention** (40px, 17px)
- **Problem:** Text like "₹110 Cr" or long names wrap awkwardly
- **Design system:** Fixed sizes cause edge cases
- **Solution:** Tested pixel values that prevent wrapping

#### **3. Visual Hierarchy** (13px list numbers)
- **Problem:** Need size between 12.8px and 16px
- **Design system:** Gap too large (12.8px → 16px)
- **Solution:** 13px creates perfect hierarchical step

#### **4. Responsive Precision** (clamp 19-24px)
- **Problem:** Need specific min/max range for editorial treatment
- **Design system:** Fixed sizes don't scale responsively
- **Solution:** clamp() with tested min/max values

#### **5. Adaptive Layouts** (14px vs 16px)
- **Problem:** Content density varies (2-10+ items)
- **Design system:** One-size-fits-all doesn't work
- **Solution:** Dynamic sizing based on content count

#### **6. Client Requirements** (navbar 11px, 12px, 14px)
- **Problem:** Must match Figma exactly
- **Design system:** 12.8px ≠ 12px precision
- **Solution:** Exact pixel values per client spec

---

---

## 🔄 **COMMON PATTERNS**

### **Pattern 1: Responsive Headings**

```tsx
// All main section headings use this pattern
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'
//       min: 28px   fluid    max: 48.8px (design system variable)
```

**Use:** Hero titles, section headers  
**Benefit:** Scales from mobile to desktop while respecting design system max

---

### **Pattern 2: Adaptive Card Sizing**

```tsx
// Card typography that changes based on content density
fontSize: cardCount >= 4 ? 'var(--text-base)' : 'var(--text-lg)'
//       4+ cards: 20px (compact)        <4 cards: 25px (spacious)
```

**Use:** Challenge cards, grid layouts  
**Benefit:** Automatically adjusts to content amount

---

### **Pattern 3: Editorial Lead Paragraph**

```tsx
// Featured first paragraph (larger than body, smaller than heading)
fontSize: 'clamp(19px, 2.8vw, 24px)'
//       mobile: 19px  fluid   desktop: 24px
```

**Use:** Company overview, featured quotes  
**Benefit:** Creates editorial "lead paragraph" treatment

---

### **Pattern 4: Sidebar Micro-Typography**

```tsx
// Labels in narrow sidebars
fontSize: '9.5px'  // Smaller than --text-xs (12.8px)

// Values in narrow sidebars
fontSize: '13px'   // Between --text-xs (12.8px) and --text-sm (16px)

// Primary info in sidebars
fontSize: '17px'   // Between --text-sm (16px) and --text-base (20px)
```

**Use:** Sidebar layouts, narrow columns  
**Benefit:** Creates hierarchy within spatial constraints

---

---

## 🌲 **DECISION TREE**

```
Need to set a font size?
│
├─ Is it a standard section heading? → Use var(--text-3xl)
│
├─ Is it body text? → Use var(--text-sm)
│
├─ Is it a section label (uppercase)? → Use var(--text-xs)
│
├─ Is it in a sidebar or narrow column?
│  ├─ Micro label? → Use 9.5px
│  ├─ Secondary info? → Use 13px
│  └─ Primary info? → Use 17px
│
├─ Is it a display metric that might wrap?
│  └─ Use clamp(1.75rem, 5vw, 2.5rem) or test var(--text-2xl)
│
├─ Does it need responsive range?
│  └─ Use clamp(minPx, vw%, var(--text-size))
│
├─ Does content amount vary (2-10+ items)?
│  └─ Use conditional: cardCount >= 4 ? smaller : larger
│
├─ Is it navbar?
│  └─ Use exact Figma px values (11px, 12px, 14px)
│
└─ When in doubt → Use design system variable
```

---

---

## 📝 **CODE EXAMPLES**

### **Example 1: Standard Section**

```tsx
export function StandardSection() {
  return (
    <section>
      {/* Section Label - Always use var(--text-xs) */}
      <span style={{ fontSize: 'var(--text-xs)' }}>
        SECTION LABEL
      </span>
      
      {/* Section Heading - Use clamp with design system max */}
      <h2 style={{ fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' }}>
        Section Heading
      </h2>
      
      {/* Body Text - Always use var(--text-sm) */}
      <p style={{ fontSize: 'var(--text-sm)' }}>
        Body paragraph text goes here.
      </p>
    </section>
  );
}
```

---

### **Example 2: Adaptive Card Grid**

```tsx
export function CardGrid({ items }) {
  const itemCount = items.length;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {items.map((item, index) => (
        <div key={index}>
          {/* Title size adapts to item count */}
          <h3 style={{ 
            fontSize: itemCount >= 4 
              ? 'var(--text-base)'   // 20px for dense layouts
              : 'var(--text-lg)'     // 25px for spacious layouts
          }}>
            {item.title}
          </h3>
          
          {/* Description always uses standard body */}
          <p style={{ fontSize: 'var(--text-sm)' }}>
            {item.description}
          </p>
        </div>
      ))}
    </div>
  );
}
```

---

### **Example 3: Sidebar Layout**

```tsx
export function Sidebar() {
  return (
    <div className="md:col-span-4"> {/* 33% width */}
      {/* Micro label - Hardcoded for spatial constraint */}
      <span style={{ fontSize: '9.5px' }}>
        LABEL
      </span>
      
      {/* Primary info - Hardcoded to prevent wrapping */}
      <h3 style={{ fontSize: '17px' }}>
        Company Name That Is Long
      </h3>
      
      {/* Secondary info - Hardcoded for hierarchy */}
      <p style={{ fontSize: '13px' }}>
        Industry description
      </p>
    </div>
  );
}
```

---

---

## ✅ **IMPLEMENTATION CHECKLIST**

### **Completed:**
- ✅ Added `--text-4xl` (61px) to design system
- ✅ Added `--text-5xl` (76.3px) to design system
- ✅ Added `--text-2xs` (12px) utility size
- ✅ Added `--text-compact` (0.875rem) utility size
- ✅ Comprehensive comments in theme.css
- ✅ Inline rationale comments in Client Context Section
- ✅ Inline rationale comments in Impact Section
- ✅ Inline rationale comments in Challenges Section
- ✅ Created complete documentation (this file)

### **Optional Improvements:**
- ⚠️ Test Impact metrics with `var(--text-2xl)` instead of `2.5rem`
- ⚠️ Consider replacing `0.875rem` with `var(--text-compact)` in Challenges
- ⚠️ Update design system guide with new variables

---

---

## 🎓 **FOR FUTURE DEVELOPERS**

### **Golden Rules:**

1. **Start with Design System**
   - Always check `/src/styles/theme.css` first
   - Use CSS variables when possible
   
2. **Hardcode Only When Necessary**
   - Spatial constraints (sidebars)
   - Wrapping prevention
   - Client specifications
   - Content-aware layouts
   
3. **Document Your Decisions**
   - Add inline comments explaining why
   - Reference this document
   - Update when adding new patterns

4. **Test Real Content**
   - Don't assume sizes work with all text
   - Test with longest expected values
   - Check wrapping at various viewports

5. **Maintain Consistency**
   - Use same patterns for same scenarios
   - Don't create new sizes unnecessarily
   - Update design system when adding common sizes

---

### **Quick Debugging:**

**Text too large?**
- Check if you're in a narrow container (sidebar)
- Consider using next size down in scale

**Text wrapping unexpectedly?**
- Measure actual content length
- Test with real data, not Lorem Ipsum
- May need hardcoded max size

**Hierarchy unclear?**
- Check contrast between adjacent sizes
- May need in-between size (13px, 17px)
- Consider font weight instead

**Inconsistent across sections?**
- Check if using variables vs hardcoded
- Verify all sections use same pattern
- Update design system if needed

---

---

## 📚 **RELATED DOCUMENTATION**

- `/FONT_SIZE_RATIONALE_ANALYSIS.md` - Deep dive into each decision
- `/TYPOGRAPHY_SYSTEM_AUDIT.md` - Full component audit
- `/FONT_DECISION_SUMMARY.md` - Executive summary
- `/DESIGN_SYSTEM.md` - Complete design system
- `/src/styles/theme.css` - CSS variables with comments
- Component files - Inline rationale comments

---

**Last Updated:** January 2025  
**Version:** 2.0  
**Status:** ✅ Production Ready

