# FIGMA BUTTON QUICK REFERENCE

## 🎯 TL;DR - What to Do

**Recommendation:** Update Figma designs to match our Button component system.

### Quick Changes Needed:
1. ✏️ Border radius: 5px → **10px**
2. 📏 Button height: 34px → **40px minimum**
3. 🎨 Animated arrow → **Static ArrowUpRight icon**
4. 🔘 Gray button → **Use Secondary variant**

---

## 🗺️ MAPPING GUIDE

### Figma → System Component Mapping

| Figma Component | Use This System Component |
|----------------|---------------------------|
| `MainCtaNav` (red, no icon) | `<Button variant="brand" size="md">` |
| `BrandCta` (red + arrow) | `<Button variant="brand" size="md" icon={<ArrowUpRight />}>` |
| `BrandCta` (black + arrow) | `<Button variant="primary" size="md" icon={<ArrowUpRight />}>` |
| `ConnectNow` (gray) | `<Button variant="secondary" size="sm">` |
| `ExploreCta` (text link) | Create `<TextLink>` component (not Button) |

---

## 📊 COMPARISON TABLE

| Property | Figma Value | System Value | Action |
|----------|-------------|--------------|--------|
| **Ken Bold Red** | #b01f24 | #b01f24 | ✅ Keep as-is |
| **Font** | DM Sans Bold | DM Sans Bold | ✅ Keep as-is |
| **Border Radius** | 5px | 10px | ✏️ Update Figma |
| **Height** | ~34px | 40-56px | ✏️ Update Figma |
| **Gradients** | Yes | No | 🤔 Decide |
| **Arrow Animation** | Dual-layer | Static | ✏️ Use static |
| **Shadows** | Minimal | Optional | ✅ Both minimal |

---

## 💻 CODE EXAMPLES

### Before (Figma Import):
```tsx
import MainCtaNav from '@/imports/MainCtaNav';

<MainCtaNav />
// Output: Small button (34px), 5px radius, gradient
```

### After (System Component):
```tsx
import { Button } from '@/app/components/Button';

<Button variant="brand" size="md">
  Schedule a Demo
</Button>
// Output: Standard button (48px), 10px radius, solid color
```

### With Icon:
```tsx
import { ArrowUpRight } from 'lucide-react';

<Button variant="brand" size="md" icon={<ArrowUpRight size={20} />}>
  Schedule a Demo
</Button>
```

---

## 🎨 VISUAL SIZE COMPARISON

```
FIGMA BUTTONS (Current):
┌─────────────────────────┐
│  Schedule a Demo        │  ← 34px height
└─────────────────────────┘  ← 5px radius

SYSTEM BUTTONS (Recommended):
┌──────────────────────────┐
│   Schedule a Demo        │  ← 48px height (md)
└──────────────────────────┘  ← 10px radius

or

┌──────────────────────────┐
│                          │
│   Schedule a Demo        │  ← 56px height (lg) ⭐ HERO CTAs
│                          │
└──────────────────────────┘  ← 10px radius
```

---

## ✅ DECISION CHECKLIST

Mark your decisions:

- [ ] **Border Radius:** Standardize to 10px across all buttons
- [ ] **Button Heights:** Increase to 40px minimum (accessibility)
- [ ] **Gradients:** 
  - [ ] Remove from Figma (use solid colors)
  - [ ] OR Add `gradient` prop to system
- [ ] **Animated Arrows:** Replace with static icons
- [ ] **Gray Button:** Map to Secondary variant
- [ ] **Text Links:** Create separate TextLink component

---

## 🚀 IMPLEMENTATION PRIORITY

### Phase 1: Critical (Do First) ⚡
1. Increase button heights to 40px (accessibility)
2. Update border radius to 10px (consistency)
3. Replace animated arrows with static icons

### Phase 2: Nice to Have 💡
4. Add optional `gradient` prop (if brand requires)
5. Create TextLink component for gradient text
6. Add `tight` prop for 5px radius edge cases

### Phase 3: Don't Need ❌
7. ~~Re-implement arrow animation~~ (removed intentionally)
8. ~~Add gray gradient variant~~ (use Secondary)
9. ~~Add XS size (34px)~~ (below accessibility minimum)

---

## 🔗 QUICK LINKS

- **Full Analysis:** `/FIGMA_BUTTON_ANALYSIS.md`
- **Summary:** `/FIGMA_ANALYSIS_SUMMARY.md`
- **Visual Comparison:** http://localhost:3000/figma-comparison
- **Button Docs:** Components → Button Variants & States
- **Usage Guide:** Components → Button Usage & Applications

---

## 📞 CONTACT

Questions? Review these files or check the design system dashboard.

**Last Updated:** January 29, 2026
