# 🎨 TYPOGRAPHY QUICK REFERENCE
**One-page cheat sheet for developers**

---

## 📊 **HTML HEADING → CSS VARIABLE MAPPING**

```
┌──────────┬────────────────┬──────────┬────────────────────────────────┐
│ HTML     │ CSS Variable   │ Size     │ Usage                          │
├──────────┼────────────────┼──────────┼────────────────────────────────┤
│ h1       │ --text-3xl     │ 48.8px   │ Hero, section headings         │
│ h2       │ --text-2xl     │ 39px     │ Major section titles           │
│ h3       │ --text-xl      │ 31.25px  │ Subsection headings            │
│ h4       │ --text-lg      │ 25px     │ Card titles (2-3 cards)        │
│ h4       │ --text-base    │ 20px     │ Card titles (4+ cards)         │
│ h5       │ --text-sm      │ 16px     │ Small headings                 │
│ h6       │ --text-xs      │ 12.8px   │ Micro headings, labels         │
│ p        │ --text-sm      │ 16px     │ Body text                      │
│ small    │ --text-xs      │ 12.8px   │ Metadata, captions             │
└──────────┴────────────────┴──────────┴────────────────────────────────┘
```

---

## 🎯 **FONT FAMILY RULES**

```
┌─────────────────────┬──────────────────────────────────────────┐
│ Element Type        │ Font Family                              │
├─────────────────────┼──────────────────────────────────────────┤
│ Hero h1             │ 'Noto Serif', serif (Light 300)          │
│ Section h2          │ 'Noto Serif', serif (Light 300)          │
│ Subsection h3       │ 'DM Sans', sans-serif (Medium 500)       │
│ Card h4             │ 'DM Sans', sans-serif (Medium 500)       │
│ Body text           │ 'DM Sans', sans-serif (Normal 400)       │
│ Labels              │ 'DM Sans', sans-serif (Medium 500)       │
│ Buttons             │ 'DM Sans', sans-serif (Bold 700)         │
│ Lead paragraph      │ 'Noto Serif', serif (Normal 400)         │
│ Large numbers       │ 'Noto Serif', serif (Light 300)          │
└─────────────────────┴──────────────────────────────────────────┘
```

**Rule of Thumb:**
- **Noto Serif** → Large editorial headings (h1, h2), featured content
- **DM Sans** → Everything else (h3-h6, body, UI, buttons)

---

## 📏 **COMPLETE SIZE SCALE**

```
76.3px  ━━━━━━━━━━━━━━━━━  --text-5xl  (Rarely used)
61px    ━━━━━━━━━━━━━━  --text-4xl  (Challenge numbers <4 cards)
48.8px  ━━━━━━━━━━━━  --text-3xl  h1, h2 (Hero/Section headings)
39px    ━━━━━━━━━━  --text-2xl  h2 (Major titles)
31.25px ━━━━━━━━  --text-xl   h3 (Subsection headings)
25px    ━━━━━━  --text-lg   h4 (Card titles - spacious)
20px    ━━━━━  --text-base  h4 (Card titles - compact)
16px    ━━━━  --text-sm    Body text, descriptions
14px    ━━━  --text-compact (Compact layouts)
12.8px  ━━  --text-xs    Labels, metadata
12px    ━━  --text-2xs   Navbar, micro labels
```

**Major Third Ratio:** Each size is 1.25× the previous size

---

## 🎨 **COLOR HIERARCHY**

### **On Light Backgrounds**
```tsx
text-black           // 100% - Rare, very strong
text-black/90        // 90%  - Primary headings ✅
text-black/70        // 70%  - Body text ✅
text-black/60        // 60%  - Secondary text
text-black/40        // 40%  - Labels, metadata ✅
text-black/20        // 20%  - Disabled
text-black/[0.08]    // 8%   - Decorative numbers
```

### **On Dark Backgrounds**
```tsx
text-white/95        // 95%  - Primary headings ✅
text-white/70        // 70%  - Body text
text-white/60        // 60%  - Secondary text ✅
text-white/40        // 40%  - Labels, metadata ✅
```

---

## 📐 **LINE HEIGHT REFERENCE**

```
leading-[1.05]  → Large display numbers (tight)
leading-[1.15]  → Hero, large headings (h1, h2)
leading-[1.25]  → Card titles, medium headings (h3, h4)
leading-[1.3]   → Methodology titles
leading-[1.35]  → Resource card titles
leading-[1.4]   → Dense text blocks
leading-[1.5]   → Standard body, compact layouts
leading-[1.6]   → Comfortable reading
leading-[1.7]   → Long-form content, articles
```

---

## 🔤 **LETTER SPACING (TRACKING)**

```
tracking-tight      → Headlines, headings (-0.025em)
tracking-normal     → Body text (0em)
tracking-[1.5px]    → Resource categories
tracking-[2px]      → Step labels, micro labels
tracking-[3px]      → Section labels (uppercase)
```

---

## ⚡ **COPY-PASTE TEMPLATES**

### **Hero Heading (h1)**
```tsx
<h1 
  className="leading-[1.15] font-light text-white/95 tracking-tight" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
>
  Your Hero Title
</h1>
```

---

### **Section Heading (h2)**
```tsx
<h2 
  className="leading-[1.15] font-light text-black tracking-tight" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' }}
>
  Section Title
</h2>
```

---

### **Subsection Heading (h3)**
```tsx
<h3 
  className="font-medium text-black leading-[1.3]" 
  style={{ fontSize: 'var(--text-xl)' }}
>
  Subsection Title
</h3>
```

---

### **Card Title (h4 - Spacious)**
```tsx
<h4 
  className="font-medium text-black leading-[1.25]" 
  style={{ fontSize: 'var(--text-lg)' }}
>
  Card Title
</h4>
```

---

### **Card Title (h4 - Compact)**
```tsx
<h4 
  className="font-medium text-black leading-[1.25]" 
  style={{ fontSize: 'var(--text-base)' }}
>
  Card Title
</h4>
```

---

### **Body Paragraph**
```tsx
<p 
  className="leading-[1.7] text-black/70" 
  style={{ fontSize: 'var(--text-sm)' }}
>
  Your body text here
</p>
```

---

### **Section Label (Uppercase)**
```tsx
<span 
  className="font-medium text-black/40 uppercase tracking-[3px]" 
  style={{ fontSize: 'var(--text-xs)' }}
>
  SECTION LABEL
</span>
```

---

### **Lead Paragraph (Featured)**
```tsx
<p 
  className="leading-[1.45] font-normal text-black" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'clamp(19px, 2.8vw, 24px)' }}
>
  Featured opening paragraph with editorial treatment
</p>
```

---

## 🔍 **DECISION FLOWCHART**

```
START: Need to add text
│
├─ Is it the main page title?
│  └─ YES → h1 + var(--text-3xl) + Noto Serif Light
│
├─ Is it a main section heading?
│  └─ YES → h2 + clamp(var(--text-3xl)) + Noto Serif Light
│
├─ Is it a subsection title?
│  └─ YES → h3 + var(--text-xl) + DM Sans Medium
│
├─ Is it a card title?
│  ├─ 2-3 cards? → h4 + var(--text-lg) + DM Sans Medium
│  └─ 4+ cards?  → h4 + var(--text-base) + DM Sans Medium
│
├─ Is it a featured paragraph?
│  └─ YES → p + clamp(19px-24px) + Noto Serif Normal
│
├─ Is it body text?
│  └─ YES → p + var(--text-sm) + DM Sans Normal
│
├─ Is it a label/metadata?
│  └─ YES → span + var(--text-xs) + DM Sans Medium + uppercase
│
└─ Is it navbar/micro label?
   └─ YES → span + var(--text-2xs) + DM Sans Medium
```

---

## 🎯 **COMMON PATTERNS**

### **Pattern 1: Responsive Section Header**
```tsx
<div>
  <span style={{ fontSize: 'var(--text-xs)' }} className="uppercase tracking-[3px]">
    SECTION LABEL
  </span>
  <h2 style={{ fontFamily: "'Noto Serif', serif", fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' }}>
    Section Heading
  </h2>
  <p style={{ fontSize: 'var(--text-sm)' }} className="text-black/60">
    Description text
  </p>
</div>
```

---

### **Pattern 2: Adaptive Card**
```tsx
function Card({ cardCount }) {
  return (
    <div>
      <h4 style={{ fontSize: cardCount >= 4 ? 'var(--text-base)' : 'var(--text-lg)' }}>
        Card Title
      </h4>
      <p style={{ fontSize: cardCount >= 4 ? 'var(--text-compact)' : 'var(--text-sm)' }}>
        Description
      </p>
    </div>
  );
}
```

---

### **Pattern 3: Content Hierarchy**
```tsx
<section>
  {/* Label */}
  <span style={{ fontSize: 'var(--text-xs)' }}>LABEL</span>
  
  {/* Heading */}
  <h2 style={{ fontSize: 'var(--text-3xl)' }}>Heading</h2>
  
  {/* Subheading */}
  <h3 style={{ fontSize: 'var(--text-xl)' }}>Subheading</h3>
  
  {/* Body */}
  <p style={{ fontSize: 'var(--text-sm)' }}>Body text</p>
  
  {/* Metadata */}
  <small style={{ fontSize: 'var(--text-xs)' }}>Metadata</small>
</section>
```

---

## 🚨 **REMEMBER**

✅ **Always use CSS variables** (var(--text-*))  
✅ **Noto Serif = Editorial headings** (h1, h2, featured content)  
✅ **DM Sans = Everything else** (h3-h6, body, UI)  
✅ **Explicitly style every heading** (no default HTML styles)  
✅ **Use adaptive sizing** for cards (2-3 vs 4+ cards)  

❌ **Never use native HTML styles** (h1 without classes won't work)  
❌ **Never hardcode random sizes** (use design system)  
❌ **Never mix font families incorrectly** (h2 shouldn't be DM Sans)  

---

## 📱 **RESPONSIVE CLAMP PATTERNS**

```tsx
// Hero headings (28px → 48.8px)
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'

// Lead paragraphs (19px → 24px)
fontSize: 'clamp(19px, 2.8vw, 24px)'

// Testimonial quotes (16px → 25px)
fontSize: 'clamp(1rem, 2.5vw, var(--text-lg))'

// Impact metrics (28px → 40px)
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'
```

---

## 🎨 **SECTION-SPECIFIC OVERRIDES**

Some sections use **intentional custom sizes**:

```tsx
// Client Context Sidebar (narrow space)
fontSize: '9.5px'   // Micro labels
fontSize: '13px'    // Secondary info
fontSize: '17px'    // Company name

// Navbar (Figma precision)
text-[12px]         // Secondary nav
text-[14px]         // Main nav
text-[11px]         // Mobile labels
```

**See:** `/FONT_SIZE_RATIONALE_ANALYSIS.md` for detailed explanations

---

## 📚 **FULL DOCUMENTATION**

- **Complete Guide:** `/TYPOGRAPHY_SYSTEM_COMPLETE.md`
- **HTML Elements:** `/HTML_ELEMENTS_TYPOGRAPHY_GUIDE.md`
- **Rationale:** `/FONT_SIZE_RATIONALE_ANALYSIS.md`
- **CSS Variables:** `/src/styles/theme.css`

---

**Print this page and keep it at your desk!** 📌

