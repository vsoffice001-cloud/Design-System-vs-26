# Design Tokens Reference

**Last Updated:** January 21, 2026  
**Version:** 1.0.0

---

## Overview

This document contains all atomic design tokens - the foundational values that power the entire design system. These tokens ensure consistency, maintainability, and scalability across all components and patterns.

---

## 🎨 Color System

### Primary Palette (92% Usage)

The foundation of the design system. These colors form the base for 92% of all UI elements.

| Color Name | Hex Code | RGB | Usage | Context |
|------------|----------|-----|-------|---------|
| **Pure Black** | `#000000` | `rgb(0, 0, 0)` | Primary text, dark backgrounds, high contrast elements | Hero sections, navigation, footer |
| **Pure White** | `#ffffff` | `rgb(255, 255, 255)` | Light backgrounds, text on dark, clean sections | Content areas, cards |
| **Warm Off-White** | `#f5f2f1` | `rgb(245, 242, 241)` | Highlighted sections, subtle backgrounds | Featured content, testimonials, stats sections |
| **Warm Border** | `#eae5e3` | `rgb(234, 229, 227)` | Subtle borders, dividers | Card borders, section separators |

**CSS Variables:**
```css
--color-black: #000000;
--color-white: #ffffff;
--color-warm-bg: #f5f2f1;
--color-warm-border: #eae5e3;
```

---

### Brand Red - Ken Bold (5% Usage)

**CRITICAL RULE:** Red is reserved EXCLUSIVELY for major call-to-action buttons. Never use for backgrounds, text, or decorative elements.

| Color Name | Hex Code | RGB | State | Usage |
|------------|----------|-----|-------|-------|
| **Red 500** | `#c62d31` | `rgb(198, 45, 49)` | Gradient End | Brand CTA gradient endpoint |
| **Red 600 (Brand)** | `#b01f24` | `rgb(176, 31, 36)` | Default | Primary brand color, gradient start |
| **Red 700** | `#8f181d` | `rgb(143, 24, 29)` | Hover | Hover state for brand buttons |
| **Red 800** | `#771419` | `rgb(119, 20, 25)` | Active | Active/pressed state |
| **Red 900** | `#5f1014` | `rgb(95, 16, 20)` | Deep | Reserved for extreme emphasis |

**CSS Variables:**
```css
--color-brand-red-500: #c62d31;
--color-brand-red-600: #b01f24;
--color-brand-red-700: #8f181d;
--color-brand-red-800: #771419;
--color-brand-red-900: #5f1014;
```

**Gradient Definition:**
```css
background: linear-gradient(90deg, #b01f24, #c62d31);
background-size: 200% 200%;
background-position: 0% 50%;
transition: background-position 0.6s cubic-bezier(0.22, 1, 0.36, 1);

/* On hover */
background-position: 100% 50%;
```

---

### Accent Colors (3% Usage)

**CRITICAL RULE:** Accent colors are ONLY for shadows (6-8% opacity), metric highlights, or subtle animation effects. NEVER as backgrounds or elements competing with red CTAs.

| Color Name | Hex Code | RGB | Usage |
|------------|----------|-----|-------|
| **Purple 600** | `#806ce0` | `rgb(128, 108, 224)` | Shadow tints, hover glows (6-8% opacity) |
| **Periwinkle 500** | `#c3c6f9` | `rgb(195, 198, 249)` | Subtle highlights, animation accents |
| **Perano 500** | `#dfeafa` | `rgb(223, 234, 250)` | Very subtle backgrounds (5% opacity max) |
| **Warm 600** | `#d9d1ce` | `rgb(217, 209, 206)` | Warm neutral tints |

**CSS Variables:**
```css
--color-accent-purple: #806ce0;
--color-accent-periwinkle: #c3c6f9;
--color-accent-perano: #dfeafa;
--color-accent-warm: #d9d1ce;
```

**Allowed Usage Examples:**
```css
/* ✅ CORRECT - Subtle shadow tint */
box-shadow: 0 8px 24px rgba(128, 108, 224, 0.06);

/* ✅ CORRECT - Metric highlight */
color: #806ce0; /* Only on numbers/metrics */

/* ❌ WRONG - Never as background */
background: #806ce0;

/* ❌ WRONG - Never as buttons */
button { background: #c3c6f9; }
```

---

### Gradients

#### Primary Gradient (Dark to Grey)
```css
background: linear-gradient(90deg, #0a0a0a, #6a6a6a);
```
- **Direction:** Left to right (90deg)
- **Start:** Near-black (#0a0a0a)
- **End:** Medium grey (#6a6a6a)
- **Usage:** Primary variant buttons, strong contrast elements

#### Brand Red Gradient
```css
background: linear-gradient(90deg, #b01f24, #c62d31);
background-size: 200% 200%;
```
- **Direction:** Left to right (90deg)
- **Start:** Red 600 (#b01f24)
- **End:** Red 500 (#c62d31)
- **Animation:** Background position shift on hover (0% → 100%)
- **Usage:** Brand CTA buttons ONLY

---

## 📐 Typography System

### Type Scale - Major Third (1.25 Ratio)

Based on a **Major Third musical scale (1.25x)** with **16px base size**.

| Token | Size (px) | Size (rem) | Line Height | Usage Context | HTML Tag |
|-------|-----------|------------|-------------|---------------|----------|
| `--text-5xl` | 76.3px | 4.769rem | 1.1 | Massive hero headings (rare) | `<h1>` |
| `--text-4xl` | 61px | 3.815rem | 1.1 | Extra large headings | `<h1>` |
| `--text-3xl` | 48.8px | 3.052rem | 1.2 | **Hero H1 - Reserved for hero moments** | `<h1>` |
| `--text-2xl` | 39px | 2.441rem | 1.3 | **Section H2 - Standard for main sections** | `<h2>` |
| `--text-xl` | 31.25px | 1.953rem | 1.4 | **Subsection H3 - Objectives & steps** | `<h3>` |
| `--text-lg` | 25px | 1.563rem | 1.5 | **Card titles (2-3 cards)** | `<h4>` |
| `--text-base` | 20px | 1.25rem | 1.6 | **Large body text, card titles (4+ cards)** | `<p>`, `<h4>` |
| `--text-sm` | 16px | 1rem | 1.6 | **Standard body text, descriptions** | `<p>` |
| `--text-xs` | 12.8px | 0.8rem | 1.5 | **Labels, metadata, categories** | `<span>` |

**CSS Variables Definition:**
```css
:root {
  --text-5xl: 4.769rem;    /* 76.3px */
  --text-4xl: 3.815rem;    /* 61px */
  --text-3xl: 3.052rem;    /* 48.8px - Hero */
  --text-2xl: 2.441rem;    /* 39px - Sections */
  --text-xl: 1.953rem;     /* 31.25px - Subsections */
  --text-lg: 1.563rem;     /* 25px - Large cards */
  --text-base: 1.25rem;    /* 20px - Body large */
  --text-sm: 1rem;         /* 16px - Body standard */
  --text-xs: 0.8rem;       /* 12.8px - Labels */
}
```

### Font Families

```css
--font-sans: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
--font-mono: 'Courier New', Courier, monospace;
```

### Font Weights

```css
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
```

### Usage Rules

1. **Never skip hierarchy levels** - If you use H1, next should be H2, not H4
2. **--text-3xl is sacred** - Only for hero sections, use sparingly
3. **2-3 cards** → Use `--text-lg` for titles
4. **4+ cards** → Use `--text-base` for titles to maintain visual balance
5. **Generous line-height** - Increases with smaller text for readability

---

## 📏 Spacing Scale

Based on **4px base unit** with Tailwind-compatible rem values.

| Token | Pixels | Rem | Tailwind Class | Usage |
|-------|--------|-----|----------------|-------|
| `spacing-1` | 4px | 0.25rem | `gap-1`, `p-1` | Tight spacing, icon gaps |
| `spacing-2` | 8px | 0.5rem | `gap-2`, `p-2` | Minimal padding, small gaps |
| `spacing-3` | 12px | 0.75rem | `gap-3`, `p-3` | Comfortable spacing |
| `spacing-4` | 16px | 1rem | `gap-4`, `p-4` | Standard spacing |
| `spacing-5` | 20px | 1.25rem | `gap-5`, `p-5` | Comfortable padding |
| `spacing-6` | 24px | 1.5rem | `gap-6`, `p-6` | **Standard grid gap** |
| `spacing-8` | 32px | 2rem | `gap-8`, `p-8` | **Large grid gap, card padding** |
| `spacing-10` | 40px | 2.5rem | `gap-10`, `p-10` | Generous spacing |
| `spacing-12` | 48px | 3rem | `gap-12`, `p-12` | **Large container padding** |
| `spacing-16` | 64px | 4rem | `gap-16`, `py-16` | **Section vertical padding** |
| `spacing-20` | 80px | 5rem | `gap-20`, `py-20` | **Large section padding** |

### Standard Spacing Patterns

```css
/* Section Vertical Padding */
.section { padding-top: 4rem; padding-bottom: 4rem; } /* py-16 */
.section-large { padding-top: 5rem; padding-bottom: 5rem; } /* py-20 */

/* Grid Gaps */
.grid-standard { gap: 1.5rem; } /* gap-6 */
.grid-large { gap: 2rem; } /* gap-8 */

/* Card Padding */
.card-small { padding: 1.5rem; } /* p-6 */
.card-medium { padding: 2rem; } /* p-8 */
.card-large { padding: 3rem; } /* p-12 */
```

---

## 🔲 Border Radius System

**CRITICAL RULE:** Never mix radius sizes within the same component.

| Token | Size | Usage | Examples |
|-------|------|-------|----------|
| `radius-image` | **2.5px** | Images, photos, visual media | Hero images, photo grids, thumbnails |
| `radius-small` | **5px** | Buttons, small cards, badges | All button variants, badges, small UI elements |
| `radius-large` | **10px** | Big cards, containers, sections | Feature cards, stat containers, modals |

**CSS Variables:**
```css
--radius-image: 2.5px;
--radius-small: 5px;
--radius-large: 10px;
```

**Usage Examples:**
```css
/* Images */
img { border-radius: 2.5px; }

/* Buttons */
button { border-radius: 5px; }

/* Cards */
.card-small { border-radius: 5px; }
.card-large { border-radius: 10px; }
```

---

## 🌑 Shadow System

Three-level elevation system for depth and hierarchy.

### Shadow Levels

```css
/* Subtle Elevation - Level 1 */
--shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
/* Usage: Subtle borders, minimal elevation */

/* Standard Cards - Level 2 */
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
/* Usage: Default card elevation, dropdowns */

/* Prominent Elements - Level 3 */
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
/* Usage: Modals, popovers, important CTAs */
```

### Brand CTA Shadow (Special)

```css
/* Brand Button Default */
box-shadow: 0 8px 24px rgba(176, 31, 36, 0.15);

/* Brand Button Hover - Animated Glow */
box-shadow: 0 12px 32px rgba(176, 31, 36, 0.25);
transition: box-shadow 0.6s cubic-bezier(0.22, 1, 0.36, 1);
```

### Accent Shadow Tints

```css
/* Purple accent shadow (subtle interactions) */
box-shadow: 0 8px 24px rgba(128, 108, 224, 0.06);

/* Warm shadow (highlighted sections) */
box-shadow: 0 4px 12px rgba(217, 209, 206, 0.08);
```

---

## ⏱️ Animation & Transition System

### Easing Functions

```css
/* Smooth, premium feel */
--ease-smooth: cubic-bezier(0.22, 1, 0.36, 1);

/* Subtle bounce */
--ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1);

/* Sharp entrance */
--ease-sharp: cubic-bezier(0.4, 0, 0.2, 1);

/* Natural ease-out */
--ease-out: cubic-bezier(0, 0, 0.2, 1);
```

### Duration Tokens

```css
--duration-instant: 150ms;   /* Micro-interactions */
--duration-fast: 300ms;      /* Button hovers */
--duration-normal: 600ms;    /* Standard transitions */
--duration-slow: 900ms;      /* Large animations */
```

### Standard Transitions

```css
/* Button Transitions */
transition: all 0.6s cubic-bezier(0.22, 1, 0.36, 1);

/* Background Gradient Shift */
background-position: 0% 50%;
transition: background-position 0.6s cubic-bezier(0.22, 1, 0.36, 1);

/* Shadow Glow */
transition: box-shadow 0.6s cubic-bezier(0.22, 1, 0.36, 1);

/* Transform Scale */
transition: transform 0.3s cubic-bezier(0.22, 1, 0.36, 1);
```

---

## 📱 Breakpoints

```css
/* Mobile First Approach */
--breakpoint-sm: 640px;   /* Small devices */
--breakpoint-md: 768px;   /* Tablets */
--breakpoint-lg: 1024px;  /* Laptops */
--breakpoint-xl: 1280px;  /* Desktops */
--breakpoint-2xl: 1536px; /* Large screens */
```

**Tailwind Usage:**
```css
/* Mobile (default) */
.class { ... }

/* Tablet and up */
@media (min-width: 768px) { ... } /* md: */

/* Desktop and up */
@media (min-width: 1024px) { ... } /* lg: */
```

---

## 🎯 Layout Constraints

```css
/* Max Content Width */
--max-width-content: 1000px;
--max-width-wide: 1200px;

/* Container Padding */
--container-padding-mobile: 1rem;    /* px-4 */
--container-padding-tablet: 1.5rem;  /* sm:px-6 */
--container-padding-desktop: 2rem;   /* md:px-8 */
```

**Standard Container Pattern:**
```html
<div class="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
  <!-- Content -->
</div>
```

---

## 🔍 Opacity Scale

```css
/* Text Opacity */
--opacity-secondary: 0.7;   /* 70% - Secondary text */
--opacity-tertiary: 0.6;    /* 60% - Tertiary text */
--opacity-disabled: 0.4;    /* 40% - Disabled state */
--opacity-subtle: 0.1;      /* 10% - Very subtle backgrounds */

/* Border Opacity */
--border-opacity-light: 0.1;  /* 10% - Light borders */
--border-opacity-standard: 0.2; /* 20% - Standard borders */

/* Accent Shadow Opacity */
--accent-shadow-opacity: 0.06; /* 6% - Accent color shadows */
```

---

## 📦 Z-Index Scale

```css
--z-base: 1;
--z-dropdown: 10;
--z-sticky: 100;
--z-navbar: 1000;
--z-modal-backdrop: 9000;
--z-modal: 9999;
--z-tooltip: 10000;
```

---

## ✅ Token Usage Checklist

Before using any token, verify:

- [ ] **Color usage respects 92-5-3 rule**
- [ ] **Red is only on major CTAs**
- [ ] **Accent colors are shadows/highlights only (6-8% opacity)**
- [ ] **Typography hierarchy is respected**
- [ ] **Border radius is consistent within components**
- [ ] **Spacing uses 4px base multiples**
- [ ] **Shadows match elevation level**
- [ ] **Animations use standard easing curves**

---

## 🔗 Related Documentation

- [Component Library](./COMPONENT_LIBRARY.md) - How tokens are applied to components
- [Pattern Library](./PATTERN_LIBRARY.md) - Token usage in complex patterns
- [Design Principles](./DESIGN_PRINCIPLES.md) - Philosophy behind token decisions

---

**End of Design Tokens Reference**
