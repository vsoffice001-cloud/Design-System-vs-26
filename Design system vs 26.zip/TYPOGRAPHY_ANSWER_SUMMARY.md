# ❓ ANSWER: "How are h1-h6 and body text defined?"

---

## 🎯 **QUICK ANSWER**

### **❌ There are NO default styles for h1-h6 or body elements**

This project uses a **component-based design system** where:
- Every heading must be explicitly styled
- No browser default styles are used
- All typography is controlled via CSS variables
- Font sizes are manually applied to each element

---

## 📐 **THE MAPPING**

While we don't have default HTML styles, here's how the design system maps conceptually to traditional HTML headings:

```
h1 (Hero)     → var(--text-3xl)  = 48.8px (Noto Serif Light)
h2 (Section)  → var(--text-3xl)  = 48.8px (Noto Serif Light)
h3 (Sub)      → var(--text-xl)   = 31.25px (DM Sans Medium)
h4 (Card)     → var(--text-lg)   = 25px (DM Sans Medium)
h4 (Compact)  → var(--text-base) = 20px (DM Sans Medium)
h5 (Small)    → var(--text-sm)   = 16px (DM Sans Medium)
h6 (Label)    → var(--text-xs)   = 12.8px (DM Sans Medium)

Body Text     → var(--text-sm)   = 16px (DM Sans Normal)
```

---

## 💻 **HOW IT ACTUALLY WORKS**

### **❌ WRONG - Browser Default (Doesn't Work)**
```tsx
<h1>My Title</h1>  // Will use ugly browser default!
```

### **✅ CORRECT - Explicitly Styled**
```tsx
<h1 
  className="leading-[1.15] font-light text-black tracking-tight" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
>
  My Title
</h1>
```

---

## 🎨 **THE COMPLETE SYSTEM**

### **Design System Variables (from `/src/styles/theme.css`)**

```css
:root {
  /* Typography Scale - Major Third (1.25 ratio) */
  --text-5xl: 4.768rem;   /* 76.3px - Massive headings */
  --text-4xl: 3.815rem;   /* 61px - Extra large */
  --text-3xl: 3.052rem;   /* 48.8px - Hero/Section h1, h2 */
  --text-2xl: 2.441rem;   /* 39px - Major titles h2 */
  --text-xl: 1.953rem;    /* 31.25px - Subsection h3 */
  --text-lg: 1.563rem;    /* 25px - Card titles h4 */
  --text-base: 1.25rem;   /* 20px - Large body, compact h4 */
  --text-sm: 1rem;        /* 16px - Body text, paragraphs */
  --text-compact: 0.875rem; /* 14px - Compact layouts */
  --text-xs: 0.8rem;      /* 12.8px - Labels, metadata h6 */
  --text-2xs: 0.75rem;    /* 12px - Micro labels, navbar */
}
```

### **Only 2 Default Styles Exist:**

```css
/* From /src/styles/theme.css */
html {
  font-size: 16px;           /* Base font size */
  scroll-behavior: smooth;
}

body {
  @apply bg-white text-black; /* Background + text color only */
}
```

**That's it!** No h1-h6 styles, no paragraph styles, nothing else.

---

## 🎨 **FONT FAMILY RULES**

### **Noto Serif (Editorial Headings)**
```tsx
fontFamily: "'Noto Serif', serif"
```

**Use for:**
- ✅ Hero h1 titles (font-light 300)
- ✅ Section h2 headings (font-light 300)
- ✅ Lead paragraphs (font-normal 400)
- ✅ Large display numbers (font-light 300)
- ✅ Featured quotes (font-normal 400)

---

### **DM Sans (Body & UI)**
```tsx
// Default font (no need to specify)
```

**Use for:**
- ✅ Subsection h3 headings (font-medium 500)
- ✅ Card h4 titles (font-medium 500)
- ✅ Body paragraphs (font-normal 400)
- ✅ Labels, metadata (font-medium 500)
- ✅ Buttons (font-bold 700)
- ✅ Navigation (font-bold 700)

---

## 📋 **PRACTICAL EXAMPLES**

### **Example 1: Section Header**

```tsx
<section className="py-20 bg-white">
  {/* Section Label (h6 level) */}
  <span 
    className="font-medium text-black/40 uppercase tracking-[3px] block mb-8" 
    style={{ fontSize: 'var(--text-xs)' }}
  >
    CHALLENGES
  </span>
  
  {/* Section Heading (h2) */}
  <h2 
    className="leading-[1.15] font-light text-black tracking-tight mb-6" 
    style={{ 
      fontFamily: "'Noto Serif', serif", 
      fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
    }}
  >
    Key Problem Statements
  </h2>
  
  {/* Description (body) */}
  <p 
    className="leading-[1.7] text-black/60 max-w-[700px]" 
    style={{ fontSize: 'var(--text-sm)' }}
  >
    A systematic approach to identifying critical market gaps
  </p>
</section>
```

---

### **Example 2: Card Component**

```tsx
<div className="bg-white border rounded-[5px] p-6">
  {/* Card Title (h4) */}
  <h4 
    className="font-medium text-black leading-[1.25] mb-4" 
    style={{ fontSize: 'var(--text-lg)' }}
  >
    Market Sizing Uncertainty
  </h4>
  
  {/* Card Description (body) */}
  <p 
    className="leading-[1.6] text-black/70" 
    style={{ fontSize: 'var(--text-sm)' }}
  >
    Unclear TAM quantification and segment prioritization strategies
  </p>
  
  {/* Metadata (small) */}
  <span 
    className="text-black/40 mt-4 block" 
    style={{ fontSize: 'var(--text-xs)' }}
  >
    Updated: Jan 2025
  </span>
</div>
```

---

## 🎯 **COLOR HIERARCHY**

### **On Light Backgrounds (White/Warm sections)**
```tsx
// Headings
text-black           // 100% - Very strong (rare)
text-black/90        // 90%  - Primary headings ✅ MOST COMMON

// Body Text
text-black/70        // 70%  - Body paragraphs ✅ MOST COMMON
text-black/60        // 60%  - Secondary descriptions

// Metadata
text-black/40        // 40%  - Labels, metadata ✅ MOST COMMON
text-black/30        // 30%  - Subtle metadata
```

### **On Dark Backgrounds (Black sections)**
```tsx
// Headings
text-white/95        // 95%  - Primary headings ✅ MOST COMMON

// Body Text
text-white/70        // 70%  - Body text
text-white/60        // 60%  - Secondary text ✅ MOST COMMON

// Metadata
text-white/40        // 40%  - Labels ✅ MOST COMMON
```

---

## 📏 **SIZE COMPARISON CHART**

```
LARGEST
  ↓
76.3px  ████████████████ --text-5xl (Rarely used)
61px    █████████████  --text-4xl (Challenge numbers)
48.8px  ████████████  --text-3xl h1, h2 ← SECTION HEADINGS
39px    ██████████  --text-2xl h2
31.25px ████████  --text-xl h3 ← SUBSECTION HEADINGS
25px    ██████  --text-lg h4 ← CARD TITLES (spacious)
20px    █████  --text-base h4 ← CARD TITLES (compact)
16px    ████  --text-sm BODY ← BODY TEXT
14px    ███  --text-compact (dense layouts)
12.8px  ██  --text-xs h6 ← LABELS
12px    ██  --text-2xs (navbar)
  ↓
SMALLEST
```

---

## ⚡ **QUICK COPY-PASTE**

### **Hero Title (h1)**
```tsx
<h1 className="leading-[1.15] font-light text-white/95 tracking-tight" 
    style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}>
  Hero Title
</h1>
```

### **Section Heading (h2)**
```tsx
<h2 className="leading-[1.15] font-light text-black tracking-tight" 
    style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}>
  Section Title
</h2>
```

### **Subsection (h3)**
```tsx
<h3 className="font-medium text-black leading-[1.3]" 
    style={{ fontSize: 'var(--text-xl)' }}>
  Subsection
</h3>
```

### **Card Title (h4)**
```tsx
<h4 className="font-medium text-black leading-[1.25]" 
    style={{ fontSize: 'var(--text-lg)' }}>
  Card Title
</h4>
```

### **Body Text**
```tsx
<p className="leading-[1.7] text-black/70" 
   style={{ fontSize: 'var(--text-sm)' }}>
  Body paragraph
</p>
```

### **Label**
```tsx
<span className="font-medium text-black/40 uppercase tracking-[3px]" 
      style={{ fontSize: 'var(--text-xs)' }}>
  LABEL
</span>
```

---

## 📚 **FULL DOCUMENTATION**

For complete details, see:

1. **Quick Reference:** `/TYPOGRAPHY_QUICK_REFERENCE.md` ← Print this!
2. **HTML Guide:** `/HTML_ELEMENTS_TYPOGRAPHY_GUIDE.md` ← Full examples
3. **Complete System:** `/TYPOGRAPHY_SYSTEM_COMPLETE.md` ← Everything
4. **Rationale:** `/FONT_SIZE_RATIONALE_ANALYSIS.md` ← Why decisions were made
5. **CSS Variables:** `/src/styles/theme.css` ← Source of truth

---

## 🎯 **KEY TAKEAWAYS**

1. ❌ **No default HTML styles** - Must manually style every heading
2. ✅ **Use CSS variables** - Always prefer `var(--text-*)` 
3. ✅ **Noto Serif** - For h1, h2, featured content
4. ✅ **DM Sans** - For h3-h6, body, UI elements
5. ✅ **Explicit styling** - Every element needs fontSize + className
6. ✅ **Semantic HTML** - Use correct tags (h1-h6) for accessibility

---

**Status:** ✅ Complete  
**Your Question Answered:** h1-h6 have NO default styles, must use CSS variables + explicit styling

