# 🎨 Case Study Design System Guide

## Table of Contents
1. [Overview](#overview)
2. [What - Design Tokens](#what---design-tokens)
3. [Why - Design Principles](#why---design-principles)
4. [Where - Token Usage Map](#where---token-usage-map)
5. [When - Decision Framework](#when---decision-framework)
6. [How - Implementation Rules](#how---implementation-rules)

---

## Overview

**Design Philosophy**: Minimalist editorial aesthetic featuring black/white alternating sections, massive typography using Major Third scale (1.25 ratio), and generous whitespace with content limited to max 1000px width.

**Core Principles**:
- ✅ Typography-first design with strict Major Third scale
- ✅ Pure black (#000) and warm off-white (#f5f2f1) color palette
- ✅ Opacity-driven hierarchy (inline modifiers: text-white/60)
- ✅ Consistent border radius system (2.5px, 5px, 10px)
- ✅ Glass-morphism effects and smooth transitions
- ✅ Maximum 1000px content width, centered alignment

---

## WHAT - Design Tokens

### Typography Scale - Major Third (1.25 Ratio)

| Token | Size | Use Case | Example |
|-------|------|----------|---------|
| `--text-xs` | 12.8px | Small labels, metadata, categories, dates | "CASE STUDY", "TECHNOLOGY", "Jan 15, '24" |
| `--text-sm` | 16px | Body text, descriptions, card content | Paragraph text, resource descriptions |
| `--text-base` | 20px | Prominent body text, large descriptions | Testimonial quotes, emphasized paragraphs |
| `--text-lg` | 25px | Subsection headings | Card titles, impact labels |
| `--text-xl` | 31.25px | Section headings | "Our Approach", "Impact Delivered" |
| `--text-2xl` | 39px | Major section headings | Main section titles |
| `--text-3xl` | 48.8px | Hero headings only | "Evaluating India's Transformer..." |

**Mathematical Progression**:
```
12.8px × 1.25 = 16px × 1.25 = 20px × 1.25 = 25px × 1.25 = 31.25px × 1.25 = 39px × 1.25 = 48.8px
```

### Color System

| Token | Hex | Use Case | Sections |
|-------|-----|----------|----------|
| `--bg-warm` | #f5f2f1 | Warm highlighted sections | Challenges, Methodology |
| `--bg-warm-500` | #eae5e3 | Subtle borders on warm | Card borders, separator lines |
| `--bg-warm-600` | #d9d1ce | Medium contrast elements | Timeline base, borders |
| `--bg-warm-700` | #c8bcb8 | Strong contrast elements | Timeline nodes (inactive) |
| `--bg-pure-black` | #000000 | Premium black sections | Hero, Resources |
| `--bg-pure-white` | #ffffff | Standard white sections | Client Context, Impact, Testimonial |

### Border Radius System

| Size | Use Case | Examples |
|------|----------|----------|
| `2.5px` | Images only | Resource thumbnails, testimonial photos |
| `5px` | Buttons & small cards | CTA buttons, small UI elements |
| `10px` | Large cards | Methodology cards, challenge cards |

### Font Weights

| Token | Value | Use Case |
|-------|-------|----------|
| `--font-weight-normal` | 400 | Body text, descriptions |
| `--font-weight-medium` | 500 | Labels, buttons, emphasis |

---

## WHY - Design Principles

### 1. Typography-First Design
**WHY**: Creates strong visual hierarchy without color, maintains editorial aesthetic

**Implementation**:
- Major Third scale creates natural size relationships (1.25 ratio)
- Each step is 25% larger than previous
- Large jumps prevent confusion, enforce decisiveness

### 2. Opacity-Driven Hierarchy
**WHY**: Maintains color palette purity while creating depth

**Implementation**:
```tsx
// Primary text on dark
<span className="text-white">Main content</span>         // 100% opacity

// Secondary text on dark
<span className="text-white/60">Supporting text</span>   // 60% opacity

// Tertiary text on dark
<span className="text-white/40">Metadata</span>          // 40% opacity

// Primary text on light
<span className="text-black/90">Main content</span>      // 90% opacity

// Secondary text on light
<span className="text-black/60">Supporting text</span>   // 60% opacity
```

### 3. Minimal Color Palette
**WHY**: Professional, timeless, maintains focus on content

**Color Usage**:
- **Pure Black (#000)**: Premium sections (Hero, Resources)
- **Warm Off-White (#f5f2f1)**: Highlighted sections (Challenges, Methodology)
- **Pure White (#fff)**: Standard content sections

### 4. Consistent Border Radius
**WHY**: Creates predictable visual rhythm, aids user recognition

**System**:
- Small elements (images): 2.5px - subtle rounding
- Medium elements (buttons): 5px - friendly but professional
- Large elements (cards): 10px - comfortable, approachable

---

## WHERE - Token Usage Map

### Section-by-Section Breakdown

#### HeroSection
```tsx
Background: var(--bg-pure-black)
Title: clamp(..., var(--text-3xl))    // 48.8px hero heading
Subtitle: var(--text-base)             // 20px prominent body
Label: var(--text-xs)                  // 12.8px metadata
Text Colors: text-white, text-white/60, text-white/40
```

#### ClientContextSection
```tsx
Background: var(--bg-pure-white)
Title: var(--text-2xl)                 // 39px major heading
Body: var(--text-sm)                   // 16px body text
Label: var(--text-xs)                  // 12.8px labels
Text Colors: text-black/90, text-black/60, text-black/40
Border Radius: rounded-[10px] (cards)
```

#### ChallengesSection
```tsx
Background: var(--bg-warm)             // #f5f2f1 warm off-white
Title: var(--text-2xl)                 // 39px major heading
Card Title: var(--text-lg)             // 25px subsection
Body: var(--text-sm)                   // 16px body
Label: var(--text-xs)                  // 12.8px metadata
Border: var(--bg-warm-500)             // Subtle borders
Border Radius: rounded-[10px] (cards)
```

#### MethodologySection
```tsx
Background: var(--bg-warm)             // #f5f2f1
Title: var(--text-2xl)                 // 39px
Step Label: var(--text-xs)             // 12.8px
Step Title: var(--text-lg)             // 25px
Body: var(--text-sm)                   // 16px
Timeline Base: var(--bg-warm-600)      // Medium contrast
Timeline Node: var(--bg-warm-700)      // Strong contrast
Card Border: var(--bg-warm-500)        // Subtle
Border Radius: rounded-[5px] (cards)
Animation: pulse-subtle (active node)
```

#### ImpactSection
```tsx
Background: var(--bg-pure-white)
Title: var(--text-2xl)                 // 39px
Metric Value: var(--text-3xl)          // 48.8px (large metrics)
Metric Label: var(--text-sm)           // 16px
Description: var(--text-sm)            // 16px
Badge: var(--text-xs)                  // 12.8px
Border Radius: rounded-[5px] (badges)
```

#### ResourcesSection
```tsx
Background: var(--bg-pure-black)
Title: var(--text-2xl)                 // 39px
Card Title: var(--text-sm)             // 14px (4-col grid)
Description: var(--text-sm)            // 14px
Category/Date: var(--text-xs)          // 12.8px
Text Colors: text-white, text-white/60, text-white/50, text-white/40
Border Radius: rounded-[2.5px] (images), rounded-[5px] (button)
```

---

## WHEN - Decision Framework

### When to Use Each Typography Size?

**Decision Tree**:

```
Is it the main hero heading?
  YES → var(--text-3xl) (48.8px)
  NO ↓

Is it a major section title?
  YES → var(--text-2xl) (39px)
  NO ↓

Is it a section heading?
  YES → var(--text-xl) (31.25px)
  NO ↓

Is it a subsection or card title?
  YES → var(--text-lg) (25px)
  NO ↓

Is it emphasized/prominent body text?
  YES → var(--text-base) (20px)
  NO ↓

Is it standard body text or description?
  YES → var(--text-sm) (16px)
  NO ↓

Is it a label, category, or metadata?
  YES → var(--text-xs) (12.8px)
```

### When to Use Each Background Color?

**Decision Tree**:

```
Is it a premium editorial section?
  YES → Is it the Hero or Resources?
    YES → var(--bg-pure-black)
  NO ↓

Should this section stand out as highlighted?
  YES → Is it Challenges or Methodology?
    YES → var(--bg-warm) (#f5f2f1)
  NO ↓

Default to white
  → var(--bg-pure-white) or className="bg-white"
```

### When to Use Each Border Color?

**Decision Tree**:

```
Is the background warm (--bg-warm)?
  YES → How much contrast needed?
    LOW → var(--bg-warm-500) (subtle borders)
    MEDIUM → var(--bg-warm-600) (timeline base)
    HIGH → var(--bg-warm-700) (inactive nodes)
  NO ↓

Is the background black?
  YES → Use opacity: border-white/20
  NO ↓

Is the background white?
  YES → Use opacity: border-black/10
```

---

## HOW - Implementation Rules

### RULE #1: Always Use Design Tokens for Typography

```tsx
// ✅ CORRECT
<h2 style={{ fontSize: 'var(--text-2xl)' }}>Section Title</h2>
<p style={{ fontSize: 'var(--text-sm)' }}>Body text</p>
<span style={{ fontSize: 'var(--text-xs)' }}>Label</span>

// ❌ WRONG - Never hardcode font sizes
<h2 style={{ fontSize: '39px' }}>Section Title</h2>
<p style={{ fontSize: '16px' }}>Body text</p>
<span style={{ fontSize: '12px' }}>Label</span>

// ❌ WRONG - Never use Tailwind font size classes
<h2 className="text-4xl">Section Title</h2>
<p className="text-base">Body text</p>
```

**WHY**: Maintains consistency across all sections, enables easy global scaling

---

### RULE #2: Use Inline Opacity Modifiers for Text Hierarchy

```tsx
// ✅ CORRECT - On dark backgrounds
<h2 className="text-white">Primary Heading</h2>
<p className="text-white/70">Secondary Text</p>
<span className="text-white/40">Tertiary Metadata</span>

// ✅ CORRECT - On light backgrounds
<h2 className="text-black/90">Primary Heading</h2>
<p className="text-black/60">Secondary Text</p>
<span className="text-black/40">Tertiary Metadata</span>

// ❌ WRONG - Don't create opacity CSS variables
<span style={{ color: 'var(--text-secondary)' }}>Text</span>
```

**WHY**: Tailwind's inline modifiers are more flexible and easier to scan

---

### RULE #3: Use Color Tokens for Backgrounds and Borders

```tsx
// ✅ CORRECT - Background colors
<section style={{ background: 'var(--bg-warm)' }}>
<section style={{ background: 'var(--bg-pure-black)' }}>
<section className="bg-white">  {/* or var(--bg-pure-white) */}

// ✅ CORRECT - Border colors on warm sections
<div style={{ borderColor: 'var(--bg-warm-500)' }}>
<div style={{ borderColor: 'var(--bg-warm-600)' }}>

// ✅ CORRECT - Border colors on black/white sections
<div className="border border-white/20">  {/* on black */}
<div className="border border-black/10">  {/* on white */}

// ❌ WRONG - Hardcoded hex values
<section style={{ background: '#f5f2f1' }}>
<div style={{ borderColor: '#eae5e3' }}>
```

**WHY**: Tokens enable theme-wide color updates from a single source

---

### RULE #4: Follow Border Radius System

```tsx
// ✅ CORRECT - Images
<img className="rounded-[2.5px]" />

// ✅ CORRECT - Buttons and small UI elements
<button className="rounded-[5px]">Click Me</button>

// ✅ CORRECT - Large cards
<div className="rounded-[10px] border p-8">Card Content</div>

// ❌ WRONG - Random radius values
<img className="rounded-lg" />      // Don't use Tailwind defaults
<button className="rounded-md" />   // Don't use Tailwind defaults
<div className="rounded-xl" />      // Don't use Tailwind defaults
```

**WHY**: Creates consistent visual rhythm, aids user pattern recognition

---

### RULE #5: Maintain 1000px Max Width Container

```tsx
// ✅ CORRECT - Every section
<section className="py-20">
  <div className="max-w-[1000px] mx-auto px-6 md:px-8">
    {/* Section content */}
  </div>
</section>

// ❌ WRONG - No max-width
<section className="container mx-auto">  {/* Too wide */}

// ❌ WRONG - Inconsistent max-width
<section className="max-w-7xl mx-auto">  {/* Not 1000px */}
```

**WHY**: Maintains comfortable reading width, consistent visual rhythm

---

### RULE #6: Use Clamp for Responsive Typography

```tsx
// ✅ CORRECT - Hero headings with responsive scaling
<h1 style={{ 
  fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  // 28px → 48.8px
}}>

// ✅ CORRECT - Section headings
<h2 style={{ 
  fontSize: 'clamp(1.5rem, 4vw, var(--text-2xl))'  // 24px → 39px
}}>

// ❌ WRONG - Fixed sizes on mobile
<h1 style={{ fontSize: 'var(--text-3xl)' }}>  {/* Too large on mobile */}
```

**WHY**: Prevents oversized text on small screens, maintains hierarchy

---

### RULE #7: Use Semantic Spacing

```tsx
// ✅ CORRECT - Section spacing
<section className="py-12 sm:py-16 md:py-20">

// ✅ CORRECT - Content spacing
<div className="mb-12 sm:mb-16 md:mb-20">  {/* Between major elements */}
<div className="mb-6 md:mb-8">             {/* Between related elements */}
<div className="mb-3 md:mb-4">             {/* Between small elements */}

// ❌ WRONG - Arbitrary values
<section className="py-32">       {/* Too much space */}
<div className="mb-7">            {/* Not part of system */}
```

**WHY**: Creates predictable rhythm, maintains generous whitespace aesthetic

---

### RULE #8: Animation Usage

```tsx
// ✅ CORRECT - Methodology active node
<div style={{ 
  animation: isCurrent ? 'pulse-subtle 2.5s ease-in-out infinite' : 'none' 
}}>

// ✅ CORRECT - Hover transitions
<div className="transition-all duration-300 hover:scale-110">

// ✅ CORRECT - Smooth property transitions
<div className="transition-colors duration-300">

// ❌ WRONG - Custom animations without tokens
<div style={{ animation: 'myCustomPulse 1s linear infinite' }}>
```

**WHY**: Maintains consistency, only one custom animation (pulse-subtle) needed

---

## Quick Reference Cheatsheet

### Typography Stack
```
Hero Heading:        clamp(..., var(--text-3xl))  → 48.8px
Major Section:       clamp(..., var(--text-2xl))  → 39px
Section Heading:     var(--text-xl)               → 31.25px
Subsection/Cards:    var(--text-lg)               → 25px
Prominent Body:      var(--text-base)             → 20px
Body Text:           var(--text-sm)               → 16px
Labels/Metadata:     var(--text-xs)               → 12.8px
```

### Color Stack
```
Hero/Resources:      var(--bg-pure-black)         → #000000
Challenges/Method:   var(--bg-warm)               → #f5f2f1
Standard Sections:   bg-white                     → #ffffff

Borders (warm):      var(--bg-warm-500/600/700)
Borders (black):     border-white/20
Borders (white):     border-black/10
```

### Border Radius Stack
```
Images:              rounded-[2.5px]
Buttons/Small:       rounded-[5px]
Cards/Large:         rounded-[10px]
```

### Opacity Stack
```
On Black:            text-white (100%), text-white/60, text-white/40
On White:            text-black/90, text-black/60, text-black/40
```

---

## Component Checklist

Before creating a new component, ensure:

- [ ] Typography uses design tokens (`var(--text-*)`)
- [ ] Background uses color tokens (`var(--bg-*)`)
- [ ] Text hierarchy uses inline opacity (`.../60`, `.../40`)
- [ ] Border radius follows 2.5px/5px/10px system
- [ ] Content constrained to `max-w-[1000px]`
- [ ] Responsive spacing with breakpoint modifiers
- [ ] Clamp() for large text on mobile
- [ ] No hardcoded font sizes or colors
- [ ] Transitions use Tailwind classes
- [ ] Animation only uses `pulse-subtle` if needed

---

**Last Updated**: Post-cleanup optimization
**Design System Version**: 2.0 (Minimal & Clean)
