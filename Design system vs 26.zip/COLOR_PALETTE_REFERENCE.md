# 🎨 Color Palette Quick Reference

## Visual Color Scales

### 🔴 Ken Bold Red - Primary Brand

```
██ --red-50      #fef2f2    RGB(254, 242, 242)   Lightest
██ --red-100     #fee2e2    RGB(254, 226, 226)   Very Light
██ --red-200     #fecaca    RGB(254, 202, 202)   Light
██ --red-300     #fca5a7    RGB(252, 165, 167)   Medium Light
██ --red-400     #f87176    RGB(248, 113, 118)   Medium
██ --red-500     #dc3238    RGB(220, 50, 56)     Standard
██ --red-600     #b01f24    RGB(176, 31, 36)     ⭐ PRIMARY BRAND
██ --red-700     #8f181d    RGB(143, 24, 29)     Hover State
██ --red-800     #771419    RGB(119, 20, 25)     Active State
██ --red-900     #5f1014    RGB(95, 16, 20)      Darkest
```

**Personality:** Bold, Action-Oriented, Conversion-Focused  
**Best for:** CTAs, Buttons, Important Accents, Links  
**Pairs with:** Black, White, Warm neutrals

---

### ⚫ Black & Gray - Foundation

```
██ --black-50    #fafafa    RGB(250, 250, 250)   Near White
██ --black-100   #f5f5f5    RGB(245, 245, 245)   Lightest Gray
██ --black-200   #e5e5e5    RGB(229, 229, 229)   Very Light Gray
██ --black-300   #d4d4d4    RGB(212, 212, 212)   Light Gray
██ --black-400   #a3a3a3    RGB(163, 163, 163)   Medium Gray
██ --black-500   #737373    RGB(115, 115, 115)   Gray
██ --black-600   #525252    RGB(82, 82, 82)      Dark Gray
██ --black-700   #404040    RGB(64, 64, 64)      Darker Gray
██ --black-800   #262626    RGB(38, 38, 38)      Very Dark
██ --black-900   #171717    RGB(23, 23, 23)      Almost Black
██ --black       #000000    RGB(0, 0, 0)         ⭐ PURE BLACK
```

**Personality:** Professional, Timeless, Authoritative  
**Best for:** Text, Headings, Hero Backgrounds, Primary UI  
**Pairs with:** Everything

---

### ⚪ White

```
██ --white       #ffffff    RGB(255, 255, 255)   ⭐ PURE WHITE
██ --white-900   #fafafa    RGB(250, 250, 250)   Slightly Off-White
██ --white-800   #f5f5f5    RGB(245, 245, 245)   Off-White
```

**Personality:** Clean, Spacious, Minimalist  
**Best for:** Section Backgrounds, Text on Dark, Cards  
**Pairs with:** Everything

---

### 🤎 Warm - Editorial Comfort

```
██ --warm-50     #fefdfd    RGB(254, 253, 253)   Barely There
██ --warm-100    #fcfbfa    RGB(252, 251, 250)   Very Subtle
██ --warm-200    #f9f7f6    RGB(249, 247, 246)   Soft
██ --warm-300    #f5f2f1    RGB(245, 242, 241)   ⭐ BASE (Current)
██ --warm-400    #f0ebe9    RGB(240, 235, 233)   Medium
██ --warm-500    #eae5e3    RGB(234, 229, 227)   Borders
██ --warm-600    #d9d1ce    RGB(217, 209, 206)   Timeline Base
██ --warm-700    #c8bcb8    RGB(200, 188, 184)   Timeline Nodes
██ --warm-800    #b7a9a3    RGB(183, 169, 163)   Dark Warm
██ --warm-900    #a6968e    RGB(166, 150, 142)   Darkest
```

**Personality:** Comfortable, Editorial, Approachable  
**Best for:** Section Backgrounds, Soft Contrast, Reading Areas  
**Pairs with:** Black text, Red accents, Purple highlights  
**Already Used:** Challenges & Methodology sections

---

### 🟣 Purple (True V) - Premium Innovation

```
██ --purple-50   #f7f6fe    RGB(247, 246, 254)   Lightest
██ --purple-100  #efedfd    RGB(239, 237, 253)   Very Light
██ --purple-200  #dfdcfb    RGB(223, 220, 251)   Light
██ --purple-300  #c4bef7    RGB(196, 190, 247)   Medium Light
██ --purple-400  #a89ff2    RGB(168, 159, 242)   Medium
██ --purple-500  #9488ec    RGB(148, 136, 236)   Standard
██ --purple-600  #806ce0    RGB(128, 108, 224)   ⭐ BASE
██ --purple-700  #6c5bc0    RGB(108, 91, 192)    Hover
██ --purple-800  #5a4ba0    RGB(90, 75, 160)     Active
██ --purple-900  #483c80    RGB(72, 60, 128)     Darkest
```

**Personality:** Premium, Innovative, Insightful, Tech-Forward  
**Best for:**
- Premium feature badges
- Data insights callouts
- Innovation/R&D sections
- Hover states on cards
- "Pro" or "Premium" indicators

**Example Use Cases:**
- "Premium Insights" badge on Impact section
- Hover accent on Challenge cards
- Innovation section backgrounds
- AI/ML feature highlights

**Pairs with:** Warm neutrals, White backgrounds, Black text  
**Avoid:** Large backgrounds (too bold), body text (readability)

---

### 🔵 Periwinkle - Trust & Reliability

```
██ --periwinkle-50   #fafbfe    RGB(250, 251, 254)   Lightest
██ --periwinkle-100  #f5f6fd    RGB(245, 246, 253)   Very Light
██ --periwinkle-200  #ebedfb    RGB(235, 237, 251)   Light
██ --periwinkle-300  #dfe1f9    RGB(223, 225, 249)   Medium Light
██ --periwinkle-400  #d3d5f9    RGB(211, 213, 249)   Medium
██ --periwinkle-500  #c3c6f9    RGB(195, 198, 249)   ⭐ BASE
██ --periwinkle-600  #a7abf0    RGB(167, 171, 240)   Standard
██ --periwinkle-700  #8b90e0    RGB(139, 144, 224)   Hover
██ --periwinkle-800  #7075c8    RGB(112, 117, 200)   Active
██ --periwinkle-900  #5a5fa0    RGB(90, 95, 160)     Darkest
```

**Personality:** Trustworthy, Reliable, Credible, Professional  
**Best for:**
- Testimonial backgrounds
- Trust indicators & badges
- Certification highlights
- Client logo sections
- Reliability metrics

**Example Use Cases:**
- Testimonial card with periwinkle-100 background
- "Certified Partner" badge
- Client success story backgrounds
- Award/recognition highlights

**Pairs with:** White, Warm neutrals, Black text  
**Avoid:** Main headings (too soft), error states (use red)

---

### 🔷 Perano (Light Blue) - Data & Professionalism

```
██ --perano-50   #fcfdfe    RGB(252, 253, 254)   Lightest
██ --perano-100  #f9fbfe    RGB(249, 251, 254)   Very Light
██ --perano-200  #f4f8fd    RGB(244, 248, 253)   Light
██ --perano-300  #eff5fc    RGB(239, 245, 252)   Medium Light
██ --perano-400  #e9f2fb    RGB(233, 242, 251)   Medium
██ --perano-500  #dfeafa    RGB(223, 234, 250)   ⭐ BASE
██ --perano-600  #c8dff5    RGB(200, 223, 245)   Standard
██ --perano-700  #a7c9ed    RGB(167, 201, 237)   Hover
██ --perano-800  #86b3e5    RGB(134, 179, 229)   Active
██ --perano-900  #6b94c0    RGB(107, 148, 192)   Darkest
```

**Personality:** Calm, Data-Driven, Professional, Analytical  
**Best for:**
- Data visualization backgrounds
- Methodology step cards
- Technical documentation sections
- Chart containers
- Process diagrams

**Example Use Cases:**
- Methodology section card backgrounds
- Data table headers
- Analytics dashboard sections
- API documentation backgrounds
- Timeline/process flow backgrounds

**Pairs with:** Black text, Warm neutrals, White  
**Avoid:** Text (too light), primary CTAs (not bold enough)

---

## 🎯 Color Personality Matrix

| Color | Emotion | Energy Level | Professional | Creative | Technical |
|-------|---------|--------------|--------------|----------|-----------|
| **Black** | Authority | High | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **White** | Clarity | Neutral | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **Ken Red** | Action | Very High | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| **Warm** | Comfort | Low | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Purple** | Premium | Medium-High | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Periwinkle** | Trust | Low-Medium | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| **Perano** | Calm | Low | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

---

## 🔄 Color Pairing Recommendations

### Excellent Combinations ✅

**Black + White + Red**
```css
background: var(--black);
color: var(--white);
accent: var(--red-600);
/* Classic, high-contrast, conversion-optimized */
```

**White + Warm + Purple Accent**
```css
background: var(--white);
section-bg: var(--warm-300);
highlight: var(--purple-600);
/* Premium editorial feel */
```

**Periwinkle Background + Black Text**
```css
background: var(--periwinkle-100);
text: var(--black);
border: var(--periwinkle-600);
/* Trustworthy, professional */
```

**Perano + Warm Gradient**
```css
background: linear-gradient(to bottom, var(--perano-100), var(--warm-100));
/* Calm, data-focused transition */
```

### Good Combinations ⚠️

**Purple + Warm** - Use sparingly, can clash if too saturated  
**Periwinkle + Perano** - Both are cool blues, ensure sufficient contrast  
**All Neutrals (Black/White/Warm)** - Safe but might lack personality

### Poor Combinations ❌

**Purple + Periwinkle + Perano** - Too much blue/purple  
**Red + Purple + Periwinkle** - Color overload  
**Warm + Perano on same element** - Temperature clash

---

## 📊 Contrast Ratios (WCAG AA Compliance)

### Text Readability

| Foreground | Background | Ratio | Status | Use Case |
|------------|------------|-------|--------|----------|
| Black | White | 21:1 | ✅ AAA | Body text |
| Black | Warm-300 | 18.5:1 | ✅ AAA | Body text |
| Black | Periwinkle-100 | 16.8:1 | ✅ AAA | Body text |
| Black | Perano-100 | 17.2:1 | ✅ AAA | Body text |
| White | Red-600 | 7.2:1 | ✅ AAA | CTA buttons |
| White | Purple-600 | 4.8:1 | ✅ AA | Buttons, UI |
| Black | Purple-100 | 15.3:1 | ✅ AAA | Body text |
| Purple-900 | Purple-50 | 11.2:1 | ✅ AAA | Badge text |
| Periwinkle-900 | Periwinkle-100 | 8.5:1 | ✅ AAA | Card text |
| Purple-600 | White | 4.8:1 | ✅ AA | Large text only |

### Interactive Elements

| Element | Contrast | Status |
|---------|----------|--------|
| Red button on black | 7.2:1 | ✅ AAA |
| Purple button on white | 4.8:1 | ✅ AA |
| Periwinkle border on white | 3.5:1 | ✅ AA (UI) |
| Perano background | 17:1+ | ✅ AAA (with black text) |

---

## 🎨 Usage Frequency Guidelines

### Primary Palette (80-90% of design)
- **Black:** 40% (text, hero backgrounds)
- **White:** 40% (section backgrounds, text on dark)
- **Warm:** 10-20% (soft section backgrounds)

### Secondary Palette (10-20% of design)
- **Red:** 5-10% (CTAs, key accents)
- **Purple:** 2-5% (premium highlights)
- **Periwinkle:** 2-5% (trust indicators)
- **Perano:** 2-5% (data sections)

### Accent Application Rules
1. **One accent per section** - Don't mix multiple accent colors in same area
2. **Lighter shades for backgrounds** - Use 50-200 range
3. **Darker shades for interactive elements** - Use 600-900 range
4. **Medium shades for borders** - Use 300-500 range

---

## 🚀 Copy-Paste CSS Examples

### Premium Badge (Purple)
```css
.premium-badge {
  background-color: var(--purple-50);
  border: 1px solid var(--purple-600);
  color: var(--purple-900);
  padding: 0.375rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
}
```

### Trust Card (Periwinkle)
```css
.trust-card {
  background-color: var(--periwinkle-100);
  border-left: 4px solid var(--periwinkle-600);
  padding: 1.5rem;
  border-radius: 0.5rem;
}
```

### Data Section (Perano)
```css
.data-section {
  background: linear-gradient(
    to bottom, 
    var(--perano-100), 
    var(--white)
  );
  padding: 4rem 0;
}
```

### Gradient Card (Multi-color)
```css
.gradient-card {
  background: linear-gradient(
    135deg, 
    var(--purple-50) 0%, 
    var(--periwinkle-50) 50%, 
    var(--perano-50) 100%
  );
  border: 1px solid var(--purple-200);
  padding: 2rem;
}
```

---

## 📱 Responsive Color Strategy

### Mobile (< 768px)
- Prioritize: Black, White, Red
- Use: Warm for section breaks
- Minimize: Purple, Periwinkle, Perano
- **Reason:** Simpler color palette improves readability on small screens

### Tablet (768px - 1024px)
- Use: All primary colors
- Introduce: One accent color per section
- **Reason:** Balanced experience between mobile and desktop

### Desktop (> 1024px)
- Full color system available
- Gradients and multi-color compositions work well
- **Reason:** Larger screens handle visual complexity better

---

## ✨ Quick Decision Tree

**Need to highlight something important?**
- For conversion → Use **Red** (#b01f24)
- For premium feature → Use **Purple** (#806ce0)
- For trust/credibility → Use **Periwinkle** (#c3c6f9)
- For data/analytics → Use **Perano** (#dfeafa)

**Need a background color?**
- For main content → Use **White** (#ffffff)
- For alternate sections → Use **Warm** (#f5f2f1)
- For hero/footer → Use **Black** (#000000)
- For subtle premium feel → Use **Purple-50** (#f7f6fe)
- For trust sections → Use **Periwinkle-100** (#f5f6fd)
- For data sections → Use **Perano-100** (#f9fbfe)

**Need border/divider?**
- Subtle → Use **Warm-500** (#eae5e3)
- Standard → Use **Black-200** (#e5e5e5)
- Premium accent → Use **Purple-300** (#c4bef7)
- Trust accent → Use **Periwinkle-400** (#d3d5f9)
- Data accent → Use **Perano-400** (#e9f2fb)

---

## 📋 Implementation Checklist

- ✅ Color system saved to `/src/styles/theme.css`
- ✅ Color strategy documented in `/COLOR_STRATEGY.md`
- ✅ Color reference created in `/COLOR_PALETTE_REFERENCE.md`
- ⬜ Choose implementation phase (1, 2, or 3)
- ⬜ Apply accent colors to selected components
- ⬜ Test accessibility with contrast checker
- ⬜ Review on multiple devices/screen sizes
- ⬜ A/B test conversion impact (if applicable)

---

**Total Colors Available:** 60+ (6 color families × 10 shades each)  
**Recommended Active Use:** 15-20 colors max  
**Core Palette:** 7 colors (Black, White, Warm-300, Red-600, Purple-600, Periwinkle-500, Perano-500)

**Last Updated:** January 2025  
**Version:** 1.0
