# FIGMA TO SYSTEM MIGRATION GUIDE

## 🎯 How to Replace Figma Imports with System Buttons

This guide shows you **exactly** how to replace each Figma import with the appropriate Button component.

---

## 📦 Step 1: Update Imports

### Replace This:
```tsx
import MainCtaNav from '@/imports/MainCtaNav';
import BrandCta from '@/imports/BrandCta';
import ConnectNow from '@/imports/ConnectNow-12083-158';
import ExploreCta from '@/imports/ExploreCta';
```

### With This:
```tsx
import { Button } from '@/app/components/Button';
import { ArrowUpRight } from 'lucide-react';
```

---

## 🔄 Step 2: Replace Components

### Component 1: MainCtaNav → Button (Brand, Medium)

**Before (Figma):**
```tsx
<MainCtaNav />
```

**After (System):**
```tsx
<Button variant="brand" size="md">
  Schedule a Demo
</Button>
```

**Differences:**
- Height: 34px → 48px (better accessibility ✅)
- Radius: 5px → 10px (matches system ✅)
- Gradient: Removed (solid color instead)

---

### Component 2: BrandCta (Red) → Button (Brand with Icon)

**Before (Figma):**
```tsx
<BrandCta />
```

**After (System):**
```tsx
<Button variant="brand" size="md" icon={<ArrowUpRight size={20} />}>
  Schedule a Demo
</Button>
```

**Differences:**
- Height: 34px → 48px ✅
- Radius: 5px → 10px ✅
- Gradient: Removed
- Animation: Dual-layer arrow → Static icon (simpler!)

---

### Component 3: BrandCta (Black) → Button (Primary with Icon)

**Before (Figma):**
```tsx
<BrandCta />  {/* Black variant */}
```

**After (System):**
```tsx
<Button variant="primary" size="md" icon={<ArrowUpRight size={20} />}>
  Schedule a Demo
</Button>
```

**Differences:**
- Height: 34px → 48px ✅
- Radius: 5px → 10px ✅
- Gradient: Gray gradient → Pure black
- Animation: Dual-layer arrow → Static icon

---

### Component 4: ConnectNow → Button (Secondary, Small)

**Before (Figma):**
```tsx
<ConnectNow />
```

**After (System):**
```tsx
<Button variant="secondary" size="sm">
  Connect now
</Button>
```

**Differences:**
- Height: 27px → 40px (accessibility fix! ✅)
- Radius: 10px → 10px (already matches! ✅)
- Color: Gray gradient → White with border
- Shadow: Purple glow → None (cleaner)
- Font: 12px → 14px (more readable)

**Alternative (if you need darker style):**
```tsx
<Button variant="ghost" size="sm">
  Connect now
</Button>
```

---

### Component 5: ExploreCta → Custom TextLink

**Before (Figma):**
```tsx
<ExploreCta />
```

**After (Create Custom Component):**

**Option A: Simple Link (No Gradient)**
```tsx
<a 
  href="#" 
  className="inline-flex items-center gap-2 text-sm text-[var(--accent-red)] hover:opacity-80 transition-opacity"
>
  Explore Consulting
  <ArrowUpRight size={12} />
</a>
```

**Option B: Gradient Text Link (More Accurate)**
```tsx
<a 
  href="#" 
  className="inline-flex items-center gap-2 text-sm bg-gradient-to-r from-[#b01f24] to-[#eb484e] bg-clip-text hover:opacity-80 transition-opacity"
  style={{ WebkitTextFillColor: 'transparent' }}
>
  Explore Consulting
  <ArrowUpRight size={12} className="text-[#eb484e]" />
</a>
```

**Note:** This is NOT a Button - it's a text link. Consider creating a reusable `<TextLink>` component.

---

## 🎨 Step 3: Common Patterns

### Hero Section CTA
```tsx
// Primary action
<Button variant="brand" size="lg" icon={<ArrowUpRight size={20} />}>
  Schedule a Demo
</Button>

// Secondary action
<Button variant="secondary" size="lg">
  Learn More
</Button>
```

### Navigation Bar
```tsx
<Button variant="brand" size="sm">
  Schedule a Demo
</Button>
```

### Card Actions
```tsx
<Button variant="secondary" size="md" icon={<ArrowUpRight size={18} />}>
  View Details
</Button>
```

### Footer CTA (on dark background)
```tsx
<Button variant="ghost" size="lg" icon={<ArrowUpRight size={20} />}>
  Get Started
</Button>
```

---

## 📏 Step 4: Size Mapping Guide

Map Figma button sizes to system sizes:

| Figma Height | System Size | Height | Use Case |
|--------------|-------------|--------|----------|
| ~27px | `sm` | 40px | Compact UIs, toolbars |
| ~34px | `md` | 48px | ⭐ **Standard buttons** |
| - | `lg` | 56px | ⭐ **Hero CTAs** |
| - | `xl` | 64px | Extra emphasis |

**Recommendation:** 
- Use `md` for standard buttons (forms, cards, modals)
- Use `lg` for hero section CTAs
- Use `sm` for compact interfaces only

---

## 🎨 Step 5: Optional - Add Gradients to System

If your brand **requires** gradients, add this optional prop to Button:

### Update Button.tsx:
```tsx
interface ButtonProps {
  // ... existing props
  gradient?: boolean;
}

// In component styling:
className={cn(
  // ... existing classes
  gradient && variant === 'brand' && 'bg-gradient-to-r from-[#b01f24] via-[#eb484e] to-[#b01f24]',
  gradient && variant === 'primary' && 'bg-gradient-to-r from-[#141016] via-[#656565] to-[#141016]',
)}
```

### Usage:
```tsx
<Button variant="brand" size="md" gradient>
  Schedule a Demo
</Button>
```

**⚠️ Use Sparingly:** Gradients should be reserved for hero CTAs only.

---

## ✅ Step 6: Verification Checklist

After replacing Figma imports, verify:

- [ ] All buttons are **40px or taller** (accessibility)
- [ ] Border radius is **10px** (consistency)
- [ ] Icons are **Lucide React** icons (not custom SVGs)
- [ ] Icon sizes: **16-20px** (depending on button size)
- [ ] Font: **DM Sans Bold** for buttons
- [ ] Colors: **#b01f24** for brand, **black** for primary
- [ ] No animations (unless intentionally re-added)
- [ ] Hover states work correctly
- [ ] Keyboard navigation works (Tab key)
- [ ] Screen readers announce button labels

---

## 🐛 Common Issues & Fixes

### Issue 1: Button looks too large
**Problem:** Figma button was 34px, system is 48px
**Fix:** This is intentional for accessibility. If needed, use `size="sm"` (40px)

### Issue 2: Border radius looks too rounded
**Problem:** Figma used 5px, system uses 10px
**Fix:** This is intentional for consistency. If critical, add `tight` prop (future feature)

### Issue 3: Missing gradient background
**Problem:** System uses solid colors by default
**Fix:** 
- **Option A:** Accept solid colors (recommended)
- **Option B:** Add `gradient` prop to Button (see Step 5)

### Issue 4: Arrow doesn't animate
**Problem:** Figma had dual-layer animated arrow
**Fix:** This was removed intentionally for simplicity. Use static `<ArrowUpRight />` icon

### Issue 5: Text link needs gradient
**Problem:** ExploreCta has gradient text, Button doesn't support this
**Fix:** Create custom TextLink component (see Component 5 above)

---

## 📊 Before/After Comparison

### Your Codebase Before:
```tsx
// 5 different Figma imports
import MainCtaNav from '@/imports/MainCtaNav';
import BrandCta from '@/imports/BrandCta';
import ConnectNow from '@/imports/ConnectNow-12083-158';
import ExploreCta from '@/imports/ExploreCta';

// Multiple component variations
<MainCtaNav />
<BrandCta />
<ConnectNow />
<ExploreCta />
```

### Your Codebase After:
```tsx
// 1 standardized component
import { Button } from '@/app/components/Button';
import { ArrowUpRight } from 'lucide-react';

// Consistent API
<Button variant="brand" size="md">Schedule a Demo</Button>
<Button variant="brand" size="md" icon={<ArrowUpRight />}>Schedule a Demo</Button>
<Button variant="secondary" size="sm">Connect now</Button>
<TextLink>Explore Consulting</TextLink>
```

**Benefits:**
- ✅ 1 component instead of 5
- ✅ Consistent sizing and styling
- ✅ Better accessibility
- ✅ Easier to maintain
- ✅ Fully documented in design system

---

## 🚀 Next Steps

1. **Choose your approach:**
   - [ ] Replace all Figma imports with Button component (recommended)
   - [ ] Add gradient prop to Button first, then migrate
   
2. **Start migration:**
   - [ ] Update imports
   - [ ] Replace components one by one
   - [ ] Test each replacement
   - [ ] Verify accessibility

3. **Clean up:**
   - [ ] Remove Figma import files once migration complete
   - [ ] Update any documentation referencing old components
   - [ ] Celebrate! 🎉

---

## 📞 Need Help?

- **Visual Comparison:** Visit `/figma-comparison` route
- **Full Analysis:** See `FIGMA_BUTTON_ANALYSIS.md`
- **Component Docs:** Check Design System → Components → Buttons

---

**Migration Time Estimate:** 30-60 minutes for full codebase
**Difficulty:** Easy
**Breaking Changes:** Yes (component API changes)

---

*Last Updated: January 29, 2026*
