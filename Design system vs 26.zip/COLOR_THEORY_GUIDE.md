# 🎨 Proper Color Theory & Strategic Usage Guide

## 🎯 Color Hierarchy Philosophy

### **Rule of Hierarchy:**
1. **Primary Structure (90-95%):** Black, White, Warm
2. **Conversion King (3-5%):** Ken Bold Red - ONLY for CTAs
3. **Strategic Accents (2-5%):** Purple, Periwinkle, Perano - Highlights only

**Golden Rule:** Red must never be competed with. It's the conversion color.

---

## 📊 Proper Color Distribution

```
████████████████████████████ Black/White/Warm (90%)
███ Ken Bold Red (5% - CTAs ONLY)
██ Accent Colors (5% - Highlights, shadows, animations)
```

---

## 🎨 Color Roles & Strategic Usage

### 1. **Primary Structure Colors (Foundation)**

#### ⚫ **Black** (#000000)
**Usage:**
- Primary text color
- Hero section backgrounds
- Resources section backgrounds
- High-contrast elements

**Alternatives:**
- Second dark color for **gradient dark backgrounds** (instead of pure black)
- Creates depth and interest while maintaining authority

**Example:**
```css
/* Standard black background */
background: var(--black);

/* OR gradient dark background for emphasis */
background: linear-gradient(135deg, #000 0%, #1a1a2e 100%);
```

---

#### ⚪ **White** (#ffffff)
**Usage:**
- Primary section backgrounds
- Text on dark backgrounds
- Card backgrounds
- Clean, spacious areas

**When to use:**
- Standard sections (Client Context, Objectives, Impact)
- Card containers
- Text overlays on dark backgrounds

---

#### 🤎 **Warm** (#f5f2f1)
**Usage:**
- Alternate section backgrounds (Challenges, Methodology)
- Creates soft visual breaks
- Editorial, reading-friendly zones

**Frequency:** ~20-30% of page

---

### 2. **🔴 Ken Bold Red - THE CONVERSION KING**

#### **Sacred Usage Rules:**

✅ **ONLY use for:**
1. **Major CTAs** - "Schedule a Demo", "Get Started", "Contact Us"
2. **Important border buttons** - Actions requiring user attention
3. **Highlighted buttons** - Critical conversion points

❌ **NEVER use for:**
- Decorative elements
- Section backgrounds
- Icons (unless on CTA)
- Text highlights
- Hover states on non-CTA elements

#### **Gradient Animation (Premium Touch):**
```css
.cta-button {
  background: linear-gradient(135deg, var(--red-700), var(--red-500));
  background-size: 200% 200%;
  transition: background-position 0.3s ease;
}

.cta-button:hover {
  background-position: 100% 0;
  animation: gradientShift 2s ease infinite;
}

@keyframes gradientShift {
  0%, 100% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
}
```

#### **Red Usage Frequency:**
- **Maximum 3-5%** of visual elements
- **5-8 CTAs** total per page
- **Never more than 2** CTAs visible simultaneously

---

### 3. **Accent Colors - Strategic Highlights**

**Purpose:** Subtle enhancement, NOT dominance

#### 🟣 **Purple (True V)** - #806ce0

**Strategic Uses:**

✅ **GOOD Uses:**
- **Metric number highlights** (colored text for key metrics)
  ```css
  .metric-value { color: var(--purple-600); }
  ```

- **Soft drop shadows** on important cards
  ```css
  box-shadow: 0 8px 24px rgba(128, 108, 224, 0.08);
  ```

- **Icon accents** for innovation/premium features
  ```css
  .icon-premium { color: var(--purple-600); }
  ```

- **Animation beams/pulses** (like navigation)
  ```css
  @keyframes purpleBeam {
    from { box-shadow: 0 0 0 0 rgba(128, 108, 224, 0.4); }
    to { box-shadow: 0 0 0 20px rgba(128, 108, 224, 0); }
  }
  ```

- **Very light tint backgrounds** (purple-50 to purple-100 only)
  ```css
  background: var(--purple-50); /* Barely visible */
  ```

❌ **BAD Uses:**
- Full section backgrounds (too dominant)
- Large badges (competes with red CTAs)
- Primary buttons (red's territory)
- Body text (readability issues)

---

#### 🔵 **Periwinkle** - #c3c6f9

**Strategic Uses:**

✅ **GOOD Uses:**
- **Trust indicator shadows**
  ```css
  box-shadow: 0 4px 16px rgba(195, 198, 249, 0.12);
  ```

- **Testimonial card subtle accents**
  ```css
  border-left: 2px solid var(--periwinkle-400);
  ```

- **Soft background tints** (periwinkle-50 to periwinkle-100)
  ```css
  background: var(--periwinkle-50); /* Very subtle */
  ```

- **Rating stars color**
  ```css
  .star { fill: var(--periwinkle-600); }
  ```

❌ **BAD Uses:**
- Entire section backgrounds
- Text color (too light for readability)
- CTAs (never compete with red)

---

#### 🔷 **Perano (Light Blue)** - #dfeafa

**Strategic Uses:**

✅ **GOOD Uses:**
- **Data visualization highlights**
  ```css
  .chart-bar { background: var(--perano-400); }
  ```

- **Methodology card soft shadows on hover**
  ```css
  &:hover {
    box-shadow: 0 8px 20px rgba(223, 234, 250, 0.10);
  }
  ```

- **Process step number backgrounds**
  ```css
  .step-number { 
    background: var(--perano-100);
    color: var(--perano-900);
  }
  ```

- **Table header backgrounds**
  ```css
  thead { background: var(--perano-50); }
  ```

❌ **BAD Uses:**
- Primary backgrounds
- Text color
- CTAs
- Large UI elements

---

## 🎯 Proper Application Examples

### ✅ **CORRECT: Subtle Shadow Accent**

```tsx
<div 
  className="card"
  style={{
    backgroundColor: 'var(--white)',
    border: '1px solid var(--black-200)',
    boxShadow: '0 4px 16px rgba(195, 198, 249, 0.08), 0 1px 3px rgba(0, 0, 0, 0.04)'
  }}
>
  {/* Periwinkle shadow is barely visible but adds trust/quality feel */}
</div>
```

**Why it works:**
- White background maintains minimalism
- Gray border for structure
- Periwinkle shadow is 8% opacity (barely visible)
- Doesn't compete with red CTAs

---

### ✅ **CORRECT: Metric Number Highlight**

```tsx
<div className="metric-card">
  <div 
    className="metric-value" 
    style={{ 
      color: 'var(--purple-700)',
      fontSize: 'clamp(2rem, 5vw, 3rem)'
    }}
  >
    ₹110 Cr
  </div>
  <div className="metric-label" style={{ color: 'var(--black-500)' }}>
    Total Addressable Market
  </div>
</div>
```

**Why it works:**
- Purple number draws eye to important metric
- Black label provides stability
- Small accent use (just the number)
- Doesn't overpower red CTAs

---

### ✅ **CORRECT: Animated Pulse Effect**

```tsx
<div 
  className="feature-icon"
  style={{
    animation: 'purplePulse 2s ease-in-out infinite'
  }}
>
  <svg style={{ color: 'var(--purple-600)' }}>
    {/* Icon */}
  </svg>
</div>

<style>{`
  @keyframes purplePulse {
    0%, 100% { 
      box-shadow: 0 0 0 0 rgba(128, 108, 224, 0.4);
    }
    50% { 
      box-shadow: 0 0 0 15px rgba(128, 108, 224, 0);
    }
  }
`}</style>
```

**Why it works:**
- Animated glow effect is subtle
- Draws attention without overwhelming
- Similar to navigation beam effect user mentioned
- Purple suits innovation/premium features

---

### ❌ **WRONG: Full Section Background**

```tsx
{/* DON'T DO THIS */}
<section style={{ backgroundColor: 'var(--periwinkle-100)' }}>
  <h2>Testimonial</h2>
  <div className="card">
    {/* Content */}
  </div>
</section>
```

**Why it's wrong:**
- Entire section is colored (too dominant)
- Competes with red CTAs for attention
- Breaks minimalist aesthetic
- Reduces Ken Bold Red's impact

---

### ✅ **CORRECT: Testimonial with Subtle Accent**

```tsx
<section style={{ backgroundColor: 'var(--white)' }}>
  <h2>Testimonial</h2>
  <div 
    className="card"
    style={{
      backgroundColor: 'var(--white)',
      border: '1px solid var(--black-200)',
      boxShadow: '0 4px 16px rgba(195, 198, 249, 0.08)'
      {/* Periwinkle shadow only - barely visible */}
    }}
  >
    {/* Content */}
  </div>
</section>
```

**Why it works:**
- White section background (maintains minimalism)
- White card with gray border (clean)
- Periwinkle shadow is 8% opacity (trust signal, barely visible)
- Red CTAs remain dominant

---

## 🎨 Color Accent Techniques

### **1. Colored Shadows (Recommended)**

```css
/* Subtle colored shadows for depth and personality */
.card {
  box-shadow: 
    0 8px 24px rgba(128, 108, 224, 0.06),  /* Purple glow */
    0 2px 8px rgba(0, 0, 0, 0.04);          /* Black depth */
}
```

**Usage:**
- Challenge cards: Purple shadow (innovation)
- Testimonial cards: Periwinkle shadow (trust)
- Methodology cards: Perano shadow (data-driven)

**Opacity rules:**
- 4-8% for primary shadow color
- Always layer with black shadow for depth

---

### **2. Metric Number Highlights**

```css
.metric-value {
  color: var(--purple-700);  /* Or periwinkle-700, perano-700 */
  font-size: clamp(2rem, 5vw, 3rem);
  filter: drop-shadow(0 2px 8px rgba(128, 108, 224, 0.15));
}
```

**Best for:**
- Impact section metric numbers
- Key statistics
- Achievement numbers

**Color choice:**
- Purple: Premium/innovation metrics
- Periwinkle: Trust/reliability metrics
- Perano: Data/analytics metrics

---

### **3. Icon Accents**

```css
.icon-accent {
  color: var(--purple-600);
  filter: drop-shadow(0 2px 4px rgba(128, 108, 224, 0.2));
}
```

**Use for:**
- Premium feature icons
- Innovation indicators
- Special badges (use sparingly)

---

### **4. Animation Effects (Like Navigation)**

```css
@keyframes colorBeam {
  from {
    box-shadow: 0 0 0 0 rgba(128, 108, 224, 0.5);
  }
  to {
    box-shadow: 0 0 0 30px rgba(128, 108, 224, 0);
  }
}

.animated-element {
  animation: colorBeam 2.5s ease-out infinite;
}
```

**Use for:**
- Active navigation indicators
- Loading states
- Scroll progress indicators
- Feature highlights on scroll

---

### **5. Very Light Tint Backgrounds**

```css
/* Only use 50-100 range */
.subtle-background {
  background: var(--purple-50);  /* Barely visible */
}

/* Or gradients for depth */
.gradient-background {
  background: linear-gradient(
    to bottom,
    var(--purple-50),
    var(--white)
  );
}
```

**Rules:**
- Only use 50-100 shades (barely visible)
- Never full section backgrounds
- Use for small cards/containers only
- Always transition to white

---

## 🚫 Common Mistakes to Avoid

### ❌ **Mistake 1: Accent Color Backgrounds**
```css
/* DON'T */
section {
  background: var(--periwinkle-100);  /* Too dominant */
}
```

✅ **Fix:**
```css
/* DO */
section {
  background: var(--white);
}

.card {
  box-shadow: 0 4px 16px rgba(195, 198, 249, 0.08);  /* Subtle shadow */
}
```

---

### ❌ **Mistake 2: Colored Badges Near CTAs**
```css
/* DON'T */
.premium-badge {
  background: var(--purple-600);  /* Competes with red CTAs */
  color: white;
}
```

✅ **Fix:**
```css
/* DO */
.premium-badge {
  background: var(--purple-50);   /* Very subtle */
  border: 1px solid var(--purple-600);
  color: var(--purple-900);
  /* OR remove badge entirely if near CTAs */
}
```

---

### ❌ **Mistake 3: Multiple Accent Colors Together**
```css
/* DON'T */
.section {
  border-left: 3px solid var(--purple-600);
  box-shadow: 0 4px 16px rgba(195, 198, 249, 0.2);
  background: var(--perano-50);
}
```

✅ **Fix:**
```css
/* DO - Pick ONE accent color per element */
.section {
  border: 1px solid var(--black-200);
  box-shadow: 0 4px 16px rgba(128, 108, 224, 0.08);  /* One color only */
  background: var(--white);
}
```

---

## 🎯 Section-by-Section Color Strategy

### **Hero Section**
```
Background: Pure black OR gradient dark (black → #1a1a2e)
Text: White
CTA: Red gradient (red-700 → red-500) with animation
Accents: None (keep focus on CTA)
```

---

### **Client Context**
```
Background: White
Text: Black
Accents: Purple for "Premium Research" if needed (50-100 range)
Shadows: Minimal black shadows
```

---

### **Challenges Section**
```
Background: Warm
Cards: White with gray borders
Hover: Purple shadow (6-8% opacity)
Text: Black
```

---

### **Engagement Objectives**
```
Background: White
Cards: White with subtle borders
Accents: None OR perano for data-focused objectives
Text: Black
```

---

### **Methodology Section**
```
Background: Warm
Cards: White
Hover: Perano shadow (6-8% opacity) - data/process feel
Text: Black
Timeline: Black/warm colors
```

---

### **Impact Section**
```
Background: White
Metrics: Purple-highlighted numbers (700 shade)
Labels: Black
Dividers: Black/gray
Shadows: Purple glow on metric numbers (drop-shadow)
```

---

### **Testimonial Section**
```
Background: White
Card: White
Border: Gray
Shadow: Periwinkle (8% opacity) - trust signal
Stars: Black OR periwinkle-700 if subtle
Text: Black
```

---

### **Final CTA Section**
```
Background: White
CTA Button: Red gradient (red-700 → red-500) with animation
Text: Black
Accents: None (full focus on red CTA)
```

---

### **Resources Section**
```
Background: Pure black
Text: White
Links: Red on hover
Accents: None (keep clean and authoritative)
```

---

## 📊 Color Usage Calculator

### **Target Distribution Per Page:**

```
Black/White/Warm: 90%
├─ Black: 40% (text, dark sections)
├─ White: 40% (light sections, cards)
└─ Warm: 10% (alternate sections)

Ken Bold Red: 5%
├─ CTAs: 3%
└─ Important buttons: 2%

Accent Colors: 5%
├─ Purple: 2% (shadows, metric highlights, animations)
├─ Periwinkle: 2% (trust shadows, testimonial accents)
└─ Perano: 1% (data shadows, methodology accents)
```

---

## ✅ Implementation Checklist

**Before adding any accent color, ask:**

- [ ] Is this competing with a red CTA? (If yes, remove accent)
- [ ] Is the opacity low enough? (Target: 4-8% for shadows)
- [ ] Is this enhancing or dominating? (Should enhance)
- [ ] Can I use a shadow instead of a background? (Prefer shadows)
- [ ] Is there already red nearby? (If yes, minimize accents)
- [ ] Does this maintain minimalism? (90% should be B/W/Warm)
- [ ] Is this a highlight, not a main element? (Accents are highlights)

---

## 🎨 Final Color Philosophy

**Remember:**

1. **Black, White, Warm = Foundation** (90%)
2. **Red = Conversion King** (5% - NEVER compete)
3. **Accents = Whispers, not shouts** (5% - subtle highlights)

**The goal:** Sophisticated minimalism with strategic color whispers that guide attention to red CTAs without competing.

**Color should:**
- ✅ Enhance depth (shadows)
- ✅ Highlight metrics (number colors)
- ✅ Add micro-interactions (animations)
- ✅ Create subtle trust signals (barely-visible backgrounds)

**Color should NOT:**
- ❌ Dominate sections
- ❌ Compete with CTAs
- ❌ Break minimalism
- ❌ Confuse hierarchy

---

**Version:** 2.0 - Proper Color Theory  
**Last Updated:** January 2025  
**Based on:** User feedback on color hierarchy and red CTA dominance
