// ============================================================================
// NEW TYPOGRAPHY HELPER COMPONENTS  
// ============================================================================

// Font Weight Demo
function FontWeightDemo() {
  const weights = [
    { weight: '400', name: 'Normal', usage: 'Body text', example: 'This is regular body text.' },
    { weight: '500', name: 'Medium', usage: 'Emphasis', example: 'This is medium weight.' },
    { weight: '700', name: 'Bold', usage: 'Headings', example: 'This is bold weight.' },
  ];

  return (
    <div className="space-y-4">
      {weights.map((w) => (
        <div key={w.weight} className="border border-black/8 rounded-[10px] p-6">
          <div className="flex items-center justify-between mb-3">
            <p className="font-mono text-sm"><strong>Weight:</strong> {w.weight} ({w.name})</p>
            <p className="text-xs text-black/60">{w.usage}</p>
          </div>
          <p style={{ fontWeight: w.weight }} className="text-base">{w.example}</p>
        </div>
      ))}
    </div>
  );
}

// Font Family Comparison
function FontFamilyComparison() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: DM Sans</p>
        <h3 style={{ fontFamily: 'DM Sans' }} className="text-2xl mb-3">DM Sans Heading</h3>
        <p style={{ fontFamily: 'DM Sans' }} className="text-sm mb-4">Geometric sans-serif. Clean, modern.</p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> UI elements, buttons, labels</p>
      </div>

      <div className="border border-black/8 rounded-[10px] p-6">
        <p className="font-mono text-xs text-black/60 mb-4">font-family: Noto Serif</p>
        <h3 style={{ fontFamily: 'Noto Serif' }} className="text-2xl mb-3">Noto Serif Heading</h3>
        <p style={{ fontFamily: 'Noto Serif' }} className="text-sm mb-4">Humanist serif. Warm, editorial.</p>
        <p className="text-xs text-black/60"><strong>Best for:</strong> Headings, body paragraphs</p>
      </div>
    </div>
  );
}

// Real Text Examples
function RealTextExamples() {
  const examples = [
    { size: '48.8px', text: 'Revolutionizing Global Communications', usage: 'Hero H1' },
    { size: '39px', text: 'Client Context: Understanding the Problem', usage: 'Section H2' },
    { size: '31.25px', text: 'Primary Research & Discovery Phase', usage: 'Subsection H3' },
    { size: '20px', text: 'Challenge Overview Card Title', usage: 'Card Heading' },
    { size: '16px', text: 'Body text describing project details and methodology.', usage: 'Body' },
    { size: '12.8px', text: 'CASE STUDY • DESIGN SYSTEM', usage: 'Label' },
  ];

  return (
    <div className="space-y-6">
      {examples.map((ex, idx) => (
        <div key={idx} className="border-l-4 border-[var(--brand-red)] pl-6 py-3">
          <div className="flex items-center gap-3 mb-2">
            <code className="font-mono text-xs bg-black/5 px-2 py-1 rounded-[3px]">{ex.size}</code>
            <span className="text-xs text-black/50">• {ex.usage}</span>
          </div>
          <p style={{ fontSize: ex.size }}>{ex.text}</p>
        </div>
      ))}
    </div>
  );
}

// Heading Hierarchy
function HeadingHierarchy() {
  return (
    <div className="border border-black/8 rounded-[10px] p-8 bg-white">
      <h1 style={{ fontSize: 'var(--text-3xl)' }} className="mb-6">H1: Hero Heading (48.8px)</h1>
      <div className="pl-6 border-l-2 border-black/10">
        <h2 style={{ fontSize: 'var(--text-2xl)' }} className="mb-4">H2: Section Heading (39px)</h2>
        <div className="pl-6 border-l-2 border-black/10">
          <h3 style={{ fontSize: 'var(--text-xl)' }} className="mb-3">H3: Subsection Heading (31.25px)</h3>
          <p style={{ fontSize: 'var(--text-sm)' }} className="text-black/70">Body text follows at 16px.</p>
        </div>
      </div>
    </div>
  );
}

// Responsive Typography Demo
function ResponsiveTypographyDemo() {
  return (
    <div className="space-y-6">
      <div className="bg-black/[0.02] rounded-[10px] p-6">
        <h4 className="font-semibold mb-4">Mobile (< 768px)</h4>
        <div className="space-y-2 text-sm">
          <p>• Hero (H1): 36px</p>
          <p>• Section (H2): 28px</p>
        </div>
      </div>

      <div className="bg-black/[0.02] rounded-[10px] p-6">
        <h4 className="font-semibold mb-4">Desktop (≥ 768px)</h4>
        <div className="space-y-2 text-sm">
          <p>• Hero (H1): 48.8px ⭐</p>
          <p>• Section (H2): 39px ⭐</p>
        </div>
      </div>
    </div>
  );
}
