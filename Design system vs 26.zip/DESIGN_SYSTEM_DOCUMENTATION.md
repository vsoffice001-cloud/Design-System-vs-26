# Design System Documentation
**YASH Transformer Bushing Case Study**  
**Version:** 1.0  
**Date:** January 21, 2026

---

## 📋 Table of Contents
1. [Design Tokens](#design-tokens)
2. [Atomic Design Structure](#atomic-design-structure)
3. [Component Inventory](#component-inventory)
4. [Button System](#button-system)
5. [Usage Guidelines](#usage-guidelines)
6. [Extended Documentation](#extended-documentation)

---

## 📚 Extended Documentation

This document provides a quick reference for the YASH Design System. For comprehensive theory, detailed scenarios, and decision-making frameworks, refer to these companion documents:

### **1. Atomic Design Methodology** (`ATOMIC_DESIGN_METHODOLOGY.md`)
- Complete theoretical foundations of Atomic Design
- What, Why, When, Where, How for each level (Atoms → Pages)
- Real-world scenarios and use cases
- Component evolution patterns
- Common anti-patterns and solutions
- **Best for:** Understanding the methodology deeply

### **2. Design Decision Scenarios** (`DESIGN_DECISION_SCENARIOS.md`)
- Daily development scenarios with step-by-step solutions
- Decision trees for choosing components
- Color, typography, and layout decision frameworks
- Button selection matrix
- Common pitfalls and how to avoid them
- Quality assurance checklist
- **Best for:** Making practical design decisions

### **3. Design System Theory** (`DESIGN_SYSTEM_THEORY.md`)
- Color theory and psychology (92-5-3 rule explained)
- Typography science (Major Third scale rationale)
- Spatial systems and harmony principles
- Visual hierarchy theories (Fitts's Law, F-Pattern)
- Interaction design foundations
- Accessibility principles (WCAG 2.1)
- Conversion psychology
- **Best for:** Understanding WHY behind every decision

---

## 🎯 Quick Navigation Guide

**Need to:**
- Understand atomic design? → Read `ATOMIC_DESIGN_METHODOLOGY.md`
- Make a design decision? → Check `DESIGN_DECISION_SCENARIOS.md`
- Learn the theory? → Study `DESIGN_SYSTEM_THEORY.md`
- Find component props? → Reference this document
- See visual examples? → View `DesignSystemPage.tsx` component

---

## 🎨 Design Tokens

### Color System (92-5-3 Rule)

**Primary Palette (92% usage)**
- Pure Black: `#000000` - Hero sections, primary text
- Pure White: `#ffffff` - Standard backgrounds
- Warm Off-White: `#f5f2f1` - Highlighted sections (Challenges, Methodology)
- Warm Border: `#eae5e3` - Subtle dividers

**Brand Red (5% usage - CTAs ONLY)**
- Red 500: `#c62d31` - Gradient end
- Red 600: `#b01f24` - PRIMARY BRAND (gradient start)
- Red 700: `#8f181d` - Hover states
- Red 800: `#771419` - Active/pressed states
- Red 900: `#5f1014` - Deep shadows

**Accent Colors (3% usage - Shadows & highlights ONLY)**
- Purple 600: `#806ce0` - Premium features
- Periwinkle 500: `#c3c6f9` - Trust indicators
- Perano 500: `#dfeafa` - Data sections
- Warm 600: `#d9d1ce` - Timeline elements

### Typography Scale (Major Third - 1.25 ratio)

**Scale Variables**
- `--text-5xl`: 76.3px (4.768rem) - Future use
- `--text-4xl`: 61px (3.815rem) - Extra large headings
- `--text-3xl`: 48.8px (3.052rem) - **HERO H1 ONLY**
- `--text-2xl`: 39px (2.441rem) - **SECTION HEADINGS (H2)**
- `--text-xl`: 31.25px (1.953rem) - Subsection headings (H3)
- `--text-lg`: 25px (1.563rem) - Card titles (2-3 cards)
- `--text-base`: 20px (1.25rem) - Large body, card titles (4+ cards)
- `--text-sm`: 16px (1rem) - **BODY TEXT**
- `--text-xs`: 12.8px (0.8rem) - Labels, metadata

**Custom Sizes (Outside Scale)**
- `--text-2xs`: 12px (0.75rem) - Navbar, micro labels
- `--text-compact`: 14px (0.875rem) - Compact body text

### Border Radius System

**Strict Hierarchy**
- `2.5px` - Images, photos
- `5px` - Buttons, small cards, badges
- `10px` - Big cards, containers, sections

**Rule:** Never mix radius sizes in the same component

### Button Size System

**Heights**
- `--button-height-sm`: 40px (2.5rem)
- `--button-height-md`: 48px (3rem)
- `--button-height-lg`: 56px (3.5rem) - **PRIMARY CTAs**
- `--button-height-xl`: 64px (4rem) - Hero/Emphasis

**Font Sizes**
- `--button-font-sm`: 14px (0.875rem)
- `--button-font-md`: 16px (1rem)
- `--button-font-lg`: 18px (1.125rem)

**Horizontal Padding**
- `--button-px-sm`: 20px (1.25rem)
- `--button-px-md`: 28px (1.75rem)
- `--button-px-lg`: 36px (2.25rem)
- `--button-px-xl`: 40px (2.5rem)

### Spacing Scale

Based on Tailwind's default spacing:
- `0.25rem` (4px) - Tight spacing
- `0.5rem` (8px) - Compact spacing
- `1rem` (16px) - Standard spacing
- `1.5rem` (24px) - Comfortable spacing
- `2rem` (32px) - Section spacing
- `3rem` (48px) - Large gaps
- `4rem` (64px) - Section padding
- `5rem` (80px) - Hero padding

---

## ⚛️ Atomic Design Structure

### Level 01: Atoms
**Foundational elements that can't be broken down further**

- **Colors**: Swatches, gradients
- **Typography**: Text sizes, weights
- **Icons**: Lucide React icon set
- **Spacing**: Gap, padding, margin units
- **Border Radius**: 2.5px, 5px, 10px
- **Shadows**: sm, md, lg elevation levels

### Level 02: Molecules
**Simple components combining atoms**

- **Buttons**: 4 variants × 4 sizes × 3 states
- **Badges**: Number badges, category labels
- **Metric Cards**: Value + label display
- **Simple Cards**: White, warm, dark variants

### Level 03: Organisms
**Complex components combining molecules**

- **Feature Grid**: 2-column numbered features
- **CTA Sections**: Hero-style call-to-action blocks
- **Stats Grid**: 4-column metric displays
- **Challenge Cards**: Numbered cards with question lists

### Level 04: Templates
**Page-level layouts (not yet implemented)**

- Hero + Context layout
- Section grid patterns
- Alternating black/white sections

### Level 05: Pages
**Complete page compositions (current case study)**

- YASH Case Study (reference implementation)

---

## 🔘 Button System

### Variants

**1. Brand (variant="brand")**
- **Gradient**: `linear-gradient(90deg, #b01f24, #c62d31)`
- **Purpose**: Highest conversion priority CTAs
- **Usage**: "Schedule a Demo", primary conversion actions
- **Effects**: Red gradient shift on hover, shadow glow
- **Restriction**: Use sparingly - only 5% of page elements

**2. Primary (variant="primary")**
- **Gradient**: `linear-gradient(90deg, #0a0a0a, #6a6a6a)`
- **Purpose**: Secondary important actions
- **Usage**: "Get Customized Report", form submits
- **Effects**: Dark-to-light gradient shift on hover
- **Color**: Pure black to medium grey (62% contrast)

**3. Secondary (variant="secondary")**
- **Style**: White bg + black border
- **Purpose**: Alternative actions
- **Usage**: "Book Discovery Call", non-primary CTAs
- **Effects**: Subtle hover states
- **Pairs with**: Primary and Brand buttons

**4. Ghost (variant="ghost")**
- **Style**: Transparent + white border
- **Purpose**: Low emphasis actions
- **Usage**: "See All Resources" - only on dark backgrounds
- **Effects**: Minimal visual weight
- **Restriction**: Dark backgrounds only

### Sizes
- `size="sm"` - 40px height (utility buttons)
- `size="md"` - 48px height (standard)
- `size="lg"` - 56px height (PRIMARY CTAs) ⭐
- `size="xl"` - 64px height (hero emphasis)

### States
- Default
- Hover (gradient shift, shadow enhancement)
- Loading (spinner animation)
- Disabled (50% opacity)

### Props
```typescript
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'brand';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  fullWidth?: boolean;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  iconOnly?: boolean;
  loading?: boolean;
  disabled?: boolean;
  ripple?: boolean;
  onClick?: () => void;
  className?: string;
  type?: 'button' | 'submit' | 'reset';
  ariaLabel?: string;
}
```

---

## 📐 Usage Guidelines

### Color Hierarchy Rules

**✅ DO:**
- Use black/white/warm for 92% of the page
- Reserve brand red ONLY for major CTAs (5%)
- Use accent colors at 6-8% opacity for shadows
- Apply gradient buttons for conversion-critical actions

**❌ DON'T:**
- Use red for backgrounds or large elements
- Mix accent colors as primary backgrounds
- Create new color variants outside the system
- Use gradient text (poor accessibility)

### Typography Rules

**✅ DO:**
- Use CSS variables (`var(--text-2xl)`) for standard sizes
- Reserve `--text-3xl` for hero moments only
- Use `--text-2xl` as standard section heading
- Maintain Major Third ratio (1.25x) progression

**❌ DON'T:**
- Hardcode font sizes without rationale
- Skip sizes in the scale arbitrarily
- Use `--text-3xl` for regular section headings
- Mix custom sizes with scale variables

### Spacing Rules

**✅ DO:**
- Max content width: 1000px, centered
- Section padding: `py-16` to `py-20`
- Grid gaps: `gap-6` or `gap-8`
- Generous whitespace between sections

**❌ DON'T:**
- Exceed 1200px container width
- Use inconsistent gaps within same component
- Crowd elements without breathing room
- Mix spacing units (stick to rem-based)

### Border Radius Rules

**✅ DO:**
- 2.5px: Images and raster graphics
- 5px: Buttons, small cards, badges
- 10px: Big cards, sections, containers

**❌ DON'T:**
- Mix radius sizes in same component
- Use radius > 10px (breaks visual language)
- Apply rounded-full to non-circular elements

---

## 🗂️ Component Inventory

### Production Components
- ✅ HeroSection
- ✅ ClientContextSection
- ✅ ChallengesSection
- ✅ EngagementObjectivesSection
- ✅ MethodologySection
- ✅ ImpactSection (3 variants)
- ✅ TestimonialSection
- ✅ FinalCTASection
- ✅ ResourcesSection
- ✅ Navbar
- ✅ ReadingProgressBar
- ✅ StickyCTA
- ✅ VariantSwitcher
- ✅ Button (4 variants, 4 sizes)
- ✅ DesignSystemPage

### Reusable Patterns
- Feature Grid (2-4 columns)
- Numbered Card Grid
- Stats Display (horizontal)
- CTA Block (centered)
- Challenge Cards (with questions)

---

## 🎯 Design Philosophy

**Minimalist Editorial Aesthetic**
- Black/white alternating sections
- Massive typography (Major Third scale)
- Generous whitespace
- Max 1000px content width
- Centered alignment

**Premium Case Study Feel**
- Glass-morphism effects
- Smooth transitions
- Sophisticated interactions
- Opacity-driven hierarchy

**Conversion-Focused**
- 5% red CTAs for high-priority actions
- Clear visual hierarchy
- Strategic gradient usage
- Accessibility-first approach

---

## 📦 File Structure

```
/src/app/components/
├── Button.tsx                    # Core button system
├── DesignSystemPage.tsx          # This documentation page
├── HeroSection.tsx
├── ClientContextSection.tsx
├── ChallengesSection.tsx
├── EngagementObjectivesSection.tsx
├── MethodologySection.tsx
├── ImpactSection.tsx
├── TestimonialSection.tsx
├── FinalCTASection.tsx
├── ResourcesSection.tsx
├── Navbar.tsx
├── ReadingProgressBar.tsx
├── StickyCTA.tsx
└── VariantSwitcher.tsx

/src/styles/
├── theme.css                     # All design tokens
└── fonts.css                     # Font imports
```

---

## 🔄 Version History

**v1.0** (January 21, 2026)
- ✅ Initial design system documentation
- ✅ Button component with 4 variants
- ✅ Primary gradient: 90deg left-to-right (#0a0a0a → #6a6a6a)
- ✅ Brand gradient: 90deg left-to-right (#b01f24 → #c62d31)
- ✅ Fixed React warnings (background property conflicts)
- ✅ Created comprehensive DesignSystemPage
- ✅ Atomic Design methodology applied

---

## 📝 Notes for Future Pages

When building new pages from this system:

1. **Start with atoms**: Choose colors, typography, spacing
2. **Combine into molecules**: Build buttons, cards, badges
3. **Assemble organisms**: Create feature grids, CTA sections
4. **Layout templates**: Arrange sections with proper spacing
5. **Compose pages**: Follow alternating black/white pattern

**Always maintain:**
- 92-5-3 color rule
- Major Third typography scale
- Border radius hierarchy
- Max 1000px content width
- Generous section padding

---

**End of Documentation**