# Design Principles & Philosophy

**Last Updated:** January 21, 2026  
**Version:** 1.0.0

---

## Overview

This document outlines the core principles, rules, and philosophical foundations that govern all design decisions in this system. Understanding these principles enables consistent, confident decision-making when creating new components or patterns.

---

## 🎨 The 92-5-3 Color Hierarchy Rule

### The Foundation

**92% - Black/White/Warm**  
The vast majority of your interface uses:
- Pure Black (`#000000`)
- Pure White (`#ffffff`)
- Warm Off-White (`#f5f2f1`)
- Warm Border (`#eae5e3`)

**5% - Ken Bold Red**  
Brand red is reserved EXCLUSIVELY for major CTAs:
- Schedule Demo
- Get Started
- Download Report
- Contact Us

**3% - Accent Colors**  
Purple, periwinkle, perano - ONLY for:
- Shadows at 6-8% opacity
- Metric number highlights
- Subtle animation effects

### Why This Matters

**The Problem:** When everything is colorful, nothing stands out.

**The Solution:** Extreme color restraint creates a "premium minimalist editorial" aesthetic where the single red CTA button becomes impossible to ignore.

### Enforcement

**✅ CORRECT:**
```tsx
{/* 92% - Foundation */}
<section className="bg-white py-20">
  <div className="bg-[#f5f2f1] rounded-[10px] p-8">
    <h3 className="text-black">Heading</h3>
    <p className="text-black/70">Description</p>
    
    {/* 5% - Single red CTA */}
    <Button variant="brand">Get Started</Button>
  </div>
</section>
```

**❌ WRONG:**
```tsx
{/* Too much color - violates 92-5-3 */}
<section className="bg-gradient-to-r from-purple-500 to-blue-500">
  <div className="bg-red-100">
    <h3 className="text-purple-600">Heading</h3>
    <Button className="bg-green-500">Click</Button>
    <Button className="bg-red-500">Also Click</Button>
  </div>
</section>
```

---

## 📐 Typography Hierarchy Philosophy

### Major Third Musical Scale (1.25 Ratio)

We use the **Major Third musical interval (1.25x)** because:
1. **Harmonious** - Same ratio as musical harmony
2. **Readable** - Not too dramatic, not too subtle
3. **Scalable** - Works across all screen sizes
4. **Mathematical** - Predictable, systematic

### The Sacred H1 Rule

**--text-3xl (48.8px) is RESERVED for hero moments.**

Why? Because when every heading is massive, none are special.

**Correct Usage:**
```tsx
{/* Hero - ONLY place for --text-3xl */}
<h1 className="text-[var(--text-3xl)]">Main Hero Heading</h1>

{/* Sections - Use --text-2xl */}
<h2 className="text-[var(--text-2xl)]">Section Heading</h2>

{/* Subsections - Use --text-xl */}
<h3 className="text-[var(--text-xl)]">Subsection Heading</h3>
```

### The 2-3 vs 4+ Card Rule

**When you have 2-3 cards:**
- Use `--text-lg` (25px) for card titles
- Visual hierarchy remains strong

**When you have 4+ cards:**
- Use `--text-base` (20px) for card titles
- Prevents visual chaos
- Maintains scanability

**Why?** More elements = smaller sizes to maintain balance.

---

## 🔲 Border Radius System Philosophy

### The Three-Tier System

**2.5px - Images**  
Subtle rounding that says "modern" without saying "bubbly"

**5px - Buttons & Small Cards**  
Friendly but professional

**10px - Big Cards & Containers**  
Generous rounding for major containers

### The Consistency Rule

**NEVER mix radius sizes within the same component.**

**✅ CORRECT:**
```tsx
{/* All children use 5px */}
<div className="rounded-[10px] p-8">
  <Button className="rounded-[5px]">Click</Button>
  <Badge className="rounded-[5px]">New</Badge>
</div>
```

**❌ WRONG:**
```tsx
{/* Mixed radii - visually jarring */}
<div className="rounded-[10px] p-8">
  <Button className="rounded-full">Click</Button>
  <Badge className="rounded-[2px]">New</Badge>
</div>
```

---

## 📏 Whitespace Philosophy

### "Generous Whitespace" Mandate

**Principle:** Space is a design element, not wasted pixels.

**Implementation:**
- Sections: `py-20` (80px) vertical padding
- Grids: `gap-6` (24px) or `gap-8` (32px)
- Cards: `p-8` (32px) or `p-12` (48px)
- Content max-width: `1000px` (centered)

### Why It Matters

1. **Readability** - Eyes need rest between sections
2. **Premium Feel** - Cramped = cheap, spacious = premium
3. **Focus** - Space directs attention
4. **Responsive** - More space = easier to adapt

**Example:**
```tsx
{/* Generous spacing creates premium feel */}
<section className="py-20 bg-white">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    <div className="mb-12">
      <h2 className="text-4xl font-bold mb-6">Heading</h2>
    </div>
    <div className="grid grid-cols-2 gap-8">
      {/* Cards with breathing room */}
    </div>
  </div>
</section>
```

---

## 🎯 CTA Hierarchy & Conversion Design

### The Single Red Button Rule

**Principle:** There should be maximum ONE brand red button per viewport/section.

**Why?** 
- Multiple red buttons = user confusion ("Which is most important?")
- Single red button = clear call-to-action
- Scarcity = urgency

**✅ CORRECT:**
```tsx
<div className="flex gap-4">
  <Button variant="brand">Primary Action</Button>
  <Button variant="secondary">Secondary</Button>
</div>
```

**❌ WRONG:**
```tsx
<div className="flex gap-4">
  <Button variant="brand">Action 1</Button>
  <Button variant="brand">Action 2</Button>
  <Button variant="brand">Action 3</Button>
</div>
```

### CTA Pairing Guidelines

**On Light Backgrounds:**
- Brand + Secondary
- Primary + Secondary

**On Dark Backgrounds:**
- Brand + Ghost
- Primary + Ghost

---

## 🌊 Visual Rhythm Through Alternation

### Black/White/Warm Alternating Pattern

**Principle:** Alternate backgrounds to create visual rhythm and prevent monotony.

**Standard Sequence:**
1. **Black** - Hero (impact)
2. **White** - Content
3. **Warm** - Highlighted (stats/testimonials)
4. **White** - Content
5. **Black** - CTA
6. **Warm** - Features
7. **Black** - Footer/Final CTA

### Rules

- ✅ Use **warm** (`#f5f2f1`) for special content (stats, testimonials, highlighted features)
- ✅ Use **black** for high contrast and CTAs
- ✅ Use **white** for standard content
- ❌ Never 3+ consecutive white sections
- ❌ Never black-white-black-white without warm breaks

---

## 🎨 Shadow & Depth Philosophy

### Minimal Shadow Approach

**Principle:** Use shadows sparingly to create hierarchy, not decoration.

**Three Levels Only:**
1. **Subtle** (`shadow-sm`) - Gentle elevation
2. **Standard** (`shadow-md`) - Default cards
3. **Prominent** (`shadow-lg`) - Modals, important elements

### Special Case: Brand Button Glow

The ONLY element with colored shadow:
```css
/* Brand button hover glow */
box-shadow: 0 12px 32px rgba(176, 31, 36, 0.25);
```

Why? Makes the CTA literally glow with importance.

---

## ⚡ Animation Philosophy

### Smooth, Premium Transitions

**Principle:** Animations should feel expensive, not gimmicky.

**Easing:** Use `cubic-bezier(0.22, 1, 0.36, 1)` for smooth, premium feel

**Duration:**
- Micro-interactions: 150-300ms
- Standard transitions: 600ms
- Large animations: 900ms

**What to Animate:**
- Button hover states
- Background gradient shifts
- Shadow glows
- Transforms (scale, translate)

**What NOT to Animate:**
- Layout shifts
- Content appearance (use fade only)
- Excessive bounces or springs

---

## 📱 Mobile-First Responsive Philosophy

### Start Small, Scale Up

**Principle:** Design for mobile first, enhance for desktop.

**Implementation:**
```css
/* Mobile (default) */
.grid { grid-cols-1 }

/* Tablet and up */
@media (min-width: 768px) {
  .grid { grid-cols-2 }
}

/* Desktop and up */
@media (min-width: 1024px) {
  .grid { grid-cols-4 }
}
```

### Responsive Content Hierarchy

**Mobile:**
- Reduce heading sizes (2.5rem instead of 3rem)
- Stack buttons vertically if needed
- Reduce padding (py-16 instead of py-20)

**Desktop:**
- Full typography scale
- Side-by-side button layouts
- Maximum spacing (py-20)

---

## 🎯 Content-First Philosophy

### Progressive Disclosure

**Principle:** Show the most important information first, details on demand.

**Implementation:**
1. **Hero** - Value proposition (10 words)
2. **Lede** - Supporting description (20 words)
3. **Features** - Benefits (3-6 cards)
4. **Details** - Deep dive (expandable)

### Word Count Guidelines

| Element | Max Words | Reason |
|---------|-----------|--------|
| Hero Heading | 10 | Immediate impact |
| Hero Description | 25 | Quick value prop |
| Section Heading | 6 | Scannable |
| Card Title | 6 | Quick comprehension |
| Card Description | 30 | Enough detail without overwhelm |
| CTA Button | 3 | Action-oriented, clear |

---

## ♿ Accessibility Principles

### Contrast Requirements

**Minimum Contrast Ratios (WCAG AA):**
- Normal text: 4.5:1
- Large text (18px+): 3:1
- UI elements: 3:1

**Our Implementation:**
- Pure black on white: 21:1 ✅
- Black/60 on white: 7:1 ✅
- White/70 on black: 10:1 ✅
- Red buttons: 4.6:1 ✅

### Keyboard Navigation

All interactive elements must be:
- Focusable via Tab
- Activatable via Enter/Space
- Visible focus states

```css
/* Focus states */
button:focus-visible {
  outline: 2px solid currentColor;
  outline-offset: 2px;
}
```

### Screen Reader Considerations

- Semantic HTML (h1, h2, nav, main, etc.)
- Alt text for images
- ARIA labels when needed
- Logical heading hierarchy

---

## 🔄 Consistency Over Novelty

### The Boring Consistency Rule

**Principle:** Predictability is a feature, not a bug.

**Implementation:**
- Same button heights across the site
- Same grid gaps across sections
- Same max-width for all content
- Same vertical padding for sections

**Why?** 
- Users learn patterns
- Faster development
- Easier maintenance
- Professional appearance

**✅ CORRECT:**
```tsx
{/* Every section uses the same container */}
<section className="py-20">
  <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8">
    {/* Content */}
  </div>
</section>
```

**❌ WRONG:**
```tsx
{/* Inconsistent containers */}
<section className="py-16">
  <div className="max-w-[900px] mx-auto px-6">...</div>
</section>
<section className="py-24">
  <div className="max-w-[1100px] mx-auto px-8">...</div>
</section>
```

---

## 🎨 Visual Hierarchy Principles

### Size = Importance

**Principle:** The most important thing should be the biggest.

**Implementation:**
1. Hero H1: Biggest (--text-3xl)
2. Section H2: Large (--text-2xl)
3. Subsection H3: Medium (--text-xl)
4. Card titles: Adaptive (--text-lg or --text-base)
5. Body text: Standard (--text-sm)
6. Metadata: Smallest (--text-xs)

### Weight = Permanence

**Principle:** Bold for permanent/important, regular for descriptive.

- **Bold:** Headings, labels, CTAs
- **Regular:** Body text, descriptions, explanations

### Opacity = Hierarchy

**Principle:** Less important = lower opacity.

- **100%** - Primary headings, CTAs
- **70%** - Secondary text, descriptions
- **60%** - Tertiary text, metadata
- **40%** - Disabled states, subtle labels

---

## 🚫 Anti-Patterns to Avoid

### Color Anti-Patterns

❌ **Multiple red CTAs in same view**
```tsx
<Button variant="brand">Action 1</Button>
<Button variant="brand">Action 2</Button>
```

❌ **Accent colors as backgrounds**
```tsx
<div className="bg-purple-500"> {/* Never! */}
```

❌ **More than 3 button variants in same section**
```tsx
<Button variant="brand">...</Button>
<Button variant="primary">...</Button>
<Button variant="secondary">...</Button>
<Button variant="ghost">...</Button> {/* Too many choices! */}
```

### Typography Anti-Patterns

❌ **Skipping hierarchy levels**
```tsx
<h1>Main Heading</h1>
<h4>Next Heading</h4> {/* Where's H2 and H3? */}
```

❌ **Multiple --text-3xl on same page**
```tsx
<h1 className="text-[var(--text-3xl)]">Hero</h1>
<h2 className="text-[var(--text-3xl)]">Section</h2> {/* Too big! */}
```

### Layout Anti-Patterns

❌ **Inconsistent max-widths**
```tsx
<div className="max-w-[900px]">...</div>
<div className="max-w-[1100px]">...</div>
```

❌ **No spacing between sections**
```tsx
<section className="py-4">...</section> {/* Too cramped! */}
```

❌ **Mixing border radius within component**
```tsx
<div className="rounded-[10px]">
  <Button className="rounded-full">...</Button> {/* Inconsistent! */}
</div>
```

---

## 🎯 Decision-Making Framework

### When Choosing Colors

1. **Is this a CTA?** → Consider brand red (if no others present)
2. **Is this content?** → Use black/white/warm
3. **Is this a shadow?** → Use accent at 6-8% opacity
4. **Is this decorative?** → Reconsider if you need it

### When Choosing Typography

1. **What's the content hierarchy?** → Use appropriate scale level
2. **How many items in the grid?** → 2-3 use --text-lg, 4+ use --text-base
3. **Is this the hero?** → Only then use --text-3xl
4. **Is this metadata?** → Use --text-xs with opacity

### When Choosing Spacing

1. **Is this a section?** → py-20 (desktop), py-16 (mobile)
2. **Is this a grid?** → gap-6 or gap-8
3. **Is this a card?** → p-8 (large), p-6 (small)
4. **Is this content width?** → max-w-[1000px]

### When Choosing Components

1. **What's the action priority?** → Determines button variant
2. **How many CTAs?** → Maximum 2 per section
3. **What's the background?** → Dark = ghost option, Light = secondary option
4. **Is this a conversion point?** → Brand button (if none present)

---

## 📚 Design System Maintenance Philosophy

### Living Documentation

**Principle:** This design system evolves, but core principles remain constant.

**When to Add:**
- New component serves unique purpose
- Pattern appears 3+ times
- Improves consistency or efficiency

**When NOT to Add:**
- One-off solution
- Duplicates existing component
- Violates core principles

### Version Control

Track changes with semantic versioning:
- **Major (1.0 → 2.0)** - Breaking changes to core principles
- **Minor (1.0 → 1.1)** - New components/patterns
- **Patch (1.0.0 → 1.0.1)** - Documentation updates, bug fixes

---

## ✅ Design Principles Checklist

Before finalizing any design:

- [ ] **Color hierarchy** follows 92-5-3 rule
- [ ] **Single red CTA** per section (max)
- [ ] **Typography hierarchy** is logical (no skipped levels)
- [ ] **Spacing is generous** and consistent
- [ ] **Border radius** is consistent within components
- [ ] **Max content width** is enforced (1000px)
- [ ] **Backgrounds alternate** for visual rhythm
- [ ] **Shadows are minimal** and purposeful
- [ ] **Animations are smooth** (600ms, cubic-bezier easing)
- [ ] **Mobile-first** responsive behavior defined
- [ ] **Accessibility** contrast ratios met
- [ ] **Content guidelines** followed (word counts)

---

## 🔗 Related Documentation

- [Design Tokens](./DESIGN_TOKENS.md) - The foundational values
- [Component Library](./COMPONENT_LIBRARY.md) - Principles in practice
- [Pattern Library](./PATTERN_LIBRARY.md) - Complex implementations

---

## 💡 Final Philosophy

**"Restrained, not restricted. Systematic, not rigid. Premium, not pretentious."**

This design system embraces minimalism not as a constraint, but as a superpower. By limiting our palette to black, white, and warm tones—and reserving red for only the most important moments—we create interfaces where every element has purpose, every CTA demands attention, and every design decision is intentional.

The rules exist not to stifle creativity, but to channel it toward better user experiences.

---

**End of Design Principles Reference**
