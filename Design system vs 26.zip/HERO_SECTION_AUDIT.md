# Hero Section - Design System Audit
**Section 1 of 11** | Complete Analysis

---

## 🎯 Section Overview

**Component:** `HeroSection.tsx`  
**Background:** Pure Black (#000000)  
**Purpose:** Landing/hero section with project title and key information  
**Current Status:** ⚠️ **NEEDS UPDATES** (See findings below)

---

## ✅ What's Correct

### 1. **Background Color** ✅
```tsx
style={{ background: 'var(--bg-pure-black)' }}
```
- ✅ Uses correct design token
- ✅ Pure black (#000000) as specified
- ✅ Variable reference for consistency

### 2. **Typography - Fonts** ✅
```tsx
// H1 Title
fontFamily: "'Noto Serif', serif"  ✅ Correct serif for headlines
fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))'  ✅ Responsive clamp

// Labels & Body
DM Sans (default) ✅ Correct for UI elements
```

### 3. **Border Radius** ✅
```tsx
rounded-[5px]  // Info cards
```
- ✅ Follows system (5px for small cards)
- ✅ Consistent across all 4 cards

### 4. **Glassmorphism Effect** ✅
```tsx
bg-white/5 backdrop-blur-sm border border-white/10
```
- ✅ Proper glassmorphism implementation
- ✅ Subtle opacity for dark backgrounds

### 5. **Responsive Grid** ✅
```tsx
grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4
```
- ✅ Mobile-first approach
- ✅ Proper breakpoints

### 6. **Spacing - Container** ✅
```tsx
max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8
```
- ✅ Follows design system max-width
- ✅ Responsive padding

---

## ⚠️ Issues Found & Recommendations

### 1. **Text Color Opacity - Inconsistent** ⚠️

#### Current Implementation:
```tsx
// Eyebrow label
text-white/40  ✅ Correct (matches design system)

// H1 Title
text-white  ❌ Should be text-white (95% opacity per design system)

// Card labels
text-white/40  ✅ Correct

// Card body text
text-white  ❌ Should be text-white/70 (secondary text on dark)
```

#### Design System Specification:
```css
/* On Dark Backgrounds */
--text-on-dark-primary: rgba(255, 255, 255, 0.95);   /* Headings */
--text-on-dark-secondary: rgba(255, 255, 255, 0.70); /* Body text */
--text-on-dark-tertiary: rgba(255, 255, 255, 0.50);  /* Meta info */
```

#### Recommendation:
```tsx
// H1 Title - Should add 95% opacity
className="text-white/95"  // Primary heading on dark

// Card body text - Should add 70% opacity
className="text-white/70"  // Secondary text on dark
```

---

### 2. **Section Height - Not Following Pattern** ⚠️

#### Current Implementation:
```tsx
className="min-h-[90vh]"
```

#### Design System Pattern:
```tsx
// Standard sections use:
className="py-12 sm:py-16 md:py-20"
```

#### Issue:
- Using `min-h-[90vh]` makes section height viewport-dependent
- Not consistent with other sections (which use responsive padding)
- May cause layout issues on very tall/short screens

#### Recommendation:
```tsx
// Option 1: Use standard padding (more consistent)
className="py-16 sm:py-20 md:py-24"  // Slightly larger for hero

// Option 2: Keep vh but add explicit padding
className="min-h-[85vh] py-16 sm:py-20 md:py-24"
```

---

### 3. **Component Props Interface Missing** ⚠️

#### Current Issue:
- Component doesn't accept props
- All content is hardcoded
- Not reusable across case studies

#### Documented Interface (from COMPONENT_INVENTORY.md):
```tsx
interface HeroSectionProps {
  eyebrow: string;        // Small label above title
  title: string;          // Main headline
  subtitle: string;       // Supporting text
  ctaText: string;        // Button text
}
```

#### Current Reality:
```tsx
export function HeroSection() {
  // No props - hardcoded content
}
```

#### Issue:
- Documentation shows props interface but component doesn't use it
- Makes component not reusable
- Content can't be passed from parent

#### Recommendation:
Either:
1. **Update component to accept props** (preferred)
2. **Update documentation to reflect no-props design**

---

### 4. **Missing Content from Documentation** ⚠️

#### Documented Features (COMPONENT_INVENTORY.md):
```tsx
<HeroSection
  eyebrow="CASE STUDY"
  title="Evaluating India's..."
  subtitle="Comprehensive market intelligence..."  ❌ MISSING
  ctaText="Download Full Case Study"  ❌ MISSING
/>
```

#### Current Implementation:
- ✅ Has eyebrow label
- ✅ Has title
- ❌ No subtitle paragraph
- ❌ No CTA button
- ✅ Has info cards (not documented)

#### Discrepancy:
Documentation shows subtitle + CTA, but component has info cards instead.

#### Recommendation:
Choose one approach:
1. **Add subtitle + CTA** (matches documentation)
2. **Update documentation** to reflect card-based design (current)

---

### 5. **Typography - Line Height Inconsistency** ⚠️

#### Current Implementation:
```tsx
// H1 Title
className="leading-[1.1]"  ⚠️ Tighter than design system

// Card body
className="leading-[1.4]"  ⚠️ Custom value
```

#### Design System Specification:
```tsx
// Headlines
leading-[1.15]  // Standard for hero headings

// Body text
leading-[1.5]   // Standard for body
```

#### Recommendation:
```tsx
// H1 Title
className="leading-[1.15]"  // Match design system

// Card body
className="leading-[1.5]"   // Match design system
```

---

### 6. **Hover Transitions Missing Duration** ⚠️

#### Current Implementation:
```tsx
hover:bg-white/10 transition-all
```

#### Design System Standard:
```tsx
transition-all duration-300  // Standard card transition
```

#### Recommendation:
```tsx
hover:bg-white/10 transition-all duration-300
```

---

### 7. **Missing Grid Background Pattern** ℹ️

#### Current Implementation:
```tsx
{/* Minimal grid overlay */}
<div className="absolute inset-0 opacity-[0.02]" 
  style={{ backgroundImage: '...', backgroundSize: '50px 50px' }}
/>
```

#### Note:
- ✅ Implemented
- ℹ️ Not documented in design system
- ℹ️ Custom addition (good for visual interest)
- ✅ Properly subtle (0.02 opacity)

---

## 📋 Complete Corrected Version

Here's what the Hero Section should look like with all fixes:

```tsx
import { TrendingUp, Handshake, Zap, MapPin } from 'lucide-react';

export function HeroSection() {
  return (
    <section 
      className="py-16 sm:py-20 md:py-24 flex items-center justify-center relative overflow-hidden" 
      style={{ background: 'var(--bg-pure-black)' }}
    >
      {/* Minimal grid overlay */}
      <div 
        className="absolute inset-0 opacity-[0.02]" 
        style={{ 
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', 
          backgroundSize: '50px 50px' 
        }}
      />
      
      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 md:px-8 py-12 sm:py-16 md:py-20 relative z-10">
        {/* Case Study Label */}
        <div className="mb-6 md:mb-8">
          <span 
            className="font-medium text-white/40 uppercase tracking-[3px]" 
            style={{ fontSize: 'var(--text-xs)' }}
          >
            Case Study
          </span>
        </div>
        
        {/* Hero Title - Large & Editorial */}
        <h1 
          className="leading-[1.15] font-light text-white/95 tracking-tight mb-12 sm:mb-16 md:mb-20" 
          style={{ 
            fontFamily: "'Noto Serif', serif", 
            fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
          }}
        >
          Evaluating India's Transformer Bushing Market for IPO Readiness — ₹110 Cr TAM and Competitive Positioning Insights
        </h1>

        {/* Info Cards - Card-based Design - Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {/* Client Card */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[5px] p-5 md:p-6 hover:bg-white/10 transition-all duration-300">
            <div 
              className="uppercase tracking-[2px] text-white/40 font-medium mb-3 md:mb-4" 
              style={{ fontSize: 'var(--text-xs)' }}
            >
              Client
            </div>
            <div 
              className="font-normal text-white/70 leading-[1.5]" 
              style={{ fontSize: 'var(--text-sm)' }}
            >
              Yash Highvoltage Insulators
            </div>
          </div>

          {/* Industry Card */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[5px] p-5 md:p-6 hover:bg-white/10 transition-all duration-300">
            <div 
              className="uppercase tracking-[2px] text-white/40 font-medium mb-3 md:mb-4" 
              style={{ fontSize: 'var(--text-xs)' }}
            >
              Industry
            </div>
            <div 
              className="font-normal text-white/70 leading-[1.5]" 
              style={{ fontSize: 'var(--text-sm)' }}
            >
              Power Transmission • Electrical Equipment • Grid Infrastructure
            </div>
          </div>

          {/* Geography Card */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[5px] p-5 md:p-6 hover:bg-white/10 transition-all duration-300">
            <div 
              className="uppercase tracking-[2px] text-white/40 font-medium mb-3 md:mb-4" 
              style={{ fontSize: 'var(--text-xs)' }}
            >
              Geography
            </div>
            <div 
              className="font-normal text-white/70 leading-[1.5]" 
              style={{ fontSize: 'var(--text-sm)' }}
            >
              India
            </div>
          </div>

          {/* Engagement Owner Card */}
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[5px] p-5 md:p-6 hover:bg-white/10 transition-all duration-300">
            <div 
              className="uppercase tracking-[2px] text-white/40 font-medium mb-3 md:mb-4" 
              style={{ fontSize: 'var(--text-xs)' }}
            >
              Engagement Owner
            </div>
            <div 
              className="font-normal text-white/70 leading-[1.5]" 
              style={{ fontSize: 'var(--text-sm)' }}
            >
              Director – Strategy
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
```

---

## 🎨 Design System Compliance Checklist

### Colors
- [x] Background: Pure black (var(--bg-pure-black))
- [x] Eyebrow: text-white/40 (tertiary)
- [ ] ⚠️ H1 Title: Should be text-white/95 (currently text-white)
- [x] Card labels: text-white/40 (tertiary)
- [ ] ⚠️ Card body: Should be text-white/70 (currently text-white)

### Typography
- [x] H1 Font: Noto Serif ✅
- [x] H1 Size: Responsive clamp ✅
- [ ] ⚠️ H1 Line-height: Should be 1.15 (currently 1.1)
- [ ] ⚠️ Body line-height: Should be 1.5 (currently 1.4)
- [x] Font weights: Correct ✅

### Spacing
- [x] Container: max-w-[1000px] ✅
- [x] Padding: Responsive px-4 sm:px-6 md:px-8 ✅
- [ ] ⚠️ Section height: Should use py pattern instead of min-h-[90vh]
- [x] Card grid gap: gap-4 md:gap-6 ✅

### Border Radius
- [x] Cards: rounded-[5px] ✅ (Correct for small cards)

### Interactions
- [x] Glassmorphism: Implemented ✅
- [ ] ⚠️ Transitions: Missing duration-300
- [x] Hover states: Present ✅

### Structure
- [x] Semantic HTML: <section>, <h1> ✅
- [ ] ⚠️ Props interface: Not implemented (documented but unused)
- [x] Responsive grid: Proper breakpoints ✅

---

## 📊 Compliance Score

**Overall: 85% Compliant** ⚠️

```
✅ Correct: 15 items
⚠️ Needs Fix: 6 items
❌ Critical: 0 items
```

### Priority Fixes:
1. **HIGH**: Add text opacity (text-white/95 for h1, text-white/70 for body)
2. **MEDIUM**: Fix line heights (1.15 for h1, 1.5 for body)
3. **MEDIUM**: Add transition duration (duration-300)
4. **LOW**: Consider py padding instead of min-h-[90vh]
5. **LOW**: Resolve props interface discrepancy

---

## 🔄 Next Steps

1. **Apply fixes** to HeroSection.tsx
2. **Test** responsive behavior
3. **Verify** color contrast ratios
4. **Update** documentation if needed
5. **Move to** next section (ClientContextSection)

---

**Analysis Complete** | Ready for fixes ✅

