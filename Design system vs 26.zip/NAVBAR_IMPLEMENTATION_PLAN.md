# 🚀 NAVBAR IMPLEMENTATION PLAN

## 📋 Executive Summary

After comprehensive analysis of Figma designs vs current implementation, we found:
- **50%** perfectly matched
- **30%** close but needs precision fixes  
- **20%** needs structural changes

**Main Issues:**
1. Navigation uses center-transform instead of Figma's inset box model
2. Several elements off by 0.16px - 1.71px
3. Responsive positioning where exact pixels needed

---

## 🎯 IMPLEMENTATION PHASES

---

### **PHASE 1: Fix Critical Desktop Positioning (State 1)**

**Objective:** Match Figma's State 1 (at hero) pixel-perfectly

**Priority:** 🔴 CRITICAL  
**Effort:** ⚡ Medium (2-3 hours)  
**Impact:** 🎨 Immediately visible improvements

#### **1.1 Navigation Options - Use Inset Box Model**

**Current Code:**
```tsx
// State 1: At Hero
<div className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 gap-4 lg:gap-6 items-center justify-center hidden lg:flex">
  <Services />
  <Industries />
  <Resources />
  <Search width={93} />
</div>
```

**Fix To:**
```tsx
// State 1: At Hero - Use exact Figma inset
<div className="absolute flex gap-[24px] inset-[21.82%_32.67%_19.85%_32.74%] items-center justify-center hidden lg:flex">
  <Services />
  <Industries />
  <Resources />
  <Search width={93} />
</div>
```

**Changes:**
- ❌ Remove: `left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2`
- ✅ Add: `inset-[21.82%_32.67%_19.85%_32.74%]`
- ✅ Change: `gap-4 lg:gap-6` → `gap-[24px]`

---

#### **1.2 Secondary Menu Right Side - Precise Position**

**Current Code:**
```tsx
<div className="absolute right-6 md:right-8 lg:right-12 top-1/2 -translate-y-1/2 flex gap-3 items-center">
```

**Fix To:**
```tsx
<div className="absolute right-6 md:right-8 lg:right-[49.71px] flex gap-3 items-center" style={{ top: 'calc(50% + 0.1px)', transform: 'translateY(-50%)' }}>
```

**Changes:**
- ✅ Change: `lg:right-12` → `lg:right-[49.71px]` (+1.71px precision)
- ✅ Change: `gap-3` → `gap-[12px]` (exact)
- ✅ Add: Inline style for `calc(50% + 0.1px)` precision

---

#### **1.3 Logo Container - Exact Desktop Position**

**Current Code:**
```tsx
<div className={`absolute bottom-[33.33%] top-[33.33%] flex gap-[6px] items-center z-10 transition-all duration-300 ${
  isHeroVisible 
    ? 'left-6 sm:left-8 md:left-10 lg:left-12' 
    : 'left-6 sm:left-8 md:left-12 lg:left-[76px]'
}`}>
```

**Fix To:**
```tsx
<div className={`absolute bottom-[33.33%] top-[33.33%] flex gap-[6px] items-center z-10 transition-all duration-300 ${
  isHeroVisible 
    ? 'left-4 sm:left-6 md:left-8 lg:left-[48px]' 
    : 'left-4 sm:left-6 md:left-8 lg:left-[76px]'
}`}>
```

**Changes:**
- ✅ Change: `lg:left-12` → `lg:left-[48px]` (explicit exact value)
- ✅ Adjust mobile/tablet to start smaller (left-4, left-6, left-8)

---

#### **1.4 Schedule Demo Button - Precise Position**

**Current Code:**
```tsx
<div className={`absolute top-1/2 -translate-y-1/2 flex items-center gap-3 ${
  isHeroVisible 
    ? 'bottom-[21%] right-6 sm:right-8 md:right-10 lg:right-12'
    : '...'
}`}>
```

**Fix To:**
```tsx
<div className={`absolute flex items-center gap-3 ${
  isHeroVisible 
    ? 'bottom-[21%] top-[21%] right-6 sm:right-8 md:right-10 lg:right-[47.84px]'
    : '...'
}`}>
```

**Changes:**
- ✅ Change: `lg:right-12` → `lg:right-[47.84px]` (+0.16px precision)
- ✅ Add: Explicit `top-[21%]` to match Figma
- ❌ Remove: `top-1/2 -translate-y-1/2` (use top/bottom instead)

---

#### **1.5 Secondary Menu Left Side - Precise Centering**

**Current Code:**
```tsx
<div className="absolute left-6 md:left-8 lg:left-10 top-1/2 -translate-y-1/2 flex gap-2 items-center max-w-[50%]">
```

**Fix To:**
```tsx
<div className="absolute left-6 md:left-8 lg:left-[40px] flex gap-[8px] items-center max-w-[50%]" style={{ top: 'calc(50% + 0.1px)', transform: 'translateY(-50%)' }}>
```

**Changes:**
- ✅ Change: `lg:left-10` → `lg:left-[40px]` (explicit)
- ✅ Change: `gap-2` → `gap-[8px]` (exact)
- ✅ Add: Inline style for 0.1px precision

---

**Phase 1 Testing Checklist:**
- [ ] Navigation centered correctly at 1200px viewport
- [ ] Secondary menu items aligned exactly
- [ ] Logo at precise 48px from left
- [ ] Schedule Demo button at 47.84px from right
- [ ] All gaps match Figma (8px, 12px, 24px)
- [ ] Vertical centering with 0.1px offset

**Expected Outcome:**
Perfect pixel-match with Figma State 1 at desktop breakpoint (1024px+)

---

---

### **PHASE 2: Fix Desktop Positioning (State 2)**

**Objective:** Verify and fix State 2 (scrolled) positioning

**Priority:** 🟡 IMPORTANT  
**Effort:** ⚡ Low (1 hour)  
**Impact:** 🎨 Ensures consistency

#### **2.1 Hamburger Menu - Exact Position**

**Current Code:**
```tsx
{!isHeroVisible && (
  <button 
    onClick={() => setShowMobileMenu(!showMobileMenu)}
    className="hidden lg:flex items-center justify-center px-[6px] py-[8px] rounded-[3px] border border-black/10 hover:bg-black/5 transition-colors bg-white"
  >
```

**Fix To:**
```tsx
{!isHeroVisible && (
  <button 
    onClick={() => setShowMobileMenu(!showMobileMenu)}
    className="absolute bottom-[28.33%] top-[28.33%] left-4 sm:left-6 md:left-8 lg:left-[40px] hidden lg:flex items-center justify-center px-[6px] py-[8px] rounded-[3px] border border-black/10 hover:bg-black/5 transition-colors bg-white"
  >
```

**Changes:**
- ✅ Add: Explicit positioning (currently relies on parent flex)
- ✅ Add: `lg:left-[40px]` exact value
- ✅ Add: `bottom-[28.33%] top-[28.33%]` vertical positioning

---

#### **2.2 Verify State 2 Navigation Position**

**Current Code (already correct):**
```tsx
// State 2: After Scroll
<div className="absolute bottom-[20.83%] right-[139.73px] top-[20.83%] gap-4 lg:gap-6 items-center justify-center hidden lg:flex">
```

**Verify:**
- ✅ `right-[139.73px]` matches Figma
- ✅ `bottom-[20.83%] top-[20.83%]` matches Figma
- ⚠️ Change: `gap-4 lg:gap-6` → `gap-[24px]` for consistency

---

**Phase 2 Testing Checklist:**
- [ ] Hamburger appears at left-[40px] when scrolled
- [ ] Navigation stays at right-[139.73px]
- [ ] Login at right-[47.71px]
- [ ] All vertical positioning uses top/bottom percentages
- [ ] Smooth transition between states

**Expected Outcome:**
Perfect pixel-match with Figma State 2 at desktop breakpoint

---

---

### **PHASE 3: Responsive Optimization**

**Objective:** Ensure responsive behavior doesn't break exact positioning

**Priority:** 🟢 POLISH  
**Effort:** ⚡ Medium (2 hours)  
**Impact:** 🎨 Professional responsive behavior

#### **3.1 Define Desktop Breakpoint Strategy**

**Current Issue:**
Using `lg` (1024px) for desktop, but Figma is designed for 1200px

**Options:**

**Option A: Keep lg (1024px) but use exact values**
```tsx
className="left-4 sm:left-6 md:left-8 lg:left-[48px]"
// Desktop starts at 1024px with exact positioning
```

**Option B: Create custom breakpoint at 1200px**
```tsx
// In tailwind.config.js
screens: {
  'desktop': '1200px',
}

// Usage:
className="left-4 sm:left-6 md:left-8 lg:left-10 desktop:left-[48px]"
```

**Option C: Use 2xl (1536px) for exact Figma match**
```tsx
className="left-4 sm:left-6 md:left-8 lg:left-10 xl:left-12 2xl:left-[48px]"
// Exact positioning only on very large screens
```

**Recommended:** **Option A** - Use exact values at lg (1024px)
- Rationale: 1024px is standard "desktop" breakpoint
- Navigation has enough space at 1024px for Figma layout
- Simpler code, no config changes needed

---

#### **3.2 Mobile/Tablet Positioning Strategy**

**Define responsive scaling:**
```tsx
// Logo example:
left-4       // 16px mobile (< 640px)
sm:left-6    // 24px small tablet (640px+)
md:left-8    // 32px tablet (768px+)
lg:left-[48px] // 48px desktop (1024px+) EXACT

// Rationale:
// - Mobile: Smaller padding for compact layout
// - Tablet: Medium padding for balanced layout  
// - Desktop: Exact Figma positioning
```

---

#### **3.3 Handle Edge Cases**

**Between 1024px - 1200px:**
- Test navigation doesn't overflow
- Verify all elements have space
- Check search bar fits (93px/175px)

**At exactly 1200px:**
- Should match Figma perfectly
- Use browser DevTools to measure

**Above 1200px (up to max-w-[1200px]):**
- Elements stay at exact positions
- Extra space on sides (centered container)

---

**Phase 3 Testing Checklist:**
- [ ] Test at 1024px (minimum desktop)
- [ ] Test at 1200px (Figma design width)
- [ ] Test at 1440px (common laptop)
- [ ] Test at 1920px (full HD)
- [ ] Verify mobile/tablet don't show desktop layout
- [ ] Check transitions don't cause layout shifts

**Expected Outcome:**
Navbar looks perfect from mobile to ultra-wide, with exact Figma match at desktop

---

---

### **PHASE 4: Polish & Validation**

**Objective:** Final testing and sub-pixel perfection

**Priority:** 🟢 POLISH  
**Effort:** ⚡ Low (1 hour)  
**Impact:** 🎨 Production-ready quality

#### **4.1 Browser DevTools Measurement**

**Process:**
1. Open Chrome DevTools
2. Set viewport to exactly 1200px width
3. Use "Inspect" to measure each element
4. Compare measurements to Figma values
5. Adjust any discrepancies

**Measurements to verify:**
```
State 1:
├─ Secondary left edge: 40px from container left
├─ Secondary right edge: 49.71px from container right
├─ Logo left edge: 48px from container left
├─ Navigation: Check inset creates correct box
├─ Schedule Demo right edge: 47.84px from container right
└─ All gaps: 8px, 12px, 24px

State 2:
├─ Hamburger left edge: 40px from container left
├─ Logo left edge: 76px from container left
├─ Navigation right edge: 139.73px from container right
└─ Login right edge: 47.71px from container right
```

---

#### **4.2 Transition Smoothness**

**Test scenarios:**
1. Scroll from top (hero visible)
2. Watch navbar transition
3. Verify:
   - Logo slides smoothly (48px → 76px)
   - Secondary bar fades out
   - Resources disappears
   - Search expands (93px → 175px)
   - Schedule Demo fades out
   - Hamburger fades in
   - Login moves and changes color

**Check for:**
- No layout jumps
- Smooth 300ms transitions
- No flickering
- Z-index issues (overlapping)

---

#### **4.3 Cross-Browser Testing**

**Test in:**
- ✅ Chrome (primary development)
- ✅ Firefox (different rendering engine)
- ✅ Safari (WebKit, macOS specific)
- ✅ Edge (Chromium-based)

**Check:**
- Sub-pixel rendering differences
- Font rendering (DM Sans)
- Backdrop-blur support
- CSS calc() support

---

#### **4.4 Accessibility Audit**

**Verify:**
- [ ] ARIA labels on buttons
- [ ] Keyboard navigation works
- [ ] Focus states visible
- [ ] Color contrast meets WCAG AA
- [ ] Touch targets ≥ 40×40px on mobile
- [ ] Screen reader compatibility

---

**Phase 4 Testing Checklist:**
- [ ] All measurements match Figma exactly
- [ ] Transitions are smooth and bug-free
- [ ] Works in all major browsers
- [ ] Passes accessibility audit
- [ ] No console errors or warnings
- [ ] Performance is good (no jank)

**Expected Outcome:**
Production-ready navbar matching Figma exactly with excellent UX

---

---

## 📅 TIMELINE ESTIMATE

| Phase | Tasks | Effort | Duration |
|-------|-------|--------|----------|
| **Phase 1** | Critical desktop fixes | Medium | 2-3 hours |
| **Phase 2** | State 2 verification | Low | 1 hour |
| **Phase 3** | Responsive optimization | Medium | 2 hours |
| **Phase 4** | Polish & validation | Low | 1 hour |
| **TOTAL** | | | **6-7 hours** |

**Recommendation:** 
- Do Phase 1 and 2 together (3-4 hours)
- Test thoroughly
- Then Phase 3 and 4 (3 hours)

---

---

## 🎯 SUCCESS CRITERIA

**Must Have (Required):**
- ✅ Navigation uses inset box model in State 1
- ✅ All desktop positions match Figma exactly (±0.5px tolerance)
- ✅ State 1 and State 2 both pixel-perfect at 1200px
- ✅ Smooth transitions between states
- ✅ Responsive behavior works on mobile/tablet

**Should Have (Important):**
- ✅ Sub-pixel precision (0.1px offsets)
- ✅ Works in all major browsers
- ✅ No console errors
- ✅ Passes accessibility audit

**Nice to Have (Polish):**
- ✅ Optimized performance (60fps transitions)
- ✅ Custom animations
- ✅ Advanced hover states

---

---

## 🚦 IMPLEMENTATION ORDER

### **Immediate (Do First):**
```
✅ Phase 1.1 - Navigation inset positioning
✅ Phase 1.2 - Secondary menu right position
✅ Phase 1.3 - Logo exact positioning
```
These have the biggest visual impact.

### **Next:**
```
✅ Phase 1.4 - Schedule Demo position
✅ Phase 1.5 - Secondary menu left precision
✅ Phase 2.1 - Hamburger positioning
✅ Phase 2.2 - Verify State 2
```
These complete the pixel-perfect desktop layout.

### **Then:**
```
✅ Phase 3 - Responsive optimization
```
Ensure it works at all screen sizes.

### **Finally:**
```
✅ Phase 4 - Polish & validation
```
Make it production-ready.

---

---

## 📝 CODE CHANGES SUMMARY

**Files to Modify:**
- `/src/app/components/Navbar.tsx` (main file)

**Approximate Lines Changed:**
- ~50-60 lines (positioning classes)
- ~5-10 lines (inline styles for calc)
- Total: ~60-70 lines out of ~400 (15% of file)

**Risk Level:** 🟢 LOW
- Changes are mostly CSS positioning
- Logic stays the same
- Easy to test and verify
- Can rollback easily if needed

---

---

## ✅ READY TO IMPLEMENT?

I'm ready to start with **Phase 1** immediately. 

**Shall I proceed with:**
1. ✅ **Phase 1 (All 5 fixes)** - Complete critical desktop positioning
2. ⏸️ Wait for your approval before Phase 2
3. 🔄 Or would you like me to do all phases at once?

**Let me know which approach you prefer!** 🚀
