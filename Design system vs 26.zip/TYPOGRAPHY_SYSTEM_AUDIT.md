# 📐 TYPOGRAPHY SYSTEM - COMPLETE AUDIT

## 🎨 **Design System Font Scale**

### **Current Typography Scale - Major Third (1.25 ratio)**

From `/src/styles/theme.css`:

| CSS Variable | Rem Value | Pixel Value | Usage Context |
|--------------|-----------|-------------|---------------|
| `--text-xs` | 0.8rem | **12.8px** | Labels, metadata, categories |
| `--text-sm` | 1rem | **16px** | Body text, descriptions |
| `--text-base` | 1.25rem | **20px** | Large body text |
| `--text-lg` | 1.563rem | **25px** | Subsection headings |
| `--text-xl` | 1.953rem | **31.25px** | Section headings |
| `--text-2xl` | 2.441rem | **39px** | Major section titles |
| `--text-3xl` | 3.052rem | **48.8px** | Hero headings |

**❌ MISSING:** `--text-4xl` is referenced but not defined!

---

## 📊 **Actual Font Sizes Used in Components**

### **HERO SECTION** (`HeroSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Case Study Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Hero Title | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Meta Labels (Client, Industry, etc.) | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Meta Values | `var(--text-sm)` | 16px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **CLIENT CONTEXT SECTION** (`ClientContextSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Field Labels | `9.5px` | None | ❌ **HARDCODED** |
| Company Name | `17px` | None | ❌ **HARDCODED** |
| Industry Text | `13px` | None | ❌ **HARDCODED** |
| Company Overview | `clamp(19px, 2.8vw, 24px)` | None | ❌ **HARDCODED** |
| Market Context Body | `var(--text-sm)` | 16px | ✅ Using variable |
| Capabilities Heading | `20px` | None | ❌ **HARDCODED** |
| List Items | `var(--text-sm)` | 16px | ✅ Using variable |
| List Numbers | `13px` | None | ❌ **HARDCODED** |
| Strategic Challenge | `var(--text-sm)` | 16px | ✅ Using variable |
| CTA Labels | `var(--text-xs)` | 12.8px | ✅ Using variable |

**Status:** ⚠️ **MIXED** - Many hardcoded pixel values (9.5px, 13px, 17px, 20px, 24px)

---

### **CHALLENGES SECTION** (`ChallengesSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Scroll Hint | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Card Numbers | `var(--text-3xl)` or `var(--text-4xl)` | 48.8px | ⚠️ **text-4xl not defined!** |
| Card Index | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Card Title | `var(--text-base)` or `var(--text-lg)` | 20px or 25px | ✅ Using variable |
| Questions | `0.875rem` or `var(--text-sm)` | 14px or 16px | ⚠️ **HARDCODED 0.875rem** |

**Status:** ⚠️ **MOSTLY GOOD** - But using undefined `text-4xl` and hardcoded 0.875rem

---

### **ENGAGEMENT OBJECTIVES SECTION** (`EngagementObjectivesSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Section Description | `var(--text-sm)` | 16px | ✅ Using variable |
| Objective Badge | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Objective Title | `var(--text-xl)` | 31.25px | ✅ Using variable |
| Objective Description | `var(--text-sm)` | 16px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **METHODOLOGY SECTION** (`MethodologySection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Section Description | `var(--text-sm)` | 16px | ✅ Using variable |
| Timeline Node Number | `var(--text-base)` | 20px | ✅ Using variable |
| Step Badge | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Step Title | `var(--text-xl)` | 31.25px | ✅ Using variable |
| Step Description | `var(--text-sm)` | 16px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **IMPACT SECTION** (`ImpactSection.tsx`)

All three variants share similar structure:

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| **Metric Values** | `clamp(1.75rem, 5vw, 2.5rem)` | 28px - 40px | ❌ **HARDCODED 2.5rem (40px)** |
| Metric Labels | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Metric Descriptions | `var(--text-sm)` | 16px | ✅ Using variable |
| Card Numbers | `var(--text-sm)` | 16px | ✅ Using variable |
| Card Titles | `var(--text-base)` | 20px | ✅ Using variable |

**Status:** ⚠️ **MOSTLY GOOD** - Metric values hardcoded to `2.5rem` (40px) instead of using `--text-2xl` (39px)

---

### **TESTIMONIAL SECTION** (`TestimonialSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Testimonial Quote | `clamp(1rem, 2.5vw, var(--text-lg))` | 16px - 25px | ✅ Using variable |
| Attribution | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Rating | `var(--text-xs)` | 12.8px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **FINAL CTA SECTION** (`FinalCTASection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Description | `var(--text-base)` | 20px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **RESOURCES SECTION** (`ResourcesSection.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Section Label | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Section Heading | `clamp(1.75rem, 5vw, var(--text-3xl))` | 28px - 48.8px | ✅ Using variable |
| Description | `var(--text-sm)` | 16px | ✅ Using variable |
| Resource Category | `var(--text-xs)` | 12.8px | ✅ Using variable |
| Resource Date | `var(--text-xs)` | 12.8px | ✅ Using variable |

**Status:** ✅ **PERFECT** - All using design system variables

---

### **NAVBAR** (`Navbar.tsx`)

| Element | Font Size | CSS Variable | Actual Value |
|---------|-----------|--------------|--------------|
| Latest Reports Label | `text-[12px]` | None | ⚠️ **HARDCODED** (close to --text-xs 12.8px) |
| Report Title | `text-[12px]` | None | ⚠️ **HARDCODED** |
| Secondary Nav Links | `text-[12px]` | None | ⚠️ **HARDCODED** |
| Main Nav Links | `text-[14px]` | None | ⚠️ **HARDCODED** |
| Search Text | `text-[14px]` | None | ⚠️ **HARDCODED** |
| Mobile Menu Labels | `text-[11px]` | None | ⚠️ **HARDCODED** |
| Mobile Menu Links | `text-[14px]` | None | ⚠️ **HARDCODED** |

**Status:** ❌ **ALL HARDCODED** - Navbar uses exact Figma pixel values, not design system

---

---

## 🔍 **ISSUES FOUND**

### **❌ CRITICAL ISSUES**

1. **Missing CSS Variable**
   - `--text-4xl` is referenced in `ChallengesSection.tsx` but not defined in `theme.css`
   - Currently falls back to browser default

2. **Client Context Section Chaos**
   - Uses **7 different hardcoded font sizes**: 9.5px, 13px, 17px, 19px, 20px, 24px, and more
   - No consistency with design system
   - Makes maintenance difficult

3. **Navbar Completely Separate**
   - All font sizes hardcoded (12px, 14px, 11px)
   - Not using design system at all
   - This was intentional for Figma precision, but inconsistent with rest of site

---

### **⚠️ MINOR ISSUES**

4. **Impact Section Metrics**
   - Uses `2.5rem` (40px) instead of `var(--text-2xl)` (39px)
   - Only 1px difference, but should use variable

5. **Challenges Card Questions**
   - Uses `0.875rem` (14px) in some cases
   - Not part of the Major Third scale
   - Should use `var(--text-sm)` (16px) or create `--text-2xs` (14px)

---

---

## 📋 **COMPLETE FONT SIZE INVENTORY**

### **Font Sizes Currently in Use:**

| Pixel Size | Location(s) | Design System Variable | Status |
|------------|-------------|------------------------|---------|
| **9.5px** | Client Context labels | None | ❌ Hardcoded |
| **11px** | Navbar mobile menu labels | None | ❌ Hardcoded |
| **12px** | Navbar (all instances) | Could use `--text-xs` (12.8px) | ⚠️ Close but different |
| **12.8px** | Section labels, metadata | `--text-xs` | ✅ From variable |
| **13px** | Client Context text | None | ❌ Hardcoded |
| **14px** | Questions, navbar | Could use `--text-2xs` (not defined) | ❌ Not in scale |
| **16px** | Body text | `--text-sm` | ✅ From variable |
| **17px** | Company name | None | ❌ Hardcoded |
| **19px** | Company overview (min) | None | ❌ Hardcoded |
| **20px** | Large body, card titles | `--text-base` | ✅ From variable |
| **24px** | Company overview (max) | None | ❌ Hardcoded |
| **25px** | Subsection headings | `--text-lg` | ✅ From variable |
| **28px** | Heading clamp (min) | Used in clamp() | ⚠️ Not a variable |
| **31.25px** | Section headings | `--text-xl` | ✅ From variable |
| **39px** | Major titles | `--text-2xl` | ✅ From variable |
| **40px** | Metric values | Should use `--text-2xl` | ⚠️ Close but hardcoded |
| **48.8px** | Hero headings | `--text-3xl` | ✅ From variable |

---

---

## 💡 **RECOMMENDATIONS**

### **1. Add Missing Variables to theme.css**

```css
/* Add these to complete the scale */
--text-2xs: 0.875rem;   /* 14px - Small body text, tertiary labels */
--text-4xl: 3.815rem;   /* 61px - Extra large headings (if needed) */
--text-5xl: 4.768rem;   /* 76.3px - Massive hero text (if needed) */
```

---

### **2. Fix Client Context Section**

Replace all hardcoded values:
- `9.5px` → `var(--text-2xs)` (add 14px variable, or use 12.8px)
- `13px` → `var(--text-xs)` (12.8px) or `var(--text-2xs)` (14px)
- `17px` → `var(--text-sm)` (16px)
- `19-24px` → `var(--text-base)` (20px)
- `20px` → `var(--text-base)` (20px) ✓ already correct!

---

### **3. Fix Impact Section Metrics**

```tsx
// BEFORE:
fontSize: 'clamp(1.75rem, 5vw, 2.5rem)'  // 28px - 40px

// AFTER:
fontSize: 'clamp(var(--text-lg), 5vw, var(--text-2xl))'  // 25px - 39px
```

---

### **4. Fix Challenges Section**

```tsx
// BEFORE:
fontSize: cardCount >= 4 ? '0.875rem' : 'var(--text-sm)'

// AFTER (if you add --text-2xs):
fontSize: cardCount >= 4 ? 'var(--text-2xs)' : 'var(--text-sm)'

// OR (use existing variable):
fontSize: 'var(--text-sm)'  // Always 16px
```

---

### **5. Navbar - Keep or Update?**

**Option A:** Keep hardcoded for Figma precision
- Navbar has exact Figma values (12px, 14px)
- Don't change if visual precision matters

**Option B:** Align with design system
```tsx
// Change:
text-[12px] → use var(--text-xs) (12.8px)
text-[14px] → use var(--text-2xs) if added, or var(--text-sm) (16px)
text-[11px] → use var(--text-2xs) (14px) or var(--text-xs) (12.8px)
```

---

---

## 📊 **SUMMARY SCORECARD**

| Component | Variables Used | Hardcoded | Status |
|-----------|----------------|-----------|--------|
| Hero Section | 100% | 0% | ✅ Perfect |
| Client Context | 40% | 60% | ❌ Needs work |
| Challenges | 85% | 15% | ⚠️ Good |
| Engagement Objectives | 100% | 0% | ✅ Perfect |
| Methodology | 100% | 0% | ✅ Perfect |
| Impact | 90% | 10% | ⚠️ Nearly perfect |
| Testimonial | 100% | 0% | ✅ Perfect |
| Final CTA | 100% | 0% | ✅ Perfect |
| Resources | 100% | 0% | ✅ Perfect |
| Navbar | 0% | 100% | ⚠️ Intentional |

**Overall:** 72% using design system variables, 28% hardcoded

---

---

## 🎯 **PROPOSED NEW DESIGN SYSTEM**

Based on actual usage, here's a refined typography scale:

```css
:root {
  /* Typography Scale - Major Third (1.25 ratio) + Pragmatic Additions */
  
  --text-2xs: 0.75rem;    /* 12px - Micro labels (navbar, tags) */
  --text-xs: 0.875rem;    /* 14px - Small labels, metadata */
  --text-sm: 1rem;        /* 16px - Body text, descriptions */
  --text-base: 1.25rem;   /* 20px - Large body text */
  --text-lg: 1.563rem;    /* 25px - Subsection headings */
  --text-xl: 1.953rem;    /* 31.25px - Section headings */
  --text-2xl: 2.441rem;   /* 39px - Major section titles */
  --text-3xl: 3.052rem;   /* 48.8px - Hero headings */
  --text-4xl: 3.815rem;   /* 61px - Extra large (rarely used) */
  --text-5xl: 4.768rem;   /* 76.3px - Massive (rarely used) */
}
```

**Changes:**
- Shifted everything down by one step
- `--text-xs` now 14px (was 12.8px) - more practical
- `--text-2xs` new at 12px - for micro labels
- Added `--text-4xl` and `--text-5xl` for completeness

---

**Ready to implement font size corrections?** Let me know which sections you want to standardize first! 🎨