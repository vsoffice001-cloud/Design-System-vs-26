# FIGMA BUTTON ANALYSIS & DESIGN SYSTEM COMPARISON

## STEP 1: EXTRACT DESIGN TOKENS FROM FIGMA IMPORTS

### Component 1: MainCtaNav.tsx - "Schedule a Demo" (Red, No Icon)
**What it does:** Primary CTA button for scheduling demos

**Design Tokens:**
- **Background Color:** `#b01f24` (Ken Bold Red) ✅ MATCHES OUR SYSTEM
- **Gradient:** `from-[#b01f24] via-[#eb484e] to-[#b01f24]` 
  - Via point at 49.483%
  - Gradient extends beyond bounds (inset with negative value)
- **Text Color:** `#fcfcfc` (off-white) ≈ Our white
- **Font:** DM Sans Bold, 14px ✅ MATCHES OUR SYSTEM
- **Font Weight:** Bold (700)
- **Padding:** 16px horizontal × 9px vertical = Total height ~34px
- **Border Radius:** 5px ❌ SYSTEM USES 10px (medium)
- **Shadow:** `0px 0px 2px 0px rgba(176,31,36,0)` = Effectively no shadow
- **Icon:** None
- **Animation:** Has gradient background layer

---

### Component 2: ConnectNow.tsx - "Connect now" (Dark Gray/Black)
**What it does:** Secondary/ghost style CTA

**Design Tokens:**
- **Background:** Gradient `from-[#656565] to-[#989898]` (gray gradient)
- **Inner Gradient Layer:** `from-[#141016] via-[#656565] to-[#141016]` (dark core)
- **Text Color:** `white` ✅
- **Font:** DM Sans Bold, 12px
- **Font Weight:** Bold (700)
- **Padding:** 12px horizontal × 7.25-8px vertical = Total height ~27px
- **Border Radius:** 10px ✅ MATCHES OUR SYSTEM (medium)
- **Shadow:** `0px 1px 30px -5px rgba(128,108,224,0.2)` (purple glow - unusual!)
- **Icon:** None
- **Animation:** Dual gradient layers

---

### Component 3: ExploreCta.tsx - "Explore Consulting" (Text Link)
**What it does:** Text link with gradient text and animated arrow

**Design Tokens:**
- **Background:** None (transparent)
- **Text Gradient:** `from-[#b01f24] to-[#eb484e]` ✅ USES OUR BRAND RED
- **Text Color:** Gradient with `-webkit-text-fill-color: transparent`
- **Font:** DM Sans Regular (NOT Bold), 12px
- **Font Weight:** Normal (400)
- **Padding:** None (inline element)
- **Border Radius:** N/A
- **Shadow:** None
- **Icon:** Diagonal arrow (↗) - 12px × 12px
  - Arrow color: `#EB484E` (lighter red)
  - Has TWO arrow layers for animation effect
  - Position offset: arrow1 at (1px, 1px), arrow2 at (-9px, 11px)
- **Animation:** Dual arrow layers suggest diagonal movement animation
- **Gap:** 1.99px between text and icon

---

### Component 4: BrandCta.tsx (RED VARIANT) - "Schedule a Demo" + Arrow
**What it does:** Primary CTA with animated arrow icon

**Design Tokens:**
- **Background Color:** `#b01f24` ✅ MATCHES
- **Gradient:** Same as Component 1 (`from-[#b01f24] via-[#eb484e] to-[#b01f24]`)
- **Text Color:** `#fcfcfc` ✅
- **Font:** DM Sans Bold, 14px ✅
- **Font Weight:** Bold (700)
- **Padding:** 16px horizontal × 9px vertical
- **Border Radius:** 5px ❌ SYSTEM USES 10px
- **Shadow:** `0px 0px 2px 0px rgba(176,31,36,0)` = No shadow
- **Icon:** Diagonal arrow (↗) - 16px × 16px
  - Arrow color: `#FCFCFC` (white)
  - Has TWO arrow layers for animation
  - arrow1: centered, arrow2: offset (-20px, +20.5px)
- **Gap:** 4px between text and icon
- **Animation:** Dual arrow layers for diagonal slide effect

---

### Component 5: BrandCta.tsx (BLACK VARIANT) - "Schedule a Demo" + Arrow (Dark)
**What it does:** Primary CTA in dark theme

**Design Tokens:**
- **Background Color:** `black` 
- **Gradient:** `from-[#141016] via-[#656565] to-[#141016]` (dark gray gradient)
- **Text Color:** `#fcfcfc` ✅
- **Font:** DM Sans Bold, 14px ✅
- **Font Weight:** Bold (700)
- **Padding:** 16px horizontal × 9px vertical
- **Border Radius:** 5px ❌
- **Shadow:** `0px 0px 2px 0px rgba(163,154,235,0)` = No shadow
- **Icon:** Same dual arrow setup as Component 4
- **Gap:** 4px between text and icon
- **Animation:** Same dual arrow animation

---

## STEP 2: COMPARE TO OUR DESIGN SYSTEM

### OUR BUTTON COMPONENT SYSTEM (Current State)

**Variants:**
- **Primary:** Black background (`#000000`), white text
- **Brand:** Ken Bold Red (`#b01f24`), white text ✅
- **Secondary:** White/light background with border
- **Ghost:** Transparent with border

**Sizes:**
- **sm:** 40px height, 14px font
- **md:** 48px height, 16px font
- **lg:** 56px height, 16px font ⭐ Most common
- **xl:** 64px height, 18px font

**Properties:**
- **Font:** DM Sans (variable weights) ✅
- **Border Radius:** 10px (medium) across all buttons
- **Shadows:** Uses elevation system (not implemented yet in buttons)
- **Icons:** Lucide React icons, 16-20px ✅
- **Icon Position:** left or right
- **Padding:** Systematic (20px-40px horizontal based on size)

**Animations:**
- ❌ NO gradient backgrounds
- ❌ NO diagonal arrow animation (we removed this!)
- ✅ Hover states with scale/shadow
- ✅ Ripple effect option

---

## STEP 3: IDENTIFY GAPS & MISMATCHES

### ❌ ISSUES FOUND:

1. **Border Radius Mismatch**
   - Figma: 5px (Components 1, 4, 5)
   - Our System: 10px
   - Impact: Visual inconsistency
   - Fix: Change Figma radius to 10px OR add 5px variant

2. **Button Height/Size Mismatch**
   - Figma: ~34px total height (9px vertical padding)
   - Our System: Minimum 40px (sm size)
   - Impact: Figma buttons are smaller than accessibility minimum
   - Fix: Increase Figma padding to match our sm (40px) or md (48px)

3. **Gradient Backgrounds**
   - Figma: Uses subtle gradients on all buttons
   - Our System: Solid colors only
   - Impact: Different visual style
   - Decision Needed: Add gradients to system OR remove from Figma?

4. **Shadow Usage**
   - Figma: Effectively no shadows (0 opacity or 0px blur)
   - Our System: Can use elevation system
   - Impact: Minimal - Figma matches our flat approach
   - Fix: None needed

5. **Animated Arrow Pattern**
   - Figma: Dual-layer arrow with offset positioning for diagonal slide
   - Our System: ❌ Removed animation intentionally
   - Impact: Animation not available in current Button component
   - Decision Needed: Re-implement diagonal arrow OR convert to static icon?

6. **Font Size Variations**
   - Figma: 12px (small links), 14px (buttons)
   - Our System: 14px (sm), 16px (md/lg), 18px (xl)
   - Impact: Figma uses smaller text
   - Fix: Map Figma 14px → our sm (40px), 12px → custom small link style

7. **Gray/Black Button Variant**
   - Figma: Has dark gray gradient button (ConnectNow)
   - Our System: Has Primary (black) but no gray gradient variant
   - Impact: Missing variant
   - Decision Needed: Add gray gradient variant OR map to existing ghost/secondary?

### ✅ MATCHES FOUND:

1. **Brand Color (#b01f24)** - Perfect match! ✅
2. **Font Family (DM Sans)** - Perfect match! ✅
3. **Font Weight (Bold for buttons)** - Perfect match! ✅
4. **White text on colored backgrounds** - Perfect match! ✅
5. **Icon usage pattern** - We support this! ✅
6. **Border radius 10px** - Figma uses this on ConnectNow ✅

---

## STEP 4: RECOMMENDATIONS & ACTION ITEMS

### OPTION A: UPDATE DESIGN SYSTEM TO MATCH FIGMA (More Changes)
**Pros:** Maintains Figma design fidelity
**Cons:** Adds complexity, smaller buttons may hurt accessibility

Changes needed:
1. Add 5px border radius variant to Button
2. Add xs size (34px height) for compact buttons
3. Implement gradient background support
4. Re-implement diagonal arrow animation
5. Add gray gradient variant

### OPTION B: UPDATE FIGMA TO MATCH DESIGN SYSTEM (Fewer Changes) ⭐ RECOMMENDED
**Pros:** Maintains design system consistency, better accessibility
**Cons:** Requires updating Figma files

Changes needed:
1. **Border Radius:** Change Figma 5px → 10px (Components 1, 4, 5)
2. **Button Height:** Increase padding to match sm (40px) or lg (56px)
3. **Gradients:** Decision point - keep or remove?
4. **Arrows:** Replace dual-arrow animation with static ArrowUpRight icon from Lucide
5. **Gray button:** Map to our Secondary or Ghost variant

### OPTION C: HYBRID APPROACH (Best of Both) ⭐⭐ MOST PRAGMATIC
**Keep from Figma:**
- Gradient backgrounds (add as optional prop)
- 5px radius as "tight" variant for compact UIs
- Small text links (12px) as separate link component

**Keep from System:**
- 40px minimum height (accessibility)
- 10px default radius
- Static icons (no animation complexity)
- Existing variant structure

---

## STEP 5: PROPOSED IMPLEMENTATION PLAN

### Phase 1: Quick Wins (No Breaking Changes)
1. Add `gradient` boolean prop to Button component
2. Add `tight` boolean prop for 5px radius (use sparingly)
3. Create TextLink component for gradient text links like ExploreCta

### Phase 2: Icon Refinements
1. Update icon sizing to match Figma (12px for small, 16px for standard)
2. Add proper icon spacing (4px gap)

### Phase 3: New Variants (If Needed)
1. Add `graydient` variant for ConnectNow style
2. Add `xs` size for 34px compact buttons (with accessibility warning)

### Phase 4: Animation (Optional)
1. Create separate AnimatedArrowButton if animation is required
2. Keep base Button component animation-free

---

## DECISION MATRIX

| Feature | Figma | System | Keep? | Action |
|---------|-------|--------|-------|--------|
| Ken Bold Red (#b01f24) | ✅ | ✅ | ✅ | Already matches |
| DM Sans Bold | ✅ | ✅ | ✅ | Already matches |
| 10px radius | Partial | ✅ | ✅ | Update Figma 5px → 10px |
| 5px radius | ✅ | ❌ | 🤔 | Add as optional `tight` prop? |
| Gradients | ✅ | ❌ | 🤔 | Add as optional `gradient` prop? |
| 40px+ height | ❌ | ✅ | ✅ | Update Figma to match |
| Diagonal arrow animation | ✅ | ❌ | ❌ | Use static icons instead |
| Static icons | ❌ | ✅ | ✅ | Replace Figma dual arrows |
| Gray gradient variant | ✅ | ❌ | 🤔 | Map to Secondary or add new? |
| Text gradient links | ✅ | ❌ | ✅ | Create TextLink component |

---

## NEXT STEPS

1. **Review this analysis** with team/client
2. **Make decision** on gradients (add to system or remove from Figma?)
3. **Make decision** on animations (keep static or re-add?)
4. **Make decision** on 5px radius (add variant or standardize to 10px?)
5. **Implement chosen approach** (A, B, or C)

**My Recommendation:** **OPTION C (Hybrid)** with these specific choices:
- ✅ Add optional `gradient` prop (minimal complexity)
- ✅ Keep 10px radius as default, add `tight` for 5px (rare cases)
- ✅ Use static ArrowUpRight icons (no animation)
- ✅ Create separate TextLink component for gradient text
- ✅ Map gray button to Secondary variant
- ✅ Increase all Figma button heights to 40px minimum

This balances design fidelity with system consistency and accessibility best practices.
