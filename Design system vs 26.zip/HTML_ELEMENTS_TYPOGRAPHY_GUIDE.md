# 📐 HTML ELEMENTS & TYPOGRAPHY MAPPING GUIDE
**How h1-h6, body, and text elements are defined in the design system**

---

## 🚨 **IMPORTANT: NO DEFAULT HTML STYLES**

### **Key Facts:**

❌ **There are NO default styles for h1-h6 in this project**  
❌ **There are NO default styles for `<p>`, `<body>`, or other text elements**  
✅ **All typography is manually styled using CSS variables or inline styles**

This is a **component-based design system** where every text element is explicitly styled.

---

---

## 🎨 **TYPOGRAPHY SCALE MAPPING**

### **Conceptual h1-h6 Mapping**

While we don't use native HTML heading styles, here's how the design system maps to traditional heading hierarchy:

| HTML Concept | CSS Variable | Size | Use Case | Font |
|--------------|--------------|------|----------|------|
| **Hero h1** | `--text-3xl` | 48.8px | Page title, hero headings | Noto Serif Light |
| **Section h1** | `--text-2xl` | 39px | Main section titles | Noto Serif Light |
| **h2** | `--text-xl` | 31.25px | Subsection headings | Noto Serif Normal |
| **h3** | `--text-lg` | 25px | Card titles (spacious) | DM Sans Medium |
| **h4** | `--text-base` | 20px | Card titles (compact) | DM Sans Medium |
| **h5** | `--text-sm` | 16px | Small headings | DM Sans Medium |
| **h6** | `--text-xs` | 12.8px | Micro headings, labels | DM Sans Medium |

---

---

## 📋 **COMPLETE TYPOGRAPHY HIERARCHY**

### **1. HERO LEVEL (Largest)**

```tsx
// Hero h1 - Main page title
<h1 
  className="leading-[1.15] font-light text-white/95 tracking-tight" 
  style={{ 
    fontFamily: "'Noto Serif', serif", 
    fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
  }}
>
  Evaluating India's Transformer Bushing Market for IPO Readiness
</h1>
```

**Properties:**
- **Size:** `var(--text-3xl)` = 48.8px (responsive: 28px → 48.8px)
- **Font:** Noto Serif
- **Weight:** Light (300)
- **Line Height:** 1.15
- **Color:** White/95% (on dark) or Black/90% (on light)
- **Use:** Hero titles, main page headings

---

### **2. SECTION HEADINGS (h2 Level)**

```tsx
// Section h2 - Main section title
<h2 
  className="leading-[1.15] font-light text-black tracking-tight" 
  style={{ 
    fontFamily: "'Noto Serif', serif", 
    fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
  }}
>
  Measurable Outcomes
</h2>
```

**Properties:**
- **Size:** `var(--text-3xl)` = 48.8px (responsive clamp)
- **Font:** Noto Serif
- **Weight:** Light (300)
- **Line Height:** 1.15
- **Color:** Black (on light) or White (on dark)
- **Use:** Main section headings (Impact, Challenges, etc.)

---

### **3. SUBSECTION HEADINGS (h3 Level)**

```tsx
// Subsection h3 - Engagement objective titles
<h3 
  className="font-medium text-black leading-[1.3]" 
  style={{ fontSize: 'var(--text-xl)' }}
>
  Market Sizing & Segmentation Analysis
</h3>
```

**Properties:**
- **Size:** `var(--text-xl)` = 31.25px
- **Font:** DM Sans
- **Weight:** Medium (500)
- **Line Height:** 1.3
- **Color:** Black/90%
- **Use:** Engagement objectives, methodology step titles

---

### **4. CARD TITLES (h4 Level - Spacious Layouts)**

```tsx
// Card h4 - When 2-3 cards (spacious)
<h4 
  className="font-medium text-black leading-[1.25]" 
  style={{ fontSize: 'var(--text-lg)' }}
>
  Market Sizing Uncertainty
</h4>
```

**Properties:**
- **Size:** `var(--text-lg)` = 25px
- **Font:** DM Sans
- **Weight:** Medium (500)
- **Line Height:** 1.25
- **Color:** Black
- **Use:** Card titles when 2-3 cards (spacious layout)

---

### **5. CARD TITLES (h4 Level - Compact Layouts)**

```tsx
// Card h4 - When 4+ cards (compact)
<h4 
  className="font-medium text-black leading-[1.25]" 
  style={{ fontSize: 'var(--text-base)' }}
>
  Competitive Positioning Blind Spots
</h4>
```

**Properties:**
- **Size:** `var(--text-base)` = 20px
- **Font:** DM Sans
- **Weight:** Medium (500)
- **Line Height:** 1.25
- **Color:** Black
- **Use:** Card titles when 4+ cards (compact layout)

---

### **6. LARGE BODY TEXT**

```tsx
// Large body - Lead paragraphs, featured text
<p 
  className="leading-[1.45] font-normal text-black" 
  style={{ 
    fontFamily: "'Noto Serif', serif", 
    fontSize: 'clamp(19px, 2.8vw, 24px)' 
  }}
>
  A vertically integrated manufacturer of high-voltage condenser...
</p>
```

**Properties:**
- **Size:** 19px → 24px (responsive)
- **Font:** Noto Serif
- **Weight:** Normal (400)
- **Line Height:** 1.45-1.5
- **Color:** Black
- **Use:** Company overview, lead paragraphs

---

### **7. STANDARD BODY TEXT (Most Common)**

```tsx
// Standard body - Paragraphs, descriptions
<p 
  className="leading-[1.7] text-black/70" 
  style={{ fontSize: 'var(--text-sm)' }}
>
  India's power transmission sector is undergoing accelerated modernization...
</p>
```

**Properties:**
- **Size:** `var(--text-sm)` = 16px
- **Font:** DM Sans (default)
- **Weight:** Normal (400)
- **Line Height:** 1.6-1.7
- **Color:** Black/70% (secondary text)
- **Use:** Body paragraphs, descriptions, list items

---

### **8. LABELS & METADATA (h6 Level)**

```tsx
// Section labels (uppercase eyebrows)
<span 
  className="font-medium text-black/40 uppercase tracking-[3px]" 
  style={{ fontSize: 'var(--text-xs)' }}
>
  CHALLENGES
</span>
```

**Properties:**
- **Size:** `var(--text-xs)` = 12.8px
- **Font:** DM Sans
- **Weight:** Medium (500)
- **Line Height:** Normal
- **Color:** Black/40% (tertiary text)
- **Tracking:** 3px (uppercase spacing)
- **Use:** Section labels, metadata, timestamps, categories

---

### **9. COMPACT BODY TEXT**

```tsx
// Compact body - Dense layouts (4+ cards)
<p 
  className="leading-[1.5] text-black/70" 
  style={{ fontSize: 'var(--text-compact)' }}
>
  How do we position against European imports?
</p>
```

**Properties:**
- **Size:** `var(--text-compact)` = 14px (0.875rem)
- **Font:** DM Sans
- **Weight:** Normal (400)
- **Line Height:** 1.5
- **Color:** Black/70%
- **Use:** Questions in 4+ card layouts, compact descriptions

---

### **10. MICRO LABELS**

```tsx
// Micro labels - Navbar, tiny metadata
<span 
  className="font-medium text-black/40 uppercase tracking-[2px]" 
  style={{ fontSize: 'var(--text-2xs)' }}
>
  INDUSTRY
</span>
```

**Properties:**
- **Size:** `var(--text-2xs)` = 12px
- **Font:** DM Sans
- **Weight:** Medium (500)
- **Line Height:** Normal
- **Color:** Black/40%
- **Use:** Navbar text, micro labels in tight spaces

---

---

## 🎯 **HTML ELEMENT USAGE PATTERNS**

### **Actual Implementation (No Default Styles)**

```tsx
// ❌ WRONG - Native HTML heading (no styles applied)
<h1>Hero Title</h1>  // Will render as browser default (ugly!)

// ✅ CORRECT - Explicitly styled heading
<h1 
  className="leading-[1.15] font-light text-white tracking-tight" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
>
  Hero Title
</h1>
```

---

---

## 📐 **VISUAL HIERARCHY CHART**

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  Hero h1 (48.8px / --text-3xl)                            │
│  Noto Serif Light, leading-[1.15]                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Section h2 (48.8px / --text-3xl)                         │
│  Noto Serif Light, leading-[1.15]                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Subsection h3 (31.25px / --text-xl)                      │
│  DM Sans Medium, leading-[1.3]                             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Card Title h4 - Spacious (25px / --text-lg)              │
│  DM Sans Medium, leading-[1.25]                            │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Card Title h4 - Compact (20px / --text-base)             │
│  DM Sans Medium, leading-[1.25]                            │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Lead Paragraph (19-24px / clamp)                          │
│  Noto Serif Normal, leading-[1.45]                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Body Text (16px / --text-sm)                              │
│  DM Sans Normal, leading-[1.7]                             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Compact Body (14px / --text-compact)                      │
│  DM Sans Normal, leading-[1.5]                             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Labels (12.8px / --text-xs)                               │
│  DM Sans Medium, uppercase, tracking-[3px]                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Micro Labels (12px / --text-2xs)                          │
│  DM Sans Medium, uppercase, tracking-[2px]                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

---

## 🎨 **FONT FAMILY USAGE**

### **Noto Serif (Editorial Headings)**

Used for:
- ✅ Hero titles (h1)
- ✅ Section headings (h2)
- ✅ Lead paragraphs
- ✅ Featured quotes
- ✅ Large display numbers
- ✅ Editorial emphasis

**Weight:** Light (300) for headings, Normal (400) for body

---

### **DM Sans (Body & UI)**

Used for:
- ✅ Subsection headings (h3)
- ✅ Card titles (h4)
- ✅ Body text
- ✅ Descriptions
- ✅ Labels
- ✅ Metadata
- ✅ Navigation
- ✅ Buttons

**Weight:** Normal (400) for body, Medium (500) for emphasis, Bold (700) for CTAs

---

---

## 📏 **COMPLETE SCALE REFERENCE**

| CSS Variable | Size (px) | Size (rem) | HTML Concept | Common Use |
|--------------|-----------|------------|--------------|------------|
| `--text-5xl` | 76.3px | 4.768rem | - | Future use, rarely needed |
| `--text-4xl` | 61px | 3.815rem | - | Challenge numbers (<4 cards) |
| `--text-3xl` | 48.8px | 3.052rem | h1, h2 | Hero, section headings |
| `--text-2xl` | 39px | 2.441rem | h2 | Major section titles |
| `--text-xl` | 31.25px | 1.953rem | h3 | Subsection headings |
| `--text-lg` | 25px | 1.563rem | h4 | Card titles (spacious) |
| `--text-base` | 20px | 1.25rem | h4, h5 | Card titles (compact), large body |
| `--text-sm` | 16px | 1rem | p, body | Standard body text |
| `--text-compact` | 14px | 0.875rem | p | Compact body (dense layouts) |
| `--text-xs` | 12.8px | 0.8rem | h6, span | Labels, metadata |
| `--text-2xs` | 12px | 0.75rem | span | Micro labels, navbar |

---

---

## 🔤 **TEXT COLOR HIERARCHY**

### **On Light Backgrounds (White/Warm sections)**

```css
/* Primary Text (Headings) */
text-black              /* 100% opacity - Main headings */
text-black/90           /* 90% opacity - Standard headings */

/* Secondary Text (Body) */
text-black/70           /* 70% opacity - Body paragraphs */
text-black/60           /* 60% opacity - Descriptions */

/* Tertiary Text (Metadata) */
text-black/40           /* 40% opacity - Labels, metadata */
text-black/30           /* 30% opacity - Subtle metadata */

/* Disabled/Decorative */
text-black/20           /* 20% opacity - Disabled state */
text-black/[0.08]       /* 8% opacity - Large background numbers */
```

---

### **On Dark Backgrounds (Black sections)**

```css
/* Primary Text (Headings) */
text-white              /* 100% opacity - Rare, very bright */
text-white/95           /* 95% opacity - Main headings */

/* Secondary Text (Body) */
text-white/70           /* 70% opacity - Body paragraphs */
text-white/60           /* 60% opacity - Standard body */

/* Tertiary Text (Metadata) */
text-white/50           /* 50% opacity - Metadata */
text-white/40           /* 40% opacity - Labels */
text-white/30           /* 30% opacity - Subtle labels */
```

---

---

## 📝 **PRACTICAL EXAMPLES**

### **Example 1: Hero Section**

```tsx
export function HeroSection() {
  return (
    <section className="py-20 bg-black">
      {/* Section Label (h6 equivalent) */}
      <span 
        className="font-medium text-white/40 uppercase tracking-[3px]" 
        style={{ fontSize: 'var(--text-xs)' }}
      >
        CASE STUDY
      </span>
      
      {/* Hero Title (h1) */}
      <h1 
        className="leading-[1.15] font-light text-white/95 tracking-tight" 
        style={{ 
          fontFamily: "'Noto Serif', serif", 
          fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
        }}
      >
        Evaluating India's Transformer Bushing Market
      </h1>
      
      {/* Subheading (body) */}
      <p 
        className="leading-[1.7] text-white/60" 
        style={{ fontSize: 'var(--text-sm)' }}
      >
        Strategic insights for IPO readiness
      </p>
    </section>
  );
}
```

---

### **Example 2: Content Section**

```tsx
export function ContentSection() {
  return (
    <section className="py-20 bg-white">
      {/* Section Label */}
      <span 
        className="font-medium text-black/40 uppercase tracking-[3px]" 
        style={{ fontSize: 'var(--text-xs)' }}
      >
        CHALLENGES
      </span>
      
      {/* Section Heading (h2) */}
      <h2 
        className="leading-[1.15] font-light text-black tracking-tight" 
        style={{ 
          fontFamily: "'Noto Serif', serif", 
          fontSize: 'clamp(1.75rem, 5vw, var(--text-3xl))' 
        }}
      >
        Key Problem Statements
      </h2>
      
      {/* Description (body) */}
      <p 
        className="leading-[1.7] text-black/60" 
        style={{ fontSize: 'var(--text-sm)' }}
      >
        A systematic approach to identifying market gaps
      </p>
    </section>
  );
}
```

---

### **Example 3: Card Component**

```tsx
export function CardComponent({ cardCount }) {
  return (
    <div className="bg-white border rounded-[5px] p-6">
      {/* Card Title (h4) - Adaptive sizing */}
      <h4 
        className="font-medium text-black leading-[1.25] mb-4" 
        style={{ 
          fontSize: cardCount >= 4 
            ? 'var(--text-base)'  // 20px for compact
            : 'var(--text-lg)'     // 25px for spacious
        }}
      >
        Market Sizing Uncertainty
      </h4>
      
      {/* Card Description (body) */}
      <p 
        className="leading-[1.6] text-black/70" 
        style={{ fontSize: 'var(--text-sm)' }}
      >
        Unclear TAM quantification and segment prioritization
      </p>
    </div>
  );
}
```

---

---

## 🎯 **QUICK DECISION GUIDE**

### **"Which heading size should I use?"**

```
Is it the main page title? 
  → Use var(--text-3xl) with Noto Serif Light

Is it a main section heading?
  → Use var(--text-3xl) with Noto Serif Light (with responsive clamp)

Is it a subsection title?
  → Use var(--text-xl) with DM Sans Medium

Is it a card title with 2-3 cards?
  → Use var(--text-lg) with DM Sans Medium

Is it a card title with 4+ cards?
  → Use var(--text-base) with DM Sans Medium

Is it a small heading?
  → Use var(--text-sm) with DM Sans Medium

Is it a label/metadata?
  → Use var(--text-xs) with DM Sans Medium, uppercase
```

---

### **"Which body text size should I use?"**

```
Is it a featured/lead paragraph?
  → Use clamp(19px, 2.8vw, 24px) with Noto Serif

Is it standard body text?
  → Use var(--text-sm) with DM Sans

Is it in a compact/dense layout (4+ cards)?
  → Use var(--text-compact) with DM Sans

Is it a label or metadata?
  → Use var(--text-xs) with DM Sans Medium, uppercase

Is it navbar or micro label?
  → Use var(--text-2xs) with DM Sans Medium
```

---

---

## ⚠️ **COMMON MISTAKES**

### **❌ DON'T DO THIS:**

```tsx
// 1. Using native HTML heading without styles
<h1>Title</h1>  // Will use browser default (ugly!)

// 2. Using Tailwind text classes
<h1 className="text-5xl">Title</h1>  // Not part of our design system

// 3. Mixing font families incorrectly
<h2 style={{ fontFamily: 'DM Sans' }}>Section Heading</h2>  // Should be Noto Serif

// 4. Hardcoding random sizes
<p style={{ fontSize: '18px' }}>Text</p>  // Use design system variables
```

---

### **✅ DO THIS INSTEAD:**

```tsx
// 1. Always explicitly style headings
<h1 
  className="leading-[1.15] font-light text-black tracking-tight" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
>
  Title
</h1>

// 2. Use design system variables
<h2 style={{ fontSize: 'var(--text-xl)' }}>Heading</h2>

// 3. Use correct font family
<h2 
  className="font-light" 
  style={{ fontFamily: "'Noto Serif', serif", fontSize: 'var(--text-3xl)' }}
>
  Section Heading
</h2>

// 4. Use design system variables or documented custom sizes
<p style={{ fontSize: 'var(--text-sm)' }}>Text</p>
```

---

---

## 📚 **SUMMARY**

### **Key Takeaways:**

1. ✅ **No default HTML styles** - Every element must be explicitly styled
2. ✅ **Use CSS variables** - Always prefer design system variables
3. ✅ **Noto Serif for headings** - Large editorial headings, lead paragraphs
4. ✅ **DM Sans for body/UI** - Body text, smaller headings, labels
5. ✅ **Adaptive sizing** - Typography changes based on layout density
6. ✅ **Semantic HTML** - Use h1-h6 for accessibility, style manually

---

### **Design System Variables:**

```css
--text-5xl: 76.3px   /* Rarely used */
--text-4xl: 61px     /* Extra large */
--text-3xl: 48.8px   /* h1, h2 - Hero/section headings */
--text-2xl: 39px     /* h2 - Major titles */
--text-xl: 31.25px   /* h3 - Subsection headings */
--text-lg: 25px      /* h4 - Card titles (spacious) */
--text-base: 20px    /* h4, h5 - Card titles (compact) */
--text-sm: 16px      /* body - Standard body text */
--text-compact: 14px /* body - Compact layouts */
--text-xs: 12.8px    /* h6 - Labels, metadata */
--text-2xs: 12px     /* Micro labels */
```

---

**Related Documentation:**
- `/TYPOGRAPHY_SYSTEM_COMPLETE.md` - Complete typography guide
- `/FONT_SIZE_RATIONALE_ANALYSIS.md` - Why certain sizes exist
- `/src/styles/theme.css` - CSS variable definitions

---

**Last Updated:** January 2025  
**Status:** ✅ Complete & Production Ready

