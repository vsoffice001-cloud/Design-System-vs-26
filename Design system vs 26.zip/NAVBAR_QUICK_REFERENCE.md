# 🎯 Navbar Quick Reference Guide

## Visual States

### 📍 **State 1: At Hero Section**

```
Desktop (XL+):
╔═══════════════════════════════════════════════════════════════╗
║ DARK BAR: Latest reports: India... │ Procurement Company▼ 🔐 Login ║
╠═══════════════════════════════════════════════════════════════╣
║ 🏢 KEN    Services▼  Industries▼  Resources▼  [🔍 Search]    ║
║                                            [Schedule a Demo]   ║
╚═══════════════════════════════════════════════════════════════╝

Desktop (LG):
╔═══════════════════════════════════════════════════════════════╗
║ 🏢 KEN    Services▼  Industries▼                              ║
║                                            [Schedule a Demo]   ║
╚═══════════════════════════════════════════════════════════════╝
(Resources hidden due to space constraint, secondary bar not shown)

Mobile:
╔═══════════════════════════════════════════════════╗
║ 🏢 KEN                    [Schedule Demo]  [≡]   ║
╚═══════════════════════════════════════════════════╝
  ↓ Tap hamburger
╔═══════════════════════════════════════════════════╗
║ ► Services                                     ▼  ║
║ ► Industries                                   ▼  ║
║ ► Resources                                    ▼  ║
║ ─────────────────────────────────────────────────║
║ COMPANY                                           ║
║   Our Story                                       ║
║   Our Experts                                     ║
║   Careers                                         ║
║   Contact Us                                      ║
║ ─────────────────────────────────────────────────║
║   Procurement                   ← From dark bar   ║
║   🔐 Log in                     ← From dark bar   ║
║ ─────────────────────────────────────────────────║
║ [         Schedule a Demo         ]               ║
╚═══════════════════════════════════════════════════╝
```

---

### 📍 **State 2: Scrolled Past Hero**

```
Desktop (XL+):
╔═══════════════════════════════════════════════════════════════╗
║ 🏢 KEN  Services▼ Industries▼ Resources▼ [🔍 Search]  🔐 Login║
║                                            [Schedule a Demo]   ║
╚═══════════════════════════════════════════════════════════════╝
(Dark bar removed, Login moved to main nav)

Desktop (LG):
╔═══════════════════════════════════════════════════════════════╗
║ 🏢 KEN    Services▼  Industries▼  Resources▼                  ║
║                                            [Schedule a Demo]   ║
╚═══════════════════════════════════════════════════════════════╝
(Resources now visible with extra space, Login in menu)

Mobile:
╔═══════════════════════════════════════════════════╗
║ 🏢 KEN                    [Schedule Demo]  [≡]   ║
╚═══════════════════════════════════════════════════╝
  ↓ Tap hamburger
╔═══════════════════════════════════════════════════╗
║ ► Services                                     ▼  ║
║ ► Industries                                   ▼  ║
║ ► Resources                                    ▼  ║
║ ─────────────────────────────────────────────────║
║ COMPANY                                           ║
║   Our Story                                       ║
║   Our Experts                                     ║
║   Careers                                         ║
║   Contact Us                                      ║
║ ─────────────────────────────────────────────────║
║   🔐 Log in                     ← Now here        ║
║ ─────────────────────────────────────────────────║
║ [         Schedule a Demo         ]               ║
╚═══════════════════════════════════════════════════╝
(Procurement section removed)
```

---

## 🔄 Transition Flow

```
┌─────────────┐
│  PAGE LOAD  │
│  (At Hero)  │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────┐
│ Secondary Bar: ✅ VISIBLE   │
│ Login Position: Dark Bar    │
│ Resources (lg): Hidden      │
│ Search Bar: 2xl+ only       │
└──────┬──────────────────────┘
       │
       │ User scrolls down ↓
       │
       ▼
┌─────────────────────────────┐
│ Hero Out of View            │
└──────┬──────────────────────┘
       │
       ▼
┌─────────────────────────────┐
│ Secondary Bar: ❌ HIDDEN    │
│ Login Position: Main Nav    │
│ Resources (lg): Visible     │
│ Search Bar: xl+ visible     │
└──────┬──────────────────────┘
       │
       │ User scrolls up ↑
       │
       ▼
┌─────────────────────────────┐
│ Hero Back in View           │
└──────┬──────────────────────┘
       │
       ▼
┌─────────────────────────────┐
│ Secondary Bar: ✅ VISIBLE   │
│ (Returns to State 1)        │
└─────────────────────────────┘
```

---

## 📱 Breakpoint Behavior Summary

| Screen Size | Secondary Bar | Resources | Search Bar | Login Location |
|-------------|---------------|-----------|------------|----------------|
| **Mobile** (< 640px) | | | |
| At Hero | Hidden | Menu | Hidden | Menu (Secondary section) |
| Scrolled | Hidden | Menu | Hidden | Menu (Main section) |
| | | | | |
| **Tablet** (640-1024px) | | | |
| At Hero | Hidden | Menu | Hidden | Menu (Secondary section) |
| Scrolled | Hidden | Menu | Hidden | Menu (Main section) |
| | | | | |
| **Desktop** (1024-1280px) | | | |
| At Hero | Hidden | Hidden | Hidden | Menu |
| Scrolled | Hidden | ✅ Visible | Hidden | Menu |
| | | | | |
| **Large** (1280-1536px) | | | |
| At Hero | ✅ Visible | ✅ Visible | Hidden | Dark Bar |
| Scrolled | Hidden | ✅ Visible | ✅ Visible | Main Nav |
| | | | | |
| **XL** (1536px+) | | | |
| At Hero | ✅ Visible | ✅ Visible | ✅ Visible | Dark Bar |
| Scrolled | Hidden | ✅ Visible | ✅ Visible (wider) | Main Nav |

---

## 🎨 Color Reference

### Secondary Bar (Dark)
```css
Background: #141016
Text: white
Text (Secondary): white/80 (opacity 80%)
Hover: white/80

Links:
- Latest reports: font-medium, tracking-[0.24px]
- Procurement/Company/Login: font-normal, leading-[26px]
```

### Main Nav (White)
```css
Background: white (with backdrop-blur)
Text: #141016
Buttons: #b01f24 (brand red)

Navigation:
- Font: DM Sans Bold, 14px, leading-[22px]
- Hover: opacity-70

Search:
- Background: #f5f5fd
- Inner: #fcfcfc
- Gradient: rgba(128,108,224,1) → transparent
```

---

## ⌨️ Code Patterns

### Check if at Hero
```tsx
const isHeroVisible = useHeroVisibility();
```

### Conditional Secondary Bar
```tsx
{isHeroVisible && (
  <div className="bg-[#141016] h-[40px]...">
    {/* Secondary menu */}
  </div>
)}
```

### Adaptive Login
```tsx
{/* In secondary bar */}
{isHeroVisible && (
  <a className="text-white">Log in</a>
)}

{/* In main nav */}
{!isHeroVisible && (
  <a className="text-[#141016]">Log in</a>
)}
```

### Resources Visibility
```tsx
<button className={`
  ${isHeroVisible ? 'hidden xl:flex' : 'flex'}
`}>
  Resources
</button>
```

### Search Bar Timing
```tsx
<div className={`
  ${isHeroVisible ? 'hidden 2xl:flex' : 'hidden xl:flex'}
`}>
  {/* Search bar */}
</div>
```

---

## 🐛 Common Issues & Solutions

### Issue: Secondary bar shows when scrolled
**Solution:** Check `isHeroVisible` hook is working
```tsx
console.log('Is hero visible:', isHeroVisible);
```

### Issue: Login appears in both places
**Solution:** Use mutually exclusive conditions
```tsx
{isHeroVisible && <LoginInSecondary />}
{!isHeroVisible && <LoginInMain />}
```

### Issue: Resources always hidden on lg
**Solution:** Make conditional on hero visibility
```tsx
{isHeroVisible ? 'hidden xl:flex' : 'flex'}
```

### Issue: Mobile menu doesn't adapt
**Solution:** Add conditional sections
```tsx
{isHeroVisible && <SecondaryItems />}
{!isHeroVisible && <MainItems />}
```

---

## ✅ Quick Test Commands

### Test Hero Visibility
1. Load page → Should see dark bar (xl+)
2. Scroll down → Dark bar disappears
3. Scroll to top → Dark bar returns

### Test Responsive
```bash
# Mobile (375px)
- Hamburger menu visible
- Secondary items in menu at hero

# Desktop (1024px)
- Resources hidden at hero
- Resources visible after scroll

# Large (1280px)
- Dark bar at hero
- Login moves to main nav after scroll
```

### Test Mobile Menu
```bash
At Hero:
- Open menu
- See "Procurement" section
- See "Login" in Procurement section

After Scroll:
- Open menu
- No "Procurement" section
- "Login" in separate section
```

---

## 📚 Related Files

- **Component:** `/src/app/components/Navbar.tsx`
- **Hooks:** `/src/app/hooks/useHeroVisibility.ts`
- **Hooks:** `/src/app/hooks/useScrollDirection.ts`
- **Button:** `/src/app/components/Button.tsx`
- **SVG Assets:** `/src/imports/svg-fodxwe3cpi.ts`
- **Figma State 1:** `/src/imports/Container-6015-6818.tsx`
- **Figma State 2:** `/src/imports/WhtMini.tsx`

---

## 🚀 Next Steps (Optional Enhancements)

- [ ] Add search functionality (modal/dropdown)
- [ ] Implement mega menus for Services/Industries
- [ ] Add keyboard navigation
- [ ] Create dropdown animations for Resources
- [ ] Add notification badge to Login
- [ ] Implement user profile dropdown (when logged in)
- [ ] Add language switcher
- [ ] Dark mode support

---

**Last Updated:** Two-State System Implementation
**Status:** ✅ Production Ready
**Tested:** All breakpoints and states working perfectly
