# Design System Use Cases & Decision Scenarios
**YASH Design System: Practical Application Guide**  
**Date:** January 21, 2026  
**Version:** 1.0

---

## 📚 Table of Contents
1. [Daily Development Scenarios](#daily-development-scenarios)
2. [Design Decision Trees](#design-decision-trees)
3. [Component Selection Guide](#component-selection-guide)
4. [Color Usage Scenarios](#color-usage-scenarios)
5. [Typography Decision Making](#typography-decision-making)
6. [Spacing & Layout Scenarios](#spacing--layout-scenarios)
7. [Button Selection Matrix](#button-selection-matrix)
8. [Common Pitfalls & Solutions](#common-pitfalls--solutions)
9. [Quality Assurance Checklist](#quality-assurance-checklist)

---

## 🎯 Daily Development Scenarios

### Scenario 1: Adding a New CTA Button

**Context:** Product manager asks for a "Download Report" button in the Impact section.

**Decision Process:**

**Step 1: Determine Priority Level**
```
Question: Is this a primary conversion action?
├─ Yes, critical conversion → Use brand variant (red)
├─ Important, but secondary → Use primary variant (black gradient)
└─ Alternative action → Use secondary/ghost variant
```

**Answer:** "Download Report" is important but not the primary conversion goal (that's "Schedule Demo").

**Decision:** Use **primary variant**

**Step 2: Choose Size**
```
Question: What's the visual hierarchy?
├─ Hero/above-the-fold → size="xl" (64px)
├─ Section primary CTA → size="lg" (56px)  ✅
├─ Standard action → size="md" (48px)
└─ Utility action → size="sm" (40px)
```

**Decision:** Use **size="lg"** (standard section CTA)

**Step 3: Icon Decision**
```
Question: Does the action benefit from an icon?
├─ Yes, enhances clarity → Add icon
└─ No, text is clear → Skip icon

Action: "Download" → Clear with download icon
```

**Decision:** Add **Download icon**

**Final Implementation:**
```tsx
import { Download } from 'lucide-react';

<Button 
  variant="primary" 
  size="lg"
  icon={<Download />}
  iconPosition="right"
  onClick={handleDownloadReport}
>
  Download Report
</Button>
```

**Rationale:**
- Primary variant: Important but not highest priority
- Size lg: Standard section CTA height
- Icon: Reinforces download action
- Right position: Suggests forward movement

---

### Scenario 2: Creating a Metrics Dashboard Section

**Context:** Client wants to add a "Key Achievements" section with 6 metrics.

**Decision Process:**

**Step 1: Analyze Content Structure**
```
Content:
- 6 metrics
- Each has: Number, Label, Growth indicator
- Need high visual prominence
```

**Step 2: Choose Layout Pattern**
```
Question: How many metrics?
├─ 2-3 metrics → Horizontal row with large numbers
├─ 4 metrics → 4-column grid (existing pattern) ✅
└─ 5-6 metrics → 2 rows × 3 columns OR 3 rows × 2 columns
```

**6 metrics = 2 rows × 3 columns**

**Step 3: Select Background**
```
Question: What's the surrounding context?
Previous section: Dark (black)
Next section: Light (white)

Rule: Alternate backgrounds
Decision: Use white background
```

**Step 4: Choose Typography**
```
Hierarchy:
├─ Section heading → --text-2xl (39px)
├─ Metric number → --text-4xl (61px) for emphasis
├─ Metric label → --text-sm (16px)
└─ Growth indicator → --text-xs (12.8px)
```

**Final Implementation:**
```tsx
<section className="bg-white py-20">
  <div className="max-w-[1000px] mx-auto px-6">
    {/* Section heading - text-2xl */}
    <h2 className="text-[var(--text-2xl)] font-normal mb-12 text-center">
      Key Achievements
    </h2>
    
    {/* Metric grid - 3 columns */}
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {metrics.map((metric) => (
        <div key={metric.id} className="text-center">
          {/* Metric number - text-4xl */}
          <div className="text-[var(--text-4xl)] font-normal mb-2">
            {metric.value}
          </div>
          
          {/* Metric label - text-sm */}
          <div className="text-[var(--text-sm)] text-black/60 mb-1">
            {metric.label}
          </div>
          
          {/* Growth indicator - text-xs */}
          <div className="text-[var(--text-xs)] text-[#059669]">
            ↑ {metric.growth}% growth
          </div>
        </div>
      ))}
    </div>
  </div>
</section>
```

**Rationale:**
- 3-column grid: Optimal for 6 metrics (balanced)
- White background: Alternates with surrounding sections
- Large numbers (text-4xl): High visual impact
- Center alignment: Equal weight to all metrics
- Green growth indicators: Subtle accent (3% rule)

---

### Scenario 3: Adding a Testimonial Quote

**Context:** Marketing wants to add a client testimonial mid-page.

**Decision Process:**

**Step 1: Determine Section Type**
```
Question: Testimonial style?
├─ Full-width hero style → Organism (TestimonialSection)
├─ Inline quote → Molecule (QuoteCard)
└─ Simple text → Atoms (typography + styling)
```

**Decision:** Full testimonial with photo = **Organism**

**Step 2: Choose Background**
```
Question: Visual hierarchy?
├─ High emphasis → Black background ✅
├─ Medium emphasis → Warm background
└─ Low emphasis → White background

Testimonials are high-value social proof
Decision: Black background with white text
```

**Step 3: Layout Structure**
```
Elements:
1. Quote text (large, prominent)
2. Client name
3. Client title
4. Client photo
5. Company logo

Layout: Center-aligned with photo and text
```

**Final Implementation:**
```tsx
<section className="bg-black text-white py-20">
  <div className="max-w-[800px] mx-auto px-6 text-center">
    {/* Quote - text-xl */}
    <blockquote className="text-[var(--text-xl)] font-normal mb-8 leading-relaxed">
      "{testimonial.quote}"
    </blockquote>
    
    {/* Client info */}
    <div className="flex flex-col items-center gap-4">
      {/* Photo */}
      <img
        src={testimonial.photo}
        alt={testimonial.name}
        className="w-16 h-16 rounded-full object-cover"
      />
      
      {/* Name - text-base */}
      <div>
        <div className="text-[var(--text-base)] font-normal">
          {testimonial.name}
        </div>
        
        {/* Title - text-sm */}
        <div className="text-[var(--text-sm)] text-white/60">
          {testimonial.title}, {testimonial.company}
        </div>
      </div>
    </div>
  </div>
</section>
```

**Rationale:**
- Black background: High emphasis for social proof
- Large quote (text-xl): Make testimonial prominent
- Center alignment: Focus attention
- Reduced max-width (800px): Better readability for quotes
- Photo: Adds credibility and personality

---

## 🌳 Design Decision Trees

### Tree 1: Choosing the Right Button Variant

```
START: Need to add a button

↓
What is the button's PURPOSE?
├─── PRIMARY CONVERSION (Schedule demo, Start trial)
│    ↓
│    Is this THE most important action on the page?
│    ├─ Yes → variant="brand" + size="lg" ✅
│    └─ No → variant="primary" + size="lg"
│
├─── SECONDARY ACTION (Download, Learn more, Book call)
│    ↓
│    Does it compete with primary CTA?
│    ├─ Yes → variant="secondary" + size="lg"
│    └─ No → variant="primary" + size="md"
│
├─── NAVIGATION (See all, View more, Explore)
│    ↓
│    What's the background color?
│    ├─ Dark (black) → variant="ghost" + size="md" ✅
│    └─ Light (white) → variant="secondary" + size="md"
│
└─── UTILITY (Close, Cancel, Back)
     ↓
     variant="secondary" + size="sm" ✅
```

**Example Applications:**

**Brand Button (variant="brand"):**
- ✅ "Schedule a Demo" in Hero section
- ✅ "Get Started Today" in Final CTA
- ❌ "Download PDF" (not primary conversion)
- ❌ "Learn More" (not conversion action)

**Primary Button (variant="primary"):**
- ✅ "Get Customized Report" in Impact section
- ✅ "Download Case Study" in Resources
- ✅ "Book Discovery Call" as secondary CTA
- ❌ "See All Resources" (use ghost on dark bg)

**Secondary Button (variant="secondary"):**
- ✅ "Book Discovery Call" paired with brand CTA
- ✅ "View Full Report" on white backgrounds
- ✅ Alternative actions
- ❌ Primary conversion actions

**Ghost Button (variant="ghost"):**
- ✅ "See All Resources" on black background
- ✅ "Explore More" on dark sections
- ❌ Never on white backgrounds (poor contrast)
- ❌ Never for primary conversions

---

### Tree 2: Choosing Typography Size

```
START: Need to add text

↓
What TYPE of text is this?
├─── PAGE HEADING (H1)
│    ↓
│    Is this the hero/main title?
│    ├─ Yes → text-3xl (48.8px) ✅
│    └─ No → text-2xl (39px)
│
├─── SECTION HEADING (H2)
│    ↓
│    Standard section heading → text-2xl (39px) ✅
│
├─── SUBSECTION HEADING (H3)
│    ↓
│    How many cards/items in this section?
│    ├─ 2-3 large items → text-xl (31.25px)
│    ├─ 4-6 items → text-lg (25px) ✅
│    └─ 7+ items → text-base (20px)
│
├─── BODY TEXT
│    ↓
│    What's the content type?
│    ├─ Primary paragraph → text-sm (16px) ✅
│    ├─ Secondary info → text-compact (14px)
│    └─ Labels/metadata → text-xs (12.8px)
│
└─── SPECIAL ELEMENTS
     ├─ Large stats → text-4xl (61px) ✅
     ├─ Emphasized numbers → text-xl (31.25px)
     └─ Navbar → text-2xs (12px) ✅
```

**Example Applications:**

**text-3xl (48.8px) - HERO ONLY:**
- ✅ "Evaluating India's Transformer Bushing Market..."
- ❌ Section headings (too large)
- ❌ Multiple uses per page (reserved for hero moment)

**text-2xl (39px) - SECTION HEADINGS:**
- ✅ "Client Context"
- ✅ "Key Challenges"
- ✅ "Our Methodology"
- ✅ Every H2 section heading

**text-xl (31.25px) - SUBSECTION HEADINGS:**
- ✅ Card titles when you have 2-3 cards
- ✅ Testimonial quotes
- ✅ Important callouts

**text-lg (25px) - CARD TITLES (MANY CARDS):**
- ✅ Feature card titles (4+ features)
- ✅ Challenge titles (multiple challenges)
- ✅ Method step titles

**text-sm (16px) - BODY TEXT:**
- ✅ Paragraph text
- ✅ Card descriptions
- ✅ List items
- ✅ Primary content

---

### Tree 3: Choosing Background Color

```
START: Need to add a section

↓
What ROLE does this section play?
├─── HERO / MAJOR EMPHASIS
│    ↓
│    Black background + white text ✅
│    (Hero, Testimonial, Final CTA, Resources)
│
├─── HIGHLIGHTED CONTENT
│    ↓
│    Is this data/methodology?
│    ├─ Yes → Warm background (#f5f2f1) ✅
│    │   (Challenges, Methodology)
│    └─ No → White background
│
├─── STANDARD CONTENT
│    ↓
│    White background ✅
│    (Context, Impact)
│
└─── APPLY ALTERNATION RULE
     ↓
     Check previous section:
     ├─ Previous = Black → Use White
     ├─ Previous = White → Use Warm OR Black
     └─ Previous = Warm → Use White
```

**Example Flow (YASH Case Study):**

```
Section 1: Hero → BLACK ⬛
Section 2: Context → WHITE ⬜ (alternates from black)
Section 3: Challenges → WARM 🟤 (highlighted data)
Section 4: Methodology → WARM 🟤 (highlighted data)
Section 5: Impact → WHITE ⬜ (standard content)
Section 6: Testimonial → BLACK ⬛ (emphasis)
Section 7: Final CTA → BLACK ⬛ (conversion)
Section 8: Resources → BLACK ⬛ (same block)
```

**Rules:**
1. Always start with black hero
2. Never have 3 of the same color in a row
3. Use warm for data/methodology sections
4. End with black for conversion sections

---

## 🎨 Color Usage Scenarios

### Scenario: CTA Buttons on Different Backgrounds

**Brand Red Button (#b01f24):**

✅ **GOOD USE CASES:**
```tsx
// On white background (high contrast)
<section className="bg-white">
  <Button variant="brand">Schedule Demo</Button>
</section>

// On black background (excellent contrast)
<section className="bg-black">
  <Button variant="brand">Get Started</Button>
</section>

// On warm background (good contrast)
<section className="bg-[#f5f2f1]">
  <Button variant="brand">Start Now</Button>
</section>
```

❌ **BAD USE CASES:**
```tsx
// Multiple brand buttons (violates 5% rule)
<div>
  <Button variant="brand">Action 1</Button>
  <Button variant="brand">Action 2</Button>
  <Button variant="brand">Action 3</Button>
</div>

// Brand button for non-conversion action
<Button variant="brand">Read More</Button>
```

**Primary Black Gradient Button:**

✅ **GOOD USE CASES:**
```tsx
// Secondary important actions on white
<section className="bg-white">
  <Button variant="primary">Download Report</Button>
</section>

// Multiple CTAs with hierarchy
<div className="flex gap-4">
  <Button variant="brand">Schedule Demo</Button>
  <Button variant="primary">Get Report</Button>
</div>
```

❌ **BAD USE CASES:**
```tsx
// On black background (poor contrast)
<section className="bg-black">
  <Button variant="primary">Click Here</Button>
</section>
```

**Ghost Button:**

✅ **GOOD USE CASES:**
```tsx
// On black background only
<section className="bg-black">
  <Button variant="ghost">See All Resources</Button>
</section>
```

❌ **BAD USE CASES:**
```tsx
// On white background (poor visibility)
<section className="bg-white">
  <Button variant="ghost">Click Here</Button>
</section>

// For primary conversion (too subtle)
<Button variant="ghost">Schedule Demo</Button>
```

---

### Scenario: Accent Color Usage

**Purple (#806ce0) - Premium Features:**

✅ **GOOD USE CASES:**
```tsx
// Shadow on premium feature card
<div className="shadow-lg shadow-[#806ce0]/8">
  Premium Feature
</div>

// Border accent on hover
<div className="hover:border-[#806ce0]/20">
  Feature Card
</div>
```

❌ **BAD USE CASES:**
```tsx
// As primary background (violates 3% rule)
<section className="bg-[#806ce0]">
  Content
</section>

// As text color (violates hierarchy)
<h2 className="text-[#806ce0]">
  Section Heading
</h2>
```

**Periwinkle (#c3c6f9) - Trust Indicators:**

✅ **GOOD USE CASES:**
```tsx
// Badge background
<span className="bg-[#c3c6f9]/10 text-[#5b5fc7] px-3 py-1">
  Verified
</span>

// Subtle glow effect
<div className="shadow-[0_0_20px_#c3c6f9]/10">
  Trust Element
</div>
```

---

## 📐 Spacing & Layout Scenarios

### Scenario: Vertical Section Spacing

**Decision Framework:**

```
Section Type → Padding
├─ Hero (extra emphasis) → py-24 or py-32
├─ Standard section → py-20 ✅ (default)
├─ Compact section → py-16
└─ Minimal section → py-12
```

**Example:**
```tsx
// Standard section spacing (most common)
<section className="py-20">
  {/* Content */}
</section>

// Hero with extra space
<section className="py-32">
  {/* Hero content */}
</section>
```

---

### Scenario: Grid Gap Sizing

**Decision Framework:**

```
Grid Contents → Gap
├─ Large cards (2-3 columns) → gap-8 (32px) ✅
├─ Medium cards (3-4 columns) → gap-6 (24px) ✅
├─ Small cards (4+ columns) → gap-4 (16px)
└─ Dense data grid → gap-2 (8px)
```

**Example:**
```tsx
// 2-column feature grid (large cards)
<div className="grid grid-cols-1 md:grid-cols-2 gap-8">
  {features.map(...)}
</div>

// 4-column metrics (compact)
<div className="grid grid-cols-1 md:grid-cols-4 gap-6">
  {metrics.map(...)}
</div>
```

---

## 📊 Button Selection Matrix

| Context | Background | Action Type | Variant | Size | Example |
|---------|-----------|-------------|---------|------|---------|
| Hero | Black | Primary conversion | brand | xl | "Schedule Demo" |
| Hero | Black | Secondary action | secondary | lg | "Learn More" |
| Section CTA | White | Important action | primary | lg | "Download Report" |
| Section CTA | White | Alternative action | secondary | lg | "Book Call" |
| Section CTA | Warm | Primary action | brand | lg | "Get Started" |
| Resources | Black | Navigation | ghost | md | "See All" |
| Form | White | Submit | primary | lg | "Submit" |
| Form | White | Cancel | secondary | md | "Cancel" |
| Modal | White | Close | secondary | sm | "Close" |
| Card | Various | Learn more | secondary | sm | "Learn More" |

---

## ⚠️ Common Pitfalls & Solutions

### Pitfall 1: Overusing Brand Red

**Problem:**
```tsx
❌ TOO MUCH RED (violates 5% rule)
<section>
  <Button variant="brand">Action 1</Button>
  <Button variant="brand">Action 2</Button>
  <Button variant="brand">Action 3</Button>
  <div className="text-[#b01f24]">Red text everywhere</div>
  <span className="bg-[#b01f24]">Red backgrounds</span>
</section>
```

**Solution:**
```tsx
✅ PROPER HIERARCHY
<section>
  {/* ONE brand button for primary conversion */}
  <Button variant="brand">Schedule Demo</Button>
  
  {/* Other actions use primary/secondary */}
  <Button variant="primary">Get Report</Button>
  <Button variant="secondary">Learn More</Button>
</section>
```

---

### Pitfall 2: Inconsistent Typography

**Problem:**
```tsx
❌ ARBITRARY SIZES
<h2 style={{ fontSize: '35px' }}>Heading</h2>
<p style={{ fontSize: '17px' }}>Body text</p>
<span style={{ fontSize: '21px' }}>Random size</span>
```

**Solution:**
```tsx
✅ USE SCALE
<h2 className="text-[var(--text-2xl)]">Heading</h2>
<p className="text-[var(--text-sm)]">Body text</p>
<span className="text-[var(--text-base)]">From scale</span>
```

---

### Pitfall 3: Poor Background Alternation

**Problem:**
```tsx
❌ MONOTONOUS
<section className="bg-white">Section 1</section>
<section className="bg-white">Section 2</section>
<section className="bg-white">Section 3</section>
<section className="bg-white">Section 4</section>
```

**Solution:**
```tsx
✅ ALTERNATING PATTERN
<section className="bg-black text-white">Hero</section>
<section className="bg-white">Context</section>
<section className="bg-[#f5f2f1]">Challenges</section>
<section className="bg-white">Impact</section>
<section className="bg-black text-white">Testimonial</section>
```

---

## ✅ Quality Assurance Checklist

### Before Shipping New Features

**Color Compliance:**
- [ ] Black/white/warm backgrounds = 92% of page
- [ ] Brand red buttons ≤ 5% of page elements
- [ ] Accent colors only in shadows/highlights (≤ 3%)
- [ ] All text passes WCAG AA contrast requirements

**Typography Compliance:**
- [ ] All sizes from Major Third scale (or documented custom)
- [ ] text-3xl used only for hero heading
- [ ] text-2xl used for all section headings (H2)
- [ ] Body text uses text-sm (16px)
- [ ] No arbitrary font sizes

**Spacing Compliance:**
- [ ] Max content width = 1000px
- [ ] Sections use py-20 (or documented alternative)
- [ ] Grid gaps consistent within component
- [ ] Adequate whitespace between sections

**Button Compliance:**
- [ ] Brand variant only for primary conversions
- [ ] Ghost variant only on dark backgrounds
- [ ] Size "lg" for section CTAs
- [ ] Icons used only when they add clarity

**Layout Compliance:**
- [ ] Background colors alternate
- [ ] Responsive breakpoints work (mobile/tablet/desktop)
- [ ] No horizontal scrolling
- [ ] Touch targets ≥ 44px (accessibility)

**Component Compliance:**
- [ ] Using existing molecules/organisms where possible
- [ ] New components follow atomic design principles
- [ ] Props interface clearly documented
- [ ] Example usage provided

---

## 🎓 Learning Resources

### When to Reference

**Building a new page:**
1. Read: Atomic Design Methodology (theory)
2. Reference: Component Inventory (available components)
3. Check: This document (decision scenarios)
4. Review: Design System Page (visual examples)

**Fixing design issues:**
1. Check: QA Checklist (this document)
2. Verify: Design tokens in theme.css
3. Review: Color/typography rules
4. Test: Against all breakpoints

**Creating new components:**
1. Follow: Atomic Design levels
2. Reference: Existing similar components
3. Document: Props and usage examples
4. Add: To Design System Page

---

**End of Use Cases & Decision Scenarios**  
**Next:** Apply these frameworks to your development workflow.
